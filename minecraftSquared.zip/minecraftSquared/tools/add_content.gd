extends SceneTree

## Run with --script res://tools/add_content.gd -- --help
func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var options: Dictionary = {}
	var arguments: PackedStringArray = OS.get_cmdline_user_args()
	var index: int = 0
	while index < arguments.size():
		var option: String = arguments[index]
		if option in ["--help","--write"]:
			options[option] = true
			index += 1
			continue
		if option not in ["--key","--name","--template","--tile","--atlas","--id"] or index+1 >= arguments.size():
			push_error("Unknown option or missing value: " + option)
			quit(1)
			return
		options[option] = arguments[index+1]
		index += 2
	if options.has("--help") or not options.has("--key") or not options.has("--name") or not options.has("--tile"):
		print("Add content: --key ruby_block --name \"Ruby Block\" --template block --tile 10,10 [--atlas blocks] [--id 13] [--write]")
		print("Without --write: validate and preview only. With --write: append to data/content.json with the next free stable ID; preserve a content.json.bak backup.")
		quit(0 if options.has("--help") else 1)
		return
	var tile: PackedStringArray = str(options["--tile"]).split(",")
	if tile.size() != 2 or not tile[0].is_valid_int() or not tile[1].is_valid_int():
		push_error("--tile must be two integer coordinates, for example 10,10.")
		quit(1)
		return
	var path: String = "res://data/content.json"
	var document: Dictionary = DataFile.object_from(path)
	if not DataFile.errors.is_empty() or not document.get("entries") is Array:
		quit(1)
		return
	var next_id: int = 1
	for entry in document["entries"]:
		if entry is Dictionary and (entry.get("id") is int or entry.get("id") is float):
			next_id = maxi(next_id,int(entry["id"])+1)
	if options.has("--id"):
		if not str(options["--id"]).is_valid_int():
			push_error("--id must be an integer.")
			quit(1)
			return
		next_id = int(options["--id"])
	var record: Dictionary = {"id":next_id,"key":options["--key"],"name":options["--name"],
		"extends":options.get("--template","block"),"tile":[int(tile[0]),int(tile[1])]}
	if options.has("--atlas"):
		record["atlas"] = options["--atlas"]
	document["entries"].append(record)
	var compiled: Dictionary = ContentCatalog.build(document)
	if not DataFile.errors.is_empty() or not ContentCatalog.validate_sprites(compiled):
		print("No file changed. Fix the validation errors and retry.")
		quit(1)
		return
	print(JSON.stringify(record,"  "))
	if not options.has("--write"):
		print("Valid preview. Add --write to save this record.")
		quit()
		return
	var temporary: String = path+".tmp"
	var output: FileAccess = FileAccess.open(temporary,FileAccess.WRITE)
	if output == null:
		push_error("Cannot write catalog temporary file: " + str(FileAccess.get_open_error()))
		quit(1)
		return
	output.store_string(JSON.stringify(document,"  ",false)+"\n")
	output.close()
	if DirAccess.copy_absolute(path,path+".bak") != OK:
		push_error("Cannot back up the catalog; original was not changed.")
		quit(1)
		return
	if DirAccess.rename_absolute(temporary,path) != OK:
		push_error("Cannot replace catalog; original/backup retained. Check content.json.tmp.")
		quit(1)
		return
	print("Added "+str(record["key"])+". Restart the game to load it. Backup: data/content.json.bak")
	quit()
