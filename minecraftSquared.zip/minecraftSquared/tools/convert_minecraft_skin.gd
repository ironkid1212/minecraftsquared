extends SceneTree

const Converter = preload("res://scripts/player/minecraft_skin_converter.gd")

func _initialize() -> void:
	var args: PackedStringArray = OS.get_cmdline_user_args()
	var input_path: String = ""
	var output_path: String = ""
	for index in range(args.size()):
		if args[index] == "--input" and index + 1 < args.size():
			input_path = args[index + 1]
		elif args[index] == "--output" and index + 1 < args.size():
			output_path = args[index + 1]
	if input_path.is_empty() or output_path.is_empty():
		printerr("Usage: --headless --path PROJECT --script res://tools/convert_minecraft_skin.gd -- --input INPUT.png --output OUTPUT.png")
		quit(1)
		return
	var source := Image.new()
	if source.load(input_path) != OK:
		printerr("Cannot load skin: " + input_path)
		quit(1)
		return
	var converted: Dictionary = Converter.convert(source)
	if converted.has("error"):
		printerr(converted["error"])
		quit(1)
		return
	var image: Image = converted["image"]
	var error: Error = image.save_png(output_path)
	if error != OK:
		printerr("Cannot save output PNG (error %s): %s" % [error, output_path])
		quit(1)
		return
	print("Converted skin to %sx%s: %s" % [image.get_width(), image.get_height(), output_path])
	quit()
