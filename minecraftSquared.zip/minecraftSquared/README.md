# Minecraft Squared

A 2D block sandbox for **Godot 4.7.2**, with procedural biomes/caves/ores,
per-block lighting, crafting, furnaces, tools, health, beds, local chat/commands, a saved day/night sky, saved worlds and custom skins.

Extract this project into a new folder. In Godot's Project Manager,
import its `project.godot`, allow assets to import, and press F5. Godot recreates
the excluded `.godot` cache automatically.

User files now live in `%APPDATA%\.minecraftSquared` on Windows, with
`saves/`, `skins/` and preferences outside the project. Existing Godot saves and
profiles are copied automatically without deleting originals or overwriting
newer files. Folder buttons are available from the menus. See
[local files and latest changes](docs/BAT_BIOMES_LOCAL_FILES.md).

## Latest update

Added native gameplay sounds and pooled particles for mining, movement, combat,
fluids, interactions and End features. Explosions now use staggered, randomized
puffs at sizes adapted from Minecraft. See
[Particles and sound](docs/PARTICLES_AND_SOUND.md) for coverage, editor settings,
performance limits and asset sources.

Closer outer islands now contain End cities and ships, persistent shulker
guards, enchanted treasure, elytra and portable shulker boxes. City bridges use
stepped purpur sections and room outlines are closed for a clean 2D cutaway.
End rods use corrected side textures and mounting directions. See
[End cities, shulkers and flight](docs/END_CITIES_SHULKERS_FLIGHT.md) for controls,
configuration, save behavior and research.

End crystals and their bases now use flat side-view sprite layers, with a gentle
pixel-aligned hover and no perspective faces.

Added saved End gateways, outer floating islands and their four biomes, chorus
plants/fruit and craftable Purpur Blocks. Pillars are capped at seven blocks wide
with solid obsidian tops. See [Outer End and gateways](docs/OUTER_END_GATEWAYS.md)
for travel, existing-save support, tuning, research and 2D adaptations.

The End now has a saved dragon fight: healing crystals, a side-view animated
dragon, ranged/landing/breath attacks, a boss bar, XP and the first dragon egg.
Defeat it to unlock the return fountain, then use four crystals to resummon it.
Fixed floating pillar foundations, oversized cages and off-center crystals.
Native crystal textures now show flat glass frames and a pink rune core.
See [the End fight and 2D adaptations](docs/ENDER_DRAGON_FIGHT.md).
Existing worlds are supported; outer islands and gateways are now included.

The previous update added supported half-block Wither skulls, Ice Spikes/Snowy
Slopes, polar bears/cubs, buildable snow golems, snowballs, snow/ice building
blocks and End stone brick slabs/stairs. See
[End island and cold-weather content](docs/END_ISLAND_COLD_CONTENT.md).


Doors now show their thin edge when closed and full panel when open, swinging
from a fixed left or right hinge. Fence gates use a side-view center post and
swing away from the player. Status effects, absorption and burning clear on
death, including fatal effect-inflicting attacks. These fixes work in existing
worlds. See [door and gate behavior](docs/FENCES_DOORS_MOBS.md).

Fixed the Husk's transparent far limbs. All 13 foreground fences now contain
players and mobs using connected 1.5-block collision shapes, with separate
inventory icons. Added 12 fence gates and 12 two-block wooden doors with native
textures, recipes, saved state and working open/close interactions. Mangrove
Swamp and Windswept Forest join the biomes, with Bogged and Wither Skeletons.
See [fences, doors and new mobs](docs/FENCES_DOORS_MOBS.md).


Added 54 missing slab/stair items and their orientations, including stone brick,
mossy stone brick, deepslate, decorative stones, and the remaining plank families.
Sunflowers now include the connecting upper stem. Larger lush chambers have
shallow clay-lined pools. Grove and Mushroom Fields join the biome list, with
husks and mooshrooms. Chunk streaming and lighting avoid synchronous generation
of unloaded terrain. See [variants, caves and travel](docs/VARIANTS_LUSH_TRAVEL.md).
Create a new world for the new biomes and cave layout; existing saves retain
original terrain. Building variants and performance fixes also work in old worlds.

Hold **Alt** to place or mine background walls; rebind **Background Layer (hold)**
in Options > Key Binds. New stronghold portal rooms use two foreground end
frames and three interactable background frames above lava. Insert five Eyes
to activate the foreground portal overlay. Both layers save independently.
Existing worlds keep their original room generation. See
[background building and End frames](docs/BACKGROUND_END_PORTALS.md).

Added a working grindstone and Minecraft-style inventory effect panels with
names, levels and live countdowns. Narrow layouts show compact icon tooltips.
See [grindstone and inventory effects](docs/GRINDSTONE_INVENTORY_EFFECTS.md).

Fixed white/missing effect icons, enabled Creative effect icons, added generated
enchanted-book variants, moved eating hands forward, and made descending slabs
and stairs use gravity. See [details and tuning](docs/EFFECTS_BOOKS_MOVEMENT.md).

Rebuilt bats, Minecraft-style nameplates, an audit of all Creative tab
assignments, Sunflower Plains, Old Growth Pine Taiga, new plants/soils,
blackstone building variants and soul lighting. Existing worlds retain their
saved generation revision; create a new world to explore the new biomes.
Your supplied settings resources and texture atlas pixels are preserved.

Warped forests, Endermen and throwable ender pearls now join the Nether.
Fortresses add blaze spawners, loot chests and Nether wart gardens. Brewing
stands use the native Minecraft GUI, blaze powder fuel and timed three-bottle
batches. Magma Cubes provide magma cream for the Survival brewing progression.
See [Nether progression controls, recipes and references](docs/NETHER_PROGRESSION.md).

The first Nether milestone adds working portals, saved dimension travel, three
Nether biomes, quartz/gold veins, glowstone, soul sand, basalt and blackstone.
Ignite the side of an obsidian frame with flint and steel. Active frames use
obsidian-looking platforms so their sides are passable in 2D; the bottom supports
the player. Portal animation is aligned to the terrain and visible in both worlds.
See [Nether controls and implementation notes](docs/NETHER_PORTALS.md).

Creative hovering and tooltips now include owned hotbar/equipment slots and saved
stack metadata. Catalog returns discard carried items, with matching-item count
controls, middle-click cloning and creative Shift-click disposal. Bookshelves
now supply power anywhere within four blocks, through walls. Enchanted items
have a cached, alpha-masked 2D glint, with an Inspector strength slider in
`data/settings/interface.tres`. Resting bows follow the wrist. See
[inventory polish notes](docs/CREATIVE_GLINT_POLISH.md).

Enchanting tables and anvils now provide the next equipment progression step.
Six bookshelves supply maximum power in the 2D layout. Enchanting spends lapis
and levels; anvils repair, rename and combine supported enchantments. The seven
initial enchantments have gameplay effects and saved item tags. GUI assets come
from your texture pack, with layouts checked against Java reference screenshots
and text measured at its final GUI scale. See
[enchanting and anvil notes](docs/ENCHANTING_AND_ANVILS.md) for recipes, placement
and editable settings.

Furnaces now have data-driven fuels, cooking times, recipe XP, Shift-click
transfers and progress tooltips. Added smooth stone, blocks of coal and metal
nuggets, including equipment recycling. New worlds start without tools; the
remaining small supply of torches, wool and bread is unchanged. Existing saved
inventories are preserved. See [smelting notes](docs/SMELTING_PROGRESSION.md)
for controls, timings and the editable recipe format.

The creative inventory uses Minecraft's actual tab, panel and scrollbar assets,
with curated contents, search, saved hotbars and equipment slots. Fences are
connected pass-through platforms, held Use works across food/shields/placement,
and experience commands support the usual add/set/query forms.
See [update notes](docs/CREATIVE_USE_FENCES.md) for controls and data editing.
Existing saves, content IDs, skins and .tres settings are preserved.

Enter `/gamemode creative`, then press **E** to open the catalog.
Return with `/gamemode survival`. Ordinary survival food still requires hunger.

## Controls

| Action | Default |
| --- | --- |
| Move / jump | A/D or arrows; hold Space to keep jumping |
| Mine / place or use | Left / right mouse |
| Inventory / drop | E / Q |
| Hotbar | 1–9 or wheel |
| Pause / settings | Escape |
| Chat / command | T / slash; Enter submits, Escape cancels |
| Debug information | F3 |
| Spectator, with fullbright | F3+N |

Options → Controls rebinds inputs. The title menu creates, reopens and deletes
worlds. Profile changes username and imports/selects/converts skins. Starter
supplies are finite, and tools must be crafted. A crafting table provides 3×3 recipes; right-click a
furnace to smelt with fuel.

## Platforms and walls

Grass, flowers, bushes and leaves are fully passable. Block-shaped cactus,
workstations and logs have one-way tops: pass through sideways/upward and land
on exposed tops. Only the uppermost block in a stack has an active top.
Beds have one-way tops at mattress height.

Transparent foreground sprites keep the wall behind them. Fully opaque tiles
cull hidden walls. Visibility comes from sprite alpha rather than collision,
so placing a cactus underground no longer opens sky-colored gaps.

## Survival

Ten hearts show health. Falls up to three blocks are safe; longer falls cause
landing damage. Death drops carried items, preserving tool wear. Click Respawn
to return at full health and recover your drops. Starter supplies are not reissued.
Spectator mode is immune to damage.

Craft a red bed at a crafting table: three white wool above three planks.
Right-click the bed to set your respawn point. A missing or obstructed bed sends
you back to a safe world-spawn location. Beds do not skip time yet.
New worlds start with three wool; older saves receive those wool once on upgrade.
Food and saturation now control regeneration; hold right-click with food to eat.
Tune these rules in `data/settings/survival.tres`; see [survival](docs/survival.md).

All five hoe materials use the corrected held direction for either facing.

## Project map

| Location | Purpose |
| --- | --- |
| `data/content.json` | Single block/item/tool catalog, templates and updates |
| `data/chat.json`, `data/commands.json` | Chat layout/limits and command registry |
| `data/beds.json` | Bed parts, orientations and respawn offsets |
| `data/recipes.json`, `data/smelting.json` | Crafting, smelting and fuels |
| `data/atlases.json`, `data/held_item_profiles.json` | Art grids and hand transforms |
| `data/biomes.json`, `data/overworld_generation.json` | Biome, geology and ore rules |
| `data/settings/` | Movement, generation, lighting, UI and system controls |
| `data/starting_inventory.json`, `data/keybindings.json` | Starter supplies and input defaults |
| `data/options_menu.json`, `data/splashes.txt` | Options and title splashes |
| `assets/`, `scenes/`, `scripts/` | Runtime art, scenes and systems |
| `tools/` | Content helper and offline skin converter |

Start with [settings](docs/project_settings.md), [content](docs/content_catalog.md),
[generation tuning](docs/natural_generation.md), or [skins](docs/2d_skins.md).
Restart after editing JSON/resources. Generation changes target new worlds.
Include `*.json` and `*.txt` in non-resource filters when configuring exports.

## Cleanup

Removed unused data packs, temporary scene saves, retired cave presets, unused
Minecraft metadata/title art, stale installer artifacts and superseded notes.
Atlas tiles compile from content instead of 1,731 serialized scene entries.
Import sidecars, script UIDs, active settings, art and authoring tools remain.

Legacy generation parameters remain stored for old saves, hidden from the
Inspector. Retired stack-text/crisp-icon menu preferences no longer override UI
defaults. See [cleanup details](docs/cleanup.md).

## Menu, bed and heart fixes

Widget edges are drawn as separate pixel-aligned slices, keeping the supplied
white hover outline continuous at GUI scales 1–4. Focus no longer paints a
second textured button over the active state. The title, pause, options, keybind
and death screens share the widget drawing code. See
[Godot's StyleBox documentation](https://docs.godotengine.org/en/stable/classes/class_stylebox.html).

Beds now use the actual supplied red bed side textures for both orientations.
Health feedback keeps current hearts red and flashes the lost-health portion
behind them, with separate blinking containers and a low-health jitter.
See [survival customization](docs/survival.md). Existing worlds remain compatible.

## Chat, commands and farmland

Press T to chat or / to start a command. Enter submits; Escape closes. Up/Down
browse typed history and Tab/Shift+Tab cycle completions. Page Up/Down or the
wheel scroll messages. Open Chat / Open Command can be rebound in Controls.

Use `/help` for the full list: give, clear, gamemode, tp, setblock, spawnpoint,
seed, heal, kill, save and say. Commands use the existing inventory, health,
mode, edit/update and save systems. Chat is local to this single-player game,
uses your profile name, and keeps text/input above the hearts and hotbar.
See [chat and command reference](docs/chat_commands.md) for syntax and tuning.

All seven supplied farmland stages are in the block atlas at tiles (5..11,52).
The existing farmland record selects stage 01 at (5,52); other stages are reserved
for later hydration/growth work. Existing worlds and tilled blocks update
automatically; no new world is required.

## Chat styling and day/night

Chat uses compact translucent message rows, command-color feedback and grey
completion text. Suggestions open in a vertical list: Tab/Shift+Tab accepts and
cycles, arrows select, wheel scrolls the list under the pointer, and clicking
accepts a row. A scrollbar tracks longer lists. Input and suggestions stay clear
of hearts and the hotbar at all tested UI sizes.

The world now has a saved day/night clock, smooth sky transitions, a 2D sun/moon
arc, eight moon phases and a stable drifting star field that fades at dawn/dusk.
Sun, moon and cloud art comes from the supplied Minecraft texture pack.
Torches retain their light and Spectator retains fullbright terrain.

Try `/time set night`, `/time set day`, `/time query day` or
`/gamerule doDaylightCycle false`. Tune `data/settings/day_night.tres` for clock
length, sky colors, moon/sun size, night lighting, stars and clouds. The default
cycle is twenty minutes. Old worlds start in the morning; existing saves remain
compatible. Read [day/night settings](docs/day_night.md) for details.

Mining timing, tool stats and durability tooltip options: [guide](docs/mining_and_tooltips.md).

Water, lava, buckets, generation and performance settings: [fluid guide](docs/fluids.md).

Sneaking, sprint/swim sprint, waterlogging and reference oak/sand shores: [guide](docs/movement_and_shores.md).


## Farming, weather and biome tinting update

See [FARMING_WEATHER.md](docs/FARMING_WEATHER.md) for crop controls, weather commands,
data/settings locations, movement values, save compatibility and research references.


## Movement, slabs/stairs and new biomes

See [STEPS_BUILDING_BIOMES.md](docs/STEPS_BUILDING_BIOMES.md) for building controls,
recipes, movement settings, the three added biomes and save compatibility.

## Equipment, storage and typed item data

See [EQUIPMENT_STORAGE_NBT.md](docs/EQUIPMENT_STORAGE_NBT.md) for offhand controls,
armor, chests/barrels, directional throwing, the three further biomes, typed NBT,
commands, tuning, compatibility limits and research references.

Chest front textures, offhand poses/alignment and empty equipment icons:
[rendering fixes](docs/CHEST_OFFHAND_POLISH.md).

## Mobs and basic combat

Adult cows, sheep and zombies now spawn, move, take damage and persist in saved
worlds. Attack with the main hand, shear sheep, milk cows, and watch for zombies
after dark. Read [MOBS_COMBAT.md](docs/MOBS_COMBAT.md) for controls, spawn and AI
settings, combat rules, research, save compatibility and the first update's limits.

Current mob update: [MOB_POLISH_2D.md](docs/MOB_POLISH_2D.md) covers pigs, chickens,
creepers, shorter aimed combat reach, player pass-through, corrected zombie limbs,
chicken feet/cold pig coat, explosions and the saved mobGriefing rule.

Mob AI, skeletons/spiders, water currents, independent throws, snow commands and copper equipment: see docs/MOB_AI_CURRENTS_COPPER.md.

Head attachments, skeleton bow charging, held lighting, Mods settings and mining obstruction: see docs/RENDER_LIGHT_TARGET_FIXES.md.

Modern Nether terrain, five Nether biomes, modular fortresses and corrected
Magma Cube spawning/movement: see [Nether progression](docs/NETHER_PROGRESSION.md).
Nether polish adds connected fortress routes, stair backing walls, unobstructed
background basalt pillars, blended fog and corrected dimensional coordinates.
New worlds use revision 3; revision-2 worlds keep their density shapes and receive
the fortress, command and background repairs. See the same guide for tuning.

Eyes of Ender, connected strongholds, twelve-eye portal activation, Lush Caves,
Silverfish, Endermites and Bats: see [progression guide](docs/NETHER_PROGRESSION.md).
Use a new world for the new underground generation. The End dimension and dragon
are the following milestone; this update saves the activated portal state.

Completion update: breeding and baby animals, usable name tags, melon/pumpkin
farming and pumpkin pie, bone meal, renewable cave vines, clay bricks, Ghasts,
Survival healing/regeneration ingredients, extended/upgraded potions and timed
milk drinking. Mob rigs, death poses, missing flowers and Lush Cave plants were
also repaired. These additions work in existing worlds; a new world is only
needed for the previously added stronghold/Lush Cave generation.
See the completion section in [the progression guide](docs/NETHER_PROGRESSION.md).
