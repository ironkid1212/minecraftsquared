class_name DroppedItems
extends Node2D

var settings: DropSettings = DropSettings.new()
var chunks: ChunkWorld
var player: CharacterBody2D
var inventory: BlockInventory
var lighting: WorldLighting
var source: TileSetAtlasSource
var drops: Array[Dictionary] = []
var _terrain_revision: int=0


func setup(world: ChunkWorld, character: CharacterBody2D, items: BlockInventory,
		light: WorldLighting, atlas: TileSetAtlasSource, config: DropSettings = null) -> void:
	settings = config if config != null else DropSettings.new()
	chunks = world
	player = character
	inventory = items
	lighting = light
	source = atlas
	top_level = true
	global_position = Vector2.ZERO
	z_index = 5
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	chunks.cell_changed.connect(_terrain_changed)

func _terrain_changed(_cell: Vector2i,_old: int,_new: int) -> void:
	_terrain_revision+=1


func spawn_item(id: int, count: int, at: Vector2, throw_velocity := Vector2.ZERO, remaining_durability: int = -1, metadata: Dictionary = {}, pickup_seconds: float = -1) -> void:
	if count <= 0 or not BlockDatabase.BLOCKS.has(id):
		return
	var uses: int = ToolDatabase.initial_durability(id, remaining_durability)
	var limit: int = inventory.stack_limit(id)
	for drop in drops:
		if throw_velocity.is_zero_approx() and drop["resting"] and limit > 1 and drop["id"] == id and NBT.same(drop.get("tags",{}),metadata) and int(drop["durability"])==uses and Vector2(drop["position"]).distance_to(at) < settings.merge_radius:
			var moved: int = mini(count, limit - int(drop["count"]))
			drop["count"] += moved
			if pickup_seconds>=0:drop["pickup_delay"]=pickup_seconds
			count -= moved
			if moved > 0:
				drop["age"] = 0.0
			if count == 0:
				return
	while count > 0:
		var amount: int = mini(count, limit)
		drops.append({"id": id, "count": amount, "durability": uses, "position": at,
			"velocity": throw_velocity if throw_velocity != Vector2.ZERO else Vector2(randf_range(-30, 30), -80),
			"age": 0.0, "resting": false,"tags":metadata.duplicate(true),"pickup_delay":pickup_seconds if pickup_seconds>=0 else settings.pickup_delay})
		count -= amount
	queue_redraw()


func _ray(from: Vector2, to: Vector2, mask: int = 1) -> Dictionary:
	var query := PhysicsRayQueryParameters2D.create(from, to, mask)
	query.exclude = [player.get_rid()]
	return get_world_2d().direct_space_state.intersect_ray(query)


func _physics_process(delta: float) -> void:
	if chunks == null or drops.is_empty():
		return
	for index in range(drops.size() - 1, -1, -1):
		var drop: Dictionary = drops[index]
		var p: Vector2 = drop["position"]
		var cell: Vector2i = chunks.ground.local_to_map(chunks.ground.to_local(p))
		# Preserve drops in unloaded regions rather than falling through absent physics.
		if not chunks.is_cell_loaded(cell):
			continue
		if BlockDatabase.has_tag(chunks.get_block(cell),"lava"):
			drops.remove_at(index)
			continue
		var in_water: bool=player.fluids!=null and player.fluids.submerged(p)=="water"
		if in_water:
			drop["resting"] = false
			var buoyant: Vector2 = drop["velocity"]
			buoyant.y = maxf(-30,buoyant.y-settings.gravity*delta-60*delta)
			drop["velocity"] = buoyant
		drop["age"] += delta
		if drop["age"] > settings.lifetime:
			drops.remove_at(index)
			continue
		var target: Vector2 = player.global_position
		var distance: float = p.distance_to(target)
		if not player.spectator and not player.survival_dead and drop["age"] >= float(drop.get("pickup_delay",settings.pickup_delay)) and distance < settings.magnet_radius and inventory.can_accept(drop["id"],drop.get("tags",{}),drop["durability"]) and _ray(p, target).is_empty():
			if distance < settings.pickup_radius:
				var remaining: int = inventory.add_item(drop["id"], drop["count"], 0, BlockInventory.MAIN_COUNT, drop["durability"],drop.get("tags",{}))
				if remaining<drop["count"] and player.get_parent().effects!=null:player.get_parent().effects.sound("entity.item.pickup",p,"player",.3,1.5,1,.12)
				if remaining == 0:
					drops.remove_at(index)
					continue
				drop["count"] = remaining
			drop["position"] = p.move_toward(target, settings.magnet_speed * delta)
			drop["velocity"] = Vector2.ZERO
			drop["resting"] = false
			continue
		var velocity: Vector2 = drop["velocity"]
		# Resting items still check for support after the player mines their floor.
		if drop["resting"]:
			if int(drop.get("support_revision",-1))==_terrain_revision:continue
			drop["support_revision"]=_terrain_revision
			if not _ray(p, p + Vector2(0, 5), 3).is_empty():
				continue
			drop["resting"] = false
		velocity.y = minf(velocity.y + settings.gravity * delta, settings.terminal_speed)
		var current: Vector2=player.fluids.current_velocity(Rect2(p-Vector2(2,2),Vector2(4,4)),drop.get("current_velocity",Vector2.ZERO),delta) if in_water else Vector2.ZERO
		drop["current_velocity"]=current
		if in_water:velocity.x*=pow(.98,delta*20)
		velocity+=current
		var next_x: Vector2 = p + Vector2(velocity.x * delta, 0)
		var wall: Dictionary = _ray(p, next_x + Vector2(signf(velocity.x) * 3.0, 0))
		if wall.is_empty():
			p.x = next_x.x
		else:
			velocity.x = 0
		var next_y: Vector2 = p + Vector2(0, velocity.y * delta)
		var hit: Dictionary = _ray(p, next_y + Vector2(0, signf(velocity.y) * 3.0), 3 if velocity.y > 0 else 1)
		if hit.is_empty():
			p.y = next_y.y
		else:
			p = Vector2(hit["position"]) + Vector2(hit["normal"]) * 3.2
			if velocity.y > 0:
				velocity.x *= 0.5
				if absf(velocity.y) < 45:
					velocity = Vector2.ZERO
					drop["resting"] = true
				else:
					velocity.y *= -settings.bounce
			else:
				velocity.y = 0
		drop["position"] = p
		drop["velocity"] = velocity-current if in_water and not drop["resting"] else velocity
	queue_redraw()


func _draw() -> void:
	var visible_bounds: Rect2 = get_global_transform_with_canvas().affine_inverse() * get_viewport_rect()
	visible_bounds = visible_bounds.grow(settings.icon_size + 4)
	if source == null:
		return
	for drop in drops:
		var p: Vector2 = drop["position"]
		if not visible_bounds.has_point(p): continue
		var id: int = drop["id"]
		var cell: Vector2i = chunks.ground.local_to_map(chunks.ground.to_local(p))
		if drop["resting"]:
			draw_rect(Rect2(p + Vector2(-3, 3), Vector2(6, 1)), Color(0, 0, 0, 0.3))
			p.y += sin(float(drop["age"]) * 4.0) * 1.2 - 2.0
		ItemDrawing.draw_icon(self, source, id,
			Rect2((p - Vector2.ONE * settings.icon_size / 2.0).floor(), Vector2.ONE * settings.icon_size), lighting.render_tint(cell),drop.get("tags",{}))
