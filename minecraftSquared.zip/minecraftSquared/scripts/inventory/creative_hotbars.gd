class_name CreativeHotbars
extends RefCounted
var options: Node
var saved: Dictionary={}
func setup(settings: Node) -> void:
	options=settings
	var stored: Variant=options._saved.get_value("creative","hotbars",{})
	if not stored is Dictionary:return
	for key in stored:
		if not str(key).is_valid_int() or int(key)<0 or int(key)>8 or not stored[key] is Array or stored[key].size()!=9:continue
		var row: Array=[];var valid: bool=true
		for entry in stored[key]:
			if not entry is Dictionary or not entry.get("key") is String or not ContentCatalog._number(entry.get("count"),0,64,true) or not ItemTags.valid(entry.get("tags",{})):valid=false;break
			var id: int=BlockDatabase.id_for(entry.key)
			if id==0 and (entry.key!="air" or entry.count!=0) or entry.count>int(BlockDatabase.BLOCKS.get(id,{}).get("max_stack",64)):valid=false;break
			row.append({"id":id,"count":int(entry.count),"durability":ToolDatabase.initial_durability(id,int(entry.get("durability",-1))),"tags":entry.get("tags",{}).duplicate(true)})
		if valid:saved[int(key)]=row
func save_bar(index: int,items: BlockInventory) -> void:
	var row: Array=[]
	for i in range(9):row.append(items.stack(i))
	saved[index]=row
	var records: Dictionary={}
	for key in saved:
		var data: Array=[]
		for entry in saved[key]:data.append({"key":"air" if entry.id==0 else BlockDatabase.BLOCKS[entry.id].key,"count":entry.count,"durability":entry.durability,"tags":entry.tags.duplicate(true)})
		records[str(key)]=data
	options._saved.set_value("creative","hotbars",records)
	if options.save_options()!=OK:push_warning("Hotbar saved for this session; preferences could not be written.")
func load_bar(index: int,items: BlockInventory) -> bool:
	if not saved.has(index):return false
	for i in range(9):items.set_stack(i,saved[index][i])
	items.changed.emit();return true
func stack(index: int) -> Dictionary:
	return saved[index/9][index%9] if saved.has(index/9) else {"id":0,"count":0,"durability":0,"tags":{}}
