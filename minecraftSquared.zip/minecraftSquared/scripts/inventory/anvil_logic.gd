class_name AnvilLogic
extends RefCounted

static func preview(left: Dictionary,right: Dictionary,new_name: String) -> Dictionary:
	if int(left.get("count",0))<=0:return {}
	var id: int=int(left.id);var maximum: int=ToolDatabase.max_durability(id)
	var result: Dictionary=left.duplicate(true);var metadata: Dictionary=result.tags
	var old_penalty: int=clampi(int(NBT.value(metadata,"RepairCost",0)),0,1000000)
	var right_penalty: int=clampi(int(NBT.value(right.get("tags",{}),"RepairCost",0)),0,1000000)
	var cost: int=old_penalty+right_penalty;var used: int=0;var changed: bool=false;var worked: bool=false
	if int(right.get("count",0))>0:
		if int(left.count)!=1:return {"error":"Repair one item at a time."}
		var source: int=int(right.id);var key: String=BlockDatabase.BLOCKS[id].key
		var material: String=key.get_slice("_",0)
		var ingredients: Array=EnchantmentDatabase.DATA.repair_ingredients.get(key,EnchantmentDatabase.DATA.repair_ingredients.get(material,[]))
		if BlockDatabase.BLOCKS[source].key in ingredients and maximum>0:
			var repair: int=maxi(1,floori(maximum*float(EnchantmentDatabase.DATA.anvil.material_repair_fraction)))
			used=mini(int(right.count),ceili((maximum-int(left.durability))/float(repair)))
			if used<=0:return {"error":"This item is already fully repaired."}
			result.durability=mini(maximum,int(left.durability)+repair*used);cost+=used;changed=true;worked=true
		elif source==id or BlockDatabase.BLOCKS[source].key=="enchanted_book":
			if source==id and maximum==0 and key!="enchanted_book":return {"error":"These items cannot be combined."}
			if source==id and maximum>0:
				var repaired: int=mini(maximum,int(left.durability)+int(right.durability)+floori(maximum*float(EnchantmentDatabase.DATA.anvil.combine_bonus)))
				if repaired>int(left.durability):result.durability=repaired;cost+=2;changed=true;worked=true
			var values: Dictionary=EnchantmentDatabase.read(metadata,key=="enchanted_book")
			var incoming: Dictionary=EnchantmentDatabase.read(right.tags,BlockDatabase.BLOCKS[source].key=="enchanted_book")
			for enchant in incoming:
				if not EnchantmentDatabase.accepts(enchant,id):continue
				if not EnchantmentDatabase.compatible(values,enchant):cost+=1;continue
				var lv: int=int(incoming[enchant]);var current: int=int(values.get(enchant,0))
				lv=mini(int(EnchantmentDatabase.definitions()[enchant].maximum),lv+1 if lv==current else maxi(lv,current))
				if lv<=current:continue
				values[enchant]=lv
				var multiplier: int=int(EnchantmentDatabase.definitions()[enchant].anvil_cost)
				if BlockDatabase.BLOCKS[source].key=="enchanted_book":multiplier=maxi(1,multiplier/2)
				cost+=multiplier*lv;changed=true;worked=true
			metadata=EnchantmentDatabase.write(metadata,values,key=="enchanted_book");used=1
		else:return {"error":"Use matching equipment, repair material or an enchanted book."}
		if not worked:return {"error":"No compatible repair or enchantment."}
	var name_value: String=new_name.strip_edges().left(50)
	var display: Dictionary=NBT.value(metadata,"display",{}).duplicate(true)
	var old_name: String=str(NBT.value(display,"Name",""))
	if name_value!=ItemTags.name(id,left.tags):
		if name_value.is_empty():
			if not old_name.is_empty():display.erase("Name");cost+=1;changed=true
		else:display["Name"]=NBT.node(NBT.STRING,name_value);cost+=1;changed=true
		if display.is_empty():metadata.erase("display")
		else:metadata["display"]=NBT.node(NBT.COMPOUND,display)
	if not changed:return {}
	if not worked:cost=mini(cost,int(EnchantmentDatabase.DATA.anvil.maximum_cost))
	else:metadata["RepairCost"]=NBT.node(NBT.INT,mini(1000000,2*maxi(old_penalty,right_penalty)+1))
	if metadata.has("Damage") and maximum>0:metadata["Damage"]=NBT.node(NBT.INT,maximum-int(result.durability))
	result.tags=metadata
	return {"stack":result,"cost":maxi(1,cost),"used":used,"too_expensive":cost>int(EnchantmentDatabase.DATA.anvil.maximum_cost)}
