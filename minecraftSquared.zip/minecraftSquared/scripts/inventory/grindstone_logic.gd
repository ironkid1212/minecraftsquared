class_name GrindstoneLogic
extends RefCounted

static func accepts(id: int) -> bool:
	return id!=0 and (ToolDatabase.max_durability(id)>0 or BlockDatabase.BLOCKS[id].key=="enchanted_book")
static func curse(key: String) -> bool:
	return key in ["binding_curse","vanishing_curse"] or EnchantmentDatabase.definitions().get(key,{}).get("curse",false)
static func values(stack: Dictionary) -> Dictionary:
	return EnchantmentDatabase.read(stack.get("tags",{}),BlockDatabase.BLOCKS[int(stack.id)].key=="enchanted_book")
static func preview(left: Dictionary,right: Dictionary) -> Dictionary:
	var inputs: Array[Dictionary]=[];var used: Array[int]=[0,0]
	for i in range(2):
		var stack: Dictionary=left if i==0 else right
		if int(stack.get("count",0))<=0:continue
		if int(stack.count)!=1 or not accepts(int(stack.id)):return {}
		inputs.append(stack);used[i]=1
	if inputs.is_empty():return {}
	var result: Dictionary=inputs[0].duplicate(true);var id: int=int(result.id)
	var maximum: int=ToolDatabase.max_durability(id);var count: int=1
	if inputs.size()==2:
		if int(inputs[1].id)!=id:return {}
		if maximum>0:result.durability=mini(maximum,int(result.durability)+int(inputs[1].durability)+floori(maximum*.05))
		else:
			if not NBT.same(result.tags,inputs[1].tags):return {}
			count=2
	elif values(result).is_empty():return {}
	var curses: Dictionary={};var xp: int=0
	for stack in inputs:
		var enchantments: Dictionary=values(stack)
		for key in enchantments:
			var lv: int=int(enchantments[key]);var rule: Dictionary=EnchantmentDatabase.definitions().get(key,{})
			if curse(key):curses[key]=maxi(int(curses.get(key,0)),lv)
			elif not rule.is_empty():xp+=int(rule.min_cost[0])+int(rule.min_cost[1])*(clampi(lv,1,int(rule.maximum))-1)
	var tags: Dictionary=result.tags.duplicate(true)
	tags.erase("Enchantments");tags.erase("StoredEnchantments");tags.erase("RepairCost")
	if maximum>0:
		if int(result.durability)<maximum:tags["Damage"]=NBT.node(NBT.INT,maximum-int(result.durability))
		else:tags.erase("Damage")
	if BlockDatabase.BLOCKS[id].key=="enchanted_book" and curses.is_empty():
		result.id=BlockDatabase.id_for("book");result.durability=0
		tags={"display":tags.display} if tags.has("display") else {}
	else:
		tags=EnchantmentDatabase.write(tags,curses,BlockDatabase.BLOCKS[id].key=="enchanted_book")
		if not curses.is_empty():tags["RepairCost"]=NBT.node(NBT.INT,int(pow(2,curses.size()))-1)
	result.count=count;result.tags=tags
	var minimum: int=ceili(xp/2.0)
	return {"stack":result,"used":used,"xp_min":minimum,"xp_max":maxi(0,minimum*2-1)}
