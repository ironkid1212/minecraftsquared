class_name StackTransfer
extends RefCounted
static func click(target: Object,index: int,owner: Object,right: bool) -> void:
	if owner.held_count>0 and target.has_method("can_insert") and not target.can_insert(index,owner.held_id):return
	if owner.held_count==0:
		if target.counts[index]<=0:return
		owner.held_id=target.ids[index];owner.held_durability=target.durability[index];owner.held_tags=target.tags[index].duplicate(true)
		owner.held_count=ceili(target.counts[index]/2.0) if right else target.counts[index]
		target.counts[index]-=owner.held_count
		if target.counts[index]==0:target.ids[index]=0;target.durability[index]=0;target.tags[index]={}
	elif target.counts[index]==0 or (target.ids[index]==owner.held_id and target.durability[index]==owner.held_durability and NBT.same(target.tags[index],owner.held_tags) and owner.stack_limit(owner.held_id)>1):
		var moved: int=mini(1 if right else owner.held_count,slot_limit(target,index,owner.held_id,owner)-target.counts[index])
		if moved<=0:return
		if target.counts[index]==0:target.ids[index]=owner.held_id;target.durability[index]=owner.held_durability;target.tags[index]=owner.held_tags.duplicate(true)
		target.counts[index]+=moved;owner.held_count-=moved
	elif not right and owner.held_count<=slot_limit(target,index,owner.held_id,owner):
		var old: Dictionary={"id":target.ids[index],"count":target.counts[index],"durability":target.durability[index],"tags":target.tags[index]}
		target.ids[index]=owner.held_id;target.counts[index]=owner.held_count;target.durability[index]=owner.held_durability;target.tags[index]=owner.held_tags.duplicate(true)
		owner.held_id=old["id"];owner.held_count=old["count"];owner.held_durability=old["durability"];owner.held_tags=old["tags"].duplicate(true)
	if owner.held_count==0:owner.held_id=0;owner.held_durability=0;owner.held_tags={}
	target._refresh()
	if target!=owner:owner.changed.emit()

static func slot_limit(target: Object,index: int,id: int,owner: Object) -> int:
	return mini(owner.stack_limit(id),target.slot_limit(index,id)) if target.has_method("slot_limit") else owner.stack_limit(id)
