class_name BrewingGrid
extends CraftingGrid
var state: BrewingState
var system: BrewingSystem
func _init(items: BlockInventory,source: BrewingState,host: BrewingSystem) -> void:
	super(items);state=source;system=host;sync()
func sync() -> void:ids=state.ids;counts=state.counts;durability=state.durability;tags=state.tags;recipe={}
func _refresh() -> void:
	for i in range(5):
		if counts[i]<=0:counts[i]=0;ids[i]=0;durability[i]=0;tags[i]={}
	state.ids=ids;state.counts=counts;state.durability=durability;state.tags=tags
	if state.remaining>0 and (state.ingredient!=state.ids[3] or not system.can_brew(state)):state.remaining=0;state.ingredient=0
	changed.emit();inventory.changed.emit()
func can_insert(index: int,id: int) -> bool:
	return not BrewingData.key_for(id).is_empty() if index<3 else BrewingData.ingredient(id) if index==3 else id==BlockDatabase.id_for("blaze_powder")
func slot_limit(index: int,id: int) -> int:return 1 if index<3 else inventory.stack_limit(id)
func click_slot(index: int,right: bool=false) -> void:
	if index<0 or index>=5:return
	sync();StackTransfer.click(self,index,inventory,right)
func deposit(index: int) -> void:
	if index<0 or index>=36 or inventory.counts[index]<=0:return
	sync();var id: int=inventory.ids[index];var targets: Array=[]
	if not BrewingData.key_for(id).is_empty():targets=[0,1,2]
	elif id==BlockDatabase.id_for("blaze_powder"):targets=[4,3]
	elif BrewingData.ingredient(id):targets=[3]
	else:inventory.quick_move(index);return
	for target: int in targets:
		if counts[target]>0 and (ids[target]!=id or not NBT.same(tags[target],inventory.tags[index])):continue
		var amount: int=mini(inventory.counts[index],slot_limit(target,id)-counts[target])
		if amount<=0:continue
		ids[target]=id;tags[target]=inventory.tags[index].duplicate(true);durability[target]=inventory.durability[index];counts[target]+=amount;inventory.remove_from_slot(index,amount)
		if inventory.counts[index]<=0:break
	_refresh()
func quick_move(index: int) -> void:sync();super.quick_move(index)
func return_items() -> Array[Dictionary]:return []
