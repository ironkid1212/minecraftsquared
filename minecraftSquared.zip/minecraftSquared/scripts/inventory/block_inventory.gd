class_name BlockInventory
extends RefCounted
var creative_mode: bool=false
signal changed
const MAIN_COUNT: int=36
const HOTBAR_COUNT: int=9
const HEAD: int=36
const CHEST: int=37
const LEGS: int=38
const FEET: int=39
const OFFHAND: int=40
const SLOT_COUNT: int=41
var capacity: int
var main_count: int
var ids:=PackedInt32Array()
var counts:=PackedInt32Array()
var durability:=PackedInt32Array()
var tags: Array[Dictionary]=[]
var held_id: int=0
var held_count: int=0
var held_durability: int=0
var held_tags: Dictionary={}
var default_stack_limit: int=64
func _init(size: int = SLOT_COUNT) -> void:
	capacity=size;main_count=MAIN_COUNT if size==SLOT_COUNT else size
	ids.resize(size);counts.resize(size);durability.resize(size)
	for i in range(size):tags.append({})
func _refresh() -> void:changed.emit()
func stack_limit(id: int) -> int:return maxi(1,int(BlockDatabase.BLOCKS.get(id,{}).get("max_stack",default_stack_limit)))
func can_insert(index: int,id: int) -> bool:
	if index<0 or index>=capacity:return false
	if id==0 or capacity!=SLOT_COUNT or index<HEAD or index==OFFHAND:return true
	return str(BlockDatabase.BLOCKS.get(id,{}).get("armor",{}).get("slot",""))==["head","chest","legs","feet"][index-HEAD]
func stack(index: int) -> Dictionary:return {"id":ids[index],"count":counts[index],"durability":durability[index],"tags":tags[index].duplicate(true)}
func set_stack(index: int, data: Dictionary) -> void:
	ids[index]=int(data.get("id",0));counts[index]=int(data.get("count",0));durability[index]=ToolDatabase.initial_durability(ids[index],int(data.get("durability",-1)));tags[index]=data.get("tags",{}).duplicate(true)
	if counts[index]<=0:clear_slot(index)
func clear_slot(index: int) -> void:
	ids[index]=0;counts[index]=0;durability[index]=0;tags[index]={}
func load_starting_items(path: String) -> void:
	for entry in DataFile.array_from(path):
		if not entry is Dictionary or int(entry.get("count",0))<1:DataFile.fail(path+": invalid starter stack.");continue
		if add_item(BlockDatabase.id_for(str(entry.get("item",""))),int(entry["count"]))>0:DataFile.fail(path+": inventory capacity exceeded.")
func add_item(id: int, amount: int, first: int = 0, end: int = -1, remaining_durability: int = -1, metadata: Dictionary = {}, excluded: int = -1) -> int:
	if amount<=0:return 0
	if not BlockDatabase.BLOCKS.has(id) or id==0 or not ItemTags.valid(metadata):return amount
	var uses: int=ToolDatabase.initial_durability(id,remaining_durability)
	var remaining: int=amount;var limit: int=stack_limit(id)
	first=clampi(first,0,main_count);end=clampi(main_count if end<0 else end,first,main_count)
	for pass_index in range(2):
		for index in range(first,end):
			if index==excluded:continue
			if pass_index==0 and (counts[index]<=0 or ids[index]!=id or durability[index]!=uses or not NBT.same(tags[index],metadata)):continue
			if pass_index==1 and counts[index]!=0:continue
			var moved: int=mini(remaining,limit-counts[index])
			if moved<=0:continue
			if counts[index]==0:ids[index]=id;durability[index]=uses;tags[index]=metadata.duplicate(true)
			counts[index]+=moved;remaining-=moved
			if remaining==0:changed.emit();return 0
		if pass_index==0 and capacity==SLOT_COUNT and excluded!=OFFHAND and first==0 and end==main_count and ids[OFFHAND]==id and counts[OFFHAND]>0 and durability[OFFHAND]==uses and NBT.same(tags[OFFHAND],metadata):
			var moved: int=mini(remaining,limit-counts[OFFHAND])
			counts[OFFHAND]+=moved;remaining-=moved
			if remaining==0:changed.emit();return 0
	if remaining!=amount:changed.emit()
	return remaining
func can_accept(id: int, metadata: Dictionary = {}, uses: int = -1) -> bool:return capacity_for(id,metadata,uses)>0
func capacity_for(id: int, metadata: Dictionary = {}, uses: int = -1) -> int:
	var available: int=0;var limit: int=stack_limit(id)
	uses=ToolDatabase.initial_durability(id,uses)
	for index in range(main_count):
		if counts[index]==0:available+=limit
		elif ids[index]==id and durability[index]==uses and NBT.same(tags[index],metadata):available+=maxi(0,limit-counts[index])
	if capacity==SLOT_COUNT and ids[OFFHAND]==id and counts[OFFHAND]>0 and durability[OFFHAND]==uses and NBT.same(tags[OFFHAND],metadata):available+=maxi(0,limit-counts[OFFHAND])
	return available
func remove_from_slot(index: int, amount: int = 1) -> int:
	if index<0 or index>=capacity or amount<=0:return 0
	var removed: int=mini(amount,counts[index]);counts[index]-=removed
	if counts[index]==0:clear_slot(index)
	if removed>0:changed.emit()
	return removed
func consume_for_placement(index: int) -> void:
	if not creative_mode:remove_from_slot(index)
func click_slot(index: int,right: bool = false) -> void:
	if index>=0 and index<capacity:StackTransfer.click(self,index,self,right)
func swap_slots(a: int,b: int) -> bool:
	if not can_insert(a,ids[b]) or not can_insert(b,ids[a]):return false
	var old: Dictionary=stack(a);set_stack(a,stack(b));set_stack(b,old);changed.emit();return true
func quick_move(index: int) -> void:
	if index<0 or index>=capacity or counts[index]<=0:return
	if capacity==SLOT_COUNT and index<MAIN_COUNT:
		for equipment in range(HEAD,FEET+1):
			if counts[equipment]==0 and can_insert(equipment,ids[index]):swap_slots(index,equipment);return
	var original: int=counts[index]
	var first: int=HOTBAR_COUNT if index<HOTBAR_COUNT else 0
	var end: int=main_count if index<HOTBAR_COUNT or index>=MAIN_COUNT else HOTBAR_COUNT
	var remainder: int=add_item(ids[index],original,first,end,durability[index],tags[index],index)
	remove_from_slot(index,original-remainder)
func return_held() -> Dictionary:
	var result: Dictionary={"id":held_id,"count":add_item(held_id,held_count,0,main_count,held_durability,held_tags),"durability":held_durability,"tags":held_tags.duplicate(true)}
	held_id=0;held_count=0;held_durability=0;held_tags={};changed.emit();return result
func damage_tool(index: int, amount: int = 1) -> bool:
	if creative_mode:return false
	if index<0 or index>=capacity or counts[index]<=0 or amount<=0 or ToolDatabase.max_durability(ids[index])==0 or ItemTags.unbreakable(tags[index]):return false
	amount=EnchantmentDatabase.durability_cost(ids[index],tags[index],amount)
	if amount==0:return false
	durability[index]-=amount
	var broken: bool=durability[index]<=0
	if broken:clear_slot(index)
	elif tags[index].has("Damage"):tags[index]["Damage"]=NBT.node(NBT.INT,ToolDatabase.max_durability(ids[index])-durability[index])
	changed.emit();return broken
func apply_tags(index: int, metadata: Dictionary) -> bool:
	if index<0 or index>=capacity or counts[index]<=0 or not ItemTags.valid(metadata):return false
	var maximum: int=ToolDatabase.max_durability(ids[index])
	if metadata.has("Damage"):
		var damage: int=int(NBT.value(metadata,"Damage",0))
		if maximum==0 or damage<0 or damage>=maximum:return false
		durability[index]=maximum-damage
	tags[index]=metadata.duplicate(true);changed.emit();return true
