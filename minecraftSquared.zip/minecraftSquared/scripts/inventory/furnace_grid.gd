class_name FurnaceGrid
extends CraftingGrid
var state: FurnaceState
var system: FurnaceSystem
func _init(items: BlockInventory,source: FurnaceState,host: FurnaceSystem) -> void:
	super(items);state=source;system=host;sync()
func sync() -> void:ids=state.ids;counts=state.counts;durability=state.durability;tags=state.tags;recipe={}
func _refresh() -> void:
	for i in range(3):
		if counts[i]<=0:counts[i]=0;ids[i]=0;durability[i]=0;tags[i]={}
	state.ids=ids;state.counts=counts;state.durability=durability;state.tags=tags;system.sync_recipe(state);changed.emit();inventory.changed.emit()
func can_insert(index: int,id: int) -> bool:
	return index==0 or index==1 and (system.fuel_seconds(id)>0 or id==BlockDatabase.id_for("bucket"))
func slot_limit(index: int,id: int) -> int:return 1 if index==1 and id==BlockDatabase.id_for("bucket") else inventory.stack_limit(id)
func click_slot(index: int,right: bool=false) -> void:
	if index<0 or index>=3:return
	sync()
	if index!=2:super.click_slot(index,right);return
	if counts[2]<=0:return
	if inventory.held_count>0 and (inventory.held_id!=ids[2] or inventory.held_durability!=durability[2] or not NBT.same(inventory.held_tags,tags[2])):return
	var amount: int=mini(1 if right and inventory.held_count>0 else ceili(counts[2]/2.0) if right else counts[2],inventory.stack_limit(ids[2])-inventory.held_count)
	if amount<=0:return
	if inventory.held_count==0:inventory.held_id=ids[2];inventory.held_durability=durability[2];inventory.held_tags=tags[2].duplicate(true)
	inventory.held_count+=amount;counts[2]-=amount
	if counts[2]==0:ids[2]=0;durability[2]=0;tags[2]={}
	_refresh();system.pay_experience(state,system.world.player.global_position)
func deposit(index: int) -> void:
	if index<0 or index>=BlockInventory.MAIN_COUNT or inventory.counts[index]<=0:return
	sync()
	var id: int=inventory.ids[index]
	var target: int=0 if system.result_for(id)!=0 else 1 if system.fuel_seconds(id)>0 else -1
	if target<0:inventory.quick_move(index);return
	if counts[target]>0 and (ids[target]!=id or durability[target]!=inventory.durability[index] or not NBT.same(tags[target],inventory.tags[index])):return
	var moved: int=mini(inventory.counts[index],slot_limit(target,id)-counts[target])
	if moved<=0:return
	if counts[target]==0:ids[target]=id;durability[target]=inventory.durability[index];tags[target]=inventory.tags[index].duplicate(true)
	counts[target]+=moved;inventory.remove_from_slot(index,moved);_refresh()
func quick_move(index: int) -> void:
	if index<0 or index>=3:return
	sync()
	if counts[index]<=0:return
	var old_count: int=counts[index];var order: Array[int]=[]
	if index==2:
		for i in range(8,-1,-1):order.append(i)
		for i in range(35,8,-1):order.append(i)
	else:
		for i in range(9,36):order.append(i)
		for i in range(9):order.append(i)
	for pass_index in range(2):
		for target in order:
			if counts[index]<=0:break
			if pass_index==0 and (inventory.ids[target]!=ids[index] or inventory.counts[target]<=0 or inventory.durability[target]!=durability[index] or not NBT.same(inventory.tags[target],tags[index])):continue
			if pass_index==1 and inventory.counts[target]!=0:continue
			var moved: int=mini(counts[index],inventory.stack_limit(ids[index])-inventory.counts[target])
			if moved<=0:continue
			if inventory.counts[target]==0:inventory.set_stack(target,{"id":ids[index],"count":moved,"durability":durability[index],"tags":tags[index]})
			else:inventory.counts[target]+=moved
			counts[index]-=moved
	_refresh()
	if index==2 and counts[index]<old_count:system.pay_experience(state,system.world.player.global_position)
func return_items() -> Array[Dictionary]:return []
