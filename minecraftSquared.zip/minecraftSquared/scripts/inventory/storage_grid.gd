class_name StorageGrid
extends CraftingGrid
var system: StorageSystem
var cells: Array[Vector2i]
func _init(owner_items: BlockInventory,host: StorageSystem,locations: Array[Vector2i]) -> void:
	super(owner_items);system=host;cells=locations;width=9
	ids.resize(cells.size()*27);counts.resize(ids.size());durability.resize(ids.size());tags.clear()
	for cell in cells:
		var data: BlockInventory=system.state_at(cell)
		var start: int=cells.find(cell)*27
		for i in range(27):ids[start+i]=data.ids[i];counts[start+i]=data.counts[i];durability[start+i]=data.durability[i];tags.append(data.tags[i].duplicate(true))
func can_insert(_index: int,id: int) -> bool:
	return not (BlockDatabase.BLOCKS.get(system.world.get_block(cells[0]),{}).get("storage",{}).get("kind")=="shulker" and BlockDatabase.BLOCKS.get(id,{}).get("storage",{}).get("kind")=="shulker")
func _refresh() -> void:
	for n in range(cells.size()):
		var data: BlockInventory=system.state_at(cells[n])
		for i in range(27):data.set_stack(i,{"id":ids[n*27+i],"count":counts[n*27+i],"durability":durability[n*27+i],"tags":tags[n*27+i]})
	changed.emit();inventory.changed.emit()
func deposit(index: int) -> void:
	var id: int=inventory.ids[index];var remaining: int=inventory.counts[index]
	if remaining<=0 or not can_insert(0,id):return
	for pass_index in range(2):
		for i in range(ids.size()):
			if pass_index==0 and (ids[i]!=id or counts[i]==0 or durability[i]!=inventory.durability[index] or not NBT.same(tags[i],inventory.tags[index])):continue
			if pass_index==1 and counts[i]!=0:continue
			var moved: int=mini(remaining,inventory.stack_limit(id)-counts[i])
			if moved<=0:continue
			if counts[i]==0:ids[i]=id;durability[i]=inventory.durability[index];tags[i]=inventory.tags[index].duplicate(true)
			counts[i]+=moved;remaining-=moved
			if remaining==0:break
		if remaining==0:break
	inventory.remove_from_slot(index,inventory.counts[index]-remaining);_refresh()
func return_items() -> Array[Dictionary]:return []
