class_name CraftingGrid
extends RefCounted

signal changed

var inventory: BlockInventory
var width: int = 2
var ids := PackedInt32Array()
var counts := PackedInt32Array()
var durability := PackedInt32Array()
var recipe: Dictionary = {}
var tags: Array[Dictionary]=[]


func _init(items: BlockInventory, grid_width: int = 2) -> void:
	inventory = items
	width = clampi(grid_width, 2, 3)
	ids.resize(width * width)
	counts.resize(width * width)
	durability.resize(width * width)
	for i in range(width*width):tags.append({})


func _refresh() -> void:
	recipe = RecipeDatabase.find_match(ids, width)
	changed.emit()
	inventory.changed.emit()


func click_slot(index: int, right: bool = false) -> void:
	if index<0 or index>=ids.size():return
	StackTransfer.click(self,index,inventory,right)


func quick_move(index: int) -> void:
	if index < 0 or index >= ids.size() or counts[index] <= 0:
		return
	counts[index] = inventory.add_item(ids[index], counts[index], 0, BlockInventory.MAIN_COUNT, durability[index], tags[index])
	if counts[index] == 0:
		ids[index] = BlockDatabase.ID.AIR
		durability[index] = 0
		tags[index]={}
	_refresh()


func available_batches() -> int:
	if recipe.is_empty():
		return 0
	var available: int = 2147483647
	for index in range(ids.size()):
		if ids[index] != BlockDatabase.ID.AIR:
			available = mini(available, counts[index])
	return available


func take_result(shift: bool = false) -> int:
	if recipe.is_empty():
		return 0
	var result: int = recipe["result"]
	var per_batch: int = recipe["count"]
	var batches: int = available_batches()
	if shift:
		batches = mini(batches, floori(inventory.capacity_for(result) / float(per_batch)))
	else:
		if inventory.held_count > 0 and (inventory.held_id != result or not inventory.held_tags.is_empty()):
			return 0
		if inventory.held_count + per_batch > inventory.stack_limit(result):
			return 0
		batches = mini(batches, 1)
	if batches <= 0:
		return 0
	var produced: int = batches * per_batch
	# Validate output room first, then consume one ingredient per occupied slot
	# per batch. Unlimited world placement does not make crafting free.
	for index in range(ids.size()):
		if ids[index] != BlockDatabase.ID.AIR:
			counts[index] -= batches
			if counts[index] == 0:
				ids[index] = BlockDatabase.ID.AIR
				durability[index] = 0
				tags[index]={}
	if shift:
		var remainder: int = inventory.add_item(result, produced)
		assert(remainder == 0)
	else:
		inventory.held_id = result
		inventory.held_durability = ToolDatabase.initial_durability(result)
		inventory.held_tags={}
		inventory.held_count += produced
	_refresh()
	return produced


func return_items() -> Array[Dictionary]:
	var overflow: Array[Dictionary] = []
	for index in range(ids.size()):
		if counts[index] == 0:
			continue
		var remainder: int = inventory.add_item(ids[index], counts[index], 0, BlockInventory.MAIN_COUNT, durability[index], tags[index])
		if remainder > 0:
			overflow.append({"id": ids[index], "count": remainder, "durability": durability[index],"tags":tags[index].duplicate(true)})
		counts[index] = 0
		ids[index] = BlockDatabase.ID.AIR
		durability[index] = 0
		tags[index]={}
	_refresh()
	return overflow
