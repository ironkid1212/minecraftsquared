class_name FurnaceState
extends RefCounted
var ids := PackedInt32Array([0, 0, 0])
var counts := PackedInt32Array([0, 0, 0])
var durability:=PackedInt32Array([0,0,0])
var tags: Array[Dictionary]=[{}, {}, {}]
var burn: float = 0.0
var burn_total: float = 0.0
var experience: float=0
var cook: float = 0.0
var recipe_key: String = ""
var recipe_durability: int=0
var recipe_tags: Dictionary={}

func clear_slot(index: int) -> void:
	ids[index]=0;counts[index]=0;durability[index]=0;tags[index]={}
