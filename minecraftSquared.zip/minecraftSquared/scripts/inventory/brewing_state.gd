class_name BrewingState
extends BlockInventory
var fuel: int=0
var remaining: float=0
var ingredient: int=0
func _init() -> void:super(5)
