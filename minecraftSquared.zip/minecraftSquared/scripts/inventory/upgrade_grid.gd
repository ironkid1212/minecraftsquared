class_name UpgradeGrid
extends CraftingGrid

var mode: String
func _init(owner: BlockInventory,kind: String) -> void:
	super(owner,2);mode=kind
	ids.resize(2);counts.resize(2);durability.resize(2);tags.resize(2)
func can_insert(index: int,id: int) -> bool:
	if mode=="grindstone":return GrindstoneLogic.accepts(id)
	if mode=="anvil":return true
	if index==1:return id==BlockDatabase.id_for("lapis_lazuli")
	for key in EnchantmentDatabase.definitions():
		if EnchantmentDatabase.accepts(key,id,true) and BlockDatabase.BLOCKS[id].key!="enchanted_book":return true
	return false
func slot_limit(index: int,id: int) -> int:
	if mode=="grindstone":return 1
	return 1 if mode=="enchanting" and index==0 else inventory.stack_limit(id)
func _refresh() -> void:
	for i in range(2):
		if counts[i]<=0:ids[i]=0;counts[i]=0;durability[i]=0;tags[i]={}
	changed.emit();inventory.changed.emit()
func deposit(index: int) -> void:
	if inventory.counts[index]<=0:return
	var target: int=-1
	if mode=="enchanting":target=1 if inventory.ids[index]==BlockDatabase.id_for("lapis_lazuli") else 0
	else:target=0 if counts[0]==0 else 1
	if not can_insert(target,inventory.ids[index]):inventory.quick_move(index);return
	if counts[target]>0 and (ids[target]!=inventory.ids[index] or durability[target]!=inventory.durability[index] or not NBT.same(tags[target],inventory.tags[index])):return
	var moved: int=mini(inventory.counts[index],slot_limit(target,inventory.ids[index])-counts[target])
	if moved<=0:return
	ids[target]=inventory.ids[index];durability[target]=inventory.durability[index];tags[target]=inventory.tags[index].duplicate(true);counts[target]+=moved
	inventory.remove_from_slot(index,moved);_refresh()
func clear_input(index: int,amount: int) -> void:
	counts[index]=maxi(0,counts[index]-amount)
	_refresh()
func stack(index: int) -> Dictionary:
	return {"id":ids[index],"count":counts[index],"durability":durability[index],"tags":tags[index].duplicate(true)}
