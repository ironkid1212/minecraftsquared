class_name AtlasDatabase
extends RefCounted

static var ATLASES: Dictionary = _load_atlases()
static var _sources: Dictionary = {}
static var _tile_opacity: Dictionary = {}
static var _pixel_images: Dictionary = {}

static func tile_is_opaque(key: String, tile: Vector2i) -> bool:
	# Inspect source alpha once during catalog compilation, never while drawing.
	var cache_key: String = key + ":" + str(tile)
	if _tile_opacity.has(cache_key): return _tile_opacity[cache_key]
	var atlas: TileSetAtlasSource = source(key)
	if atlas == null or atlas.texture == null: return false
	if not _pixel_images.has(key):
		var pixels: Image = atlas.texture.get_image()
		if pixels == null or pixels.is_empty(): return false
		if pixels.is_compressed() and pixels.decompress() != OK: return false
		_pixel_images[key] = pixels
	var pixels: Image = _pixel_images[key]
	var origin: Vector2i = atlas.margins + tile * (atlas.texture_region_size + atlas.separation)
	if origin.x < 0 or origin.y < 0 or origin.x + atlas.texture_region_size.x > pixels.get_width() or origin.y + atlas.texture_region_size.y > pixels.get_height(): return false
	var opaque: bool = true
	for y in range(origin.y, origin.y + atlas.texture_region_size.y):
		for x in range(origin.x, origin.x + atlas.texture_region_size.x):
			if pixels.get_pixel(x, y).a < 0.999:
				opaque = false
				break
		if not opaque: break
	_tile_opacity[cache_key] = opaque
	return opaque

static func release_pixel_images() -> void:
	_pixel_images.clear()

static func _load_atlases() -> Dictionary:
	var result: Dictionary = {}
	for entry in DataFile.array_from("res://data/atlases.json"):
		if not entry is Dictionary or not entry.get("key") is String or not entry.get("texture") is String:
			DataFile.fail("atlases.json: each atlas needs key and texture strings.")
			continue
		var key: String = entry["key"]
		var valid: bool = not key.is_empty() and not result.has(key) and FileAccess.file_exists(entry["texture"])
		for field in ["tile_size", "margin", "separation"]:
			var vector: Variant = entry.get(field)
			if not vector is Array or vector.size() != 2:
				valid = false
				continue
			for value in vector:
				if not (value is int or value is float) or not is_finite(float(value)) or float(value) != int(value) or value < (1 if field == "tile_size" else 0):
					valid = false
		if not valid:
			DataFile.fail("atlases.json: duplicate key, missing texture or invalid integer grid: " + key)
			continue
		result[key] = entry
	if not result.has("blocks") or result["blocks"]["tile_size"] != [16.0,16.0]:
		DataFile.fail("atlases.json: the world requires a blocks atlas with 16x16 tiles.")
	return result

static func source(key: String, world_source: TileSetAtlasSource = null) -> TileSetAtlasSource:
	if key == "blocks" and world_source != null:
		return world_source
	if not ATLASES.has(key):
		return null
	if not _sources.has(key):
		var atlas := TileSetAtlasSource.new()
		configure(atlas,key)
		_sources[key] = atlas
	return _sources[key]

static func configure(atlas: TileSetAtlasSource, key: String) -> void:
	var data: Dictionary = ATLASES[key]
	atlas.texture = load(data["texture"]) as Texture2D
	atlas.texture_region_size = Vector2i(data["tile_size"][0],data["tile_size"][1])
	atlas.margins = Vector2i(data["margin"][0],data["margin"][1])
	atlas.separation = Vector2i(data["separation"][0],data["separation"][1])

static func validate_tile(key: String, tile: Vector2i, label: String) -> bool:
	var atlas: TileSetAtlasSource = source(key)
	if atlas == null or atlas.texture == null:
		DataFile.fail("Missing atlas/texture for " + label)
		return false
	var end: Vector2i = atlas.margins + tile * (atlas.texture_region_size + atlas.separation) + atlas.texture_region_size
	if tile.x < 0 or tile.y < 0 or end.x > atlas.texture.get_width() or end.y > atlas.texture.get_height():
		DataFile.fail("Atlas tile outside texture for " + label + ": " + str(tile))
		return false
	return true
