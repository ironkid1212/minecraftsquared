class_name RecipeDatabase
extends RefCounted

# Inspired by griffpatch's Paper Minecraft _Recipes list and gui_invrow:
# align occupied ingredients to the top-left, encode a 3x3 pattern, look it
# up, then try its horizontal mirror. Zero means an empty cell.
static var RECIPES: Array[Dictionary] = _load_recipes()

static func _load_recipes() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var entries: Array = DataFile.array_from("res://data/recipes.json")
	for entry in entries:
		if not entry is Dictionary or not entry.get("pattern", null) is Array:
			DataFile.fail("recipes.json: each recipe needs a pattern array.")
			continue
		var rows: Array = entry["pattern"]
		var id: int = BlockDatabase.id_for(str(entry.get("result", "")))
		var count: int = int(entry.get("count", 0))
		if rows.is_empty() or rows.size() > 3 or id == 0 or count < 1 or not entry.get("exact",false) is bool:
			DataFile.fail("recipes.json: invalid dimensions, result or count: " + str(entry))
			continue
		var pattern: Array = []
		var valid: bool = true
		for row in rows:
			if not row is Array or row.is_empty() or row.size() > 3:
				valid = false
				break
			var translated: Array = []
			for key in row:
				var ingredient: int=BlockDatabase.id_for("air" if key==null else str(key))
				if key!=null and str(key)!="air" and ingredient==0:
					DataFile.fail("recipes.json: unknown ingredient '"+str(key)+"'.");valid=false;break
				translated.append(ingredient)
			pattern.append(translated)
		if not valid:
			DataFile.fail("recipes.json: rows need 1-3 keys; use null for empty cells.")
			continue
		result.append({"name": entry.get("name", "Recipe"), "pattern": pattern, "result": id, "count": count,"exact":entry.get("exact",false),"shapeless":entry.get("shapeless",false)})
	return result

static var _lookup: Dictionary = {}
static var _exact_lookup: Dictionary = {}
static var _shapeless_lookup: Dictionary = {}


static func signature(grid: PackedInt32Array, width: int, mirror: bool = false, exact: bool = false) -> String:
	if width < 1 or width > 3 or grid.is_empty() or grid.size() % width != 0:
		return ""
	var minimum := Vector2i(999, 999)
	var maximum := Vector2i(-1, -1)
	for index in range(grid.size()):
		if grid[index] != BlockDatabase.ID.AIR:
			var p := Vector2i(index % width, floori(index / float(width)))
			minimum = minimum.min(p)
			maximum = maximum.max(p)
	if maximum.x < 0:
		return ""
	var occupied_size: Vector2i = maximum - minimum + Vector2i.ONE
	if occupied_size.x > 3 or occupied_size.y > 3:
		return ""
	var tokens := PackedStringArray()
	for y in range(3):
		for x in range(3):
			var token: String = "#"
			if x < occupied_size.x and y < occupied_size.y:
				var source_x: int = maximum.x - x if mirror else minimum.x + x
				var id: int = grid[(minimum.y + y) * width + source_x]
				if id != BlockDatabase.ID.AIR:
					# Like Paper Minecraft's crafting category in _BLOCK_DATA,
					# this permits future variants to share a recipe key.
					token = str(id if exact else BlockDatabase.BLOCKS.get(id, {}).get("crafting_key", id))
			tokens.append(token)
	return "|".join(tokens)


static func _build_lookup() -> void:
	for recipe in RECIPES:
		var rows: Array = recipe["pattern"]
		assert(not rows.is_empty() and rows.size() <= 3, "Recipe must have 1-3 rows")
		assert(BlockDatabase.BLOCKS.has(recipe["result"]) and int(recipe["count"]) > 0)
		var grid := PackedInt32Array()
		grid.resize(9)
		for y in range(rows.size()):
			assert(rows[y].size() <= 3, "Recipe rows must have at most 3 ingredients")
			for x in range(rows[y].size()):
				var id: int = rows[y][x]
				assert(id == BlockDatabase.ID.AIR or BlockDatabase.BLOCKS.has(id))
				grid[y * 3 + x] = id
		var exact: bool=bool(recipe.get("exact",false))
		var lookup: Dictionary=_exact_lookup if exact else _lookup
		var key: String = signature(grid, 3,false,exact)
		if recipe.get("shapeless",false):
			key=shapeless_signature(grid,exact);lookup=_shapeless_lookup
		if key.is_empty() or lookup.has(key):
			DataFile.fail("recipes.json: empty or duplicate recipe: " + str(recipe["name"]))
			continue
		lookup[key] = recipe


static func find_match(grid: PackedInt32Array, width: int) -> Dictionary:
	if _lookup.is_empty():
		_build_lookup()
	for mirrored in [false,true]:
		var exact_key: String=signature(grid,width,mirrored,true)
		if _exact_lookup.has(exact_key): return _exact_lookup[exact_key]
	for exact in [true,false]:
		var unordered: String=shapeless_signature(grid,exact)
		if _shapeless_lookup.has(unordered):return _shapeless_lookup[unordered]
	var key: String = signature(grid, width)
	if _lookup.has(key):
		return _lookup[key]
	return _lookup.get(signature(grid, width, true), {})


static func validate() -> void:
	if _lookup.is_empty():
		_build_lookup()

static func shapeless_signature(grid: PackedInt32Array,exact: bool) -> String:
	var tokens:=PackedStringArray()
	for id in grid:
		if id!=0:tokens.append(str(id if exact else BlockDatabase.BLOCKS[id].crafting_key))
	tokens.sort();return ("exact:" if exact else "group:")+"|".join(tokens)
