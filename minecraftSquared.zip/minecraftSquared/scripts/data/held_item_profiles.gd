class_name HeldItemProfiles
extends RefCounted

## Vanilla third-person transforms are loaded once; projection runs on equip,
## never per frame. Flat icons preserve their artwork rather than turn edge-on.
static var PROFILES: Dictionary = _load_profiles()
const HAND_BASIS := Basis(Vector3.RIGHT, -PI / 2) * Basis(Vector3.UP, PI)


static func _numeric_array(value: Variant, count: int) -> bool:
	if not value is Array or value.size() != count:
		return false
	for component in value:
		if not (component is float or component is int) or not is_finite(float(component)):
			return false
	return true


static func _load_profiles() -> Dictionary:
	var result: Dictionary = {}
	for entry in DataFile.array_from("res://data/held_item_profiles.json"):
		if not entry is Dictionary or not entry.get("key") is String:
			DataFile.fail("held_item_profiles.json: each profile needs a string key.")
			continue
		var key: String = entry["key"]
		if key.is_empty() or result.has(key) or entry.get("size_class") not in ["block", "item"]:
			DataFile.fail("held_item_profiles.json: invalid/duplicate profile: " + key)
			continue
		if not _numeric_array(entry.get("model_axis"), 3) or not _numeric_array(entry.get("sprite_axis"), 2):
			DataFile.fail("held_item_profiles.json: invalid principal axes: " + key)
			continue
		if not entry.get("flip_x",false) is bool or not entry.get("flip_y",false) is bool:
			DataFile.fail("held_item_profiles.json: flip_x/flip_y must be booleans: " + key)
			continue
		if _vec3(entry["model_axis"]).is_zero_approx() or Vector2(entry["sprite_axis"][0], entry["sprite_axis"][1]).is_zero_approx():
			DataFile.fail("held_item_profiles.json: axes cannot be zero: " + key)
			continue
		if not entry.get("items", []) is Array:
			DataFile.fail("held_item_profiles.json: items must be a list of block/item keys: " + key)
			continue
		var display: Variant = entry.get("display")
		if not display is Dictionary or not display.has("thirdperson_righthand"):
			DataFile.fail("held_item_profiles.json: thirdperson_righthand required: " + key)
			continue
		var valid: bool = true
		for context in display:
			var pose: Variant = display[context]
			if not pose is Dictionary:
				valid = false
				continue
			for field in ["rotation", "translation", "scale"]:
				if not _numeric_array(pose.get(field), 3):
					valid = false
			if valid and (_vec3(pose["scale"]).x <= 0 or not _vec3(pose["scale"]).is_equal_approx(Vector3.ONE * float(pose["scale"][0]))):
				valid = false
		if not valid:
			DataFile.fail("held_item_profiles.json: expected XYZ rotation/translation and positive uniform scale: " + key)
			continue
		result[key] = entry
	for required in ["block", "generated"]:
		if not result.has(required):
			DataFile.fail("held_item_profiles.json: missing fallback profile: " + required)
	return result


static func validate() -> void:
	var assigned: Dictionary = {}
	for key in PROFILES:
		for item in PROFILES[key].get("items", []):
			if not item is String or BlockDatabase.id_for(item) <= 0 or assigned.has(item):
				DataFile.fail("held_item_profiles.json: unknown or duplicate item assignment: " + str(item))
			assigned[item] = key
	for definition in BlockDatabase.BLOCKS.values():
		var held: Variant = definition.get("held", {})
		if held is Dictionary and held.has("profile") and not PROFILES.has(held["profile"]):
			DataFile.fail("Unknown held profile for " + str(definition["key"]))


static func resolve(definition: Dictionary, settings: PlayerSettings, offhand: bool = false) -> Dictionary:
	var key: String = "generated" if (definition.get("atlas_type", "blocks") == "items" or definition.get("wall_attach", false)) else "block"
	for candidate in PROFILES:
		if definition.get("key", "") in PROFILES[candidate].get("items", []):
			key = candidate
			break
	var overrides: Variant = definition.get("held", {})
	if overrides is Dictionary and overrides.get("profile") is String:
		key = overrides["profile"]
	if not PROFILES.has(key):
		return {"size": settings.held_item_size, "offset": Vector2.ZERO, "rotation": 0.0}
	var profile: Dictionary = PROFILES[key]
	var display: Dictionary = profile["display"]
	var left: bool = (settings.main_hand == 1) != offhand
	var pose: Dictionary = display.get("thirdperson_lefthand", display["thirdperson_righthand"]) if left else display["thirdperson_righthand"]
	var angles: Vector3 = _vec3(pose["rotation"]) * (PI / 180)
	var translation: Vector3 = _vec3(pose["translation"])
	if left:
		# Java ItemTransform mirrors Y/Z rotation and X translation for left hand.
		angles.y = -angles.y
		angles.z = -angles.z
		translation.x = -translation.x
	var rotation := Basis(Vector3.RIGHT, angles.x) * Basis(Vector3.UP, angles.y) * Basis(Vector3.BACK, angles.z)
	var axis: Vector2 = _side(HAND_BASIS * rotation * _vec3(profile["model_axis"]))
	var sprite_axis := Vector2(profile["sprite_axis"][0], profile["sprite_axis"][1])
	var block: bool = profile["size_class"] == "block"
	var size: float = settings.held_block_size if block else settings.held_item_size
	if overrides is Dictionary:
		var custom_size: Variant = overrides.get("size")
		if custom_size is float or custom_size is int:
			size = clampf(float(custom_size), 1, 32)
	var native_size: float = 16 * float(pose["scale"][0])
	var offset: Vector2 = _side(HAND_BASIS * translation) * size / native_size
	var adjustment: float = settings.held_block_angle_offset if block else settings.held_item_angle_offset
	return {"size": size, "offset": offset, "rotation": wrapf(axis.angle() - sprite_axis.angle(), -PI, PI) + deg_to_rad(adjustment), "flip_x": profile.get("flip_x",false), "flip_y": profile.get("flip_y",false)}


static func _vec3(value: Array) -> Vector3:
	return Vector3(value[0], value[1], value[2])


static func _side(value: Vector3) -> Vector2:
	return Vector2(-value.z, value.y)
