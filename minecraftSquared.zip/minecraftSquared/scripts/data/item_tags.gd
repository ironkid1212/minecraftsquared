class_name ItemTags
extends RefCounted
static func valid(tags: Variant) -> bool:
	if not NBT.valid_tags(tags):return false
	for key in ["Damage","Unbreakable"]:
		if tags.has(key) and int(tags[key]["t"]) not in [NBT.BYTE,NBT.SHORT,NBT.INT]:return false
	if tags.has("display"):
		if int(tags["display"]["t"])!=NBT.COMPOUND:return false
		var display: Dictionary=tags["display"]["v"]
		if display.has("Name") and int(display["Name"]["t"])!=NBT.STRING:return false
		if display.has("Lore"):
			if int(display["Lore"]["t"])!=NBT.LIST:return false
			for line in display["Lore"]["v"]:
				if int(line["t"])!=NBT.STRING:return false
	if tags.has("components") and int(tags["components"]["t"])!=NBT.COMPOUND:return false
	if tags.has("RepairCost") and (int(tags.RepairCost.t) not in [NBT.BYTE,NBT.SHORT,NBT.INT] or not ContentCatalog._number(tags.RepairCost.v,0,1000000,true)):return false
	for field in ["Enchantments","StoredEnchantments"]:
		if not tags.has(field):continue
		if int(tags[field].t)!=NBT.LIST:return false
		var seen: Dictionary={}
		for entry in tags[field].v:
			if int(entry.t)!=NBT.COMPOUND:return false
			var enchant: Dictionary=entry.v
			if not enchant.has("id") or int(enchant.id.t)!=NBT.STRING or not enchant.has("lvl") or int(enchant.lvl.t) not in [NBT.BYTE,NBT.SHORT,NBT.INT] or not ContentCatalog._number(enchant.lvl.v,1,255,true) or seen.has(enchant.id.v):return false
			seen[enchant.id.v]=true
	return true
static func name(id: int,tags: Dictionary) -> String:
	var display: Dictionary=NBT.value(tags,"display",{})
	var custom: String=str(NBT.value(display,"Name",""))
	if custom.is_empty():custom=str(NBT.value(NBT.value(tags,"components",{}),"minecraft:custom_name",""))
	if not custom.is_empty():
		if custom.begins_with("{"):
			var json:=JSON.new()
			if json.parse(custom)==OK and json.data is Dictionary:custom=str(json.data.get("text",custom))
		return custom
	return str(BlockDatabase.BLOCKS.get(id,{}).get("name",""))
static func lore(tags: Dictionary) -> Array:
	var result: Array=[]
	for line in NBT.value(NBT.value(tags,"display",{}),"Lore",[]):result.append(str(line.get("v","")))
	return result
static func unbreakable(tags: Dictionary) -> bool:return int(NBT.value(tags,"Unbreakable",0))!=0
