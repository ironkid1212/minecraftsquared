class_name EnchantmentDatabase
extends RefCounted

static var DATA: Dictionary=DataFile.object_from("res://data/enchantments.json")
static var DROPS: Dictionary=DataFile.object_from("res://data/enchantment_drops.json")
static func definitions() -> Dictionary:return DATA.definitions
static func book_stack(values: Dictionary) -> Dictionary:
	return {"id":BlockDatabase.id_for("enchanted_book"),"count":1,"durability":0,"tags":write({},values,true)}
static func creative_books(all_levels: bool=false) -> Array[Dictionary]:
	var books: Array[Dictionary]=[]
	for key in definitions():
		var maximum: int=int(definitions()[key].maximum)
		for lv in range(1 if all_levels else maximum,maximum+1):books.append(book_stack({key:lv}))
	return books
static func read(tags: Dictionary,stored: bool=false) -> Dictionary:
	var result: Dictionary={}
	for entry in NBT.value(tags,"StoredEnchantments" if stored else "Enchantments",[]):
		var key: String=str(NBT.value(entry.v,"id","")).trim_prefix("minecraft:")
		result[key]=maxi(int(result.get(key,0)),clampi(int(NBT.value(entry.v,"lvl",0)),0,255))
	return result
static func level(tags: Dictionary,key: String) -> int:
	return mini(int(definitions().get(key,{}).get("maximum",0)),int(read(tags).get(key,0)))
static func write(tags: Dictionary,values: Dictionary,stored: bool=false) -> Dictionary:
	var result: Dictionary=tags.duplicate(true);var list: Array=[]
	for key in values:
		if int(values[key])>0:list.append(NBT.node(NBT.COMPOUND,{"id":NBT.node(NBT.STRING,"minecraft:"+key),"lvl":NBT.node(NBT.SHORT,int(values[key]))}))
	var field: String="StoredEnchantments" if stored else "Enchantments"
	if list.is_empty():result.erase(field)
	else:result[field]=NBT.node(NBT.LIST,list)
	return result
static func label(key: String,lv: int) -> String:
	var rule: Dictionary=definitions().get(key,{})
	return str(rule.get("name",key.replace("_"," ").capitalize()))+(" "+(["","I","II","III","IV","V"][lv] if lv>=1 and lv<=5 else str(lv)) if int(rule.get("maximum",2))>1 else "")
static func accepts(key: String,id: int,table: bool=false) -> bool:
	if table and BlockDatabase.BLOCKS.get(id,{}).has("utility"):return false
	if not definitions().has(key):return false
	var item: Dictionary=BlockDatabase.BLOCKS.get(id,{})
	if item.get("key") in ["book","enchanted_book"]:return true
	var kind: String=str(ToolDatabase.TOOLS.get(id,{}).get("kind",""))
	var targets: Array=definitions()[key].targets
	if item.get("key")=="elytra":return not table and "durable" in targets
	if table and (item.has("shield") or kind=="shears" or key=="sharpness" and kind=="axe"):return false
	return kind in targets or "armor" in targets and item.has("armor") or "bow" in targets and item.has("ranged") or "durable" in targets and ToolDatabase.max_durability(id)>0
static func compatible(values: Dictionary,key: String) -> bool:
	for existing in values:
		if existing==key:continue
		if existing in definitions().get(key,{}).get("exclusive",[]) or key in definitions().get(existing,{}).get("exclusive",[]):return false
	return true
static func enchantability(id: int) -> int:
	var item: Dictionary=BlockDatabase.BLOCKS.get(id,{})
	var material: String=str(item.get("key","")).get_slice("_",0)
	var values: Dictionary=DATA.armor_enchantability if item.has("armor") else DATA.enchantability
	return int(values.get(material,DATA.enchantability.default))
static func roll(id: int,cost: int,rng: RandomNumberGenerator) -> Dictionary:
	var ability: int=enchantability(id)/4
	var power: int=maxi(1,roundi((cost+1+rng.randi_range(0,ability)+rng.randi_range(0,ability))*(1+(rng.randf()+rng.randf()-1)*.15)))
	var choices: Dictionary={};var result: Dictionary={}
	for key in definitions():
		var rule: Dictionary=definitions()[key]
		if not accepts(key,id,true):continue
		for lv in range(int(rule.maximum),0,-1):
			if power>=int(rule.min_cost[0])+int(rule.min_cost[1])*(lv-1) and power<=int(rule.max_cost[0])+int(rule.max_cost[1])*(lv-1):choices[key]=lv;break
	while not choices.is_empty():
		var weight: int=0
		for key in choices:weight+=int(definitions()[key].weight)
		var ticket: int=rng.randi_range(1,weight);var chosen: String=""
		for key in choices:
			ticket-=int(definitions()[key].weight)
			if ticket<=0:chosen=key;break
		result[chosen]=choices[chosen];choices.erase(chosen)
		for key in choices.keys():
			if not compatible(result,key):choices.erase(key)
		if rng.randi_range(0,49)>power:break
		power/=2
	if BlockDatabase.BLOCKS[id].key=="book" and result.size()>1:result.erase(result.keys()[rng.randi_range(0,result.size()-1)])
	return result
static func offers(id: int,shelves: int,seed_value: int) -> Array[Dictionary]:
	var result: Array[Dictionary]=[]
	if id==0:return result
	var possible: bool=false
	for key in definitions():
		if accepts(key,id,true):possible=true;break
	if not possible:return result
	var rng:=RandomNumberGenerator.new();rng.seed=seed_value
	var power: int=roundi(clampi(shelves,0,int(DATA.table.max_bookshelves))*float(DATA.table.vanilla_power)/int(DATA.table.max_bookshelves))
	for index in range(3):
		var base: int=rng.randi_range(1,8)+power/2+rng.randi_range(0,power)
		var required: int=maxi(1,base/3) if index==0 else base*2/3+1 if index==1 else maxi(base,power*2)
		var rolls:=RandomNumberGenerator.new();rolls.seed=seed_value+index*1031
		var values: Dictionary=roll(id,required,rolls)
		if required<index+1:required=0;values={}
		var clue: String="" if values.is_empty() else str(values.keys()[rolls.randi_range(0,values.size()-1)])
		result.append({"required":required,"cost":index+1,"values":values,"clue":clue})
	return result
static func durability_cost(id: int,tags: Dictionary,amount: int,rng: RandomNumberGenerator=null) -> int:
	var lv: int=level(tags,"unbreaking")
	if lv<=0:return amount
	var spent: int=0
	for i in range(amount):
		var roll_value: float=rng.randf() if rng!=null else randf()
		var chance: float=.6+.4/(lv+1) if BlockDatabase.BLOCKS[id].has("armor") and BlockDatabase.BLOCKS[id].key!="elytra" else 1.0/(lv+1)
		if roll_value<chance:spent+=1
	return spent
static func mining_drops(block: int,tool: int,tags: Dictionary,rng: RandomNumberGenerator=null) -> Dictionary:
	var key: String=BlockDatabase.BLOCKS[block].key;var rule: Dictionary=DROPS.get(key,{})
	if rule.has("silk") and level(tags,"silk_touch")>0:return {"drops":[{"id":BlockDatabase.id_for(rule.silk),"count":1}],"silk":true}
	var drops: Array=BlockDatabase.roll_drops(block,rng,tool);var lv: int=level(tags,"fortune")
	if rule.get("fortune")=="crop":
		var crop: Dictionary=rule.crop;var count: int=int(crop.base);drops=[]
		for i in range(int(crop.trials)+lv):
			if (rng.randf() if rng!=null else randf())<float(crop.probability):count+=1
		for fixed in crop.fixed:drops.append({"id":BlockDatabase.id_for(fixed.item),"count":int(fixed.count)})
		drops.append({"id":BlockDatabase.id_for(crop.item),"count":count})
	if rule.has("base_count"):
		for drop in drops:drop.count=rng.randi_range(int(rule.base_count[0]),int(rule.base_count[1])) if rng!=null else randi_range(int(rule.base_count[0]),int(rule.base_count[1]))
	if key=="gravel":
		var chance: float=[.1,.142857,.25,1.0][mini(lv,3)]
		if (rng.randf() if rng!=null else randf())<chance:drops=[{"id":BlockDatabase.id_for("flint"),"count":1}]
	elif lv>0 and rule.get("fortune")=="ore":
		for drop in drops:
			var multiplier: int=maxi(1,(rng.randi_range(0,lv+1) if rng!=null else randi_range(0,lv+1)))
			drop.count*=multiplier
	elif lv>0 and rule.get("fortune")=="limited":
		for drop in drops:drop.count=mini(int(rule.maximum_count),drop.count+(rng.randi_range(0,lv) if rng!=null else randi_range(0,lv)))
	elif lv>0 and rule.get("fortune")=="redstone":
		for drop in drops:drop.count+=(rng.randi_range(0,lv) if rng!=null else randi_range(0,lv))
	return {"drops":drops,"silk":false}
static func validate() -> bool:
	if DATA.get("version")!=1 or not DATA.get("definitions") is Dictionary or not DATA.get("table") is Dictionary or not ContentCatalog._number(DATA.table.get("max_bookshelves"),1,64,true):return false
	if not ContentCatalog._number(DATA.table.get("bookshelf_radius"),1,12,true) or not ContentCatalog._number(DATA.table.get("vanilla_power"),1,15,true):return false
	if not DATA.get("anvil") is Dictionary or not DATA.get("enchantability") is Dictionary or not DATA.get("armor_enchantability") is Dictionary or not DATA.get("repair_ingredients") is Dictionary:return false
	var anvil: Dictionary=DATA.anvil
	if not ContentCatalog._number(anvil.get("maximum_cost"),1,1000,true) or not ContentCatalog._number(anvil.get("material_repair_fraction"),.01,1) or not ContentCatalog._number(anvil.get("combine_bonus"),0,1) or not ContentCatalog._number(anvil.get("damage_chance"),0,1):return false
	for values in [DATA.enchantability,DATA.armor_enchantability]:
		for key in values:
			if not ContentCatalog._number(values[key],1,100,true):return false
	for ingredients in DATA.repair_ingredients.values():
		if not ingredients is Array:return false
		for key in ingredients:
			if not key is String or BlockDatabase.id_for(key)==0:return false
	for key in definitions():
		if not definitions()[key] is Dictionary:return false
		var r: Dictionary=definitions()[key]
		if not r.get("name") is String or not ContentCatalog._number(r.get("maximum"),1,5,true) or not ContentCatalog._number(r.get("weight"),1,100,true) or not r.get("targets") is Array or not r.get("exclusive") is Array or not ContentCatalog._number(r.get("anvil_cost"),1,100,true) or not ContentCatalog._vector(r.get("min_cost"),2,0,100,true) or not ContentCatalog._vector(r.get("max_cost"),2,0,100,true):return false
		for target in r.targets:
			if target not in ["pickaxe","axe","shovel","hoe","sword","durable","armor","bow"]:return false
		for other in r.exclusive:
			if not definitions().has(other):return false
	for key in DROPS:
		var rule: Variant=DROPS[key]
		if BlockDatabase.id_for(key)==0 or not rule is Dictionary or not rule.get("fortune") in ["none","ore","redstone","gravel","crop","limited"]:return false
		if rule.has("silk") and BlockDatabase.id_for(rule.silk)==0:return false
		if rule.has("base_count") and not ContentCatalog._vector(rule.base_count,2,1,64,true):return false
		if rule.get("fortune")=="crop":
			if not rule.get("crop") is Dictionary:return false
			var crop: Dictionary=rule.crop
			if not crop.get("item") is String or BlockDatabase.id_for(crop.item)==0 or not ContentCatalog._number(crop.get("base"),1,32,true) or not ContentCatalog._number(crop.get("trials"),0,16,true) or not ContentCatalog._number(crop.get("probability"),0,1) or not crop.get("fixed") is Array:return false
			for fixed in crop.fixed:
				if not fixed is Dictionary or not fixed.get("item") is String or BlockDatabase.id_for(fixed.item)==0 or not ContentCatalog._number(fixed.get("count"),1,64,true):return false
	return true
