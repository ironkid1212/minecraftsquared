class_name ToolDatabase
extends RefCounted

## Tools refer to stable item keys; all definitions and mining rules live in content.json.
static var TOOLS: Dictionary = _load_tools()


static func _load_tools() -> Dictionary:
	var result: Dictionary = {}
	for id in BlockDatabase.BLOCKS:
		var tool: Variant = BlockDatabase.BLOCKS[id].get("tool")
		if tool is Dictionary:
			result[id] = tool
	return result


static func max_durability(id: int) -> int:
	if BlockDatabase.BLOCKS.get(id,{}).has("utility"):return int(BlockDatabase.BLOCKS[id].utility.durability)
	return int(TOOLS.get(id, {}).get("durability",BlockDatabase.BLOCKS.get(id,{}).get("armor",{}).get("durability",BlockDatabase.BLOCKS.get(id,{}).get("shield",{}).get("durability",BlockDatabase.BLOCKS.get(id,{}).get("ranged",{}).get("durability",0)))))


static func initial_durability(id: int, remaining: int = -1) -> int:
	var maximum: int = max_durability(id)
	return (maximum if remaining < 0 else clampi(remaining, 1, maximum)) if maximum > 0 else 0


static func matches(block_id: int, tool_id: int) -> bool:
	var mining: Dictionary = BlockDatabase.BLOCKS.get(block_id, {}).get("mining", {})
	var tool: Dictionary = TOOLS.get(tool_id, {})
	return not tool.is_empty() and tool["kind"] == mining.get("tool", "") 


static func can_harvest(block_id: int, tool_id: int) -> bool:
	var mining: Dictionary = BlockDatabase.BLOCKS.get(block_id, {}).get("mining", {})
	return not mining.get("requires_tool", false) or (matches(block_id, tool_id) and int(TOOLS[tool_id]["tier"]) >= int(mining.get("minimum_tier", 0)))


## Speed and harvest eligibility are separate, just as in Java Edition.
static func mining_speed(block_id: int, tool_id: int) -> float:
	var mining: Dictionary = BlockDatabase.BLOCKS.get(block_id, {}).get("mining", {})
	var tool: Dictionary = TOOLS.get(tool_id, {})
	var overrides: Dictionary = mining.get("speed_overrides", {})
	if overrides.has(tool.get("kind", "")):
		return float(overrides[tool["kind"]])
	return float(tool["mining_speed"]) if matches(block_id, tool_id) else 1.0

static func mining_time(block_id: int, tool_id: int, grounded: bool = true, underwater: bool = false, metadata: Dictionary = {}) -> float:
	var block: Dictionary = BlockDatabase.BLOCKS.get(block_id, {})
	if not block.get("diggable", false): return INF
	var hardness: float = float(block.get("hardness", 0.0))
	if hardness == 0: return 0.0
	var speed: float = mining_speed(block_id, tool_id)
	var efficiency: int=EnchantmentDatabase.level(metadata,"efficiency")
	if speed>1 and efficiency>0:speed+=efficiency*efficiency+1
	speed /= (1.0 if grounded else 5.0)
	if underwater: speed /= 5.0
	var divisor: float = 30.0 if can_harvest(block_id, tool_id) else 100.0
	var ticks: int = ceili(hardness * divisor / speed - 0.000001)
	return ticks / 20.0
