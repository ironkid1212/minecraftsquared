class_name NBT
extends RefCounted

## Typed NBT nodes: {t: type ID, v: value}. Item metadata is a compound's children.
## Longs use decimal strings so JSON world saves cannot lose 64-bit precision.
const BYTE=1
const SHORT=2
const INT=3
const LONG=4
const FLOAT=5
const DOUBLE=6
const BYTE_ARRAY=7
const STRING=8
const LIST=9
const COMPOUND=10
const INT_ARRAY=11
const LONG_ARRAY=12
const MAX_BYTES=16384
static var error: String=""

static func node(type: int, value: Variant) -> Dictionary: return {"t":type,"v":value}
static func value(tags: Dictionary, key: String, fallback: Variant = null) -> Variant:
	return tags.get(key,{}).get("v",fallback)
static func same(a: Dictionary,b: Dictionary) -> bool:
	if a.is_empty() and b.is_empty():return true
	return snbt(node(COMPOUND,a))==snbt(node(COMPOUND,b))
static func valid_tags(tags: Variant) -> bool:
	return tags is Dictionary and JSON.stringify(tags).to_utf8_buffer().size()<=MAX_BYTES and valid(node(COMPOUND,tags))
static func valid(tag: Variant, depth: int = 0) -> bool:
	if depth>16 or not tag is Dictionary or tag.size()!=2 or not ContentCatalog._number(tag.get("t"),1,12,true): return false
	var v: Variant=tag.get("v")
	match int(tag["t"]):
		BYTE: return ContentCatalog._number(v,-128,127,true)
		SHORT: return ContentCatalog._number(v,-32768,32767,true)
		INT: return ContentCatalog._number(v,-2147483648,2147483647,true)
		LONG: return v is String and v.length()<=20 and v.is_valid_int() and str(int(v))==v
		FLOAT: return ContentCatalog._number(v,-3.4028234663852886e38,3.4028234663852886e38)
		DOUBLE: return ContentCatalog._number(v,-1.7976931348623157e308,1.7976931348623157e308)
		STRING: return v is String and v.length()<=8192
		COMPOUND:
			if not v is Dictionary or v.size()>128: return false
			for key in v:
				if not key is String or key.length()>256 or not valid(v[key],depth+1): return false
			return true
		LIST:
			if not v is Array or v.size()>1024:return false
			var type: int=int(v[0].get("t",0)) if not v.is_empty() and v[0] is Dictionary else 0
			for item in v:
				if not valid(item,depth+1) or int(item["t"])!=type:return false
			return true
		BYTE_ARRAY,INT_ARRAY,LONG_ARRAY:
			if not v is Array or v.size()>1024:return false
			for item in v:
				if not valid(node(BYTE if int(tag["t"])==BYTE_ARRAY else INT if int(tag["t"])==INT_ARRAY else LONG,item),depth+1):return false
			return true
	return false

class Reader extends RefCounted:
	var text: String
	var at: int=0
	var failure: String=""
	func peek() -> String:return text[at] if at<text.length() else ""
	func space() -> void:
		while peek() in [" ","\t","\n","\r"] and at<text.length():at+=1
	func token() -> String:
		space()
		var quote: String=peek()
		if quote in ["\"","'"]:
			at+=1
			var result: String=""
			while at<text.length():
				var ch: String=text[at];at+=1
				if ch==quote:return result
				if ch=="\\" and at<text.length():
					ch=text[at];at+=1
					ch="\n" if ch=="n" else "\t" if ch=="t" else ch
				result+=ch
			failure="Unterminated quoted string."
			return result
		var start: int=at
		while at<text.length() and peek() not in [",","}","]"," ","\t","\n","\r"]:at+=1
		return text.substr(start,at-start)
	func read(depth: int = 0) -> Dictionary:
		space()
		if depth>16 or at>=text.length():failure="Missing value or excessive nesting.";return {}
		var ch: String=peek()
		if ch=="{":
			at+=1;space()
			var compound: Dictionary={}
			while peek()!="}" and at<text.length() and failure.is_empty():
				var key: String=""
				if peek() in ["\"","'"]:key=token()
				else:
					var start: int=at
					while at<text.length() and peek() not in [":"," ","\t","\n"]:at+=1
					key=text.substr(start,at-start)
				space()
				if peek()!=":" or key.is_empty() or compound.has(key):failure="Expected a unique key followed by ':'.";return {}
				at+=1;compound[key]=read(depth+1);space()
				if peek()==",":at+=1;space()
				elif peek()!="}":failure="Expected ',' or '}'.";return {}
			if peek()!="}":failure="Unclosed compound.";return {}
			at+=1;return NBT.node(NBT.COMPOUND,compound)
		if ch=="[":
			at+=1;space()
			var type: int=NBT.LIST
			if at+1<text.length() and text[at+1]==";":
				type=NBT.BYTE_ARRAY if peek().to_upper()=="B" else NBT.INT_ARRAY if peek().to_upper()=="I" else NBT.LONG_ARRAY if peek().to_upper()=="L" else 0
				at+=2
			var array: Array=[];space()
			while peek()!="]" and at<text.length() and failure.is_empty():
				var item: Dictionary=read(depth+1)
				array.append(item if type==NBT.LIST else item.get("v"))
				space()
				if peek()==",":at+=1;space()
				elif peek()!="]":failure="Expected ',' or ']'.";return {}
			if peek()!="]":failure="Unclosed list.";return {}
			at+=1;return NBT.node(type,array)
		var quoted: bool=ch in ["\"","'"]
		var raw: String=token()
		if not quoted:
			if raw in ["true","false"]:return NBT.node(NBT.BYTE,1 if raw=="true" else 0)
			var suffix: String=raw.right(1).to_lower()
			var numeric: String=raw.left(-1)
			if suffix in ["b","s","l"] and numeric.is_valid_int():return NBT.node(NBT.BYTE if suffix=="b" else NBT.SHORT if suffix=="s" else NBT.LONG,numeric if suffix=="l" else int(numeric))
			if suffix in ["f","d"] and numeric.is_valid_float():return NBT.node(NBT.FLOAT if suffix=="f" else NBT.DOUBLE,float(numeric))
			if raw.is_valid_int():return NBT.node(NBT.INT,int(raw))
			if raw.is_valid_float():return NBT.node(NBT.DOUBLE,float(raw))
		return NBT.node(NBT.STRING,raw)

static func parse(source: String) -> Dictionary:
	error=""
	if source.to_utf8_buffer().size()>MAX_BYTES:error="Tag data exceeds 16 KiB.";return {}
	var reader:=Reader.new();reader.text=source
	var tag: Dictionary=reader.read();reader.space()
	if not reader.failure.is_empty() or reader.at!=source.length() or not valid(tag):
		error=reader.failure if not reader.failure.is_empty() else "Invalid type, range, list or trailing data."
		return {}
	return tag

static func snbt(tag: Dictionary) -> String:
	var v: Variant=tag.get("v")
	match int(tag.get("t",0)):
		COMPOUND:
			var parts:=PackedStringArray();var keys: Array=v.keys();keys.sort()
			for key in keys:parts.append(JSON.stringify(key)+":"+snbt(v[key]))
			return "{"+",".join(parts)+"}"
		STRING:return JSON.stringify(v)
		LIST:
			var parts:=PackedStringArray()
			for item in v:parts.append(snbt(item))
			return "["+",".join(parts)+"]"
		BYTE_ARRAY,INT_ARRAY,LONG_ARRAY:
			var parts:=PackedStringArray()
			for item in v:parts.append(str(item)+"l" if int(tag["t"])==LONG_ARRAY else str(int(item))+ ("b" if int(tag["t"])==BYTE_ARRAY else ""))
			return "["+ ("B" if int(tag["t"])==BYTE_ARRAY else "I" if int(tag["t"])==INT_ARRAY else "L")+";"+",".join(parts)+"]"
	var type: int=int(tag.get("t",0))
	return str(int(v) if type in [BYTE,SHORT,INT] else v)+({BYTE:"b",SHORT:"s",LONG:"l",FLOAT:"f",DOUBLE:"d"}.get(type,""))

static func _string(buffer: StreamPeerBuffer, value: String) -> void:
	var bytes: PackedByteArray=value.to_utf8_buffer();buffer.put_u16(bytes.size());buffer.put_data(bytes)
static func _payload(buffer: StreamPeerBuffer, tag: Dictionary) -> void:
	var type: int=int(tag["t"]);var v: Variant=tag["v"]
	match type:
		BYTE:buffer.put_8(int(v))
		SHORT:buffer.put_16(int(v))
		INT:buffer.put_32(int(v))
		LONG:buffer.put_64(int(v))
		FLOAT:buffer.put_float(float(v))
		DOUBLE:buffer.put_double(float(v))
		STRING:_string(buffer,str(v))
		COMPOUND:
			for key in v:buffer.put_u8(int(v[key]["t"]));_string(buffer,str(key));_payload(buffer,v[key])
			buffer.put_u8(0)
		LIST:
			buffer.put_u8(int(v[0]["t"]) if not v.is_empty() else 0);buffer.put_32(v.size())
			for item in v:_payload(buffer,item)
		BYTE_ARRAY,INT_ARRAY,LONG_ARRAY:
			buffer.put_32(v.size())
			for item in v:_payload(buffer,node(BYTE if type==BYTE_ARRAY else INT if type==INT_ARRAY else LONG,item))
static func encode(tags: Dictionary, root_name: String = "") -> PackedByteArray:
	if not valid_tags(tags):error="Invalid compound.";return PackedByteArray()
	var buffer:=StreamPeerBuffer.new();buffer.big_endian=true
	buffer.put_u8(COMPOUND);_string(buffer,root_name);_payload(buffer,node(COMPOUND,tags));return buffer.data_array

class BinaryReader extends RefCounted:
	var buffer:=StreamPeerBuffer.new()
	var failure: String=""
	func available(count: int) -> bool:
		if count<0 or buffer.get_available_bytes()<count:failure="Truncated NBT.";return false
		return true
	func string_value() -> String:
		if not available(2):return ""
		var count: int=buffer.get_u16()
		if not available(count):return ""
		return buffer.get_data(count)[1].get_string_from_utf8()
	func read(type: int,depth: int = 0) -> Dictionary:
		if depth>16:failure="NBT nesting exceeds 16.";return {}
		var sizes: Dictionary={1:1,2:2,3:4,4:8,5:4,6:8}
		if sizes.has(type) and not available(int(sizes[type])):return {}
		match type:
			NBT.BYTE:return NBT.node(type,buffer.get_8())
			NBT.SHORT:return NBT.node(type,buffer.get_16())
			NBT.INT:return NBT.node(type,buffer.get_32())
			NBT.LONG:return NBT.node(type,str(buffer.get_64()))
			NBT.FLOAT:return NBT.node(type,buffer.get_float())
			NBT.DOUBLE:return NBT.node(type,buffer.get_double())
			NBT.STRING:return NBT.node(type,string_value())
			NBT.COMPOUND:
				var value: Dictionary={}
				while failure.is_empty():
					if not available(1):return {}
					var child: int=buffer.get_u8()
					if child==0:return NBT.node(type,value)
					var key: String=string_value()
					if value.has(key) or value.size()>=128:failure="Duplicate/excessive NBT keys.";return {}
					value[key]=read(child,depth+1)
			NBT.LIST,NBT.BYTE_ARRAY,NBT.INT_ARRAY,NBT.LONG_ARRAY:
				if not available(5 if type==NBT.LIST else 4):return {}
				var child: int=buffer.get_u8() if type==NBT.LIST else NBT.BYTE if type==NBT.BYTE_ARRAY else NBT.INT if type==NBT.INT_ARRAY else NBT.LONG
				var count: int=buffer.get_32()
				if count<0 or count>1024:failure="Invalid NBT array length.";return {}
				var value: Array=[]
				for i in range(count):
					var tag: Dictionary=read(child,depth+1)
					if not failure.is_empty():return {}
					value.append(tag if type==NBT.LIST else tag.get("v"))
				return NBT.node(type,value)
		failure="Unknown NBT type.";return {}
static func decode(bytes: PackedByteArray) -> Dictionary:
	error=""
	if bytes.size()>MAX_BYTES or bytes.size()<3:error="Invalid NBT size.";return {}
	var reader:=BinaryReader.new();reader.buffer.big_endian=true;reader.buffer.data_array=bytes
	if reader.buffer.get_u8()!=COMPOUND:error="NBT root must be a compound.";return {}
	reader.string_value()
	var result: Dictionary=reader.read(COMPOUND)
	if not reader.failure.is_empty() or reader.buffer.get_available_bytes()!=0 or not valid(result):
		error=reader.failure if not reader.failure.is_empty() else "Invalid NBT payload."
		return {}
	return result
