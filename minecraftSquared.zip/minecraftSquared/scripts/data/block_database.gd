class_name BlockDatabase
extends RefCounted

# Legacy aliases for existing scripts only. New content never needs an enum edit.
enum ID {
	AIR = 0,
	GRASS = 1,
	DIRT = 2,
	STONE = 3,
	OAK_LOG = 4,
	OAK_LEAVES = 5,
	TORCH = 6,
	OAK_PLANKS = 7,
	STICK = 8,
	CRAFTING_TABLE = 9,
	WOODEN_PICKAXE = 10,
	WOODEN_AXE = 11,
	WOODEN_SHOVEL = 12,
}

const DESTROY_START := Vector2i(14,10)
const DESTROY_STAGE_COUNT: int = 10
static var BLOCKS: Dictionary = _load_blocks()
static var UPDATE_RULES: Dictionary = _load_update_rules()
static var _keys: Dictionary = {}

static func id_for(key: String) -> int:
	if key.is_empty() or key == "air":
		return ID.AIR
	if _keys.is_empty():
		for id in BLOCKS:
			_keys[str(BLOCKS[id]["key"])] = id
	if not _keys.has(key):
		DataFile.fail("Unknown content key: " + key)
		return ID.AIR
	return _keys[key]

static func roll_drops(id: int, rng: RandomNumberGenerator = null, tool_id: int = 0) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var rule: Dictionary = UPDATE_RULES.get("blocks", {}).get(str(BLOCKS.get(id, {}).get("key", "")), {})
	for tag in rule.get("self_drop_tool_tags", []):
		if has_tag(tool_id, str(tag)):
			return [{"id": id, "count": 1}]
	var drops: Array = BLOCKS.get(id, {}).get("drops", [])
	for drop in drops:
		var chance: float = float(drop.get("chance", 1.0))
		if chance >= 1.0 or (chance > 0 and (rng.randf() if rng != null else randf()) < chance):
			var amount: Variant=drop.get("count",1)
			var count: int=(rng.randi_range(int(amount[0]),int(amount[1])) if rng!=null else randi_range(int(amount[0]),int(amount[1]))) if amount is Array else int(amount)
			result.append({"id": int(drop["id"]) if drop.has("id") else id_for(str(drop["item"])), "count": count})
	return result

static func _load_update_rules() -> Dictionary:
	var rules: Dictionary = {}
	for record in BLOCKS.values():
		if not record.get("updates", {}).is_empty(): rules[record["key"]] = record["updates"]
	return {"blocks": rules}

static func has_tag(id: int, tag: String) -> bool:
	return tag in BLOCKS.get(id,{}).get("tags",[])

static func in_category(category: String) -> PackedInt32Array:
	var result := PackedInt32Array()
	for id in BLOCKS:
		if BLOCKS[id]["category"] == category:
			result.append(id)
	return result


static func _load_blocks() -> Dictionary:
	return ContentCatalog.build(DataFile.object_from("res://data/content.json"))
