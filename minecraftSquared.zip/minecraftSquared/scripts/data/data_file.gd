class_name DataFile
extends RefCounted

static var errors: PackedStringArray = []

static func fail(message: String) -> void:
	errors.append(message)
	push_error(message)


static func read_json(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		fail("Missing data file: " + path)
		return null
	var parser := JSON.new()
	if parser.parse(FileAccess.get_file_as_string(path)) != OK:
		fail("%s line %d: %s" % [path, parser.get_error_line() + 1, parser.get_error_message()])
		return null
	return parser.data


static func array_from(path: String) -> Array:
	var value: Variant = read_json(path)
	if not value is Array:
		fail(path + " must contain a JSON array.")
		return []
	return value


static func object_from(path: String) -> Dictionary:
	var value: Variant = read_json(path)
	if not value is Dictionary:
		fail(path + " must contain a JSON object.")
		return {}
	return value
