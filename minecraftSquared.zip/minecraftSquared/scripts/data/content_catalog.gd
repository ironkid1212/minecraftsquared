class_name ContentCatalog
extends RefCounted

## One authoritative record per item, inspired by Paper Minecraft's _BLOCK_DATA.
## Dictionaries are compiled once into the fast fields consumed by existing systems.
const FIELDS := ["id","key","name","extends","tile","atlas","icon","collision","placement","background",
	"hardness","diggable","max_stack","category","tags","tint","light","mining","tool",
	"drops","root","crafting_group","interaction","held","updates","platform_height","waterloggable","moisture_tiles","biome_tint","biome_overlay","collision_height","render_offset","collision_boxes","building","internal","armor","storage","blast_resistance","shield","food","ranged","experience","climbable","fence","gate","door","spawn_mob","skull","slipperiness","creative","creative_tabs","utility","movement_multiplier","potion"]

static func merge(base: Dictionary, patch: Dictionary) -> Dictionary:
	var result: Dictionary = base.duplicate(true)
	for key in patch:
		if key == "extends":
			continue
		if patch[key] is Dictionary and result.get(key) is Dictionary:
			result[key] = merge(result[key],patch[key])
		else:
			result[key] = patch[key].duplicate(true) if patch[key] is Dictionary or patch[key] is Array else patch[key]
	return result

static func _template(key: String, templates: Dictionary, chain: Array) -> Dictionary:
	if key in chain or not templates.has(key) or not templates[key] is Dictionary:
		DataFile.fail("content.json: missing/invalid/cyclic template: " + str(chain + [key]))
		return {}
	var record: Dictionary = templates[key]
	if record.has("id") or record.has("key"):
		DataFile.fail("content.json: templates cannot assign item IDs or keys: " + key)
	var base: Dictionary = {}
	if record.has("extends"):
		if not record["extends"] is String:
			DataFile.fail("content.json: extends must name a template: " + key)
		else:
			base = _template(record["extends"],templates,chain + [key])
	return merge(base,record)

static func _number(value: Variant, minimum: float, maximum: float = INF, integer: bool = false) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and value >= minimum and value <= maximum and (not integer or float(value) == int(value))

static func _vector(value: Variant, size: int, minimum: float = -INF, maximum: float = INF, integer: bool = false) -> bool:
	if not value is Array or value.size() != size:
		return false
	for component in value:
		if not _number(component,minimum,maximum,integer):
			return false
	return true

static func _known(record: Dictionary, fields: Array, label: String) -> bool:
	var valid: bool = true
	for key in record:
		if key not in fields:
			DataFile.fail("%s: unknown field '%s'. Check the spelling; new behaviors need engine support." % [label,key])
			valid = false
	return valid

static func _valid(record: Dictionary, label: String) -> bool:
	var valid: bool = _known(record,FIELDS,label)
	if record.has("potion") and not record.potion is String:valid=false
	if record.has("movement_multiplier") and not _number(record.movement_multiplier,.05,2):valid=false
	if record.has("utility") and (not record.utility is Dictionary or record.utility.get("kind")!="igniter" or not _number(record.utility.get("durability"),1,10000,true)):valid=false
	if record.has("background") and not record.background is bool:valid=false
	if not record.get("waterloggable",false) is bool: valid = false
	if not record.get("internal",false) is bool: valid=false
	if not record.get("creative",false) is bool or not record.get("creative_tabs",[]) is Array:valid=false
	else:
		for tab in record.get("creative_tabs",[]):
			if not tab is String or not str(tab).is_valid_identifier():valid=false
	if record.has("spawn_mob") and (not record.spawn_mob is String or str(record.spawn_mob).is_empty()):valid=false
	if record.has("slipperiness") and not _number(record.slipperiness,.1,.999):valid=false
	if record.has("skull") and (not record.skull is Dictionary or record.skull.get("mount") not in ["floor","left","right"]):valid=false
	if record.has("door"):
		var door: Variant=record.door
		if not door is Dictionary or not _known(door,["item","upper","open","hinge"],label+".door") or not door.get("upper") is bool or not door.get("open") is bool or not door.get("item") is String or not _number(door.get("hinge",1),-1,1,true) or int(door.get("hinge",1)) not in [-1,1]:valid=false
	if record.has("gate"):
		var gate: Variant=record.gate
		if not gate is Dictionary or not _known(gate,["open","closed","opened","opened_left","swing"],label+".gate") or not gate.get("open") is bool or not gate.get("closed") is String or not gate.get("opened") is String or not gate.get("opened_left") is String or not _number(gate.get("swing",1),-1,1,true) or int(gate.get("swing",1)) not in [-1,1]:valid=false
	if record.has("fence"):
		var fence: Variant=record.fence
		if not fence is Dictionary or not _known(fence,["group","tiles","collision_height"],label+".fence"):valid=false
		elif not fence.get("group") is String or not fence.get("tiles") is Array or fence.tiles.size()!=4 or not _number(fence.get("collision_height"),16,24,true) or record.get("collision") not in ["solid","platform"]:valid=false
		else:
			for tile in fence.tiles:
				if not _vector(tile,2,0,INF,true):valid=false
	if record.has("climbable"):
		if not record.climbable is Dictionary or record.climbable.get("support") not in ["wall","hanging"] or record.get("collision")!="none":valid=false
	if record.has("food"):
		var food: Variant=record.food
		if not food is Dictionary or not _number(food.get("nutrition"),0,20,true) or not _number(food.get("saturation"),0,40) or not _number(food.get("seconds"),.05,10):valid=false
		elif food.has("remainder") and not food.remainder is String:valid=false
	if record.has("ranged"):
		var ranged: Variant=record.ranged
		if not ranged is Dictionary or record.get("max_stack")!=1 or not _number(ranged.get("durability"),1,10000,true) or not _number(ranged.get("speed"),1,2000) or not _number(ranged.get("gravity"),0,2000) or not _number(ranged.get("charge_seconds"),.1,10) or not _number(ranged.get("minimum_charge"),.05,10):valid=false
	if record.has("experience") and not _vector(record.experience,2,0,1000,true):valid=false
	if record.has("armor"):
		var armor: Variant=record["armor"]
		if not armor is Dictionary or not _known(armor,["slot","points","toughness","durability","texture"],label+".armor"):valid=false
		elif armor.get("slot") not in ["head","chest","legs","feet"] or not _number(armor.get("points"),0,20,true) or not _number(armor.get("toughness"),0,20) or not _number(armor.get("durability"),1,10000,true) or not armor.get("texture") is String or record.get("max_stack")!=1:valid=false
	if record.has("storage"):
		var storage: Variant=record["storage"]
		if not storage is Dictionary or not _known(storage,["kind","slots","pairs","left_tile","right_tile"],label+".storage"):valid=false
		elif storage.get("kind") not in ["chest","barrel","shulker"] or not _number(storage.get("slots"),27,27,true) or not storage.get("pairs") is bool:valid=false
		else:
			for field in ["left_tile","right_tile"]:
				if storage.has(field) and not _vector(storage[field],2,0,INF,true):valid=false
	if record.has("collision_boxes"):
		if not record["collision_boxes"] is Array or record["collision_boxes"].is_empty() or record["collision_boxes"].size()>8: valid=false
		else:
			for box in record["collision_boxes"]:
				if not _vector(box,4,0,16,true): valid=false
				elif box[2]<=0 or box[3]<=0 or box[0]+box[2]>16 or box[1]+box[3]>16: valid=false
	if record.has("building"):
		var shape: Variant=record["building"]
		if not shape is Dictionary or not _known(shape,["kind","material","half","facing","item"],label+".building"): valid=false
		elif shape.get("kind") not in ["slab","stairs"] or shape.get("half") not in ["bottom","top","double"] or shape.get("facing") not in ["left","right"] or not shape.get("item") is String or not shape.get("material") is String: valid=false
	if not _number(record.get("collision_height",16),1,24 if record.has("gate") else 16,true): valid=false
	if record.has("render_offset") and not _vector(record["render_offset"],2,-8,8,true): valid=false
	if record.get("biome_tint","") not in ["","grass","foliage","birch","spruce"]: valid=false
	if record.has("biome_overlay") and not _vector(record["biome_overlay"],2,0,INF,true): valid=false
	if record.has("moisture_tiles"):
		if not record["moisture_tiles"] is Array or record["moisture_tiles"].size()!=8: valid=false
		else:
			for tile in record["moisture_tiles"]:
				if not _vector(tile,2,0,INF,true): valid=false
	if record.has("updates") and not record["updates"] is Dictionary:
		DataFile.fail(label + ".updates must be an object.")
		valid = false
	if not record.get("name") is String or str(record.get("name","")).strip_edges().is_empty():
		valid = false
	if not _vector(record.get("tile"),2,0,INF,true) or not record.get("atlas") is String or not AtlasDatabase.ATLASES.has(record.get("atlas")):
		valid = false
	if record.get("collision") not in ["solid","platform","none"] or record.get("placement") not in ["block","attached","none"]:
		valid = false
	if record.get("placement") == "none" and record.get("collision") != "none":
		valid = false
	if record.get("placement") != "none" and record.get("atlas") != "blocks":
		DataFile.fail(label + ": placed world sprites must use the blocks atlas; icon may use another atlas.")
		valid = false
	if not _number(record.get("hardness"),0) or not _number(record.get("max_stack"),1,999,true) or not record.get("diggable") is bool:
		valid = false
	if not _vector(record.get("tint"),4,0,1) or not record.get("category") is String or str(record.get("category","")).is_empty():
		valid = false
	if not record.get("tags") is Array:
		valid = false
	else:
		for tag in record["tags"]:
			if not tag is String or tag.is_empty():
				valid = false
	for field in ["root","crafting_group"]:
		if not record.get(field) is String:
			valid = false
	if not _number(record.get("platform_height",16),1,16,true): valid = false
	if not _number(record.get("blast_resistance",0),0,INF):valid=false
	if record.get("interaction") not in ["","crafting_table","furnace","bed","storage","spawner","enchanting","anvil","grindstone","brewing","end_portal","fence_gate","door"]:
		DataFile.fail(label + ": unsupported interaction action: " + str(record.get("interaction")))
		valid = false
	var light: Variant = record.get("light")
	if not light is Dictionary:
		valid = false
	elif not _known(light,["absorption","emission"],label+".light") or not _number(light.get("absorption"),0,16,true) or not _number(light.get("emission"),0,15,true):
		valid = false
	var mining: Variant = record.get("mining")
	if not mining is Dictionary:
		valid = false
	elif not _known(mining,["tool","requires_tool","minimum_tier","speed_overrides"],label+".mining") or not mining.get("tool") is String or not mining.get("requires_tool") is bool or not _number(mining.get("minimum_tier"),0,INF,true):
		valid = false
	elif mining["requires_tool"] and str(mining["tool"]).is_empty():
		valid = false
	if mining is Dictionary and mining.has("speed_overrides"):
		if not mining["speed_overrides"] is Dictionary:
			valid = false
		else:
			for kind in mining["speed_overrides"]:
				if not kind is String or not _number(mining["speed_overrides"][kind],0.001): valid = false
	if record.has("shield"):
		var shield: Variant=record.shield
		if not shield is Dictionary or not _known(shield,["durability","delay","move_factor","wear_threshold","disable_seconds"],label+".shield"):valid=false
		elif not _number(shield.get("durability"),1,10000,true) or not _number(shield.get("delay"),0,2) or not _number(shield.get("move_factor"),.1,1) or not _number(shield.get("wear_threshold"),0,100) or not _number(shield.get("disable_seconds"),0,30) or record.get("max_stack")!=1:valid=false
	var tool: Variant = record.get("tool")
	if tool != null:
		if not tool is Dictionary:
			valid = false
		elif not _known(tool,["kind","tier","durability","mining_speed","wear_per_block","attack_damage","attack_speed"],label+".tool") or not tool.get("kind") is String or str(tool.get("kind","")).is_empty() or not _number(tool.get("tier"),0,INF,true) or not _number(tool.get("durability"),1,2147483647,true) or not _number(tool.get("wear_per_block"),1,2147483647,true) or not _number(tool.get("mining_speed"),0.001) or not _number(tool.get("attack_damage"),0) or not _number(tool.get("attack_speed"),0.001):
			valid = false
		if record.get("placement") != "none" or record.get("max_stack") != 1:
			DataFile.fail(label + ": tools need placement:none and max_stack:1 (use a tool template).")
			valid = false
	var held: Variant = record.get("held")
	if not held is Dictionary:
		valid = false
	elif not _known(held,["profile","size","grip","offset","rotation_degrees","flip_x","flip_y"],label+".held") or not held.get("profile") is String:
		valid = false
	else:
		for field in ["flip_x","flip_y"]:
			if held.has(field) and not held[field] is bool:
				valid = false
		if held.has("size") and not _number(held["size"],1,32):
			valid = false
		if held.has("rotation_degrees") and not _number(held["rotation_degrees"],-INF):
			valid = false
		if held.has("grip") and not _vector(held["grip"],2,0,1):
			valid = false
		if held.has("offset") and not _vector(held["offset"],2):
			valid = false
	var icon: Variant = record.get("icon")
	if icon != null:
		if not icon is Dictionary:
			valid = false
		elif not _known(icon,["atlas","tile","tint"],label+".icon") or not icon.get("atlas",record.get("atlas")) is String or not AtlasDatabase.ATLASES.has(icon.get("atlas",record.get("atlas"))) or not _vector(icon.get("tile",record.get("tile")),2,0,INF,true) or not _vector(icon.get("tint",record.get("tint")),4,0,1):
			valid = false
	var drops: Variant = record.get("drops")
	if not drops is Array:
		valid = false
	else:
		for drop in drops:
			if not drop is Dictionary:
				valid = false
			elif not _known(drop,["item","count","chance"],label+".drops") or not drop.get("item") is String or not (_number(drop.get("count",1),1,2147483647,true) or _vector(drop.get("count"),2,1,64,true) and drop.count[1]>=drop.count[0]) or not _number(drop.get("chance",1.0),0,1):
				valid = false
	if not valid:
		DataFile.fail(label + ": invalid properties. See docs/content_catalog.md for valid types and ranges.")
	return valid

static func build(document: Dictionary, label: String = "content.json") -> Dictionary:
	var result: Dictionary = {}
	var keys: Dictionary = {}
	if not _known(document,["version","defaults","templates","entries"],label) or document.get("version") != 1 or not document.get("defaults") is Dictionary or not document.get("templates") is Dictionary or not document.get("entries") is Array:
		DataFile.fail(label + ": version:1, defaults object, templates object and entries array required.")
		return result
	var defaults: Dictionary = document["defaults"]
	var templates: Dictionary = document["templates"]
	_known(defaults,FIELDS,label+" defaults")
	for key in templates:
		var resolved: Dictionary = _template(str(key),templates,[])
		_known(resolved,FIELDS,label+" template "+str(key))
	var profiles: Dictionary = {}
	for profile in DataFile.array_from("res://data/held_item_profiles.json"):
		if profile is Dictionary and profile.get("key") is String:
			profiles[profile["key"]] = true
	for entry in document["entries"]:
		if not entry is Dictionary or not _number(entry.get("id"),1,2147483647,true) or not entry.get("key") is String:
			DataFile.fail(label + ": every entry requires a positive integer id and a string key.")
			continue
		var id: int = int(entry["id"])
		var key: String = entry["key"]
		if not key.is_valid_identifier() or key != key.to_lower() or key == "air" or keys.has(key) or result.has(id):
			DataFile.fail(label + ": duplicate/invalid/reserved key or ID: " + key)
			continue
		var record: Dictionary = defaults.duplicate(true)
		if entry.has("extends"):
			if not entry["extends"] is String:
				DataFile.fail(label + ": extends must be a template name: " + key)
				continue
			record = merge(record,_template(entry["extends"],templates,[]))
		record = merge(record,entry)
		if not _valid(record,label+" / "+key):
			continue
		if not profiles.has(record["held"]["profile"]):
			DataFile.fail(label + ": unknown held profile for " + key)
			continue
		var tile := Vector2i(record["tile"][0],record["tile"][1])
		var icon: Dictionary = record["icon"] if record["icon"] is Dictionary else {}
		var icon_tile: Array = icon.get("tile",record["tile"])
		var color: Array = record["tint"]
		var icon_color: Array = icon.get("tint",color)
		record["atlas_type"] = record["atlas"]
		record["atlas"] = tile
		record["icon_atlas"] = icon.get("atlas",record["atlas_type"])
		record["icon_tile"] = Vector2i(icon_tile[0],icon_tile[1])
		record["icon_tint"] = Color(icon_color[0],icon_color[1],icon_color[2],icon_color[3])
		record["tint"] = Color(color[0],color[1],color[2],color[3])
		record["solid"] = record["collision"] == "solid"
		record["platform"] = record["collision"] == "platform"
		record["platform_height"] = int(record.get("platform_height",16))
		record["placeable"] = record["placement"] != "none"
		record["wall_attach"] = record["placement"] == "attached"
		record["background"]=record.get("background",record["placeable"] and not record.get("internal",false) and not record["wall_attach"] and "fluid" not in record["tags"] and "plant" not in record["tags"] and not record.has("climbable") and record["interaction"] in ["","end_portal","crafting_table","enchanting","anvil","grindstone"])
		# Visibility and collision are independent: cutout sprites need their wall.
		record["occludes_background"] = not record.has("door") and not record.has("gate") and record["placeable"] and not "fluid" in record["tags"] and not record["wall_attach"] and record["tint"].a >= 0.999 and AtlasDatabase.tile_is_opaque(record["atlas_type"], record["atlas"])
		record["light_absorption"] = int(record["light"]["absorption"])
		record["light_level"] = int(record["light"]["emission"])
		result[id] = record
		keys[key] = id
	# References resolve only after every record exists, including forward references.
	for id in result:
		var record: Dictionary = result[id]
		if record.get("food",{}).has("remainder") and not keys.has(str(record.food.remainder)):
			DataFile.fail(label+": unknown food remainder for "+str(record.key))
		for drop in record["drops"]:
			var key: String = drop["item"]
			if key == "self":
				drop["id"] = id
			elif keys.has(key):
				drop["id"] = keys[key]
			else:
				DataFile.fail(label + ": unknown drop item '" + key + "' for " + str(record["key"]))
				drop["id"] = 0
			if not drop.get("count") is Array:drop["count"] = int(drop.get("count",1))
			drop["chance"] = float(drop.get("chance",1))
		var root: Dictionary = record
		var visited: Dictionary = {}
		while not str(root["root"]).is_empty():
			var next: String = root["root"]
			if not keys.has(next) or visited.has(next):
				DataFile.fail(label + ": unknown/cyclic crafting root for " + str(record["key"]))
				break
			visited[next] = true
			root = result[keys[next]]
		record["crafting_key"] = root["crafting_group"] if not str(root["crafting_group"]).is_empty() else int(root["id"])
	AtlasDatabase.release_pixel_images()
	return result

static func validate_sprites(records: Dictionary) -> bool:
	var valid: bool = true
	for record in records.values():
		for side in ["left_tile","right_tile"]:
			if record.get("storage",{}).has(side):
				var tile: Array=record["storage"][side]
				valid=AtlasDatabase.validate_tile("blocks",Vector2i(int(tile[0]),int(tile[1])),record["key"]+" "+side) and valid
		if record.has("biome_overlay"):
			var t: Array=record["biome_overlay"]
			valid=AtlasDatabase.validate_tile("blocks",Vector2i(int(t[0]),int(t[1])),record["key"]+" biome overlay") and valid
		for tile in record.get("moisture_tiles",[])+record.get("fence",{}).get("tiles",[]):
			valid=AtlasDatabase.validate_tile("blocks",Vector2i(int(tile[0]),int(tile[1])),record["key"]+" moisture") and valid
		valid = AtlasDatabase.validate_tile(record["atlas_type"],record["atlas"],record["key"]+" world") and valid
		valid = AtlasDatabase.validate_tile(record["icon_atlas"],record["icon_tile"],record["key"]+" inventory") and valid
	return valid
