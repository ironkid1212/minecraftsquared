class_name BrewingData
extends RefCounted
static var DATA: Dictionary=DataFile.object_from("res://data/brewing.json")
static func key_for(id: int) -> String:return str(BlockDatabase.BLOCKS.get(id,{}).get("potion",""))
static func ingredient(id: int) -> bool:
	for rule in DATA.recipes:
		if BlockDatabase.id_for(rule.ingredient)==id:return true
	return false
static func result(id: int,ingredient_id: int) -> int:
	for rule in DATA.recipes:
		if key_for(id)==rule.input and BlockDatabase.id_for(rule.ingredient)==ingredient_id:return BlockDatabase.id_for(DATA.potions[rule.output].item)
	return 0
static func consumable(id: int) -> Dictionary:
	if id==BlockDatabase.id_for("milk_bucket"):return {"nutrition":0,"saturation":0,"always_edible":true,"seconds":float(DATA.drink_seconds)}
	if key_for(id).is_empty():return BlockDatabase.BLOCKS.get(id,{}).get("food",{})
	return {"nutrition":0,"saturation":0,"always_edible":true,"seconds":float(DATA.drink_seconds)}
static func validate() -> bool:
	if DATA.get("version")!=1 or not ContentCatalog._number(DATA.get("seconds"),.05,120) or not ContentCatalog._number(DATA.get("fuel_uses"),1,100,true) or not DATA.get("potions") is Dictionary or not DATA.get("recipes") is Array:return false
	for key in DATA.potions:
		var p: Variant=DATA.potions[key]
		if not p is Dictionary or BlockDatabase.id_for(str(p.get("item","")))==0 or p.get("effect") not in ["","fire_resistance","instant_health","regeneration","speed","strength"] or not ContentCatalog._number(p.get("seconds"),0,9600) or not ContentCatalog._number(p.get("amplifier",0),0,4,true):return false
	for rule in DATA.recipes:
		if not rule is Dictionary or not DATA.potions.has(rule.get("input")) or not DATA.potions.has(rule.get("output")) or BlockDatabase.id_for(str(rule.get("ingredient","")))==0:return false
	return true
