class_name AdventureData
extends RefCounted
static var DATA: Dictionary=_load()
static func _load() -> Dictionary:
	var data: Dictionary=DataFile.object_from("res://data/adventure.json")
	var valid: bool=true
	for group in ["structures","spawners","hunger","xp"]:
		if not data.get(group) is Dictionary:valid=false
	if valid:
		var s: Dictionary=data.structures;var spawn: Dictionary=data.spawners
		valid=s.get("enabled") is bool and ContentCatalog._number(s.get("region_width"),128,1024,true) and ContentCatalog._number(s.get("chance"),0,1) and ContentCatalog._number(s.get("minimum_depth"),8,256,true) and ContentCatalog._number(s.get("maximum_depth"),s.get("minimum_depth",8),300,true) and ContentCatalog._number(s.get("monster_room_weight"),0,1) and ContentCatalog._number(s.get("mineshaft_half_width"),16,float(s.get("region_width",192))*.5-12,true) and ContentCatalog._number(s.get("mineshaft_levels"),1,5,true) and ContentCatalog._number(s.get("level_spacing"),6,16,true)
		valid=valid and ContentCatalog._number(spawn.get("activation_range"),1,32) and ContentCatalog._number(spawn.get("spawn_range"),1,8,true) and ContentCatalog._number(spawn.get("spawn_count"),1,8,true) and ContentCatalog._number(spawn.get("nearby_cap"),1,16,true) and ContentCatalog._vector(spawn.get("delay_ticks"),2,1,2400,true) and spawn.delay_ticks[0]<=spawn.delay_ticks[1] and ContentCatalog._number(spawn.get("maximum_light"),0,15,true)
		for key in ["sprint_per_block","swim_per_block","jump","sprint_jump","mine","attack","damage","heal_exhaustion"]:
			valid=valid and ContentCatalog._number(data.hunger.get(key),0,10)
		valid=valid and ContentCatalog._number(data.hunger.get("exhaustion_step"),.1,40) and ContentCatalog._number(data.hunger.get("starve_seconds"),.1,60) and ContentCatalog._number(data.hunger.get("starve_floor"),0,20)
		valid=valid and ContentCatalog._number(data.xp.get("orb_cap"),1,128,true) and ContentCatalog._number(data.xp.get("lifetime"),1,300) and ContentCatalog._number(data.xp.get("pickup_range"),.1,4) and ContentCatalog._number(data.xp.get("attract_range"),.1,16) and ContentCatalog._number(data.xp.get("mob_hostile"),0,1000,true) and ContentCatalog._vector(data.xp.get("mob_passive"),2,0,100,true)
	if not valid:DataFile.fail("adventure.json: invalid structure, spawner, food or XP rules.")
	return data
