class_name SurvivalScreen
extends Control

var survival: PlayerSurvival
var _panel: Control
var _title: Label
var _reason: Label
var _respawn: Button
var _quit: Button
var _skin := MenuSkin.new()
var _age: float = 0
const EMPTY: Texture2D = preload("res://assets/ui/hearts/container.png")
const EMPTY_FLASH: Texture2D = preload("res://assets/ui/hearts/container_blinking.png")
const FULL: Texture2D = preload("res://assets/ui/hearts/full.png")
const HALF: Texture2D = preload("res://assets/ui/hearts/half.png")
const FULL_FLASH: Texture2D = preload("res://assets/ui/hearts/full_blinking.png")
const HALF_FLASH: Texture2D = preload("res://assets/ui/hearts/half_blinking.png")
const EFFECT_BACKGROUND: Texture2D=preload("res://assets/ui/effect_background.png")
# Keep strong references: a temporary load in _draw can release the texture RID
# before the renderer consumes the draw command, leaving a white rectangle.
const EFFECT_ICONS: Dictionary={
	"wither":preload("res://assets/ui/wither.png"),
	"poison":preload("res://assets/ui/poison.png"),
	"slowness":preload("res://assets/ui/slowness.png"),
	"hunger":preload("res://assets/ui/hunger.png"),
	"regeneration":preload("res://assets/ui/regeneration.png"),
	"absorption":preload("res://assets/ui/absorption.png"),
	"resistance":preload("res://assets/ui/resistance.png"),
	"fire_resistance":preload("res://assets/ui/fire_resistance.png"),
	"speed":preload("res://assets/ui/speed.png"),
	"strength":preload("res://assets/ui/strength.png"),"levitation":preload("res://assets/ui/effects/levitation.png")}
const HARMFUL: Array[String]=["poison","slowness","hunger","wither","levitation"]
var drawn_effects: Array[Dictionary]=[]

func setup(owner_survival: PlayerSurvival) -> void:
	survival = owner_survival
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	z_index = 100
	_panel = Control.new()
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_panel)
	var tint := ColorRect.new()
	tint.color = Color(.32,.015,.015,.58)
	tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_panel.add_child(tint)
	_title = Label.new()
	_title.text = "You died!"
	_panel.add_child(_title)
	_reason = Label.new()
	_panel.add_child(_reason)
	_respawn = Button.new()
	_respawn.text = "Respawn"
	_respawn.focus_mode = Control.FOCUS_NONE
	_respawn.pressed.connect(survival.respawn)
	_panel.add_child(_respawn)
	_quit = Button.new()
	_quit.text = "Title Screen"
	_quit.focus_mode = Control.FOCUS_NONE
	_quit.pressed.connect(_to_title)
	_panel.add_child(_quit)
	_panel.hide()
	get_viewport().size_changed.connect(_layout)
	_layout()

func _layout() -> void:
	if survival == null: return
	var view: Vector2 = get_viewport_rect().size
	var scale_value: int = clampi(floori(minf(view.x/320.0,view.y/200.0)),1,3)
	var center: Vector2 = (view*.5).floor()
	_panel.theme = _skin.theme_for(scale_value)
	for label in [_title,_reason]:
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.add_theme_font_override("font",ItemDrawing.settings.font)
		label.add_theme_color_override("font_shadow_color",Color.BLACK)
		label.add_theme_constant_override("shadow_offset_x",scale_value)
		label.add_theme_constant_override("shadow_offset_y",scale_value)
	_title.add_theme_font_size_override("font_size",16*scale_value)
	_reason.add_theme_font_size_override("font_size",8*scale_value)
	_title.position = Vector2(0,center.y-62*scale_value)
	_title.size = Vector2(view.x,24*scale_value)
	_reason.position = Vector2(0,center.y-31*scale_value)
	_reason.size = Vector2(view.x,16*scale_value)
	_respawn.position = center + Vector2(-100,-2)*scale_value
	_respawn.size = Vector2(200,20)*scale_value
	_quit.position = center + Vector2(-100,24)*scale_value
	_quit.size = Vector2(200,20)*scale_value

func show_death(reason: String) -> void:
	_age = 0
	_reason.text = reason
	_respawn.disabled = true
	_panel.show()
	get_viewport().gui_release_focus()
	_layout()

func set_reason(reason: String) -> void: _reason.text = reason
func hide_death() -> void:
	if _panel != null: _panel.hide()

func _to_title() -> void:
	var scene: Node = get_tree().current_scene
	if scene != null and scene.has_method("save_and_return"): scene.save_and_return()
	else: get_tree().change_scene_to_file("res://scenes/front_end.tscn")

func _process(delta: float) -> void:
	if survival == null: return
	_age += delta
	_respawn.disabled = _age < .5
	queue_redraw()

func _draw() -> void:
	drawn_effects.clear()
	if survival == null or survival.dead: return
	var bar: BlockHotbar = survival.world.hotbar
	var s: float = bar.UI_SCALE
	if not bar.visible:
		var inventory: CreativeInventoryScreen=survival.world.inventory_screen
		if inventory.is_open and not inventory.effect_panel.can_show():_draw_effects(s)
		return
	_draw_effects(s)
	if survival.world.player.spectator or survival.world.player.creative:return
	var hearts: int = ceili(survival.settings.maximum_health/2.0)
	var rows: int = ceili(hearts/10.0)
	var absorption_hearts: int=ceili(survival.absorption/2)
	var flashing: bool = survival.hearts_blinking()
	var armor: int=roundi(Equipment.totals(survival.world.inventory).x)
	if armor>0:
		for i in range(10):
			var at: Vector2=bar.position+Vector2(i*8,-(rows+1+(1 if absorption_hearts>0 else 0))*10-13)*s
			var value: int=clampi(armor-i*2,0,2)
			draw_texture_rect(preload("res://assets/ui/armor_full.png") if value==2 else preload("res://assets/ui/armor_half.png") if value==1 else preload("res://assets/ui/armor_empty.png"),Rect2(at.floor(),Vector2(9,9)*s),false)
	for i in range(hearts):
		var origin: Vector2 = bar.position + Vector2((i%10)*8,-(rows-i/10)*10-13)*s
		if survival.settings.low_health_jitter and survival.health <= 4:
			origin.y += (hash(Vector2i(floori(_age*20),i)) & 1) * s
		var rect := Rect2(origin.floor(),Vector2(9,9)*s)
		draw_texture_rect(EMPTY_FLASH if flashing else EMPTY,rect,false)
		# Draw old health behind current health. Only the missing portion is pale.
		var previous: int = clampi(ceili(survival.previous_health)-i*2,0,2)
		if flashing and previous>0:draw_texture_rect(_heart_texture(previous==1,true),rect,false)
		var current: int=clampi(ceili(survival.health)-i*2,0,2)
		if current>0:draw_texture_rect(_heart_texture(current==1,false),rect,false)

	for i in range(absorption_hearts):
		var p: Vector2=(bar.position+Vector2(i*8,-(rows+1)*10-13)*s).floor()
		draw_texture_rect(EMPTY,Rect2(p,Vector2(9,9)*s),false)
		draw_texture_rect(preload("res://assets/ui/hearts/absorbing_full.png") if survival.absorption-i*2>=2 else preload("res://assets/ui/hearts/absorbing_half.png"),Rect2(p,Vector2(9,9)*s),false)

func _draw_effects(s: float) -> void:
	var beneficial: int=0;var harmful: int=0
	var columns: int=maxi(1,floori(get_viewport_rect().size.x/(25*s)))
	for key in EFFECT_ICONS:
		if not survival.effects.remaining.has(key):continue
		var negative: bool=key in HARMFUL
		var index: int=harmful if negative else beneficial
		if negative:harmful+=1
		else:beneficial+=1
		var row: int=1 if negative else 0
		var at:=Vector2(get_viewport_rect().size.x-(index%columns+1)*25*s,(1+26*(row+2*(index/columns)))*s).floor()
		var bounds:=Rect2(at,Vector2(24,24)*s)
		if bounds.end.y>survival.world.hotbar.position.y-4*s:continue
		var seconds: float=float(survival.effects.remaining[key]);var alpha: float=1
		if seconds<=10:
			alpha=clampf(seconds*.2,0,.5)+cos(seconds*4*PI)*clampf((10-seconds)*.025,0,.25)
		draw_texture_rect(EFFECT_BACKGROUND,bounds,false)
		draw_texture_rect(EFFECT_ICONS[key],Rect2(at+Vector2(3,3)*s,Vector2(18,18)*s),false,Color(1,1,1,clampf(alpha,0,1)))
		drawn_effects.append({"key":key,"bounds":bounds,"alpha":clampf(alpha,0,1)})

func _heart_texture(half: bool,blink: bool) -> Texture2D:
	if survival.effects.remaining.has("wither"):
		if blink:return preload("res://assets/ui/hearts/withered_half_blinking.png") if half else preload("res://assets/ui/hearts/withered_full_blinking.png")
		return preload("res://assets/ui/hearts/withered_half.png") if half else preload("res://assets/ui/hearts/withered_full.png")
	if survival.effects.remaining.has("poison"):
		if blink:return preload("res://assets/ui/hearts/poisoned_half_blinking.png") if half else preload("res://assets/ui/hearts/poisoned_full_blinking.png")
		return preload("res://assets/ui/hearts/poisoned_half.png") if half else preload("res://assets/ui/hearts/poisoned_full.png")
	return (HALF_FLASH if half else FULL_FLASH) if blink else (HALF if half else FULL)
