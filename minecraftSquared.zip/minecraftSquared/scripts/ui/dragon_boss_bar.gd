class_name DragonBossBar
extends Control
const BACK: Texture2D=preload("res://assets/ui/boss/purple_background.png")
const FILL: Texture2D=preload("res://assets/ui/boss/purple_progress.png")
var fight: EndFight
func _ready() -> void:mouse_filter=Control.MOUSE_FILTER_IGNORE;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;z_index=100
func _process(_dt: float) -> void:queue_redraw()
func _draw() -> void:
	if fight==null or not fight.present() or fight.world.player.survival_dead or fight.world.player.global_position.distance_to(fight.floor_point())>128*16:return
	var s: float=minf(fight.world.hotbar.UI_SCALE,maxf(1,floorf(get_viewport_rect().size.x/220)))
	var width: float=get_viewport_rect().size.x;var at:=Vector2(floorf((width-182*s)*.5),12*s)
	draw_texture_rect(BACK,Rect2(at,Vector2(182,5)*s),false)
	var pixels: int=clampi(roundi(182*fight.health/float(EndFight.RULES.health)),0,182)
	if pixels>0:draw_texture_rect_region(FILL,Rect2(at,Vector2(pixels,5)*s),Rect2(0,0,pixels,5))
	var font: Font=ItemDrawing.settings.font;var text_value: String="Ender Dragon";var font_size: int=roundi(8*s)
	var p:=Vector2(roundf((width-font.get_string_size(text_value,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x)*.5),2*s+font.get_ascent(font_size))
	draw_string(font,p+Vector2(s,s),text_value,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,Color(.2,.1,.2));draw_string(font,p,text_value,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,Color.WHITE)
