class_name OptionsSlider
extends Control

signal value_changed(value: int)

var label: String = ""
var minimum: int = 1
var maximum: int = 4
var value: int = 1
var gui_scale: int = 1
var font: Font
var normal: StyleBox
var highlighted: StyleBox
var handle: StyleBox
var handle_highlighted: StyleBox
var dragging: bool = false
var hovered: bool = false

func _ready() -> void:
	focus_mode = Control.FOCUS_ALL
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_force_pass_scroll_events = false
	mouse_entered.connect(func(): hovered = true; queue_redraw())
	mouse_exited.connect(func(): hovered = false; queue_redraw())
	focus_entered.connect(queue_redraw)
	focus_exited.connect(queue_redraw)

func set_value(next: int, notify: bool = false) -> void:
	var previous: int = value
	value = clampi(next, minimum, maximum)
	queue_redraw()
	if notify and previous != value:
		value_changed.emit(value)

func _value_at(x: float) -> int:
	var half_handle: float = 4.0 * gui_scale
	var fraction: float = clampf((x - half_handle) / maxf(1, size.x - half_handle * 2), 0, 1)
	return roundi(lerpf(minimum, maximum, fraction))

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		dragging = event.pressed
		if dragging:
			grab_focus()
		set_value(_value_at(event.position.x), true)
		accept_event()
	elif event is InputEventMouseMotion and dragging:
		set_value(_value_at(event.position.x), true)
		accept_event()
	elif event is InputEventKey and event.pressed:
		var key: Key = event.keycode
		if key == KEY_LEFT or key == KEY_RIGHT:
			set_value(value + (1 if key == KEY_RIGHT else -1), true)
			accept_event()
		elif key == KEY_HOME or key == KEY_END:
			set_value(minimum if key == KEY_HOME else maximum, true)
			accept_event()

func _draw() -> void:
	if font == null or normal == null:
		return
	var active: bool = hovered or has_focus() or dragging
	draw_style_box(highlighted if active else normal, Rect2(Vector2.ZERO, size))
	var handle_width: float = 8.0 * gui_scale
	var fraction: float = float(value - minimum) / maxi(1, maximum - minimum)
	draw_style_box(handle_highlighted if active else handle,
		Rect2(Vector2((size.x - handle_width) * fraction, 0).round(), Vector2(handle_width, size.y)))
	var text: String = "%s: %d" % [label, value]
	var font_size: int = 8 * gui_scale
	var width: float = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	var baseline: Vector2 = Vector2((size.x - width) / 2.0,
		(size.y - font.get_height(font_size)) / 2.0 + font.get_ascent(font_size)).round()
	draw_string(font, baseline + Vector2.ONE * gui_scale, text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(0.2, 0.2, 0.2))
	draw_string(font, baseline, text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.WHITE)
