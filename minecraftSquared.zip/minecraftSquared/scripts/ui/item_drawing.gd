class_name ItemDrawing
extends RefCounted

static var settings: InterfaceSettings = preload("res://data/settings/interface.tres")


static func draw_stack(canvas: CanvasItem, source: TileSetAtlasSource, font: Font,
		id: int, count: int, bounds: Rect2, ui_scale: float = 1.0, icon_size: float = -1.0, remaining_durability: int = -1, metadata: Dictionary = {}) -> void:
	if source == null or count <= 0 or id == BlockDatabase.ID.AIR:
		return
	if icon_size < 0:
		icon_size = settings.inventory_icon_size
	var dimensions: Vector2 = icon_dimensions(icon_size, ui_scale)
	var rect := Rect2((bounds.get_center() - dimensions / 2.0).floor(), dimensions)
	draw_icon(canvas, source, id, rect,Color.WHITE,metadata)
	var maximum: int = ToolDatabase.max_durability(id)
	if maximum > 0 and remaining_durability >= 0 and remaining_durability < maximum:
		var ratio: float = clampf(float(remaining_durability) / maximum, 0.0, 1.0)
		var bar := Rect2((bounds.position + Vector2(2,13) * ui_scale).round(), Vector2(13,2) * ui_scale)
		canvas.draw_rect(bar, Color.BLACK)
		canvas.draw_rect(Rect2(bar.position, Vector2(roundf(13 * ratio) * ui_scale, ui_scale)), Color.from_hsv(ratio / 3.0, 1.0, 0.9))
	if count > 1 and font != null:
		var text: String = str(count)
		var font_size: int = roundi(settings.stack_font_size * ui_scale)
		var width: float = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
		var p: Vector2 = (bounds.end - Vector2(width, 0) + settings.stack_offset * ui_scale).round()
		canvas.draw_string(font, p + (settings.stack_shadow_offset * ui_scale).round(), text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(0.2, 0.2, 0.2))
		canvas.draw_string(font, p, text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.WHITE)


static func get_icon_source(block_source: TileSetAtlasSource, id: int) -> TileSetAtlasSource:
	return AtlasDatabase.source(BlockDatabase.BLOCKS[id]["icon_atlas"], block_source)


static func draw_icon(canvas: CanvasItem, source: TileSetAtlasSource, id: int,
		rect: Rect2, light_tint: Color = Color.WHITE, metadata: Dictionary = {}) -> void:
	if id == BlockDatabase.ID.AIR or not BlockDatabase.BLOCKS.has(id):
		return
	var definition: Dictionary = BlockDatabase.BLOCKS[id]
	var icon_source: TileSetAtlasSource = get_icon_source(source, id)
	if icon_source == null:
		return
	var tint: Color = definition["icon_tint"] * light_tint
	var coords: Vector2i = definition["icon_tile"]
	var pixel_origin: Vector2i = icon_source.margins + coords * (icon_source.texture_region_size + icon_source.separation)
	canvas.draw_texture_rect_region(icon_source.texture, rect,
		Rect2(Vector2(pixel_origin), Vector2(icon_source.texture_region_size)), tint)
	if EnchantmentGlint.active(id,metadata):EnchantmentGlint.draw(canvas,icon_source.texture,Rect2i(pixel_origin,icon_source.texture_region_size),rect,light_tint)


static func icon_dimensions(logical_size: float, ui_scale: float) -> Vector2:
	var pixels: float = maxf(1.0, roundf(logical_size * ui_scale))
	return Vector2.ONE * pixels


static func panel_label_position(font: Font,text: String,top: Vector2,scale_value: float,panel: Vector2,centered: bool=false) -> Vector2:
	var font_size: int=roundi(8*scale_value)
	var x: float=top.x
	if centered:x=roundf((176*scale_value-font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x)*.5)/scale_value
	return (panel+Vector2(x*scale_value,top.y*scale_value+font.get_ascent(font_size))).round()

static func draw_panel_label(canvas: CanvasItem,font: Font,text: String,top: Vector2,scale_value: float,panel: Vector2,centered: bool=false) -> void:
	canvas.draw_string(font,panel_label_position(font,text,top,scale_value,panel,centered),text,HORIZONTAL_ALIGNMENT_LEFT,-1,roundi(8*scale_value),Color(.25,.25,.25))
