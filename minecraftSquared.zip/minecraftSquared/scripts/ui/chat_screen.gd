class_name ChatScreen
extends Control

var world: Node2D
var commands: CommandSystem
var config: Dictionary
var is_open: bool = false
var entry: LineEdit
var messages: Array[Dictionary] = []
var history := PackedStringArray()
var _history_index: int = 0
var _draft: String = ""
var _clock: float = 0
var _scale: int = 1
var _font_size: int = 8
var _line_height: float = 10
var _message_rect := Rect2()
var _rows: Array[Dictionary] = []
var _scroll: int = 0
var _completion_seed: String = ""
var _candidates := PackedStringArray()
var _candidate_index: int = -1
var _setting_text: bool = false
var _popup_rect := Rect2()
var _popup_first: int = 0
var _popup_rows: int = 0
var _tab_applied: bool = false
var _last_caret: int = -1
var _ghost: Label
var _layout_key := Vector4(-1,-1,-1,-1)

func setup(game: Node2D) -> void:
	world = game
	config = DataFile.object_from("res://data/chat.json")
	var ranges: Dictionary = {"maximum_messages":[10,500],"maximum_input_length":[16,1024],"maximum_give_count":[1,4096],"message_seconds":[1,120],"fade_seconds":[.1,10],"width":[100,600],"font_size":[6,16],"open_lines":[1,30],"closed_lines":[1,10],"maximum_scale":[1,4],"suggestion_rows":[1,12],"background_opacity":[0,1],"line_height":[8,16]}
	for key in ranges:
		if not ContentCatalog._number(config.get(key),ranges[key][0],ranges[key][1]):
			DataFile.fail("chat.json: invalid " + key)
			return
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	clip_contents = true
	z_index = 60
	entry = LineEdit.new()
	entry.max_length = int(config["maximum_input_length"])
	entry.placeholder_text = ""
	entry.context_menu_enabled = false
	entry.mouse_filter = Control.MOUSE_FILTER_STOP
	entry.text_changed.connect(func(_value: String):
		if not _setting_text: _refresh_suggestions()
	)
	add_child(entry)
	entry.hide()
	_ghost = Label.new()
	_ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ghost.clip_text = true
	_ghost.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	add_child(_ghost)
	_ghost.hide()
	commands = CommandSystem.new()
	commands.setup(world,self)
	get_viewport().size_changed.connect(_layout)
	_layout()


func username() -> String:
	var scene: Node = get_tree().current_scene
	if scene != null and scene is GameFrontEnd: return scene.profile.username
	return "Steve"

func post(text: String, color: Color = Color.WHITE) -> void:
	# Plain text only: user text never becomes BBCode, markup or executable code.
	text = text.replace("\r"," ").replace("\n"," ").replace("\t"," ")
	messages.append({"text":text.substr(0,2048),"time":_clock,"color":color})
	while messages.size() > int(config["maximum_messages"]): messages.pop_front()
	_scroll = 0
	_rewrap()
	queue_redraw()

func set_open(value: bool, prefix: String = "") -> void:
	if value == is_open: return
	if value and (get_tree().paused or world.player.survival_dead or world.inventory_screen.is_open or (world.furnace_screen.is_open or world.upgrade_is_open()) or (world.storage_screen!=null and world.storage_screen.is_open)): return
	is_open = value
	world.player.input_blocked = value
	var menus: bool = world.inventory_screen.is_open or (world.furnace_screen.is_open or world.upgrade_is_open()) or (world.storage_screen!=null and world.storage_screen.is_open) or get_tree().paused
	world.player.set_interaction_enabled(not value and not menus)
	world.hotbar.set_process_input(not value)
	world.inventory_screen.set_process_input(not value and not (world.furnace_screen.is_open or world.upgrade_is_open()) and (world.storage_screen==null or not world.storage_screen.is_open) and not world.player.survival_dead)
	world.furnace_screen.set_process_input(not value and not world.player.survival_dead)
	if world.storage_screen!=null:world.storage_screen.set_process_input(not value and not world.player.survival_dead)
	world.mining_held = false
	world.reset_mining()
	world._debug_key_down = false
	world._debug_press_event = null
	var options: Node = get_node("/root/GameOptions")
	for definition in options.keybinds.definitions: Input.action_release(definition["action"])
	entry.visible = value
	mouse_filter = Control.MOUSE_FILTER_STOP if value else Control.MOUSE_FILTER_IGNORE
	_scroll = 0
	_candidates.clear()
	_candidate_index = -1
	if value:
		_history_index = history.size()
		_draft = ""
		set_text(prefix)
		entry.grab_focus.call_deferred()
	else:
		entry.release_focus()
		entry.text = ""
	_layout()
	world.target_overlay.queue_redraw()
	queue_redraw()

func set_text(text: String, preserve_completion: bool = false) -> void:
	_setting_text = true
	entry.text = text
	entry.caret_column = text.length()
	_setting_text = false
	if not preserve_completion: _refresh_suggestions()

func _refresh_suggestions() -> void:
	_completion_seed = entry.text
	_candidates = commands.complete(entry.text) if is_open and entry.caret_column == entry.text.length() else PackedStringArray()
	_candidate_index = 0 if not _candidates.is_empty() else -1
	_popup_first = 0
	_tab_applied = false
	_layout()

func submit() -> void:
	var text: String = entry.text.strip_edges()
	set_open(false)
	if text.is_empty(): return
	if history.is_empty() or history[-1] != text: history.append(text)
	while history.size() > int(config["maximum_messages"]): history.remove_at(0)
	if text.begins_with("/"): commands.execute(text)
	else: post("<" + username() + "> " + text)

func _input(event: InputEvent) -> void:
	if entry == null: return
	if not is_open:
		if (event is InputEventKey or event is InputEventMouseButton) and event.pressed and not (event is InputEventKey and event.echo) and (GameBindings.matches(event,"chat") or GameBindings.matches(event,"command")):
			set_open(true,"/" if GameBindings.matches(event,"command") else "")
			if is_open: get_viewport().set_input_as_handled()
		return
	if event is InputEventMouseMotion and not _candidates.is_empty() and _popup_rect.has_point(event.position):
		var index: int = clampi(floori((event.position.y-_popup_rect.position.y-_scale)/_line_height)+_popup_first,0,_candidates.size()-1)
		if index != _candidate_index:
			_candidate_index = index
			_tab_applied = false
			_layout()
		return
	if event is InputEventMouseButton:
		if event.pressed and event.button_index in [MOUSE_BUTTON_WHEEL_UP,MOUSE_BUTTON_WHEEL_DOWN]:
			var step: int = -1 if event.button_index == MOUSE_BUTTON_WHEEL_UP else 1
			if not _candidates.is_empty() and _popup_rect.has_point(event.position):
				_popup_first = clampi(_popup_first+step,0,maxi(0,_candidates.size()-_popup_rows))
				queue_redraw()
			else:
				_scroll = clampi(_scroll-step*3,0,maxi(0,_rows.size()-1))
				queue_redraw()
			get_viewport().set_input_as_handled()
			return
		if event.pressed and event.button_index == MOUSE_BUTTON_LEFT and not _candidates.is_empty() and _popup_rect.has_point(event.position):
			var index: int = clampi(floori((event.position.y-_popup_rect.position.y-_scale)/_line_height)+_popup_first,0,_candidates.size()-1)
			set_text(_candidates[index],true)
			_candidates.clear()
			_candidate_index = -1
			_layout()
			entry.grab_focus()
		if not entry.get_global_rect().has_point(event.position): get_viewport().set_input_as_handled()
		return
	if not event is InputEventKey or not event.pressed: return
	var key: Key = event.keycode if event.keycode != 0 else event.physical_keycode
	match key:
		KEY_ESCAPE: set_open(false)
		KEY_ENTER, KEY_KP_ENTER: submit()
		KEY_UP, KEY_DOWN:
			if not _candidates.is_empty():
				_candidate_index = wrapi(_candidate_index+(-1 if key==KEY_UP else 1),0,_candidates.size())
				_tab_applied = false
				_reveal_candidate()
				_layout()
			else:
				if _history_index == history.size(): _draft = entry.text
				_history_index = clampi(_history_index + (-1 if key == KEY_UP else 1),0,history.size())
				set_text(history[_history_index] if _history_index < history.size() else _draft)
				_candidates.clear()
				_layout()
		KEY_PAGEUP, KEY_PAGEDOWN:
			_scroll = clampi(_scroll + (5 if key == KEY_PAGEUP else -5),0,maxi(0,_rows.size()-1))
		KEY_TAB: _complete(event.shift_pressed)
		_: return # Let LineEdit receive ordinary typing, selection and paste in GUI input.
	queue_redraw()
	get_viewport().set_input_as_handled()

func _complete(backwards: bool) -> void:
	if entry.caret_column != entry.text.length(): return
	if _candidates.is_empty(): _refresh_suggestions()
	if _candidates.is_empty(): return
	if _tab_applied: _candidate_index = wrapi(_candidate_index+(-1 if backwards else 1),0,_candidates.size())
	elif backwards: _candidate_index = _candidates.size()-1
	_candidate_index = maxi(0,_candidate_index)
	set_text(_candidates[_candidate_index],true)
	_tab_applied = true
	_reveal_candidate()
	_layout()

func _reveal_candidate() -> void:
	if _candidate_index < _popup_first: _popup_first = _candidate_index
	elif _candidate_index >= _popup_first+_popup_rows: _popup_first = _candidate_index-_popup_rows+1
	_popup_first = maxi(0,_popup_first)

func _candidate_label(index: int) -> String:
	return _candidates[index].get_slice(" ",_candidates[index].get_slice_count(" ")-1).trim_prefix("/")

func _process(delta: float) -> void:
	_clock += delta
	if world == null or entry == null: return
	if is_open and world.player.survival_dead: set_open(false)
	var view: Vector2 = get_viewport_rect().size
	var key := Vector4(view.x,view.y,world.hotbar.position.y,ItemDrawing.settings.maximum_scale)
	if is_open and entry.caret_column != _last_caret: _refresh_suggestions()
	elif key != _layout_key: _layout()
	if is_open or not messages.is_empty() and _clock-float(messages[-1]["time"]) <= float(config["message_seconds"]): queue_redraw()

func _layout() -> void:
	if world == null or entry == null: return
	_last_caret = entry.caret_column
	var view: Vector2 = get_viewport_rect().size
	_layout_key = Vector4(view.x,view.y,world.hotbar.position.y,ItemDrawing.settings.maximum_scale)
	_scale = clampi(floori(view.x/340.0),1,mini(int(config["maximum_scale"]),ItemDrawing.settings.maximum_scale))
	_font_size = int(config["font_size"]) * _scale
	_line_height = ceilf(maxf(ItemDrawing.settings.font.get_height(_font_size),int(config["line_height"])*_scale)/_scale)*_scale
	size = Vector2(view.x,HudLayout.text_bottom(world))
	entry.add_theme_font_override("font",ItemDrawing.settings.font)
	entry.add_theme_font_size_override("font_size",_font_size)
	var verb: String = entry.text.trim_prefix("/").get_slice(" ",0)
	entry.add_theme_color_override("font_color",Color("ff5555") if entry.text.begins_with("/") and not verb.is_empty() and not commands.commands.has(verb) else Color.WHITE)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0,0,0,float(config["background_opacity"]))
	for side in [SIDE_LEFT,SIDE_TOP,SIDE_RIGHT,SIDE_BOTTOM]: style.set_content_margin(side,2*_scale)
	entry.add_theme_stylebox_override("normal",style)
	entry.add_theme_stylebox_override("focus",style)
	var input_height: float = maxf(_line_height+4*_scale,entry.get_combined_minimum_size().y)
	entry.position = Vector2(3*_scale,maxf(0,size.y-input_height))
	entry.size = Vector2(maxf(1,view.x-6*_scale),input_height)
	_popup_rows = mini(mini(_candidates.size(),int(config["suggestion_rows"])),maxi(1,floori(entry.position.y/_line_height*.6)))
	var popup_width: float = 0
	for i in range(_candidates.size()): popup_width = maxf(popup_width,ItemDrawing.settings.font.get_string_size(_candidate_label(i),HORIZONTAL_ALIGNMENT_LEFT,-1,_font_size).x)
	popup_width = minf(view.x-6*_scale,ceilf(popup_width/_scale)*_scale+8*_scale)
	var stem: String = _completion_seed.substr(0,_completion_seed.rfind(" ")+1)
	var px: float = entry.position.x+2*_scale+ItemDrawing.settings.font.get_string_size(stem,HORIZONTAL_ALIGNMENT_LEFT,-1,_font_size).x
	px = clampf(px,3*_scale,maxf(3*_scale,view.x-popup_width-3*_scale))
	_popup_rect = Rect2(Vector2(px,entry.position.y-_popup_rows*_line_height-2*_scale),Vector2(popup_width,_popup_rows*_line_height+2*_scale))
	_popup_first = clampi(_popup_first,0,maxi(0,_candidates.size()-_popup_rows))
	var bottom: float = (_popup_rect.position.y if not _candidates.is_empty() else entry.position.y)-2*_scale if is_open else size.y
	var height: float = minf(int(config["open_lines"])*_line_height,maxf(0,bottom-3*_scale))
	var width: float = minf(int(config["width"])*_scale,view.x-6*_scale)
	var wrap_changed: bool = _message_rect.size.x != width or _rows.is_empty() and not messages.is_empty()
	_message_rect = Rect2(Vector2(3*_scale,bottom-height),Vector2(width,height))
	if wrap_changed or _font_size != int(get_meta("wrap_font",0)):
		set_meta("wrap_font",_font_size)
		_rewrap()
	_ghost.add_theme_font_override("font",ItemDrawing.settings.font)
	_ghost.add_theme_font_size_override("font_size",_font_size)
	_ghost.add_theme_color_override("font_color",Color(.65,.65,.65))
	_ghost.text = ""
	var typed_width: float = ItemDrawing.settings.font.get_string_size(entry.text,HORIZONTAL_ALIGNMENT_LEFT,-1,_font_size).x
	_ghost.position = entry.position + Vector2(2*_scale+typed_width,0)
	_ghost.size = Vector2(maxf(0,entry.size.x-typed_width-4*_scale),entry.size.y)
	if is_open and _candidate_index >= 0 and _candidate_index < _candidates.size() and _candidates[_candidate_index].begins_with(entry.text) and entry.caret_column == entry.text.length():
		_ghost.text = _candidates[_candidate_index].substr(entry.text.length())
	_ghost.visible = is_open and not _ghost.text.is_empty() and typed_width < entry.size.x-4*_scale
	queue_redraw()

func _rewrap() -> void:
	_rows.clear()
	for message in messages:
		for text in ItemTooltipDrawing._wrap(ItemDrawing.settings.font,message["text"],_font_size,maxf(1,_message_rect.size.x-4*_scale)):
			_rows.append({"text":text,"time":message["time"],"color":message["color"]})

func _draw() -> void:
	if world == null or world.player.survival_dead or world.inventory_screen.is_open or (world.furnace_screen.is_open or world.upgrade_is_open()) or (world.storage_screen!=null and world.storage_screen.is_open): return
	var font: Font = ItemDrawing.settings.font
	var limit: int = floori(_message_rect.size.y/_line_height) if is_open else mini(int(config["closed_lines"]),floori(size.y/_line_height))
	var bottom: float = _message_rect.end.y

	var drawn: int = 0
	for i in range(_rows.size()-1-_scroll,-1,-1):
		if drawn >= limit: break
		var row: Dictionary = _rows[i]
		var age: float = _clock-float(row["time"])
		var alpha: float = 1.0 if is_open else clampf((float(config["message_seconds"])-age)/float(config["fade_seconds"]),0,1)
		if alpha <= 0: continue
		var y: float = bottom-(drawn+1)*_line_height
		var rect := Rect2(Vector2(_message_rect.position.x,y),Vector2(_message_rect.size.x,_line_height))
		draw_rect(rect,Color(0,0,0,float(config["background_opacity"])*alpha))
		var at := Vector2(rect.position.x+2*_scale,y+font.get_ascent(_font_size)).round()
		var color: Color = row["color"]
		color.a = alpha
		draw_string(font,at+Vector2.ONE*_scale,row["text"],HORIZONTAL_ALIGNMENT_LEFT,-1,_font_size,Color(0,0,0,alpha))
		draw_string(font,at,row["text"],HORIZONTAL_ALIGNMENT_LEFT,-1,_font_size,color)
		drawn += 1
	if is_open and not _candidates.is_empty():
		draw_rect(_popup_rect,Color(0,0,0,.92))
		for row in range(_popup_rows):
			var index: int = _popup_first+row
			var at: Vector2 = (_popup_rect.position+Vector2(2*_scale,_scale+row*_line_height+font.get_ascent(_font_size))).round()
			draw_string(font,at,_candidate_label(index),HORIZONTAL_ALIGNMENT_LEFT,-1,_font_size,Color("ffff55") if index==_candidate_index else Color.WHITE)
		if _candidates.size()>_popup_rows:
			var track := Rect2(_popup_rect.end.x-2*_scale,_popup_rect.position.y+_scale,_scale,_popup_rect.size.y-2*_scale)
			draw_rect(track,Color(.25,.25,.25))
			var height: float = maxf(_scale,track.size.y*_popup_rows/_candidates.size())
			var y: float = track.position.y+(track.size.y-height)*_popup_first/maxf(1,_candidates.size()-_popup_rows)
			draw_rect(Rect2(track.position.x,y,_scale,height),Color(.8,.8,.8))

func closed_text_height() -> float:
	var count: int = 0
	for row in _rows:
		if _clock-float(row["time"]) < float(config["message_seconds"]): count += 1
	return mini(count,int(config["closed_lines"])) * _line_height
