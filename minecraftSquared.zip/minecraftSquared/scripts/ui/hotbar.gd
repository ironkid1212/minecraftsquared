class_name BlockHotbar
extends Control

signal selection_changed

var background_texture: Texture2D
var selector_texture: Texture2D

var UI_FONT: Font

var UI_SCALE: float = 3.0
const BAR_SIZE := Vector2(182, 22)
const SLOT_COUNT: int = 9


var inventory: BlockInventory
var selected_slot: int = 0
var atlas_source: TileSetAtlasSource
var player_style: PlayerSettings=preload("res://data/settings/player.tres")
const OFFHAND_LEFT: Texture2D=preload("res://assets/ui/offhand_left.png")
const OFFHAND_RIGHT: Texture2D=preload("res://assets/ui/offhand_right.png")


func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_force_pass_scroll_events = false
	size = BAR_SIZE * UI_SCALE
	update_position()
	get_viewport().size_changed.connect(update_position)


func configure(source: TileSetAtlasSource, items: BlockInventory = null, style: PlayerSettings = null) -> void:
	if style!=null:player_style=style
	UI_FONT = ItemDrawing.settings.font
	background_texture = ItemDrawing.settings.hotbar_texture
	selector_texture = ItemDrawing.settings.selector_texture
	update_position()
	atlas_source = source
	inventory = items
	if inventory != null:
		inventory.changed.connect(_sync_inventory)
		_sync_inventory()
	queue_redraw()


func _sync_inventory() -> void:
	queue_redraw()


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mouse := event as InputEventMouseButton
		if mouse.pressed and mouse.button_index == MOUSE_BUTTON_LEFT:
			select_slot(clampi(floori((mouse.position.x / UI_SCALE - 1.0) / 20.0), 0, 8))
			accept_event()


func update_position() -> void:
	var viewport_size := get_viewport_rect().size
	# Reserve either side so changing hands cannot clip the offhand at small sizes.
	UI_SCALE = maxf(1.0, minf(ItemDrawing.settings.maximum_scale, floorf((viewport_size.x - 20.0) / (BAR_SIZE.x+58))))
	size = BAR_SIZE * UI_SCALE
	position = Vector2(
		floorf((viewport_size.x - size.x) / 2.0),
		floorf(viewport_size.y - size.y - 18.0)
	)


func get_selected_block() -> int:
	return inventory.ids[selected_slot] if inventory!=null and inventory.counts[selected_slot]>0 else 0


func is_mouse_over() -> bool:
	if has_offhand() and Rect2(global_position+offhand_frame_rect().position*UI_SCALE,offhand_frame_rect().size*UI_SCALE).has_point(get_global_mouse_position()):return true
	return get_global_rect().has_point(get_global_mouse_position())


func has_offhand() -> bool:return inventory!=null and inventory.counts[BlockInventory.OFFHAND]>0
func offhand_frame_rect() -> Rect2:
	return Rect2(Vector2(BAR_SIZE.x if player_style.main_hand==1 else -29,-1),Vector2(29,24))
func offhand_item_rect() -> Rect2:
	# Each 29px sprite has 7px of transparent padding toward the main hotbar.
	return Rect2(offhand_frame_rect().position+Vector2(10 if player_style.main_hand==1 else 3,4),Vector2(16,16))


func select_slot(index: int) -> void:
	selected_slot = wrapi(index, 0, SLOT_COUNT)
	selection_changed.emit()
	queue_redraw()


func _input(event: InputEvent) -> void:
	if not visible: return
	if not event is InputEventKey and not event is InputEventMouseButton: return
	if not event.pressed or event is InputEventKey and event.echo: return
	for index in range(SLOT_COUNT):
		if GameBindings.matches(event,"hotbar_" + str(index + 1)):
			select_slot(index)
			get_viewport().set_input_as_handled()
			return
	if GameBindings.matches(event,"hotbar_previous"):
		select_slot(selected_slot - 1)
		get_viewport().set_input_as_handled()
	elif GameBindings.matches(event,"hotbar_next"):
		select_slot(selected_slot + 1)
		get_viewport().set_input_as_handled()


func _draw() -> void:
	if background_texture == null:
		return
	draw_texture_rect(background_texture, Rect2(Vector2.ZERO, size), false)
	if atlas_source != null:
		draw_block_icons()
	draw_selection_border()
	if has_offhand():
		var frame: Rect2=offhand_frame_rect();var item: Rect2=offhand_item_rect()
		draw_texture_rect(OFFHAND_RIGHT if player_style.main_hand==1 else OFFHAND_LEFT,Rect2(frame.position*UI_SCALE,frame.size*UI_SCALE),false)
		ItemDrawing.draw_stack(self,atlas_source,UI_FONT,inventory.ids[BlockInventory.OFFHAND],inventory.counts[BlockInventory.OFFHAND],Rect2(item.position*UI_SCALE,item.size*UI_SCALE),UI_SCALE,ItemDrawing.settings.hotbar_icon_size,inventory.durability[BlockInventory.OFFHAND],inventory.tags[BlockInventory.OFFHAND])


func draw_block_icons() -> void:
	for index in range(SLOT_COUNT):
		var count: int = inventory.counts[index] if inventory != null else 1
		var bounds := Rect2(Vector2(3 + index * 20, 3) * UI_SCALE, Vector2(16, 16) * UI_SCALE)
		ItemDrawing.draw_stack(self, atlas_source, UI_FONT, inventory.ids[index] if inventory!=null else 0, count, bounds, UI_SCALE, ItemDrawing.settings.hotbar_icon_size, inventory.durability[index] if inventory != null else -1,inventory.tags[index] if inventory!=null else {})


func draw_selection_border() -> void:
	if selector_texture == null:
		return
	var slot_center := Vector2(11 + selected_slot * 20, 11)
	var selector_size := selector_texture.get_size()
	var selector_position := (slot_center - selector_size / 2.0).floor()
	draw_texture_rect(
		selector_texture,
		Rect2(selector_position * UI_SCALE, selector_size * UI_SCALE),
		false
	)
