class_name HudLayout
extends RefCounted

## Reserve the hotbar AND heart rows, even when spectator hides them.
static func text_bottom(world: Node2D) -> float:
	var scale_value: float = world.hotbar.UI_SCALE
	var rows: int = ceili(world.settings.survival.maximum_health / 20.0)
	if Equipment.totals(world.inventory).x>0:rows+=1
	if world.survival!=null and world.survival.absorption>0:rows+=1
	return maxf(0, world.hotbar.position.y - (rows * 10 + 17) * scale_value)
