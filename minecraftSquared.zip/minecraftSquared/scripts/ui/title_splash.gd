class_name TitleSplash
extends Control

const FONT: Font = preload("res://assets/fonts/minecraft_font.otf")
var splashes_path: String = "res://data/splashes.txt"
var gui_scale: int = 1
var splash_text: String = ""
var lines: PackedStringArray = []
var elapsed: float = 0.0
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_rng.randomize()
	load_splashes()
	choose_splash()

func load_splashes() -> void:
	lines.clear()
	if FileAccess.file_exists(splashes_path):
		for line in FileAccess.get_file_as_string(splashes_path).split("\n"):
			var clean: String = line.strip_edges().trim_prefix("\ufeff")
			if not clean.is_empty() and not clean.begins_with("#"):
				lines.append(clean)

func choose_splash() -> void:
	splash_text = lines[_rng.randi_range(0, lines.size() - 1)] if not lines.is_empty() else ""
	elapsed = 0.0
	queue_redraw()

func _process(delta: float) -> void:
	if is_visible_in_tree() and not splash_text.is_empty():
		elapsed += delta
		queue_redraw()

func _draw() -> void:
	if splash_text.is_empty():
		return
	var font_size: int = 8 * gui_scale
	var width: float = FONT.get_string_size(splash_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	var fit: float = minf(1, 120.0 * gui_scale / maxf(1, width))
	var pulse: float = 0.96 + sin(elapsed * TAU * 2.0) * 0.04
	draw_set_transform(size / 2.0, deg_to_rad(-20), Vector2.ONE * fit * pulse)
	var baseline := Vector2(-width / 2.0, FONT.get_ascent(font_size) - FONT.get_height(font_size) / 2.0)
	draw_string(FONT, baseline + Vector2.ONE * gui_scale, splash_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(0.25, 0.25, 0))
	draw_string(FONT, baseline, splash_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(1, 1, 0))
