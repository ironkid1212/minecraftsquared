class_name UpgradeScreen
extends InventoryScreen

var world: Node2D
var mode: String="enchanting"
var cell:=Vector2i.ZERO
var options: Array[Dictionary]=[]
var shelves: int=0
var rename: LineEdit
var _left_signature: String=""
var _offer_signature: String=""
var _anvil: Dictionary={}
var _shelf_dirty: bool=true
var _shelf_count: int=0
var _shelf_location: String=""
const ENCHANT_PANEL: Texture2D=preload("res://assets/ui/upgrades/enchanting_table.png")
const ANVIL_PANEL: Texture2D=preload("res://assets/ui/upgrades/anvil.png")
const OFFER: Texture2D=preload("res://assets/ui/upgrades/enchantment_slot.png")
const OFFER_DISABLED: Texture2D=preload("res://assets/ui/upgrades/enchantment_slot_disabled.png")
const OFFER_HOVER: Texture2D=preload("res://assets/ui/upgrades/enchantment_slot_highlighted.png")
const NAME_FIELD: Texture2D=preload("res://assets/ui/upgrades/anvil_text_field.png")
const NAME_DISABLED: Texture2D=preload("res://assets/ui/upgrades/anvil_text_field_disabled.png")
const ANVIL_ERROR: Texture2D=preload("res://assets/ui/upgrades/anvil_error.png")
const RUNES: Texture2D=preload("res://assets/ui/upgrades/ascii_sga.png")
const BOOK: Texture2D=preload("res://assets/ui/upgrades/enchanting_table_book.png")
const LEVELS: Array[Texture2D]=[preload("res://assets/ui/upgrades/level_1.png"),preload("res://assets/ui/upgrades/level_2.png"),preload("res://assets/ui/upgrades/level_3.png")]
const LEVELS_DISABLED: Array[Texture2D]=[preload("res://assets/ui/upgrades/level_1_disabled.png"),preload("res://assets/ui/upgrades/level_2_disabled.png"),preload("res://assets/ui/upgrades/level_3_disabled.png")]

func setup(data: BlockInventory,source: TileSetAtlasSource,style: PlayerSettings=null) -> void:
	super.setup(data,source,style)
	set_process_input(false)
	rename=LineEdit.new();add_child(rename);rename.max_length=50;rename.placeholder_text="";rename.flat=true;rename.focus_mode=Control.FOCUS_CLICK
	rename.add_theme_font_override("font",UI_FONT);rename.add_theme_color_override("font_color",Color.WHITE)
	for state in ["normal","focus","read_only"]:rename.add_theme_stylebox_override(state,StyleBoxEmpty.new())
	rename.add_theme_constant_override("minimum_character_width",1)
	rename.text_changed.connect(func(_text: String):_update_state();queue_redraw())
	_resize()
func _resize() -> void:
	super._resize()
	if rename!=null:
		rename.add_theme_font_size_override("font_size",roundi(8*ui_scale))
		rename.position=(panel_position+Vector2(62,20)*ui_scale).round();rename.size=Vector2(103,16)*ui_scale
		rename.visible=is_open and mode=="anvil"
func open_station(at: Vector2i,kind: String,game: Node2D) -> void:
	if is_open:set_open(false)
	world=game;cell=at;mode=kind
	_shelf_dirty=true
	set_open(true,true)
	crafting=UpgradeGrid.new(items,mode);crafting.changed.connect(_grid_changed)
	_left_signature="";_offer_signature="";rename.text="";rename.release_focus();rename.visible=mode=="anvil";set_process_input(true);_grid_changed()
func set_open(value: bool,table_mode: bool=false) -> void:
	super.set_open(value,table_mode)
	set_process_input(value)
	if rename!=null:rename.visible=value and mode=="anvil"
func _input(event: InputEvent) -> void:
	_track_pointer(event)
	if not is_open:return
	if event is InputEventKey and event.pressed and event.physical_keycode==KEY_ESCAPE:
		set_open(false);get_viewport().set_input_as_handled();return
	if rename.has_focus():return
	super._input(event)
func craft_slot_rect(index: int) -> Rect2:
	return Rect2(Vector2(27 if index==0 else 76,47),Vector2(16,16)) if mode=="anvil" else Rect2(Vector2(15 if index==0 else 35,47),Vector2(16,16))
func result_rect() -> Rect2:return Rect2(134,47,16,16) if mode=="anvil" else Rect2(-1000,-1000,1,1)
func offer_rect(index: int) -> Rect2:return Rect2(60,14+index*19,108,19)
func _grid_changed() -> void:
	if not crafting is UpgradeGrid:return
	var signature: String=str(crafting.ids[0])+":"+NBT.snbt(NBT.node(NBT.COMPOUND,crafting.tags[0]))
	if signature!=_left_signature:
		_left_signature=signature
		if mode=="anvil":rename.text=ItemTags.name(crafting.ids[0],crafting.tags[0]) if crafting.counts[0]>0 else ""
	rename.editable=mode=="anvil" and crafting.counts[0]>0
	_update_state();queue_redraw()
func count_bookshelves() -> int:
	if not world.chunks.cell_changed.is_connected(_shelf_changed):world.chunks.cell_changed.connect(_shelf_changed)
	var radius: int=int(EnchantmentDatabase.DATA.table.bookshelf_radius)
	var location: String=str(cell)+":"+str(radius)
	if location!=_shelf_location:_shelf_location=location;_shelf_dirty=true
	if not _shelf_dirty:return _shelf_count
	var total: int=0
	for x in range(-radius,radius+1):
		for y in range(-radius,radius+1):
			if x*x+y*y>radius*radius:continue
			var at: Vector2i=cell+Vector2i(x,y)
			if world.chunks.is_cell_loaded(at) and world.get_block(at)==BlockDatabase.id_for("bookshelf"):total+=1
	_shelf_count=mini(total,int(EnchantmentDatabase.DATA.table.max_bookshelves));_shelf_dirty=false
	return _shelf_count
func _shelf_changed(at: Vector2i,old_id: int,new_id: int) -> void:
	var shelf: int=BlockDatabase.id_for("bookshelf")
	var radius: int=int(EnchantmentDatabase.DATA.table.bookshelf_radius)
	if (old_id==shelf or new_id==shelf) and (at-cell).length_squared()<=radius*radius:_shelf_dirty=true
func _update_state() -> void:
	if not is_open or not crafting is UpgradeGrid:return
	if mode=="anvil":_anvil=AnvilLogic.preview(crafting.stack(0),crafting.stack(1),rename.text);return
	shelves=count_bookshelves()
	var signature: String=str(crafting.ids[0])+":"+str(shelves)+":"+str(world.experience.enchant_seed)
	if signature!=_offer_signature:
		_offer_signature=signature;options=EnchantmentDatabase.offers(crafting.ids[0],shelves,world.experience.enchant_seed)
	if not EnchantmentDatabase.read(crafting.tags[0]).is_empty() or crafting.ids[0]==BlockDatabase.id_for("enchanted_book"):options=[]
func _process(_dt: float) -> void:
	if not is_open:return
	if not world.cell_is_reachable(cell) or BlockDatabase.BLOCKS.get(world.get_block(cell),{}).get("interaction")!=mode:set_open(false);return
	_update_state();queue_redraw()
func can_enchant(index: int) -> bool:
	return index>=0 and index<options.size() and not options[index].values.is_empty() and crafting.counts[0]==1 and (world.player.creative or world.experience.level()>=maxi(int(options[index].required),int(options[index].cost)) and crafting.ids[1]==BlockDatabase.id_for("lapis_lazuli") and crafting.counts[1]>=int(options[index].cost))
func enchant(index: int) -> bool:
	_update_state()
	if not can_enchant(index):return false
	var offer: Dictionary=options[index];var book: bool=crafting.ids[0]==BlockDatabase.id_for("book")
	crafting.tags[0]=EnchantmentDatabase.write(crafting.tags[0],offer.values,book)
	if book:crafting.ids[0]=BlockDatabase.id_for("enchanted_book")
	if not world.player.creative:crafting.clear_input(1,int(offer.cost));world.experience.spend_levels(int(offer.cost))
	world.experience.enchant_seed=randi_range(1,2147483646);_offer_signature="";crafting._refresh();return true
func take_anvil(shift: bool=false) -> bool:
	_update_state()
	if _anvil.is_empty() or not _anvil.has("stack") or not world.player.creative and (_anvil.too_expensive or world.experience.level()<int(_anvil.cost)):return false
	var result: Dictionary=_anvil.stack
	if shift:
		if items.capacity_for(result.id,result.tags,result.durability)<int(result.count):return false
	else:
		if items.held_count>0 and (items.held_id!=int(result.id) or items.held_durability!=int(result.durability) or not NBT.same(items.held_tags,result.tags)):return false
		if items.held_count+int(result.count)>items.stack_limit(int(result.id)):return false
	var paid: int=int(_anvil.cost);var used: int=int(_anvil.used)
	if shift:items.add_item(result.id,result.count,0,items.main_count,result.durability,result.tags)
	else:items.held_id=result.id;items.held_count+=int(result.count);items.held_durability=result.durability;items.held_tags=result.tags.duplicate(true)
	crafting.clear_input(0,int(result.count));crafting.clear_input(1,used)
	if not world.player.creative:
		world.experience.spend_levels(paid)
		if randf()<float(EnchantmentDatabase.DATA.anvil.damage_chance):
			var key: String=BlockDatabase.BLOCKS[world.get_block(cell)].key
			world.set_block(cell,BlockDatabase.id_for("chipped_anvil" if key=="anvil" else "damaged_anvil") if key!="damaged_anvil" else 0)
	_update_state();return true
func _gui_input(event: InputEvent) -> void:
	_track_pointer(event)
	if not is_open:return
	if event is InputEventMouseButton and event.pressed and event.button_index in [MOUSE_BUTTON_LEFT,MOUSE_BUTTON_RIGHT]:
		var pointer: Vector2=(event.position-panel_position)/ui_scale
		if mode=="enchanting":
			for i in range(3):
				if offer_rect(i).has_point(pointer):enchant(i);accept_event();return
		elif result_rect().has_point(pointer):take_anvil(event.shift_pressed);accept_event();return
		var index: int=slot_at(event.position)
		if event.shift_pressed and index>=0:crafting.deposit(index);accept_event();return
	super._gui_input(event)
func _draw() -> void:
	if not is_open or not crafting is UpgradeGrid:return
	draw_rect(Rect2(Vector2.ZERO,size),Color(0,0,0,.55))
	draw_set_transform(panel_position,0,Vector2.ONE*ui_scale)
	draw_texture_rect_region(ANVIL_PANEL if mode=="anvil" else ENCHANT_PANEL,Rect2(Vector2.ZERO,PANEL_SIZE),Rect2(Vector2.ZERO,PANEL_SIZE))
	var pointer: Vector2=(_pointer_position()-panel_position)/ui_scale
	if mode=="enchanting":
		_draw_book()
		for i in range(3):
			var active: bool=can_enchant(i)
			draw_texture_rect(OFFER_HOVER if active and offer_rect(i).has_point(pointer) else OFFER if active else OFFER_DISABLED,offer_rect(i),false)
			if i<options.size():
				draw_texture_rect(LEVELS[i] if active else LEVELS_DISABLED[i],Rect2(61,15+i*19,16,16),false)
				_draw_runes(i,active)
	else:
		draw_texture_rect(NAME_FIELD if crafting.counts[0]>0 else NAME_DISABLED,Rect2(59,20,110,16),false)
		if crafting.counts[0]>0 and crafting.counts[1]>0 and not _anvil.has("stack"):draw_texture_rect(ANVIL_ERROR,Rect2(99,45,28,21),false)
	var hover: int=slot_at(_pointer_position());var input_hover: int=craft_slot_at(_pointer_position())
	if hover>=0:draw_rect(slot_rect(hover),Color(1,1,1,.3))
	if input_hover>=0:draw_rect(craft_slot_rect(input_hover),Color(1,1,1,.3))
	draw_set_transform(Vector2.ZERO)
	ItemDrawing.draw_panel_label(self,UI_FONT,"Repair & Name" if mode=="anvil" else "Enchant",Vector2(60,6) if mode=="anvil" else Vector2(12,6),ui_scale,panel_position)
	ItemDrawing.draw_panel_label(self,UI_FONT,"Inventory",Vector2(8,72),ui_scale,panel_position)
	if mode=="enchanting":
		for i in range(options.size()):
			var offer: Dictionary=options[i];var active: bool=can_enchant(i);var color:=Color("80ff20") if active else Color("777777")
			if int(offer.required)==0:continue
			var number: String=str(offer.required)
			_text(number,Vector2(165-_logical_text_width(number),22+i*19),color)
	else:
		if _anvil.has("stack"):
			var output: Dictionary=_anvil.stack
			ItemDrawing.draw_stack(self,atlas_source,UI_FONT,output.id,output.count,_screen_rect(result_rect()),ui_scale,-1,output.durability,output.tags)
			var expensive: bool=not world.player.creative and (_anvil.too_expensive or world.experience.level()<int(_anvil.cost))
			var cost_text: String="Too Expensive!" if _anvil.too_expensive and not world.player.creative else "Enchantment Cost: %d"%int(_anvil.cost)
			var width: float=_logical_text_width(cost_text)
			draw_rect(_screen_rect(Rect2(168-width-2,67,width+4,10)),Color(0,0,0,.45))
			_text(cost_text,Vector2(168-width,67),Color("ff5555") if expensive else Color("80ff20"))
	for i in range(36):ItemDrawing.draw_stack(self,atlas_source,UI_FONT,items.ids[i],items.counts[i],_screen_rect(slot_rect(i)),ui_scale,-1,items.durability[i],items.tags[i])
	for i in range(2):ItemDrawing.draw_stack(self,atlas_source,UI_FONT,crafting.ids[i],crafting.counts[i],_screen_rect(craft_slot_rect(i)),ui_scale,-1,crafting.durability[i],crafting.tags[i])
	if items.held_count>0:ItemDrawing.draw_stack(self,atlas_source,UI_FONT,items.held_id,items.held_count,Rect2(_pointer_position()-Vector2.ONE*8*ui_scale,Vector2.ONE*16*ui_scale),ui_scale,-1,items.held_durability,items.held_tags)
	else:
		var item_id: int=crafting.ids[input_hover] if input_hover>=0 else items.ids[hover] if hover>=0 else 0
		if item_id!=0:ItemTooltipDrawing.draw_item_tooltip(self,UI_FONT,ItemDrawing.settings,item_id,crafting.durability[input_hover] if input_hover>=0 else items.durability[hover],_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale,crafting.tags[input_hover] if input_hover>=0 else items.tags[hover])
		elif mode=="enchanting":
			if Rect2(8,10,47,33).has_point(pointer):ItemTooltipDrawing.draw_tooltip(self,UI_FONT,ItemDrawing.settings,"Bookshelves: %d / %d"%[shelves,EnchantmentDatabase.DATA.table.max_bookshelves],"Bookshelves within %d blocks count, even through walls."%int(EnchantmentDatabase.DATA.table.bookshelf_radius),_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale)
			for i in range(options.size()):
				if offer_rect(i).has_point(pointer):
					var offer: Dictionary=options[i];var clue: String=str(offer.clue)
					var title: String=EnchantmentDatabase.label(clue,int(offer.values[clue]))+" ... ?" if not clue.is_empty() else "No available enchantment"
					var detail: String="\n%d Lapis Lazuli\n%d Enchantment Levels"%[offer.cost,offer.cost]
					if not world.player.creative and world.experience.level()<int(offer.required):detail="Level Requirement: %d"%offer.required
					ItemTooltipDrawing.draw_tooltip(self,UI_FONT,ItemDrawing.settings,title,detail,_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale)
		elif result_rect().has_point(pointer):
			if _anvil.has("stack"):ItemTooltipDrawing.draw_item_tooltip(self,UI_FONT,ItemDrawing.settings,_anvil.stack.id,_anvil.stack.durability,_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale,_anvil.stack.tags)
			elif _anvil.has("error"):ItemTooltipDrawing.draw_tooltip(self,UI_FONT,ItemDrawing.settings,"Anvil",str(_anvil.error),_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale)
func _screen_rect(rect: Rect2) -> Rect2:return Rect2(panel_position+rect.position*ui_scale,rect.size*ui_scale)
func _text(value: String,at: Vector2,color: Color,font_size: int=8) -> void:
	var pixels: int=roundi(font_size*ui_scale)
	draw_string(UI_FONT,(panel_position+at*ui_scale+Vector2(0,UI_FONT.get_ascent(pixels))).round(),value,HORIZONTAL_ALIGNMENT_LEFT,-1,pixels,color)
func _logical_text_width(value: String) -> float:
	return ceilf(UI_FONT.get_string_size(value,HORIZONTAL_ALIGNMENT_LEFT,-1,roundi(8*ui_scale)).x/ui_scale)
func _draw_runes(index: int,active: bool) -> void:
	var rng:=RandomNumberGenerator.new();rng.seed=world.experience.enchant_seed+index*77
	var color:=Color("ffff80") if offer_rect(index).has_point((_pointer_position()-panel_position)/ui_scale) and active else Color("685e4a") if active else Color("888077")
	for i in range(12):
		var letter: int=97+rng.randi_range(0,25)
		draw_texture_rect_region(RUNES,Rect2(79+i*6,16+index*19,6,8),Rect2((letter%16)*8,(letter/16)*8,6,8),color)
func _draw_book() -> void:
	# Side-by-side projections of the actual book UVs fit the 2D presentation.
	var center: Vector2=panel_position+Vector2(32,28)*ui_scale
	draw_set_transform(center,-.10,Vector2.ONE*ui_scale)
	draw_texture_rect_region(BOOK,Rect2(-22,-14,22,28),Rect2(0,0,6,10))
	draw_texture_rect_region(BOOK,Rect2(-20,-11,18,22),Rect2(1,11,5,8))
	draw_set_transform(center,.10,Vector2.ONE*ui_scale)
	draw_texture_rect_region(BOOK,Rect2(0,-14,22,28),Rect2(16,0,6,10))
	draw_texture_rect_region(BOOK,Rect2(2,-11,18,22),Rect2(13,11,5,8))
	draw_set_transform(panel_position,0,Vector2.ONE*ui_scale)
