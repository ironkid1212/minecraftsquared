class_name EnchantmentGlint
extends RefCounted

## Prebaked alpha-masked frames; animation slices run on the renderer without
## per-frame Image uploads, shader/material changes or a node per inventory slot.
const PATTERN: Texture2D=preload("res://assets/ui/upgrades/enchanted_glint_item.png")
const FRAMES: int=32
const PERIOD: float=2.4
const CACHE_LIMIT: int=128
static var _cache: Dictionary={}
static var _images: Dictionary={}
static var _pattern: Image
static func active(id: int,tags: Dictionary) -> bool:
	return id!=0 and (BlockDatabase.BLOCKS[id].key in ["enchanted_book","enchanted_golden_apple"] or not EnchantmentDatabase.read(tags).is_empty() or not EnchantmentDatabase.read(tags,true).is_empty())
static func sheet(texture: Texture2D,region: Rect2i) -> Texture2D:
	var key: String=str(texture.get_instance_id())+":"+str(region)
	if _cache.has(key):return _cache[key]
	if _pattern==null:_pattern=PATTERN.get_image()
	var texture_id: int=texture.get_instance_id()
	if not _images.has(texture_id):_images[texture_id]=texture.get_image()
	var source: Image=_images[texture_id]
	var image:=Image.create(region.size.x*FRAMES,region.size.y,false,Image.FORMAT_RGBA8)
	for frame in range(FRAMES):
		for y in range(region.size.y):
			for x in range(region.size.x):
				var alpha: float=source.get_pixelv(region.position+Vector2i(x,y)).a
				if alpha<=0:continue
				var a: Color=_pattern.get_pixel(posmod(x*3+y+frame*4,_pattern.get_width()),posmod(y*3-x+frame*2,_pattern.get_height()))
				var b: Color=_pattern.get_pixel(posmod(x*2-y-frame*3,_pattern.get_width()),posmod(y*2+x+frame*4,_pattern.get_height()))
				var strength: float=clampf((maxf(a.r,maxf(a.g,a.b))+maxf(b.r,maxf(b.g,b.b)))*.48,0,.55)
				image.set_pixel(frame*region.size.x+x,y,Color(.72,.35,1,strength*alpha))
	var result:=ImageTexture.create_from_image(image)
	if _cache.size()>=CACHE_LIMIT:_cache.erase(_cache.keys()[0])
	_cache[key]=result;return result
static func draw(canvas: CanvasItem,texture: Texture2D,region: Rect2i,bounds: Rect2,tint: Color=Color.WHITE) -> void:
	var redraw: Callable=canvas.queue_redraw
	if not ItemDrawing.settings.changed.is_connected(redraw):ItemDrawing.settings.changed.connect(redraw)
	var strength: float=ItemDrawing.settings.enchantment_glint_strength
	if strength<=0:return
	tint.a*=strength
	var frames: Texture2D=sheet(texture,region)
	# Keep the textures used by this draw batch alive if the global cache evicts
	# an older entry. Renderer animation slices may outlive the next redraw.
	var frame: int=Engine.get_frames_drawn()
	if int(canvas.get_meta("glint_draw_frame",-1))!=frame:
		canvas.set_meta("glint_draw_frame",frame);canvas.set_meta("glint_draw_textures",{})
	var retained: Dictionary=canvas.get_meta("glint_draw_textures",{})
	retained[frames.get_instance_id()]=frames
	canvas.set_meta("glint_draw_textures",retained)
	for i in range(FRAMES):
		canvas.draw_animation_slice(PERIOD,PERIOD*i/FRAMES,PERIOD*(i+1)/FRAMES)
		canvas.draw_texture_rect_region(frames,bounds,Rect2(i*region.size.x,0,region.size.x,region.size.y),tint)
	canvas.draw_end_animation()
