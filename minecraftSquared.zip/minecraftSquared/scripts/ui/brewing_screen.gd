class_name BrewingScreen
extends FurnaceScreen
var brewing: bool=false
var brewery: BrewingSystem
const BREW_PANEL=preload("res://assets/ui/brewing/panel.png")
const BREW_PROGRESS=preload("res://assets/ui/brewing/brew_progress.png")
const BUBBLES=preload("res://assets/ui/brewing/bubbles.png")
const FUEL=preload("res://assets/ui/brewing/fuel_length.png")
func open_furnace(at: Vector2i,host: FurnaceSystem) -> void:brewing=false;super.open_furnace(at,host)
func open_brewing(at: Vector2i,host: BrewingSystem) -> void:
	if is_open:set_open(false)
	brewing=true;cell=at;brewery=host;set_open(true,true);crafting=BrewingGrid.new(items,host.state_at(at),host);crafting.changed.connect(queue_redraw)
func craft_slot_rect(index: int) -> Rect2:
	if not brewing:return super.craft_slot_rect(index)
	return Rect2([Vector2(56,51),Vector2(79,58),Vector2(102,51),Vector2(79,17),Vector2(17,17)][index],Vector2(16,16))
func _gui_input(event: InputEvent) -> void:
	_track_pointer(event)
	if brewing and is_open and event is InputEventMouseButton and event.pressed and event.shift_pressed and event.button_index in [MOUSE_BUTTON_LEFT,MOUSE_BUTTON_RIGHT]:
		var index: int=slot_at(event.position)
		if index>=0:crafting.deposit(index);accept_event();return
	super._gui_input(event)
func _process(delta: float) -> void:
	if not brewing:super._process(delta);return
	if crafting is BrewingGrid:crafting.sync()
	queue_redraw()
func _draw() -> void:
	if not brewing:super._draw();return
	if not is_open or not crafting is BrewingGrid:return
	var state: BrewingState=crafting.state
	draw_rect(Rect2(Vector2.ZERO,size),Color(0,0,0,.55));draw_set_transform(panel_position,0,Vector2.ONE*ui_scale)
	draw_texture_rect_region(BREW_PANEL,Rect2(Vector2.ZERO,PANEL_SIZE),Rect2(Vector2.ZERO,PANEL_SIZE))
	var fuel: int=ceili(18*state.fuel/float(BrewingData.DATA.fuel_uses))
	if fuel>0:draw_texture_rect_region(FUEL,Rect2(60,44,fuel,4),Rect2(0,0,fuel,4))
	if state.remaining>0:
		var h: int=clampi(ceili(28*(1-state.remaining/float(BrewingData.DATA.seconds))),0,28)
		if h>0:draw_texture_rect_region(BREW_PROGRESS,Rect2(97,16,9,h),Rect2(0,0,9,h))
		var bubble: int=[29,24,20,16,11,6,0][posmod(int(state.remaining*20)/2,7)]
		if bubble>0:draw_texture_rect_region(BUBBLES,Rect2(63,14+29-bubble,12,bubble),Rect2(0,29-bubble,12,bubble))
	var own: int=slot_at(_pointer_position());var hovered: int=craft_slot_at(_pointer_position())
	if own>=0:draw_rect(slot_rect(own),Color(1,1,1,.3))
	if hovered>=0:draw_rect(craft_slot_rect(hovered),Color(1,1,1,.3))
	draw_set_transform(Vector2.ZERO)
	ItemDrawing.draw_panel_label(self,UI_FONT,"Brewing Stand",Vector2(0,6),ui_scale,panel_position,true)
	ItemDrawing.draw_panel_label(self,UI_FONT,"Inventory",Vector2(8,72),ui_scale,panel_position)
	for i in range(36):
		var rect: Rect2=slot_rect(i);ItemDrawing.draw_stack(self,atlas_source,UI_FONT,items.ids[i],items.counts[i],Rect2(panel_position+rect.position*ui_scale,rect.size*ui_scale),ui_scale,-1,items.durability[i],items.tags[i])
	for i in range(5):
		var rect: Rect2=craft_slot_rect(i);ItemDrawing.draw_stack(self,atlas_source,UI_FONT,state.ids[i],state.counts[i],Rect2(panel_position+rect.position*ui_scale,rect.size*ui_scale),ui_scale,-1,state.durability[i],state.tags[i])
	if items.held_count>0:ItemDrawing.draw_stack(self,atlas_source,UI_FONT,items.held_id,items.held_count,Rect2(_pointer_position()-Vector2.ONE*8*ui_scale,Vector2.ONE*16*ui_scale),ui_scale,-1,items.held_durability,items.held_tags)
	elif own>=0 or hovered>=0:
		var id: int=state.ids[hovered] if hovered>=0 else items.ids[own]
		if id>0:ItemTooltipDrawing.draw_item_tooltip(self,UI_FONT,ItemDrawing.settings,id,state.durability[hovered] if hovered>=0 else items.durability[own],_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale,state.tags[hovered] if hovered>=0 else items.tags[own])
