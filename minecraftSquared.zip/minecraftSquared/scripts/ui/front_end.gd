class_name GameFrontEnd
extends Control

@export var game_scene: PackedScene = preload("res://scenes/world.tscn")
@export var autosave_seconds: float = 60.0
@export var worlds_path: String = UserFiles.SAVES
@export_file("*.txt") var splashes_path: String = "res://data/splashes.txt"
@export var profile_directory: String = UserFiles.SKINS
var profile := PlayerProfileStore.new()
var _files_button: Button
var _profile_button: Button
var _profile_username: Label
var _username: LineEdit
var _username_label: Label
var _username_hint: Label
var _model_button: Button
var _load_skin: Button
var _convert_skin: Button
var _export_skin: Button
var _reset_skin: Button
var _profile_save: Button
var _profile_cancel: Button
var _profile_preview: ProfilePreview
var _skin_scroll: ScrollContainer
var _skin_rows: VBoxContainer
var _skin_entries: Array[Dictionary] = []
var _skin_group := ButtonGroup.new()
var _chosen_skin_index: int = -1
var _use_skin: Button
var _rename_skin_button: Button
var _delete_skin_button: Button
var _skin_edit_message: Label
var _skin_edit_name: LineEdit
var _skin_edit_apply: Button
var _skin_edit_cancel: Button
var _managed_skin_id: String=""
var _skin_back: Button
var _keep_profile_draft: bool = false
var _draft_skin_id: String = "default"
var _skin_info: Label
var _file_dialog: FileDialog
var _dialog_mode: String = ""
var _draft_image: Image
var _source_image: Image
var _draft_slim: bool = false
var _last_source_path: String = ""
var _delete: Button
var _delete_message: Label
var _delete_confirm: Button
var _delete_cancel: Button
var _pending_delete_id: String = ""
var _splash: TitleSplash

var store := WorldSaveStore.new()
var document: Dictionary = {}
var game: Node
var world: Node2D
var page: String = "title"
var _skin := MenuSkin.new()
var _scale: int = 1
var _layer: CanvasLayer
var _panel: Control
var _background: TextureRect
var _logo: TextureRect
var _edition: Label
var _heading: Label
var _status: Label
var _play: Button
var _options: Button
var _quit: Button
var _list: ScrollContainer
var _rows: VBoxContainer
var _row_group := ButtonGroup.new()
var _selected_index: int = -1
var _empty: Label
var _join: Button
var _new: Button
var _back: Button
var _name_label: Label
var _name: LineEdit
var _seed_label: Label
var _seed: LineEdit
var _seed_hint: Label
var _create: Button
var _entries: Array[Dictionary] = []
var _timer: Timer
var _busy: bool = false
var _creation_initialized: bool = false

func _ready() -> void:
	UserFiles.prepare()
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	get_window().content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	get_tree().auto_accept_quit = false
	store.save_root = worlds_path
	profile.directory = profile_directory
	profile.load_profile(_base_settings().player.skin_texture)
	_build()
	get_viewport().size_changed.connect(_layout)
	_timer = Timer.new()
	_timer.wait_time = maxf(10, autosave_seconds)
	_timer.timeout.connect(func():
		if is_instance_valid(world) and not save_current():
			_report_error(store.last_error)
	)
	add_child(_timer)
	show_page("title")

func _button(text: String, callback: Callable) -> Button:
	var button := Button.new()
	button.text = text
	button.pressed.connect(InterfaceAudio.click)
	button.mouse_force_pass_scroll_events = false
	button.pressed.connect(callback)
	_panel.add_child(button)
	return button

func _label(text: String, centered: bool = true) -> Label:
	var label := Label.new()
	label.text = text
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if centered else HORIZONTAL_ALIGNMENT_LEFT
	_panel.add_child(label)
	return label

func _build() -> void:
	_layer = CanvasLayer.new()
	_layer.layer = 50
	add_child(_layer)
	_panel = Control.new()
	_panel.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_layer.add_child(_panel)
	_background = TextureRect.new()
	_background.texture = preload("res://assets/ui/title/dirt.png")
	_background.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	_background.stretch_mode = TextureRect.STRETCH_TILE
	_background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_background.modulate = Color(0.22, 0.22, 0.22)
	_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(_background)
	_logo = TextureRect.new()
	_logo.texture = preload("res://assets/ui/title/minecraft.png")
	_logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(_logo)
	_edition = _label("")
	_splash = TitleSplash.new()
	_splash.splashes_path = splashes_path
	_panel.add_child(_splash)
	_heading = _label("")
	_status = _label("")
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.add_theme_color_override("font_color", Color(1, 0.7, 0.5))
	_play = _button("Singleplayer", func(): show_page("worlds"))
	_options = _button("Options...", func(): _options_menu().open_options("title"))
	_quit = _button("Quit Game", _request_quit)
	_files_button = _button("Open Game Folder",func(): UserFiles.open_folder(files_path()))
	_profile_button = _button("Profile...", func(): show_page("profile"))
	_profile_username = _label(profile.username, false)
	_list = ScrollContainer.new()
	_list.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_panel.add_child(_list)
	_rows = VBoxContainer.new()
	_rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_child(_rows)
	_empty = _label("No worlds yet.\nCreate one to get started.")
	_join = _button("Play Selected World", _join_selected)
	_new = _button("Create New World", func(): show_page("create"))
	_delete = _button("Delete World", _request_delete)
	_delete_message = _label("")
	_delete_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_delete_confirm = _button("Delete World", _confirm_delete)
	_delete_cancel = _button("Cancel", func(): show_page("worlds"))
	_back = _button("Back", func(): show_page("worlds" if page == "create" else "title"))
	_name_label = _label("World Name", false)
	_name = LineEdit.new()
	_name.max_length = 64
	_name.text = "New World"
	_name.placeholder_text = "New World"
	_name.text_changed.connect(func(_text: String): _create.disabled = _name.text.strip_edges().is_empty())
	_panel.add_child(_name)
	_seed_label = _label("Seed", false)
	_seed = LineEdit.new()
	_seed.max_length = 128
	_seed.placeholder_text = "Leave blank for a random seed"
	_seed.text_submitted.connect(func(_text: String): _create_world())
	_panel.add_child(_seed)
	_seed_hint = _label("Use a number or any text.\nThe same seed recreates the same terrain.", false)
	_create = _button("Create New World", _create_world)
	_username_label = _label("Username", false)
	_username = LineEdit.new()
	_username.max_length = 16
	_username.text_changed.connect(func(value: String): _profile_save.disabled = not PlayerProfileStore.valid_username(value))
	_panel.add_child(_username)
	_username_hint = _label("3-16 letters, numbers, _", false)
	_model_button = _button("Source: Classic/Steve", _toggle_skin_model)
	_load_skin = _button("Load 2D Skin...", func(): _choose_skin_file("2d"))
	_convert_skin = _button("Convert Minecraft Skin...", func(): _choose_skin_file("minecraft"))
	_export_skin = _button("Export 2D PNG...", func(): _choose_skin_file("export"))
	_reset_skin = _button("Skins...", func(): show_page("skins"))
	_skin_scroll = ScrollContainer.new()
	_skin_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_panel.add_child(_skin_scroll)
	_skin_rows = VBoxContainer.new()
	_skin_rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_skin_scroll.add_child(_skin_rows)
	_use_skin = _button("Use Skin", _use_selected_skin)
	_skin_back = _button("Back", _return_to_profile)
	_rename_skin_button=_button("Rename",func():_request_skin_edit(false))
	_delete_skin_button=_button("Delete",func():_request_skin_edit(true))
	_skin_edit_message=_label("");_skin_edit_message.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	_skin_edit_name=LineEdit.new();_skin_edit_name.max_length=64;_panel.add_child(_skin_edit_name)
	_skin_edit_apply=_button("Save Name",_apply_skin_edit)
	_skin_edit_cancel=_button("Cancel",func():show_page("skins"))
	_skin_edit_name.text_changed.connect(func(value: String):_skin_edit_apply.disabled=value.strip_edges().is_empty())
	_skin_edit_name.text_submitted.connect(func(_value: String):_apply_skin_edit())
	_profile_save = _button("Save Profile", _save_profile)
	_profile_cancel = _button("Cancel", func(): show_page("title"))
	_profile_preview = ProfilePreview.new()
	_panel.add_child(_profile_preview)
	_skin_info = _label("")
	_file_dialog = FileDialog.new()
	_file_dialog.access = FileDialog.ACCESS_FILESYSTEM
	_file_dialog.use_native_dialog = true
	_file_dialog.filters = PackedStringArray(["*.png ; PNG skin images"])
	_file_dialog.file_selected.connect(_skin_file_selected)
	_file_dialog.canceled.connect(func(): get_viewport().gui_release_focus())
	_layer.add_child(_file_dialog)

func set_menu_overlay_active(obscured: bool) -> void:
	if obscured:
		_panel.hide()
	elif not is_instance_valid(world) and not _busy:
		_panel.show()
		_layout()
		get_viewport().gui_release_focus()

func _options_menu() -> Node:
	return get_node("/root/GameOptions")

func show_page(next: String) -> void:
	page = next
	_status.text = ""
	_panel.show()
	for control in [_rename_skin_button,_delete_skin_button,_skin_edit_message,_skin_edit_name,_skin_edit_apply,_skin_edit_cancel,_skin_scroll, _use_skin, _skin_back, _logo, _edition, _splash, _profile_button, _profile_username, _delete, _delete_message, _delete_confirm, _delete_cancel, _username_label, _username, _username_hint, _model_button, _load_skin, _convert_skin, _export_skin, _reset_skin, _profile_save, _profile_cancel, _profile_preview, _skin_info, _heading, _play, _options, _quit, _list, _empty, _join, _new, _back, _name_label, _name, _seed_label, _seed, _seed_hint, _create]:
		control.hide()
	match page:
		"title":
			for control in [_logo, _edition, _splash, _play, _options, _profile_button, _profile_username, _quit]: control.show()
			_splash.choose_splash()
		"worlds":
			_heading.text = "Select World"
			for control in [_heading, _list, _join, _new, _delete, _back]: control.show()
			_refresh_world_list()
		"create":
			_heading.text = "Create New World"
			for control in [_heading, _name_label, _name, _seed_label, _seed, _seed_hint, _create, _back]: control.show()
			if not _creation_initialized:
				_name.text = "New World"
				_seed.text = ""
				_creation_initialized = true
			_create.disabled = _name.text.strip_edges().is_empty()
		"delete":
			_heading.text = "Delete World?"
			for control in [_heading, _delete_message, _delete_confirm, _delete_cancel]: control.show()
		"profile":
			_heading.text = "Profile"
			for control in [_heading, _username_label, _username, _username_hint, _model_button, _load_skin, _convert_skin, _export_skin, _reset_skin, _profile_save, _profile_cancel, _profile_preview, _skin_info]: control.show()
			if not _keep_profile_draft: _begin_profile()
			_keep_profile_draft = false
		"skins":
			_heading.text = "Select Skin"
			for control in [_heading,_rename_skin_button,_delete_skin_button, _skin_scroll, _use_skin, _skin_back, _profile_preview, _skin_info]: control.show()
			_refresh_skin_list()
		"skin_rename", "skin_delete":
			_heading.text="Rename Skin" if page=="skin_rename" else "Delete Skin?"
			for control in [_heading,_skin_edit_message,_skin_edit_apply,_skin_edit_cancel]:control.show()
			_skin_edit_name.visible=page=="skin_rename"
			_skin_edit_apply.text="Save Name" if page=="skin_rename" else "Delete Skin"
			_skin_edit_apply.disabled=page=="skin_rename" and _skin_edit_name.text.strip_edges().is_empty()
		"loading":
			_heading.text = "Preparing World..."
			_heading.show()
	_files_button.visible=page in ["title","worlds","profile","skins"]
	_files_button.text="Open Saves Folder" if page=="worlds" else "Open Skins Folder" if page in ["profile","skins"] else "Open Game Folder"
	_files_button.tooltip_text=ProjectSettings.globalize_path(files_path())
	_layout()
	get_viewport().gui_release_focus()

func files_path() -> String:
	return store.save_root if page=="worlds" else profile.directory if page in ["profile","skins"] else "user://"

func _refresh_world_list() -> void:
	_entries = store.list_worlds()
	for row in _rows.get_children():
		_rows.remove_child(row)
		row.queue_free()
	_selected_index = -1
	for index in range(_entries.size()):
		var entry: Dictionary = _entries[index]
		var local_time: int = int(entry["last_played"]) + int(Time.get_time_zone_from_system().get("bias", 0)) * 60
		var stamp: String = Time.get_datetime_string_from_unix_time(local_time).replace("T", " ").left(16)
		var detail: String = "Save could not be read" if entry["broken"] else "Seed: %s | %s" % [str(entry["seed"]), stamp]
		var row := WorldListRow.new()
		row.configure(str(entry["name"]), detail, _scale)
		row.button_group = _row_group
		row.pressed.connect(func(): _select_world(index))
		row.gui_input.connect(func(event: InputEvent):
			if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed and event.double_click:
				_select_world(index)
				_join_selected()
		)
		_rows.add_child(row)
	_join.disabled = true
	_delete.disabled = true
	_empty.visible = _entries.is_empty()

func _select_world(index: int) -> void:
	_selected_index = index
	_join.disabled = false
	_delete.disabled = false
	(_rows.get_child(index) as WorldListRow).button_pressed = true

func _join_selected() -> void:
	if _selected_index < 0 or _selected_index >= _entries.size() or _busy:
		return
	var loaded: Dictionary = store.load_world(str(_entries[_selected_index]["id"]))
	if loaded.is_empty():
		_status.text = store.last_error
		return
	_start_world(loaded)

func _base_settings() -> Resource:
	var prototype: Node = game_scene.instantiate()
	var world_prototype: Node = prototype
	if prototype.has_method("screen_to_world_viewport"):
		world_prototype = prototype.world_scene.instantiate()
	var settings: Resource = world_prototype.settings.duplicate(true)
	if world_prototype != prototype: world_prototype.free()
	prototype.free()
	return settings

func _create_world() -> void:
	if _busy or _name.text.strip_edges().is_empty():
		return
	var created: Dictionary = store.new_document(_name.text, _seed.text, _base_settings())
	_start_world(created)

func _start_world(next: Dictionary) -> void:
	_busy = true
	show_page("loading")
	await get_tree().process_frame
	await get_tree().process_frame
	document = next
	game = game_scene.instantiate()
	game.process_mode = Node.PROCESS_MODE_PAUSABLE
	var settings: Resource = store.settings_for(document, _base_settings())
	if game.has_method("screen_to_world_viewport"):
		var prototype: Node = game.world_scene.instantiate()
		prototype.settings = settings
		var packed := PackedScene.new()
		var result: Error = packed.pack(prototype)
		prototype.free()
		if result != OK:
			game.free()
			_busy = false
			show_page("worlds")
			_status.text = "Could not prepare the world scene."
			return
		game.world_scene = packed
	else:
		game.settings = settings
	add_child(game)
	world = game.world if game.has_method("screen_to_world_viewport") else game
	if world.inventory_screen == null or not store.restore_world(document, world):
		var message: String = store.last_error if not store.last_error.is_empty() else "World initialization failed. Check the debugger."
		game.free()
		game = null
		world = null
		_busy = false
		show_page("worlds")
		_status.text = message
		return
	profile.apply_to(world)
	if game.has_method("_update_camera"): game._update_camera()
	else: world.player.get_node("Camera2D").force_update_scroll()
	# Commit new worlds before exposing gameplay. Failed writes keep the world
	# in memory with an error instead of pretending it was saved successfully.
	if not save_current():
		_panel.hide()
		_busy = false
		_timer.start()
		_report_error(store.last_error)
		return
	_panel.hide()
	_busy = false
	_creation_initialized = false
	_timer.start()

func save_current() -> bool:
	if not is_instance_valid(world):
		return true
	return store.save_world(document, world)

func save_and_return() -> void:
	if not save_current():
		_report_error(store.last_error)
		return
	var options: Node = _options_menu()
	if options.is_open: options.set_open(false)
	_timer.stop()
	if is_instance_valid(game): game.free()
	game = null
	world = null
	document = {}
	get_tree().paused = false
	show_page("title")

func _report_error(message: String) -> void:
	if is_instance_valid(world):
		var options: Node = _options_menu()
		options.set_open(true)
		options._hint.text = "Save failed. Check the save folder."
		options._hint.tooltip_text = message
		options._hint.show()
	else:
		_status.text = message
	push_warning("World save: " + message)

func _request_quit() -> void:
	if not save_current():
		_report_error(store.last_error)
		return
	_options_menu().save_options()
	get_tree().quit()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_request_quit()

func _unhandled_key_input(event: InputEvent) -> void:
	if _panel.visible and not _options_menu().is_open and page != "loading" and event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		if page in ["skin_rename","skin_delete"]: show_page("skins")
		elif page == "skins": _return_to_profile()
		elif page != "title": show_page("worlds" if page in ["create", "delete"] else "title")
		get_viewport().set_input_as_handled()

func _place(control: Control, origin: Vector2, offset: Vector2, dimensions: Vector2) -> void:
	control.position = origin + offset * _scale
	control.size = dimensions * _scale

func _layout() -> void:
	if _panel == null:
		return
	var screen: Vector2 = get_viewport_rect().size
	var max_scale: int = int(ItemDrawing.settings.maximum_scale)
	_scale = clampi(floori(minf((screen.x - 20) / 320.0, (screen.y - 20) / 220.0)), 1, max_scale)
	_panel.size = screen
	_panel.theme = _skin.theme_for(_scale)
	_files_button.position=Vector2(screen.x-118*_scale,screen.y-26*_scale if page=="title" else 6*_scale)
	_files_button.size=Vector2(112,20)*_scale
	_rows.add_theme_constant_override("separation", 4 * _scale)
	_skin_rows.add_theme_constant_override("separation", 4 * _scale)
	for row in _skin_rows.get_children():
		row.gui_scale = _scale
		row.custom_minimum_size.y = 40 * _scale
		row._layout()
	for row in _rows.get_children():
		if row is WorldListRow:
			row.gui_scale = _scale
			row.custom_minimum_size.y = 40 * _scale
			row._layout()
	_background.texture = _skin.background_texture(_scale)
	_background.size = screen
	var origin: Vector2 = ((screen - Vector2(320, 220) * _scale) / 2.0).floor()
	_place(_logo, origin, Vector2(20, 0), Vector2(280, 70))
	_place(_edition, origin, Vector2(20, 53), Vector2(280, 20))
	_place(_splash, origin, Vector2(185, 30), Vector2(140, 44))
	_splash.gui_scale = _scale
	_splash.queue_redraw()
	_place(_play, origin, Vector2(60, 96), Vector2(200, 20))
	_place(_options, origin, Vector2(60, 124), Vector2(98, 20))
	_place(_profile_button, origin, Vector2(162, 124), Vector2(98, 20))
	_profile_username.text = profile.username
	_profile_username.position = Vector2(6, maxf(0, screen.y - 14 * _scale))
	_profile_username.size = Vector2(120, 12) * _scale
	_place(_quit, origin, Vector2(60, 152), Vector2(200, 20))
	_place(_heading, origin, Vector2(0, 0), Vector2(320, 20))
	_place(_list, origin, Vector2(0, 28), Vector2(320, 125))
	_place(_empty, origin, Vector2(0, 58), Vector2(320, 60))
	_place(_join, origin, Vector2(0, 162), Vector2(155, 20))
	_place(_new, origin, Vector2(165, 162), Vector2(155, 20))
	_place(_delete, origin, Vector2(0, 190), Vector2(155, 20))
	_place(_back, origin, Vector2(165, 190), Vector2(155, 20))
	_place(_delete_message, origin, Vector2(10, 50), Vector2(300, 100))
	_place(_delete_confirm, origin, Vector2(0, 190), Vector2(155, 20))
	_place(_delete_cancel, origin, Vector2(165, 190), Vector2(155, 20))
	_place(_name_label, origin, Vector2(20, 35), Vector2(280, 12))
	_place(_name, origin, Vector2(20, 49), Vector2(280, 22))
	_place(_seed_label, origin, Vector2(20, 84), Vector2(280, 12))
	_place(_seed, origin, Vector2(20, 98), Vector2(280, 22))
	_place(_seed_hint, origin, Vector2(20, 125), Vector2(280, 40))
	_place(_create, origin, Vector2(0, 190), Vector2(155, 20))
	if page == "create": _place(_back, origin, Vector2(165, 190), Vector2(155, 20))
	_place(_username_label, origin, Vector2(20, 25), Vector2(180, 12))
	_place(_username, origin, Vector2(20, 39), Vector2(180, 22))
	_place(_username_hint, origin, Vector2(20, 63), Vector2(180, 12))
	_place(_model_button, origin, Vector2(20, 78), Vector2(180, 20))
	_place(_load_skin, origin, Vector2(20, 102), Vector2(180, 20))
	_place(_convert_skin, origin, Vector2(20, 126), Vector2(180, 20))
	_place(_export_skin, origin, Vector2(20, 150), Vector2(92, 20))
	_place(_reset_skin, origin, Vector2(118, 150), Vector2(82, 20))
	_place(_profile_save, origin, Vector2(0, 190), Vector2(155, 20))
	_place(_profile_cancel, origin, Vector2(165, 190), Vector2(155, 20))
	_place(_profile_preview, origin, Vector2(220, 28), Vector2(80, 124))
	_profile_preview.gui_scale = _scale
	_place(_skin_info, origin, Vector2(210, 156), Vector2(100, 25))
	_place(_skin_scroll, origin, Vector2(0, 28), Vector2(200, 125))
	_place(_rename_skin_button,origin,Vector2(0,162),Vector2(96,20))
	_place(_delete_skin_button,origin,Vector2(104,162),Vector2(96,20))
	_place(_skin_edit_message,origin,Vector2(20,35),Vector2(280,80))
	_place(_skin_edit_name,origin,Vector2(20,120),Vector2(280,22))
	_place(_skin_edit_apply,origin,Vector2(0,190),Vector2(155,20))
	_place(_skin_edit_cancel,origin,Vector2(165,190),Vector2(155,20))
	_place(_use_skin, origin, Vector2(0, 190), Vector2(155, 20))
	_place(_skin_back, origin, Vector2(165, 190), Vector2(155, 20))
	_place(_status, origin, Vector2(0, 216), Vector2(320, 14))


func _request_delete() -> void:
	if is_instance_valid(world) or _busy or _selected_index < 0 or _selected_index >= _entries.size():
		return
	var entry: Dictionary = _entries[_selected_index]
	_pending_delete_id = str(entry["id"])
	_delete_message.text = 'Delete "%s"?\n\nThis permanently removes this world, including its inventory, block changes and backup.' % str(entry["name"])
	show_page("delete")

func _confirm_delete() -> void:
	if page != "delete" or _pending_delete_id.is_empty() or is_instance_valid(world) or _busy:
		return
	if not store.delete_world(_pending_delete_id):
		_status.text = store.last_error
		return
	_pending_delete_id = ""
	show_page("worlds")
	_status.text = "World deleted."

func _begin_profile() -> void:
	_draft_skin_id = profile.selected_skin_id
	_username.text = profile.username
	_draft_slim = profile.slim
	_source_image = null
	_last_source_path = ""
	_model_button.text = "Source: Slim/Alex" if _draft_slim else "Source: Classic/Steve"
	_set_draft_skin(profile.texture.get_image())
	_profile_save.disabled = not PlayerProfileStore.valid_username(_username.text)
	if not profile.last_error.is_empty(): _status.text = profile.last_error

func _set_draft_skin(image: Image) -> void:
	if not PlayerProfileStore.valid_2d_image(image):
		_status.text = "A 2D skin must be 48N x 32N pixels."
		return
	_draft_image = image
	_profile_preview.set_skin(ImageTexture.create_from_image(image))
	_skin_info.text = "%d x %d\n2D skin" % [image.get_width(), image.get_height()]

func _toggle_skin_model() -> void:
	_draft_slim = not _draft_slim
	_model_button.text = "Source: Slim/Alex" if _draft_slim else "Source: Classic/Steve"
	if _source_image != null:
		_convert_source_skin()

func _choose_skin_file(mode: String) -> void:
	_dialog_mode = mode
	_file_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE if mode == "export" else FileDialog.FILE_MODE_OPEN_FILE
	_file_dialog.title = "Export 2D Skin" if mode == "export" else "Choose Minecraft Skin" if mode == "minecraft" else "Choose 2D Skin"
	_file_dialog.current_file = (_username.text if PlayerProfileStore.valid_username(_username.text) else "skin") + "_2d.png" if mode == "export" else ""
	_file_dialog.popup_centered_ratio(0.8)

func _skin_file_selected(path: String) -> void:
	get_viewport().gui_release_focus()
	if _dialog_mode == "export":
		if path.get_extension().to_lower() != "png":
			_status.text = "Export with a .png filename."
			return
		if not _last_source_path.is_empty() and ProjectSettings.globalize_path(path).simplify_path().to_lower() == ProjectSettings.globalize_path(_last_source_path).simplify_path().to_lower():
			_status.text = "Choose another filename to keep the source skin."
			return
		_status.text = "2D skin exported." if _draft_image.save_png(path) == OK else "Could not export the PNG. Check its folder."
		return
	var image := Image.new()
	if image.load(path) != OK or image.get_width() > 4096:
		_status.text = "Could not read this PNG, or it is too large."
		return
	if _dialog_mode == "minecraft":
		_source_image = image
		_last_source_path = path
		_convert_source_skin()
	else:
		if not PlayerProfileStore.valid_2d_image(image):
			_status.text = "A 2D skin must be 48N x 32N pixels."
			return
		_source_image = null
		_last_source_path = path
		_set_draft_skin(image)
		if _remember_draft_skin():
			_status.text = "Added to your skins. Press Save Profile to apply."

func _convert_source_skin() -> void:
	var result: Dictionary = MinecraftSkinConverter.convert(_source_image, _draft_slim)
	if result.has("error"):
		_status.text = result["error"]
		return
	_set_draft_skin(result["image"])
	if _remember_draft_skin():
		_status.text = "Converted and added to your skins. Save Profile to apply."

func _save_profile() -> void:
	if not profile.save_profile(_username.text, _draft_image, _draft_slim):
		_status.text = profile.last_error
		return
	if is_instance_valid(world): profile.apply_to(world)
	show_page("title")
	_status.text = "Profile saved."


func _remember_draft_skin() -> bool:
	var id: String = profile.remember_skin(_draft_image, _last_source_path.get_file().get_basename(), _draft_slim)
	if id.is_empty():
		_status.text = profile.last_error
		return false
	_draft_skin_id = id
	return true


func _refresh_skin_list() -> void:
	for row in _skin_rows.get_children():
		_skin_rows.remove_child(row)
		row.queue_free()
	_skin_entries = profile.list_skins()
	_chosen_skin_index = -1
	_use_skin.disabled = true
	_rename_skin_button.disabled=true;_delete_skin_button.disabled=true
	_skin_scroll.scroll_vertical = 0
	for index in range(_skin_entries.size()):
		var entry: Dictionary = _skin_entries[index]
		var row := SkinListRow.new()
		row.configure_skin(entry, _scale)
		row.button_group = _skin_group
		row.pressed.connect(func(): _select_skin(index))
		_skin_rows.add_child(row)
		if str(entry["id"]) == _draft_skin_id: _select_skin(index)
	get_viewport().gui_release_focus()


func _select_skin(index: int) -> void:
	if index < 0 or index >= _skin_entries.size(): return
	_chosen_skin_index = index
	_use_skin.disabled = false
	(_skin_rows.get_child(index) as Button).button_pressed = true
	var entry: Dictionary = _skin_entries[index]
	_rename_skin_button.disabled=entry.id=="default";_delete_skin_button.disabled=entry.id=="default"
	var texture: Texture2D = entry["texture"]
	_profile_preview.set_skin(texture)
	_skin_info.text = "%d x %d\n2D skin" % [texture.get_width(), texture.get_height()]
	get_viewport().gui_release_focus()


func _use_selected_skin() -> void:
	if _chosen_skin_index < 0 or _chosen_skin_index >= _skin_entries.size(): return
	var entry: Dictionary = _skin_entries[_chosen_skin_index]
	var texture: Texture2D = entry["texture"]
	_draft_skin_id = str(entry["id"])
	_draft_slim = bool(entry["slim"])
	_source_image = null
	_last_source_path = ""
	_set_draft_skin(texture.get_image())
	_model_button.text = "Source: Slim/Alex" if _draft_slim else "Source: Classic/Steve"
	_return_to_profile()
	_status.text = "Skin selected. Press Save Profile to apply."


func _return_to_profile() -> void:
	_keep_profile_draft = true
	_set_draft_skin(_draft_image)
	show_page("profile")

func _request_skin_edit(removing: bool) -> void:
	if _chosen_skin_index<0 or _chosen_skin_index>=_skin_entries.size():return
	var entry: Dictionary=_skin_entries[_chosen_skin_index]
	if entry.id=="default":return
	_managed_skin_id=entry.id
	_skin_edit_name.text=entry.name
	_skin_edit_message.text=('Delete "'+str(entry.name)+'" from your skin library? Your original imported file is kept. If this skin is active, Steve becomes the active skin.') if removing else ('Choose a new name for "'+str(entry.name)+'".')
	show_page("skin_delete" if removing else "skin_rename")
func _apply_skin_edit() -> void:
	if page not in ["skin_rename","skin_delete"] or _managed_skin_id.is_empty():return
	var deleting: bool=page=="skin_delete"
	if not (profile.delete_skin(_managed_skin_id) if deleting else profile.rename_skin(_managed_skin_id,_skin_edit_name.text)):
		_status.text=profile.last_error;return
	var message: String="Skin deleted." if deleting else "Skin renamed."
	if deleting and _draft_skin_id==_managed_skin_id:
		_draft_skin_id="default";_draft_slim=false;_source_image=null;_last_source_path="";_set_draft_skin(PlayerProfileStore.STEVE.get_image())
	if deleting and is_instance_valid(world):profile.apply_to(world)
	show_page("skins")
	if not deleting:
		for index in range(_skin_entries.size()):
			if _skin_entries[index].id==_managed_skin_id:_select_skin(index);break
	_status.text=profile.last_error if not profile.last_error.is_empty() else message
	_managed_skin_id=""
