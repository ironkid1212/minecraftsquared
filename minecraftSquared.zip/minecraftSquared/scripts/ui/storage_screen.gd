class_name StorageScreen
extends InventoryScreen
const STORAGE_PANEL: Texture2D=preload("res://assets/ui/storage.png")
var cells: Array[Vector2i]=[]
var system: StorageSystem
var rows: int=3
var _last_pointer:=Vector2(-10000,-10000)
func _process(_delta: float) -> void:
	var pointer: Vector2=_pointer_position()
	if pointer!=_last_pointer:_last_pointer=pointer;queue_redraw()
func open_container(locations: Array[Vector2i],host: StorageSystem) -> void:
	if is_open:set_open(false)
	cells=locations;system=host;rows=cells.size()*3
	set_open(true,true)
	crafting=StorageGrid.new(items,host,cells);crafting.changed.connect(queue_redraw)
	_resize()
func _resize() -> void:
	size=get_viewport_rect().size;ui_scale=ItemDrawing.settings.gui_scale(size)
	ui_scale=maxf(1,minf(ui_scale,floorf((size.y-16)/(114+rows*18))))
	panel_position=((size-Vector2(176,114+rows*18)*ui_scale)*.5).floor();queue_redraw()
func _input(event: InputEvent) -> void:
	_track_pointer(event)
	if not is_open:return
	if not event is InputEventKey and not event is InputEventMouseButton:return
	if not event.pressed or event is InputEventKey and event.echo:return
	if GameBindings.matches(event,"inventory") or event is InputEventKey and event.physical_keycode==KEY_ESCAPE:set_open(false);get_viewport().set_input_as_handled()
	else:super._input(event)
func slot_rect(index: int) -> Rect2:
	return Rect2(8+(index%9)*18,rows*18+(90 if index<9 else 32+((index-9)/9)*18),16,16)
func craft_slot_rect(index: int) -> Rect2:return Rect2(8+(index%9)*18,18+(index/9)*18,16,16)
func result_rect() -> Rect2:return Rect2(-1000,-1000,0,0)
func _gui_input(event: InputEvent) -> void:
	if is_open and not read_only and event is InputEventMouseButton and event.pressed and event.shift_pressed:
		var index: int=slot_at(event.position)
		if index>=0:
			crafting.deposit(index);accept_event();return
	super._gui_input(event)
func _draw() -> void:
	if not is_open or system==null:return
	draw_rect(Rect2(Vector2.ZERO,size),Color(0,0,0,.55))
	draw_set_transform(panel_position,0,Vector2.ONE*ui_scale)
	var upper: float=17+rows*18
	draw_texture_rect_region(STORAGE_PANEL,Rect2(0,0,176,upper),Rect2(0,0,176,upper))
	draw_texture_rect_region(STORAGE_PANEL,Rect2(0,upper,176,97),Rect2(0,125,176,97))
	var main_hover: int=slot_at(_pointer_position());var hover: int=craft_slot_at(_pointer_position())
	if main_hover>=0:draw_rect(slot_rect(main_hover),Color(1,1,1,.3))
	if hover>=0:draw_rect(craft_slot_rect(hover),Color(1,1,1,.3))
	draw_set_transform(Vector2.ZERO)
	ItemDrawing.draw_panel_label(self,UI_FONT,system.title(cells),Vector2(8,6),ui_scale,panel_position)
	ItemDrawing.draw_panel_label(self,UI_FONT,"Inventory",Vector2(8,rows*18+20),ui_scale,panel_position)
	for i in range(BlockInventory.MAIN_COUNT):ItemDrawing.draw_stack(self,atlas_source,UI_FONT,items.ids[i],items.counts[i],Rect2(panel_position+slot_rect(i).position*ui_scale,Vector2(16,16)*ui_scale),ui_scale,-1,items.durability[i],items.tags[i])
	for i in range(crafting.ids.size()):ItemDrawing.draw_stack(self,atlas_source,UI_FONT,crafting.ids[i],crafting.counts[i],Rect2(panel_position+craft_slot_rect(i).position*ui_scale,Vector2(16,16)*ui_scale),ui_scale,-1,crafting.durability[i],crafting.tags[i])
	if items.held_count>0:
		ItemDrawing.draw_stack(self,atlas_source,UI_FONT,items.held_id,items.held_count,Rect2(_pointer_position()-Vector2(8,8)*ui_scale,Vector2(16,16)*ui_scale),ui_scale,-1,items.held_durability,items.held_tags)
	elif hover>=0:ItemTooltipDrawing.draw_item_tooltip(self,UI_FONT,ItemDrawing.settings,crafting.ids[hover],crafting.durability[hover],_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale,crafting.tags[hover])
	elif main_hover>=0:ItemTooltipDrawing.draw_item_tooltip(self,UI_FONT,ItemDrawing.settings,items.ids[main_hover],items.durability[main_hover],_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale,items.tags[main_hover])

func panel_dimensions() -> Vector2:return Vector2(176,114+rows*18)
