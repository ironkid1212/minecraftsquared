class_name KeybindScreen
extends Control

var bindings: GameBindings
var _menu: Node
var _title: Label
var _hint: Label
var _scroll: ScrollContainer
var _rows: VBoxContainer
var _reset_all: Button
var _done: Button
var _buttons: Dictionary = {}
var _resets: Dictionary = {}
var _labels: Array[Label] = []
var capturing: String = ""
var _pending_key: int = 0
var _scale: int = 1

func setup(menu: Node, data: GameBindings) -> void:
	_menu = menu
	bindings = data
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	mouse_filter = Control.MOUSE_FILTER_STOP
	_title = Label.new()
	_title.text = "Key Binds"
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_title)
	_hint = Label.new()
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_hint)
	_scroll = ScrollContainer.new()
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_scroll.mouse_force_pass_scroll_events = false
	add_child(_scroll)
	_rows = VBoxContainer.new()
	_rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.add_child(_rows)
	for context in ["movement", "survival", "spectator", "global"]:
		var heading := Label.new()
		heading.text = str({"movement":"Movement", "survival":"Survival", "spectator":"Spectator", "global":"Interface / Debug"}[context])
		_rows.add_child(heading)
		_labels.append(heading)
		for definition in bindings.definitions:
			if definition["context"] != context: continue
			var action: String = definition["action"]
			var row := HBoxContainer.new()
			_rows.add_child(row)
			var label := Label.new()
			label.text = definition["label"]
			label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			row.add_child(label)
			_labels.append(label)
			var button := _button("")
			row.add_child(button)
			button.clip_text = true
			button.pressed.connect(func(): begin_capture(action))
			_buttons[action] = button
			var reset := _button("Reset")
			row.add_child(reset)
			reset.pressed.connect(func(): bindings.reset_action(action))
			_resets[action] = reset
	_reset_all = _button("Reset All")
	add_child(_reset_all)
	_reset_all.pressed.connect(func(): bindings.reset_all())
	_done = _button("Done")
	add_child(_done)
	_done.pressed.connect(_back)
	bindings.changed.connect(func(_action: String): refresh())
	refresh()
	visible = false

func _button(text: String) -> Button:
	var button := Button.new()
	button.text = text
	button.pressed.connect(InterfaceAudio.click)
	button.focus_mode = Control.FOCUS_NONE
	button.mouse_force_pass_scroll_events = false
	return button

func _style(control: Control, font: Font, scale_value: int) -> void:
	control.add_theme_font_override("font", font)
	control.add_theme_font_size_override("font_size", 8 * scale_value)
	control.add_theme_color_override("font_color", Color.WHITE)
	control.add_theme_color_override("font_shadow_color", Color(.2,.2,.2))
	control.add_theme_constant_override("shadow_offset_x", scale_value)
	control.add_theme_constant_override("shadow_offset_y", scale_value)
	if control is Button:
		for state in ["normal", "hover", "pressed", "hover_pressed", "disabled"]:
			control.add_theme_stylebox_override(state, _menu._style("button" if state == "normal" else "button_disabled" if state == "disabled" else "button_highlighted"))

func arrange(window_size: Vector2, scale_value: int, font: Font) -> void:
	_scale = scale_value
	size = Vector2(310, 260) * _scale
	position = ((window_size - size) * .5).floor()
	_title.position = Vector2.ZERO
	_title.size = Vector2(310,20) * _scale
	_hint.position = Vector2(0,24) * _scale
	_hint.size = Vector2(310,16) * _scale
	_scroll.position = Vector2(0,46) * _scale
	_scroll.size = Vector2(310,180) * _scale
	_rows.add_theme_constant_override("separation", 4 * _scale)
	for child in _rows.get_children():
		if child is Label:
			child.custom_minimum_size.y = 20 * _scale
			_style(child,font,_scale)
		elif child is HBoxContainer:
			child.add_theme_constant_override("separation", 3 * _scale)
			child.custom_minimum_size.y = 22 * _scale
			child.get_child(0).custom_minimum_size = Vector2(126,20) * _scale
			child.get_child(1).custom_minimum_size = Vector2(118,20) * _scale
			child.get_child(2).custom_minimum_size = Vector2(44,20) * _scale
			for control in child.get_children(): _style(control,font,_scale)
	_reset_all.position = Vector2(0,238) * _scale
	_reset_all.size = Vector2(150,20) * _scale
	_done.position = Vector2(160,238) * _scale
	_done.size = Vector2(150,20) * _scale
	for control in [_title,_hint,_reset_all,_done]: _style(control,font,_scale)
	_hint.add_theme_font_size_override("font_size", 7 * _scale)
	refresh()

func refresh() -> void:
	for action in _buttons:
		var conflict: PackedStringArray = bindings.conflicts(action)
		var button: Button = _buttons[action]
		button.text = "> " + bindings.label(action) + " <" if capturing == action else bindings.label(action)
		button.modulate = Color(1,.45,.45) if not conflict.is_empty() else Color(1,1,.5) if capturing == action else Color.WHITE
		button.tooltip_text = bindings.label(action) + ("\nConflicts with: " + ", ".join(conflict) if not conflict.is_empty() else "")
		_resets[action].disabled = bindings.bindings[action] == bindings.defaults[action]
	_hint.text = "Press key/mouse. Esc: cancel. Backspace: unbind." if not capturing.is_empty() else "Click a binding to change it. Red indicates a conflict."
	get_viewport().gui_release_focus()

func begin_capture(action: String) -> void:
	capturing = action
	_pending_key = 0
	refresh()

func _back() -> void:
	capturing = ""
	_pending_key = 0
	_menu.close_controls()

func _finish(value: Dictionary, assign: bool = true) -> void:
	if assign: bindings.set_binding(capturing, value)
	capturing = ""
	_pending_key = 0
	refresh()

func _input(event: InputEvent) -> void:
	if not is_visible_in_tree(): return
	if capturing.is_empty():
		if event is InputEventKey and event.pressed and event.physical_keycode == KEY_ESCAPE:
			_back()
			get_viewport().set_input_as_handled()
		return
	if event is InputEventKey:
		get_viewport().set_input_as_handled()
		if event.echo: return
		var code: int = event.physical_keycode if event.physical_keycode != 0 else event.keycode
		if event.pressed and code == KEY_ESCAPE:
			_finish({},false)
			return
		if event.pressed and code in [KEY_BACKSPACE,KEY_DELETE]:
			_finish({})
			return
		if event.pressed and code in [KEY_F3,KEY_CTRL,KEY_SHIFT,KEY_ALT,KEY_META]:
			_pending_key = code
			_hint.text = "Release to bind this key, or press another for a chord."
			return
		if not event.pressed and code != _pending_key: return
		var value: Dictionary = {"key": code}
		for modifier in ["ctrl", "shift", "alt", "meta"]:
			if event.get(modifier + "_pressed"): value[modifier] = true
		if code == KEY_CTRL: value.erase("ctrl")
		if code == KEY_SHIFT: value.erase("shift")
		if code == KEY_ALT: value.erase("alt")
		if code == KEY_META: value.erase("meta")
		if _pending_key == KEY_F3 and code != KEY_F3: value["hold"] = KEY_F3
		_finish(value)
	elif event is InputEventMouseButton:
		get_viewport().set_input_as_handled()
		if event.pressed:
			var value: Dictionary = {"mouse": event.button_index}
			for modifier in ["ctrl", "shift", "alt", "meta"]:
				if event.get(modifier + "_pressed"): value[modifier] = true
			if _pending_key == KEY_F3: value["hold"] = KEY_F3
			_finish(value)
