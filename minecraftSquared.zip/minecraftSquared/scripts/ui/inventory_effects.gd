class_name InventoryEffects
extends Control
const BACKGROUND: Texture2D=preload("res://assets/ui/inventory_effect_background.png")
var screen: Control
var entries: Array[Dictionary]=[]
var _style: StyleBoxTexture
func setup(owner_screen: Control) -> void:
	screen=owner_screen;mouse_filter=Control.MOUSE_FILTER_IGNORE;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	_style=ItemTooltipDrawing._style(BACKGROUND,4)
func _process(_delta: float) -> void:
	if screen.is_open:queue_redraw()
func available_width() -> float:
	return (get_viewport_rect().size.x-screen.panel_position.x)/screen.ui_scale-screen.panel_dimensions().x-2
func can_show() -> bool:return screen.is_open and not screen.is_table_mode and available_width()>=32
static func duration(seconds: float) -> String:
	var value: int=maxi(0,floori(seconds));return "%d:%02d"%[value/60,value%60]
static func effect_name(key: String,amplifier: int) -> String:
	return key.replace("_"," ").capitalize()+(" "+["I","II","III","IV","V"][clampi(amplifier,0,4)] if amplifier>0 else "")
func _draw() -> void:
	entries.clear()
	if not can_show() or screen.world.survival==null:return
	var effects: EntityEffects=screen.world.survival.effects
	var keys: Array=[]
	for key in SurvivalScreen.EFFECT_ICONS:
		if effects.remaining.has(key):keys.append(key)
	keys.sort_custom(func(a: String,b: String):return float(effects.remaining[a])<float(effects.remaining[b]) if not is_equal_approx(float(effects.remaining[a]),float(effects.remaining[b])) else a<b)
	var s: float=screen.ui_scale;var wide: bool=available_width()>=120
	var step: int=33 if keys.size()<=5 else 132/maxi(1,keys.size()-1)
	var crowded: bool=step<26
	var origin: Vector2=(screen.panel_position+Vector2(screen.panel_dimensions().x+2,0)*s).floor()
	for i in range(keys.size()):
		var key: String=keys[i];var at: Vector2=origin+Vector2(0,i*step)*s
		var bounds:=Rect2(at,Vector2(120 if wide else 32,step if crowded else 32)*s)
		entries.append({"key":key,"name":effect_name(key,int(effects.amplifiers.get(key,0))),"duration":duration(effects.remaining[key]),"bounds":bounds,"wide":wide})
		draw_set_transform(at,0,Vector2.ONE*s);draw_style_box(_style,Rect2(Vector2.ZERO,bounds.size/s))
	draw_set_transform(Vector2.ZERO)
	# Backgrounds first, matching Minecraft's compressed stack rendering.
	for entry in entries:
		var at: Vector2=entry.bounds.position
		var icon_size: int=mini(18,step-2) if crowded else 18
		draw_texture_rect(SurvivalScreen.EFFECT_ICONS[entry.key],Rect2(at+Vector2(6 if wide else (32-icon_size)*.5,(step-icon_size)*.5 if crowded else 7)*s,Vector2.ONE*icon_size*s),false)
		if wide:
			# Smaller labels only for very crowded stacks, avoiding text collisions.
			var logical_font: int=mini(9,maxi(6,(step-3)/2));var pixels: int=roundi(logical_font*s)
			var font: Font=screen.UI_FONT
			for line in range(2):
				var point: Vector2=(at+Vector2(28,(1 if crowded else 6)+line*(logical_font+1))*s+Vector2(0,font.get_ascent(pixels))).round()
				var color: Color=Color.WHITE if line==0 else Color("7f7f7f")
				var text: String=entry.name if line==0 else entry.duration
				draw_string(font,point+Vector2.ONE*s,text,HORIZONTAL_ALIGNMENT_LEFT,-1,pixels,Color(color.r*.25,color.g*.25,color.b*.25))
				draw_string(font,point,text,HORIZONTAL_ALIGNMENT_LEFT,-1,pixels,color)
	if not wide and screen.items.held_count==0:
		var pointer: Vector2=screen._pointer_position()
		for i in range(entries.size()-1,-1,-1):
			if entries[i].bounds.has_point(pointer):
				ItemTooltipDrawing.draw_tooltip(self,screen.UI_FONT,ItemDrawing.settings,entries[i].name,entries[i].duration,pointer,get_viewport_rect(),s);break
