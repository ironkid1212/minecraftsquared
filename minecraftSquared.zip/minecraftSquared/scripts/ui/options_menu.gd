extends CanvasLayer

## Add this script as the GameOptions autoload. It supports both World directly
## and PixelGame's hosted World; it never replaces either scene or its scripts.
@export var preferences_path: String = "user://options.cfg"

const DEFINITIONS_PATH: String = "res://data/options_menu.json"
const WIDGET_PATH: String = "res://assets/ui/widgets/"
const FALLBACK_FONT: Font = preload("res://assets/fonts/minecraft_font.otf")

var is_open: bool = false
var screen_mode: String = "options"
var return_screen: String = "title"
var _menu_skin := MenuSkin.new()
var _background: TextureRect
var _pause_logo: TextureRect
var _resume: Button
var _pause_options: Button
var definitions: Array = []
var values: Dictionary = {}
var defaults: Dictionary = {}
var controls: Dictionary = {}
var _world: Node2D
var _host: Node
var _interface: Resource
var _camera: Camera2D
var _saved := ConfigFile.new()
var _modified: Dictionary = {}
var _was_paused: bool = false
var _screen: Control
var _shade: ColorRect
var _title: Label
var _hint: Label
var _reset: Button
var _done: Button
var _save_quit: Button
var _scale: int = 1
var _textures: Dictionary = {}
var _scaled_textures: Dictionary = {}
var keybinds := GameBindings.new()
var _mods_button: Button
var _controls_button: Button
var _keybind_screen: KeybindScreen

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 100
	_saved.load(preferences_path)
	keybinds.setup(_saved)
	keybinds.changed.connect(func(_action: String):
		if save_options() != OK: push_warning("Key binds apply for this session but could not be saved.")
	)
	var document: Variant = JSON.parse_string(FileAccess.get_file_as_string(DEFINITIONS_PATH))
	if not document is Dictionary or not document.get("controls") is Array:
		push_error("Options menu: invalid " + DEFINITIONS_PATH)
		set_process(false)
		return
	definitions = document["controls"]
	_interface = load("res://data/settings/interface.tres")
	for texture_name in ["button", "button_highlighted", "button_disabled", "slider", "slider_highlighted", "slider_handle", "slider_handle_highlighted"]:
		_textures[texture_name] = _load_widget(texture_name)
	_build_ui(str(document.get("title", "Options")))
	get_viewport().size_changed.connect(_layout)
	_layout()
	_screen.hide()
	if values.is_empty():
		_initialize_options()

func _load_widget(texture_name: String) -> Texture2D:
	var path: String = WIDGET_PATH + texture_name + ".png"
	var texture: Texture2D
	if ResourceLoader.exists(path, "Texture2D"):
		texture = ResourceLoader.load(path, "Texture2D") as Texture2D
	if texture != null:
		return texture
	# A newly copied PNG may exist before the editor finishes importing it.
	var image := Image.new()
	if FileAccess.file_exists(path) and image.load(path) == OK and not image.is_empty():
		return ImageTexture.create_from_image(image)
	push_warning("Options menu: missing widget texture: " + path + ". Extract the supplied assets/ui/widgets folder into your project. Using a temporary plain widget.")
	return ImageTexture.create_from_image(_fallback_widget(texture_name))

func _fallback_widget(texture_name: String) -> Image:
	var dimensions := Vector2i(8 if texture_name.begins_with("slider_handle") else 200, 20)
	var image: Image = Image.create(dimensions.x, dimensions.y, false, Image.FORMAT_RGBA8)
	var highlighted: bool = texture_name.ends_with("highlighted")
	image.fill(Color.WHITE if highlighted else Color(0.08, 0.08, 0.08))
	image.fill_rect(Rect2i(Vector2i.ONE, dimensions - Vector2i(2, 2)), Color(0.55, 0.55, 0.55))
	var dark: bool = texture_name in ["slider", "slider_highlighted", "button_disabled"]
	image.fill_rect(Rect2i(Vector2i(2, 2), dimensions - Vector2i(4, 4)), Color(0.18, 0.18, 0.18) if dark else Color(0.4, 0.4, 0.4))
	return image

func _find_world(node: Node) -> Node2D:
	if node is Node2D and node.has_method("get_block") and node.get_node_or_null("Player") != null:
		return node
	for child in node.get_children():
		var result: Node2D = _find_world(child)
		if result != null:
			return result
	return null

func _process(_delta: float) -> void:
	if is_instance_valid(_world):
		return
	var scene: Node = get_tree().current_scene
	if scene == null:
		return
	var candidate: Node2D = _find_world(scene)
	if candidate == null or not candidate.is_node_ready():
		return
	_world = candidate
	_interface = _world.settings.interface
	_camera = _world.player.get_node("Camera2D")
	_host = null
	var ancestor: Node = _world.get_parent()
	while ancestor != null:
		if ancestor.has_method("screen_to_world_viewport") and ancestor.has_method("_resize"):
			_host = ancestor
			break
		ancestor = ancestor.get_parent()
	_initialize_options()

func _initialize_options() -> void:
	# Remove retired preferences; project resources own font/icon defaults.
	for retired in ["stack_text", "crisp_icons"]:
		if _saved.has_section_key("options", retired): _saved.erase_section_key("options", retired)
	values.clear()
	for definition in definitions:
		var key: String = definition["key"]
		if not defaults.has(key):
			defaults[key] = _validated_value(definition, _current_value(definition))
		values[key] = _validated_value(definition, _current_value(definition))
	# Capture all project defaults before applying any saved runtime changes.
	for definition in definitions:
		var key: String = definition["key"]
		if _saved.has_section_key("options", key):
			set_option(key, _saved.get_value("options", key))
		else:
			_refresh_control(definition)
	_layout()

func _current_value(definition: Dictionary) -> Variant:
	match str(definition["target"]):
		"mods":return values.get(definition["key"],definition.get("default"))
		"zoom":
			if is_instance_valid(_host):
				return _host.pixel_scale
			return roundi(_camera.zoom.x) if is_instance_valid(_camera) else int(values.get("world_zoom", 3))
		"fullscreen":
			return get_window().mode == Window.MODE_FULLSCREEN or get_window().mode == Window.MODE_EXCLUSIVE_FULLSCREEN
		"interface":
			return _interface.get(definition["property"])
	return null

func _definition(key: String) -> Dictionary:
	for definition in definitions:
		if definition["key"] == key:
			return definition
	return {}

func _validated_value(definition: Dictionary, requested: Variant) -> Variant:
	var key: String = definition["key"]
	if definition["kind"] == "toggle":
		return requested if requested is bool else bool(defaults.get(key, false))
	var number: float = float(requested) if requested is int or requested is float else float(defaults.get(key, 1))
	if not is_finite(number):
		number = float(defaults.get(key, 1))
	return clampi(roundi(number), int(definition["min"]), int(definition["max"]))

func set_option(key: String, requested: Variant) -> void:
	var definition: Dictionary = _definition(key)
	if definition.is_empty():
		return
	var value: Variant = _validated_value(definition, requested)
	values[key] = value
	_modified[key] = true
	match str(definition["target"]):
		"zoom":
			if is_instance_valid(_host):
				_host.presentation.automatic_scale = false
				_host.presentation.maximum_scale = maxi(_host.presentation.maximum_scale, int(value))
				_host.presentation.fixed_scale = int(value)
				_host._resize()
			elif is_instance_valid(_camera):
				_camera.zoom = Vector2.ONE * int(value)
				_camera.force_update_scroll()
		"fullscreen":
			if value:
				get_window().mode = Window.MODE_FULLSCREEN
			elif get_window().mode in [Window.MODE_FULLSCREEN, Window.MODE_EXCLUSIVE_FULLSCREEN]:
				get_window().mode = Window.MODE_WINDOWED
		"mods":
			if is_instance_valid(_world) and _world.lighting!=null:_world.lighting.apply_dynamic_preferences()
		"interface":
			_interface.set(definition["property"], value)
			if is_instance_valid(_world):
				_world.hotbar.update_position()
				_world.hotbar.queue_redraw()
				_world.inventory_screen._resize()
				_world.furnace_screen._resize()
				if _world.upgrade_screen!=null:_world.upgrade_screen._resize()
	_refresh_control(definition)
	if key == "ui_scale":
		call_deferred("_layout")

func _cycle(key: String) -> void:
	var definition: Dictionary = _definition(key)
	if definition["kind"] == "toggle":
		set_option(key, not bool(values[key]))
	else:
		var next: int = int(values[key]) + 1
		set_option(key, int(definition["min"]) if next > int(definition["max"]) else next)

func _refresh_control(definition: Dictionary) -> void:
	var key: String = definition["key"]
	if not controls.has(key) or not values.has(key):
		return
	var control: Control = controls[key]
	if control is OptionsSlider:
		control.set_value(int(values[key]))
	else:
		var text: String = ("ON" if values[key] else "OFF") if definition["kind"] == "toggle" else str(values[key])
		if definition.has("labels"):text=definition.labels[int(values[key])-int(definition.min)]
		control.text = "%s: %s" % [definition["label"], text]

func reset_options() -> void:
	for definition in _page_definitions():
		var key: String=definition.key
		set_option(key, defaults[key])

func save_options() -> Error:
	for key in values:
		if _modified.has(key) or _saved.has_section_key("options", key):
			_saved.set_value("options", key, values[key])
	return _saved.save(preferences_path)

func _unhandled_key_input(event: InputEvent) -> void:
	if is_instance_valid(_world) and _world.player.survival_dead: return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		if is_open:
			if screen_mode == "controls":
				close_controls()
			elif screen_mode == "mods":
				_options_back()
			elif screen_mode == "options" and return_screen == "pause":
				_options_back()
			else:
				set_open(false)
		elif is_instance_valid(_world):
			if _world.upgrade_is_open():
				_world.upgrade_screen.set_open(false)
			elif _world.storage_screen!=null and _world.storage_screen.is_open:
				_world.storage_screen.set_open(false)
			elif _world.furnace_screen.is_open:
				_world.furnace_screen.set_open(false)
			elif _world.inventory_screen.is_open:
				_world.inventory_screen.set_open(false)
			else:
				set_open(true)
		else:
			return
		get_viewport().set_input_as_handled()

func open_options(from_screen: String = "title") -> void:
	if not is_open:
		set_open(true)
	screen_mode = "options"
	return_screen = from_screen
	_layout()
	get_viewport().gui_release_focus()

func open_controls() -> void:
	screen_mode = "controls"
	_layout()
	get_viewport().gui_release_focus()

func close_controls() -> void:
	_keybind_screen.capturing = ""
	screen_mode = "options"
	_layout()
	get_viewport().gui_release_focus()

func open_mods() -> void:
	screen_mode="mods"
	_layout()
	get_viewport().gui_release_focus()

func _page_definitions() -> Array:
	return definitions.filter(func(definition: Dictionary):return str(definition.get("page","options"))==("mods" if screen_mode=="mods" else "options"))

func _options_back() -> void:
	if screen_mode=="mods":
		save_options();screen_mode="options";_layout();get_viewport().gui_release_focus();return
	if return_screen == "pause" and is_instance_valid(_world):
		if save_options() != OK:
			push_warning("Options could not be saved to " + preferences_path)
		screen_mode = "pause"
		_layout()
		get_viewport().gui_release_focus()
	else:
		set_open(false)

func set_open(open: bool) -> void:
	if open and is_instance_valid(_world) and _world.player.survival_dead: return
	if open == is_open:
		return
	is_open = open
	if open:
		_hint.text = "Changes apply immediately"
		_hint.tooltip_text = ""
		for definition in definitions:
			values[definition["key"]] = _validated_value(definition, _current_value(definition))
			_refresh_control(definition)
		_was_paused = get_tree().paused
		screen_mode = "pause" if is_instance_valid(_world) else "options"
		return_screen = "pause" if is_instance_valid(_world) else "title"
		if is_instance_valid(_world):
			if _world.chat != null: _world.chat.set_open(false)
			_world.mining_held = false
			_world.reset_mining()
			_world.player.set_interaction_enabled(false)
		get_tree().paused = true
		_screen.show()
		_frontend_visibility(true)
		_layout()
	else:
		_screen.hide()
		get_tree().paused = _was_paused
		if is_instance_valid(_world):
			_world.player.set_interaction_enabled(not (_world.upgrade_is_open() or _world.inventory_screen.is_open or _world.furnace_screen.is_open or (_world.storage_screen!=null and _world.storage_screen.is_open)))
		_frontend_visibility(false)
		if save_options() != OK:
			push_warning("Options apply for this session, but could not be saved to " + preferences_path)
	get_viewport().gui_release_focus()

func _frontend_visibility(obscured: bool) -> void:
	var scene: Node = get_tree().current_scene
	if scene != null and scene.has_method("set_menu_overlay_active"):
		scene.set_menu_overlay_active(obscured)

func _style(texture_name: String, border: int = 3) -> PixelWidgetStyle:
	var style := PixelWidgetStyle.new()
	var cache_key: String = "%s_%d" % [texture_name, _scale]
	if not _scaled_textures.has(cache_key):
		# Upscale source pixels first, then nine-slice at screen resolution.
		# Both source and destination borders now remain exactly 3 GUI pixels.
		var texture: Texture2D = _textures.get(texture_name) as Texture2D
		if texture == null:
			texture = _load_widget(texture_name)
			_textures[texture_name] = texture
		var image: Image = texture.get_image()
		if image != null:
			image = image.duplicate() as Image
		if image == null or image.is_empty():
			push_warning("Options menu: unreadable texture pixels for " + WIDGET_PATH + texture_name + ".png. Using a temporary plain widget.")
			image = _fallback_widget(texture_name)
		image.resize(image.get_width() * _scale, image.get_height() * _scale, Image.INTERPOLATE_NEAREST)
		_scaled_textures[cache_key] = ImageTexture.create_from_image(image)
	style.texture = _scaled_textures[cache_key]
	for side in [SIDE_LEFT, SIDE_TOP, SIDE_RIGHT, SIDE_BOTTOM]:
		style.set_texture_margin(side, border * _scale)
		style.set_content_margin(side, 0)
	if texture_name.begins_with("slider_handle"):
		style.set_texture_margin(SIDE_BOTTOM, 3 * _scale)
	return style

func _button(text: String) -> Button:
	var button := Button.new()
	button.text = text
	button.focus_mode = Control.FOCUS_NONE
	button.mouse_force_pass_scroll_events = false
	_screen.add_child(button)
	return button

func _build_ui(title: String) -> void:
	_screen = Control.new()
	_screen.name = "OptionsScreen"
	_screen.mouse_filter = Control.MOUSE_FILTER_STOP
	_screen.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(_screen)
	_background = TextureRect.new()
	_background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_background.stretch_mode = TextureRect.STRETCH_TILE
	_background.texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	_background.modulate = Color(0.22, 0.22, 0.22)
	_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_screen.add_child(_background)
	_shade = ColorRect.new()
	_shade.color = Color(0, 0, 0, 0.72)
	_shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_screen.add_child(_shade)
	_pause_logo = TextureRect.new()
	_pause_logo.texture = preload("res://assets/ui/title/minecraft.png")
	_pause_logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_pause_logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_pause_logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_screen.add_child(_pause_logo)
	_title = Label.new()
	_title.text = title
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_screen.add_child(_title)
	_hint = Label.new()
	_hint.text = "Changes apply immediately"
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_screen.add_child(_hint)
	for definition in definitions:
		var key: String = definition["key"]
		var control: Control
		if definition["kind"] == "slider":
			var slider := OptionsSlider.new()
			slider.label = definition["label"]
			slider.minimum = int(definition["min"])
			slider.maximum = int(definition["max"])
			slider.value_changed.connect(func(value: int): set_option(key, value))
			_screen.add_child(slider)
			control = slider
		else:
			var button: Button = _button(str(definition["label"]))
			button.pressed.connect(func(): _cycle(key))
			control = button
		controls[key] = control
	_mods_button = _button("Mods...")
	_mods_button.pressed.connect(open_mods)
	_controls_button = _button("Controls...")
	_controls_button.pressed.connect(open_controls)
	_reset = _button("Reset Defaults")
	_reset.pressed.connect(reset_options)
	_done = _button("Done")
	_done.pressed.connect(_options_back)
	_resume = _button("Back to Game")
	_resume.pressed.connect(func(): set_open(false))
	_pause_options = _button("Options...")
	_pause_options.pressed.connect(func(): open_options("pause"))
	_save_quit = _button("Save and Quit to Title")
	_save_quit.pressed.connect(func():
		var scene: Node = get_tree().current_scene
		if scene != null and scene.has_method("save_and_return"):
			scene.save_and_return()
	)

	_keybind_screen = KeybindScreen.new()
	_screen.add_child(_keybind_screen)
	_keybind_screen.setup(self,keybinds)

func _layout() -> void:
	if _screen == null:
		return
	var window_size: Vector2 = get_viewport().get_visible_rect().size
	var preferred: int = int(_interface.get("maximum_scale")) if _interface != null else 3
	var page_definitions: Array=_page_definitions()
	var rows: int = ceili(page_definitions.size() / 2.0)
	var footer_y: float = 50 + rows * 28 + 16
	var scene: Node = get_tree().current_scene
	var pause_page: bool = screen_mode == "pause"
	var keybind_page: bool = screen_mode == "controls"
	var mods_page: bool=screen_mode=="mods"
	var has_world: bool = is_instance_valid(_world)
	var show_save: bool = pause_page and has_world and scene != null and scene.has_method("save_and_return")
	_title.text = "Game Menu" if pause_page else "Mods" if mods_page else "Options"
	_hint.text="Dynamic Lighting" if mods_page else "Changes apply immediately"
	_pause_logo.visible = pause_page
	_title.visible = not keybind_page
	_hint.visible = not pause_page and not keybind_page
	_controls_button.visible = not pause_page and not keybind_page and not mods_page
	_mods_button.visible = _controls_button.visible
	_keybind_screen.visible = keybind_page
	_resume.visible = pause_page
	_pause_options.visible = pause_page
	_reset.visible = not pause_page and not keybind_page
	_done.visible = not pause_page and not keybind_page
	for definition in definitions:controls[definition.key].visible=not pause_page and not keybind_page and definition in page_definitions
	_save_quit.visible = show_save
	var panel_height: float = 260.0 if keybind_page else 204.0 if pause_page else footer_y + 60
	_scale = clampi(floori(minf((window_size.x - 20) / 310.0, (window_size.y - 20) / panel_height)), 1, preferred)
	_screen.size = window_size
	_shade.size = window_size
	_shade.visible = has_world
	_background.size = window_size
	_background.visible = not has_world
	_background.texture = _menu_skin.background_texture(_scale)
	var origin: Vector2 = ((window_size - Vector2(310, panel_height) * _scale) / 2.0).floor()
	_place(_pause_logo, origin, Vector2(25, 0), Vector2(260, 65))
	_place(_title, origin, Vector2(0, 67 if pause_page else 0), Vector2(310, 20))
	_place(_hint, origin, Vector2(0, 88 if pause_page else 24), Vector2(310, 16))
	for index in range(page_definitions.size()):
		var definition: Dictionary = page_definitions[index]
		var control: Control = controls[definition["key"]]
		_place(control, origin, Vector2((index % 2) * 160, 50 + floori(index / 2.0) * 28), Vector2(150, 20))
		if control is OptionsSlider:
			control.gui_scale = _scale
			control.font = _interface.get("font") if _interface != null else FALLBACK_FONT
			control.normal = _style("slider")
			control.highlighted = _style("slider_highlighted")
			control.handle = _style("slider_handle", 2)
			control.handle_highlighted = _style("slider_handle_highlighted", 2)
			control.queue_redraw()
		_refresh_control(definition)
	_place(_controls_button, origin, Vector2(0, footer_y), Vector2(150, 20))
	_place(_mods_button, origin, Vector2(160, footer_y), Vector2(150, 20))
	_place(_reset, origin, Vector2(0, footer_y + 28), Vector2(150, 20))
	_place(_done, origin, Vector2(160, footer_y + 28), Vector2(150, 20))
	_place(_resume, origin, Vector2(55, 104), Vector2(200, 20))
	_place(_pause_options, origin, Vector2(55, 132), Vector2(200, 20))
	_place(_save_quit, origin, Vector2(55, 160), Vector2(200, 20))
	_keybind_screen.arrange(window_size,_scale,_interface.get("font") if _interface != null else FALLBACK_FONT)
	for child in _screen.get_children():
		if child is Button or child is Label:
			child.add_theme_font_override("font", _interface.get("font") if _interface != null else FALLBACK_FONT)
			child.add_theme_font_size_override("font_size", 8 * _scale)
			child.add_theme_color_override("font_color", Color.WHITE)
			child.add_theme_color_override("font_shadow_color", Color(0.2, 0.2, 0.2))
			child.add_theme_constant_override("shadow_offset_x", _scale)
			child.add_theme_constant_override("shadow_offset_y", _scale)
		if child is Button:
			child.add_theme_stylebox_override("normal", _style("button"))
			child.add_theme_stylebox_override("hover", _style("button_highlighted"))
			child.add_theme_stylebox_override("pressed", _style("button_highlighted"))
			child.add_theme_stylebox_override("hover_pressed", _style("button_highlighted"))
			child.add_theme_stylebox_override("disabled", _style("button_disabled"))
			child.add_theme_stylebox_override("focus", StyleBoxEmpty.new())

func _place(control: Control, origin: Vector2, offset: Vector2, dimensions: Vector2) -> void:
	control.position = origin + offset * _scale
	control.size = dimensions * _scale

func _exit_tree() -> void:
	keybinds.shutdown()
