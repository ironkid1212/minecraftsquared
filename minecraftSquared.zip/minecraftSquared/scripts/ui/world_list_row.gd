class_name WorldListRow
extends Button

var title_label: Label
var detail_label: Label
var gui_scale: int = 1

func configure(title: String, detail: String, scale: int) -> void:
	gui_scale = scale
	toggle_mode = true
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	custom_minimum_size = Vector2(0, 40 * scale)
	text = ""
	title_label = Label.new()
	title_label.text = title
	detail_label = Label.new()
	detail_label.text = detail
	detail_label.add_theme_color_override("font_color", Color(0.65, 0.65, 0.65))
	for label in [title_label, detail_label]:
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		label.clip_text = true
		label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		add_child(label)
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0, 0, 0, 0.4)
	var selected := StyleBoxFlat.new()
	selected.bg_color = Color(1, 1, 1, 0.12)
	selected.border_color = Color.WHITE
	selected.set_border_width_all(scale)
	for state in ["normal", "hover"]: add_theme_stylebox_override(state, normal)
	for state in ["pressed", "hover_pressed", "focus"]: add_theme_stylebox_override(state, selected)
	resized.connect(_layout)
	_layout()

func _layout() -> void:
	if title_label == null:
		return
	var border: StyleBoxFlat = get_theme_stylebox("pressed") as StyleBoxFlat
	if border != null: border.set_border_width_all(gui_scale)
	title_label.position = Vector2(6, 4) * gui_scale
	title_label.size = Vector2(maxf(1, size.x - 12 * gui_scale), 14 * gui_scale)
	detail_label.position = Vector2(6, 21) * gui_scale
	detail_label.size = Vector2(maxf(1, size.x - 12 * gui_scale), 14 * gui_scale)
