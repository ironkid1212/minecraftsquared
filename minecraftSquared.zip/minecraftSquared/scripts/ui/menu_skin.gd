class_name MenuSkin
extends RefCounted

const FONT: Font = preload("res://assets/fonts/minecraft_font.otf")
var _textures: Dictionary = {}
var _themes: Dictionary = {}

func background_texture(scale: int) -> Texture2D:
	var key: String = "dirt_%d" % scale
	if not _textures.has(key):
		var image: Image = preload("res://assets/ui/title/dirt.png").get_image().duplicate() as Image
		image.resize(image.get_width() * 2 * scale, image.get_height() * 2 * scale, Image.INTERPOLATE_NEAREST)
		_textures[key] = ImageTexture.create_from_image(image)
	return _textures[key]

func style(name: String, scale: int, field: bool = false) -> PixelWidgetStyle:
	var key: String = "%s_%d" % [name, scale]
	if not _textures.has(key):
		var path: String = "res://assets/ui/widgets/" + name + ".png"
		var source: Texture2D = load(path) as Texture2D
		var image: Image = source.get_image() if source != null else Image.new()
		image = image.duplicate() as Image
		if image.is_empty():
			image = Image.create(200, 20, false, Image.FORMAT_RGBA8)
			image.fill(Color(0.1, 0.1, 0.1))
		image.resize(image.get_width() * scale, image.get_height() * scale, Image.INTERPOLATE_NEAREST)
		_textures[key] = ImageTexture.create_from_image(image)
	var box := PixelWidgetStyle.new()
	box.texture = _textures[key]
	for side in [SIDE_LEFT, SIDE_TOP, SIDE_RIGHT, SIDE_BOTTOM]:
		box.set_texture_margin(side, 3 * scale)
		box.set_content_margin(side, (4 if field else 0) * scale)
	return box

func theme_for(scale: int) -> Theme:
	if _themes.has(scale):
		return _themes[scale]
	var theme := Theme.new()
	theme.default_font = FONT
	theme.default_font_size = 8 * scale
	for type in ["Button", "Label", "LineEdit", "ItemList", "CheckButton"]:
		theme.set_color("font_color", type, Color.WHITE)
		theme.set_color("font_shadow_color", type, Color(0.15, 0.15, 0.15))
		theme.set_constant("shadow_offset_x", type, scale)
		theme.set_constant("shadow_offset_y", type, scale)
	for state in ["normal", "hover", "pressed", "hover_pressed", "disabled"]:
		theme.set_stylebox(state, "Button", style("button_disabled" if state == "disabled" else "button" if state == "normal" else "button_highlighted", scale))
	theme.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	theme.set_stylebox("normal", "LineEdit", style("text_field", scale, true))
	theme.set_stylebox("focus", "LineEdit", style("text_field_highlighted", scale, true))
	theme.set_stylebox("read_only", "LineEdit", style("text_field", scale, true))
	theme.set_color("caret_color", "LineEdit", Color.WHITE)
	theme.set_color("font_placeholder_color", "LineEdit", Color(0.55, 0.55, 0.55))
	var panel := StyleBoxFlat.new()
	panel.bg_color = Color(0, 0, 0, 0.55)
	theme.set_stylebox("panel", "ItemList", panel)
	var selected := StyleBoxFlat.new()
	selected.bg_color = Color(1, 1, 1, 0.12)
	selected.border_color = Color.WHITE
	selected.set_border_width_all(scale)
	theme.set_stylebox("selected", "ItemList", selected)
	theme.set_stylebox("selected_focus", "ItemList", selected)
	theme.set_stylebox("focus", "ItemList", StyleBoxEmpty.new())
	theme.set_constant("v_separation", "ItemList", 5 * scale)
	theme.set_constant("line_separation", "ItemList", 3 * scale)
	_themes[scale] = theme
	return theme
