class_name CreativeInventoryScreen
extends InventoryScreen
const PANEL: Texture2D=preload("res://assets/ui/creative/panel.png")
const SEARCH_PANEL: Texture2D=preload("res://assets/ui/creative/tab_item_search.png")
const BAG_PANEL: Texture2D=preload("res://assets/ui/creative/tab_inventory.png")
const SCROLLER: Texture2D=preload("res://assets/ui/creative/scroller.png")
const SCROLLER_DISABLED: Texture2D=preload("res://assets/ui/creative/scroller_disabled.png")
const PAPER: Texture2D=preload("res://assets/ui/creative/icons/paper.png")
var world: Node2D
var search: LineEdit
var tabs: Array=[]
var category: String="building"
var _tab_ranks: Dictionary={}
var catalog: Array[int]=[]
var _catalog_stacks: Array[Dictionary]=[]
var effect_panel: InventoryEffects
var row: int=0
var dragging_scroll: bool=false
var _last_pointer:=Vector2(-10000,-10000)
var _bag: bool=false
var _textures: Dictionary={}
var hotbars:=CreativeHotbars.new()
var ordering: Dictionary=DataFile.object_from("res://data/creative_order.json")
func creative_open() -> bool:return world!=null and world.player.creative and not is_table_mode
func active_catalog() -> bool:return creative_open() and not _bag
func setup(data: BlockInventory,source: TileSetAtlasSource,style: PlayerSettings=null) -> void:
	super.setup(data,source,style)
	effect_panel=InventoryEffects.new();add_child(effect_panel);effect_panel.setup(self)
	tabs=DataFile.array_from("res://data/creative_tabs.json")
	for tab in ordering.get("tab_order",{}):
		var ranks: Dictionary={}
		var keys: Array=ordering.tab_order[tab]
		for i in range(keys.size()):ranks[str(keys[i])]=i
		_tab_ranks[tab]=ranks
	for definition in tabs:
		if not definition is Dictionary or not definition.get("key") is String or not definition.get("label") is String or definition.get("side") not in ["top","bottom"] or not ContentCatalog._number(definition.get("column"),0,6,true):DataFile.fail("creative_tabs.json: invalid tab definition.");return
		for state in ["selected","unselected"]:
			var path: String="res://assets/ui/creative/tab_%s_%s_%d.png"%[definition.side,state,int(definition.column)+1]
			_textures[path]=load(path)
		if not str(definition.get("icon_texture","")).is_empty():_textures[definition.icon_texture]=load(definition.icon_texture)
	var tab_keys: Array=[]
	for definition in tabs:tab_keys.append(str(definition.key))
	for entry: Dictionary in BlockDatabase.BLOCKS.values():
		if not entry.get("creative",false):continue
		if "natural" in entry.get("creative_tabs",[]) and (entry.get("tool")!=null or entry.has("armor") or entry.has("shield") or entry.has("ranged")):
			DataFile.fail("content.json / "+str(entry.key)+": equipment cannot be assigned to Natural Blocks.");return
		if entry.get("creative_tabs",[]).is_empty():
			DataFile.fail("content.json / "+str(entry.key)+": Creative items need explicit tabs.");return
		for key in entry.get("creative_tabs",[]):
			if key not in tab_keys:DataFile.fail("content.json / "+str(entry.key)+": unknown Creative tab "+str(key));return
	hotbars.setup(get_node("/root/GameOptions"))
	search=LineEdit.new();search.placeholder_text="Search Items";search.max_length=80
	search.add_theme_color_override("font_color",Color(.2,.2,.2));search.add_theme_color_override("font_placeholder_color",Color(.4,.4,.4))
	for state in ["normal","focus","read_only"]:
		var box:=StyleBoxEmpty.new()
		search.add_theme_stylebox_override(state,box)
	add_child(search);search.text_changed.connect(func(_text: String):row=0;rebuild())
	rebuild();_resize();_controls()
func rebuild() -> void:
	catalog.clear();_catalog_stacks.clear()
	if category=="hotbars":
		for i in range(81):catalog.append(int(hotbars.stack(i).id))
		row=clampi(row,0,max_row());queue_redraw();return
	var query: String=search.text.strip_edges().to_lower().trim_prefix("minecraft:") if search!=null and category=="all" else ""
	var books: Array[Dictionary]=[]
	for id in BlockDatabase.BLOCKS:
		var e: Dictionary=BlockDatabase.BLOCKS[id]
		if id==0 or not e.get("creative",false) or e.get("internal",false) or "fluid" in e.tags:continue
		if e.key=="enchanted_book":
			if category!="all" and category not in e.creative_tabs:continue
			for stack in EnchantmentDatabase.creative_books(category=="all"):
				var values: Dictionary=EnchantmentDatabase.read(stack.tags,true)
				var key: String=str(values.keys()[0])
				var text: String=(str(e.name)+" "+str(e.key)+" "+EnchantmentDatabase.label(key,int(values[key]))).to_lower()
				if query.begins_with("#"):
					if query.trim_prefix("#") not in e.tags:continue
				elif not query.is_empty() and query not in text:continue
				books.append(stack)
			if not books.is_empty():catalog.append(int(id))
			continue
		if query.begins_with("#"):
			var tag: String=query.trim_prefix("#")
			if tag not in e.tags and tag!=str(e.get("crafting_group","")):continue
		elif not query.is_empty() and query not in str(e.name).to_lower() and query not in str(e.key):continue
		var assigned: Array=e.get("creative_tabs",[])
		if category!="all" and category not in assigned:continue
		catalog.append(int(id))
	catalog.sort_custom(func(a: int,b: int):return _sort_key(a)<_sort_key(b))
	var expanded: Array[int]=[]
	for id in catalog:
		if BlockDatabase.BLOCKS[id].key=="enchanted_book":
			for stack in books:expanded.append(id);_catalog_stacks.append(stack)
		else:
			expanded.append(id);_catalog_stacks.append({"id":id,"count":1,"durability":ToolDatabase.initial_durability(id),"tags":{}})
	catalog=expanded
	row=clampi(row,0,max_row());queue_redraw()
func _sort_key(id: int) -> int:
	var key: String=str(BlockDatabase.BLOCKS[id].key)
	if category=="building":
		var woods: Array=ordering.get("woods",[]);var shapes: Array=ordering.get("wood_shapes",[])
		for i in range(woods.size()):
			var prefix: String=str(woods[i])+"_"
			if key.begins_with(prefix):
				var shape: int=shapes.find(key.trim_prefix(prefix))
				return i*100+(shape if shape>=0 else 50)
	return 10000+int(_tab_ranks[category][key]) if _tab_ranks.get(category,{}).has(key) else 100000+id
func max_row() -> int:return maxi(0,ceili(catalog.size()/9.0)-5)
func select_category(key: String) -> void:
	category=key;_bag=key=="inventory";row=0;dragging_scroll=false
	rebuild();_resize();_controls()
	if search!=null:
		if key=="all":search.grab_focus()
		else:search.release_focus()
func panel_dimensions() -> Vector2:return Vector2(195,136) if creative_open() else PANEL_SIZE
func _resize() -> void:
	size=get_viewport_rect().size;ui_scale=ItemDrawing.settings.gui_scale(size)
	if creative_open():ui_scale=maxf(1,minf(ui_scale,minf(floorf((size.y-20)/192),floorf((size.x-20)/195))))
	panel_position=((size-panel_dimensions()*ui_scale)*.5).floor()
	if search!=null:
		search.position=(panel_position+Vector2(82,4)*ui_scale).round();search.size=Vector2(87,11)*ui_scale
		search.add_theme_font_override("font",UI_FONT);search.add_theme_font_size_override("font_size",roundi(8*ui_scale))
	queue_redraw()
func _controls() -> void:
	if search!=null:search.visible=is_open and active_catalog() and category=="all"
func set_open(value: bool,table_mode: bool=false) -> void:
	if value and not is_open:_bag=false;category="building";row=0
	super.set_open(value,table_mode)
	if not value:dragging_scroll=false
	rebuild();_resize();_controls()
func catalog_rect(index: int) -> Rect2:return Rect2(9+(index%9)*18,18+(index/9)*18,16,16)
func catalog_at(point: Vector2) -> int:
	var cell: int=catalog_cell_at(point)
	return row*9+cell if cell>=0 and row*9+cell<catalog.size() else -1
func catalog_cell_at(point: Vector2) -> int:
	var local: Vector2=(point-panel_position)/ui_scale
	for i in range(45):
		if catalog_rect(i).has_point(local):return i
	return -1
func tab_rect(tab: Dictionary) -> Rect2:return Rect2(int(tab.column)*28,-28 if tab.side=="top" else 132,26,32)
func tab_at(point: Vector2) -> int:
	var local: Vector2=(point-panel_position)/ui_scale
	for i in range(tabs.size()):
		if tab_rect(tabs[i]).has_point(local):return i
	return -1
func slot_rect(index: int) -> Rect2:
	if not creative_open():return super.slot_rect(index)
	if index<9:return Rect2(9+index*18,112,16,16)
	if not _bag:return Rect2(-1000,-1000,0,0)
	if index<BlockInventory.HEAD:return Rect2(9+((index-9)%9)*18,54+((index-9)/9)*18,16,16)
	return Rect2([Vector2(54,6),Vector2(54,33),Vector2(108,6),Vector2(108,33),Vector2(35,20)][index-BlockInventory.HEAD],Vector2(16,16))
func craft_slot_at(point: Vector2) -> int:return -1 if creative_open() else super.craft_slot_at(point)
func result_rect() -> Rect2:return Rect2(-1000,-1000,0,0) if creative_open() else super.result_rect()
func _input(event: InputEvent) -> void:
	_track_pointer(event)
	if world!=null and world.player.creative and not is_open and world.player.interaction_enabled and event is InputEventKey and event.pressed and not event.echo:
		for i in range(9):
			if not GameBindings.matches(event,"hotbar_"+str(i+1)):continue
			if Input.is_action_pressed("creative_save_toolbar"):
				hotbars.save_bar(i,items);world.show_mode_notice("Saved hotbar "+str(i+1));get_viewport().set_input_as_handled();return
			if Input.is_action_pressed("creative_load_toolbar"):
				var loaded: bool=hotbars.load_bar(i,items);world.show_mode_notice(("Loaded hotbar " if loaded else "No saved hotbar ")+str(i+1));get_viewport().set_input_as_handled();return
	if not is_open or not active_catalog():super._input(event);return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode==KEY_ESCAPE or GameBindings.matches(event,"inventory") and not search.has_focus():set_open(false);get_viewport().set_input_as_handled();return
		if not search.has_focus():
			var index: int=catalog_at(_pointer_position())
			if index>=0:
				for i in range(9):
					if GameBindings.matches(event,"hotbar_"+str(i+1)):_assign_catalog_hotbar(index,i);get_viewport().set_input_as_handled();return
func _scroll(point: Vector2) -> void:
	row=roundi(clampf(((point-panel_position)/ui_scale).y-25,0,74)/74*max_row());queue_redraw()
func _gui_input(event: InputEvent) -> void:
	_track_pointer(event)
	if not is_open:return
	if creative_open() and event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT:
		var tab: int=tab_at(event.position)
		if tab>=0:select_category(str(tabs[tab].key));accept_event();return
		var local: Vector2=(event.position-panel_position)/ui_scale
		if _bag and Rect2(174,112,16,16).has_point(local):
			if event.shift_pressed:
				for i in range(items.capacity):items.clear_slot(i)
			items.held_count=0;items.held_id=0;items.held_tags={};items.held_durability=0;items.changed.emit();accept_event();return
	if _bag and creative_open() and event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_MIDDLE:
		var index: int=slot_at(event.position)
		if index>=0 and items.counts[index]>0 and items.held_count==0:_carry(items.stack(index),items.stack_limit(items.ids[index]))
		accept_event();return
	if not active_catalog():
		if creative_open() and event is InputEventMouseButton and event.pressed and event.shift_pressed and event.button_index in [MOUSE_BUTTON_LEFT,MOUSE_BUTTON_RIGHT]:
			var index: int=slot_at(event.position)
			if index>=0:items.clear_slot(index);items.changed.emit();accept_event();return
		super._gui_input(event);return
	if event is InputEventMouseMotion and dragging_scroll:
		if event.button_mask&MOUSE_BUTTON_MASK_LEFT:_scroll(event.position);accept_event();return
		dragging_scroll=false
	if not event is InputEventMouseButton:return
	var local: Vector2=(event.position-panel_position)/ui_scale
	if not event.pressed:dragging_scroll=false;return
	if event.button_index in [MOUSE_BUTTON_WHEEL_UP,MOUSE_BUTTON_WHEEL_DOWN]:
		row=clampi(row+(-1 if event.button_index==MOUSE_BUTTON_WHEEL_UP else 1),0,max_row());queue_redraw();accept_event();return
	if event.button_index not in [MOUSE_BUTTON_LEFT,MOUSE_BUTTON_RIGHT,MOUSE_BUTTON_MIDDLE]:return
	if Rect2(175,18,12,89).has_point(local):dragging_scroll=true;_scroll(event.position)
	else:
		var index: int=catalog_at(event.position)
		if catalog_cell_at(event.position)>=0:
			catalog_click(index,event.button_index,event.shift_pressed)
		else:
			var i: int=slot_at(event.position)
			if i>=0:
				if event.shift_pressed:items.clear_slot(i);items.changed.emit()
				elif event.button_index==MOUSE_BUTTON_MIDDLE:
					if items.counts[i]>0 and items.held_count==0:_carry(items.stack(i),items.stack_limit(items.ids[i]))
				else:items.click_slot(i,event.button_index==MOUSE_BUTTON_RIGHT)
			elif event.button_index!=MOUSE_BUTTON_MIDDLE and not Rect2(Vector2.ZERO,panel_dimensions()).has_point(local) and items.held_count>0:
				var amount: int=1 if event.button_index==MOUSE_BUTTON_RIGHT else items.held_count
				drop_requested.emit(items.held_id,amount,items.held_durability,items.held_tags.duplicate(true));_shrink_cursor(amount)
	accept_event();queue_redraw()
func catalog_stack(index: int) -> Dictionary:
	if index<0 or index>=catalog.size():return {"id":0,"count":0,"durability":0,"tags":{}}
	return hotbars.stack(index) if category=="hotbars" else _catalog_stacks[index].duplicate(true)
func _carry(stack: Dictionary,count: int) -> void:
	items.held_id=int(stack.id);items.held_count=count;items.held_durability=int(stack.durability);items.held_tags=stack.get("tags",{}).duplicate(true);items.changed.emit()
func _shrink_cursor(amount: int) -> void:
	items.held_count=maxi(0,items.held_count-amount)
	if items.held_count==0:items.held_id=0;items.held_durability=0;items.held_tags={}
	items.changed.emit()
func catalog_click(index: int,button: MouseButton,shift: bool) -> void:
	var stack: Dictionary=catalog_stack(index)
	if button==MOUSE_BUTTON_MIDDLE:
		if items.held_count==0 and stack.id!=0:_carry(stack,items.stack_limit(stack.id))
		return
	if items.held_count==0:
		if stack.id!=0:_carry(stack,items.stack_limit(stack.id) if shift else int(stack.count))
	elif stack.id==items.held_id and int(stack.durability)==items.held_durability and NBT.same(stack.get("tags",{}),items.held_tags):
		if button==MOUSE_BUTTON_RIGHT:_shrink_cursor(1)
		else:items.held_count=items.stack_limit(items.held_id) if shift else mini(items.stack_limit(items.held_id),items.held_count+1);items.changed.emit()
	elif button==MOUSE_BUTTON_RIGHT:_shrink_cursor(1)
	else:_shrink_cursor(items.held_count)
func _update_preview(delta: float) -> void:
	if not creative_open():super._update_preview(delta);return
	var target: Vector2=(_pointer_position()-panel_position)/ui_scale-Vector2(88,26)
	_preview_pose.look_at(target,delta);_preview_pose.idle_time+=delta;_preview_pose.inventory=items
	if _preview_pose.offhand==null:_preview_pose.offhand=PlayerPresentation.new();_preview_pose.offhand.configure(player_style)
	_preview_pose.offhand.is_offhand=true
	_preview_pose.offhand.held_tags=items.tags[BlockInventory.OFFHAND];_preview_pose.offhand.set_held_item(items.ids[BlockInventory.OFFHAND],atlas_source)
	if preview_presentation!=null:_preview_pose.set_held_item(preview_presentation.held_id,atlas_source);_preview_pose.held_tags=preview_presentation.held_tags
func _process(delta: float) -> void:
	if not active_catalog():super._process(delta)
	else:
		var pointer: Vector2=_pointer_position()
		if pointer!=_last_pointer:_last_pointer=pointer;queue_redraw()
func _draw_tabs(selected_only: bool=false) -> void:
	draw_set_transform(panel_position,0,Vector2.ONE*ui_scale)
	for tab in tabs:
		var selected: bool=str(tab.key)==category
		if selected_only and not selected:continue
		var path: String="res://assets/ui/creative/tab_%s_%s_%d.png"%[tab.side,"selected" if selected else "unselected",int(tab.column)+1]
		var rect: Rect2=tab_rect(tab);draw_texture_rect(_textures[path],rect,false)
		var icon:=Rect2(rect.position+Vector2(5,8),Vector2(16,16))
		if not str(tab.icon_texture).is_empty():draw_texture_rect(_textures[tab.icon_texture],icon,false)
		else:ItemDrawing.draw_icon(self,atlas_source,BlockDatabase.id_for(str(tab.icon_item)),icon)
func _draw() -> void:
	if not creative_open():super._draw();return
	if not is_open:return
	draw_rect(Rect2(Vector2.ZERO,size),Color(0,0,0,.55));_draw_tabs()
	draw_texture_rect_region(BAG_PANEL if _bag else SEARCH_PANEL if category=="all" else PANEL,Rect2(0,0,195,136),Rect2(0,0,195,136))
	_draw_tabs(true)
	var hover: int=-1 if _bag else catalog_at(_pointer_position())
	var owned_hover: int=slot_at(_pointer_position())
	if _bag:
		var t:=Transform2D(0,Vector2.ONE*ui_scale,0,panel_position)
		PlayerSkinDrawing.draw_model(self,player_style,Vector2(88,26),1,_preview_pose.facing,0,0,t,_preview_pose)
		draw_set_transform(panel_position,0,Vector2.ONE*ui_scale)
		for i in range(BlockInventory.HEAD,BlockInventory.SLOT_COUNT):
			if items.counts[i]==0:draw_texture_rect(EMPTY_EQUIPMENT_ICONS[i-BlockInventory.HEAD],slot_rect(i),false)
	else:
		for i in range(45):
			if row*9+i==hover:draw_rect(catalog_rect(i),Color(1,1,1,.3))
		var y: float=18+74*(float(row)/max_row() if max_row()>0 else 0)
		draw_texture_rect(SCROLLER if max_row()>0 else SCROLLER_DISABLED,Rect2(175,y,12,15),false)
	if owned_hover>=0:draw_rect(slot_rect(owned_hover),Color(1,1,1,.3))
	draw_set_transform(Vector2.ZERO)
	if not _bag:
		for tab in tabs:
			if tab.key==category:ItemDrawing.draw_panel_label(self,UI_FONT,tab.label,Vector2(8,6),ui_scale,panel_position);break
		for i in range(45):
			var index: int=row*9+i
			if index>=catalog.size():break
			var bounds:=Rect2(panel_position+catalog_rect(i).position*ui_scale,Vector2(16,16)*ui_scale)
			var stack: Dictionary=catalog_stack(index)
			if category=="hotbars" and stack.id==0 and index%9==index/9:draw_texture_rect(PAPER,bounds,false)
			else:ItemDrawing.draw_stack(self,atlas_source,UI_FONT,stack.id,stack.count,bounds,ui_scale,-1,stack.durability,stack.get("tags",{}))
	for i in range(BlockInventory.SLOT_COUNT if _bag else 9):ItemDrawing.draw_stack(self,atlas_source,UI_FONT,items.ids[i],items.counts[i],Rect2(panel_position+slot_rect(i).position*ui_scale,Vector2(16,16)*ui_scale),ui_scale,-1,items.durability[i],items.tags[i])
	if items.held_count>0:ItemDrawing.draw_stack(self,atlas_source,UI_FONT,items.held_id,items.held_count,Rect2(_pointer_position()-Vector2(8,8)*ui_scale,Vector2(16,16)*ui_scale),ui_scale,-1,items.held_durability,items.held_tags)
	else:
		var tab: int=tab_at(_pointer_position())
		if tab>=0:ItemTooltipDrawing.draw_tooltip(self,UI_FONT,ItemDrawing.settings,str(tabs[tab].label),"",_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale)
		elif hover>=0 and category=="hotbars" and catalog[hover]==0:ItemTooltipDrawing.draw_tooltip(self,UI_FONT,ItemDrawing.settings,"Saved Hotbar "+str(hover/9+1),"Close inventory: hold C + "+str(hover/9+1)+" to save; X + "+str(hover/9+1)+" to load.",_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale)
		elif hover>=0 and catalog[hover]>0:
			var stack: Dictionary=catalog_stack(hover)
			ItemTooltipDrawing.draw_item_tooltip(self,UI_FONT,ItemDrawing.settings,stack.id,stack.durability,_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale,stack.get("tags",{}))
		elif owned_hover>=0:ItemTooltipDrawing.draw_item_tooltip(self,UI_FONT,ItemDrawing.settings,items.ids[owned_hover],items.durability[owned_hover],_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale,items.tags[owned_hover])
		elif _bag and Rect2(174,112,16,16).has_point((_pointer_position()-panel_position)/ui_scale):ItemTooltipDrawing.draw_tooltip(self,UI_FONT,ItemDrawing.settings,"Destroy Item","Shift-click to clear inventory.",_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale)

func _assign_catalog_hotbar(index: int,slot: int) -> void:
	var stack: Dictionary=catalog_stack(index)
	if stack.id==0:return
	stack=stack.duplicate(true);stack.count=items.stack_limit(stack.id);items.set_stack(slot,stack);items.changed.emit()
func _ui_pointer_exited() -> void:
	dragging_scroll=false
	super._ui_pointer_exited()
