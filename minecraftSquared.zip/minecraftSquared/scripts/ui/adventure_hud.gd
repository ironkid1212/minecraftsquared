class_name AdventureHUD
extends Control
var world: Node2D
const XP_BACK=preload("res://assets/ui/xp/experience_bar_background.png")
const XP_FILL=preload("res://assets/ui/xp/experience_bar_progress.png")
const FOOD=[preload("res://assets/ui/food/food_empty.png"),preload("res://assets/ui/food/food_half.png"),preload("res://assets/ui/food/food_full.png")]
const HUNGER=[preload("res://assets/ui/food/food_empty_hunger.png"),preload("res://assets/ui/food/food_half_hunger.png"),preload("res://assets/ui/food/food_full_hunger.png")]
func setup(game: Node2D) -> void:
	world=game;mouse_filter=Control.MOUSE_FILTER_IGNORE;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;z_index=100
func _process(_dt: float) -> void:queue_redraw()
func _draw() -> void:
	if world.survival.dead or world.player.spectator or world.player.creative or not world.hotbar.visible:return
	var s: float=world.hotbar.UI_SCALE;var at: Vector2=world.hotbar.position
	var xp_rect:=Rect2((at+Vector2(0,-7)*s).floor(),Vector2(182,5)*s)
	draw_texture_rect(XP_BACK,xp_rect,false)
	var pixels: int=floori(182*world.experience.progress())
	if pixels>0:draw_texture_rect_region(XP_FILL,Rect2(xp_rect.position,Vector2(pixels,5)*s),Rect2(0,0,pixels,5))
	var level: int=world.experience.level()
	if level>0:
		var font: Font=ItemDrawing.settings.font;var text_value: String=str(level);var font_size: int=roundi(8*s)
		var p: Vector2=(at+Vector2(91,-10)*s-Vector2(font.get_string_size(text_value,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x*.5,0)).floor()
		draw_string(font,p+Vector2(s,s),text_value,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,Color(.1,.15,0));draw_string(font,p,text_value,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,Color(.5,1,.12))
	var textures: Array=HUNGER if world.survival.effects.remaining.has("hunger") else FOOD
	for i in range(10):
		var value: int=clampi(world.food.level-i*2,0,2)
		var p: Vector2=(at+Vector2(173-i*8,-23)*s).floor()
		var tick: int=int(Time.get_ticks_msec()/50)
		if world.food.saturation<=0 and tick%(world.food.level*3+1)==0:p.y+=s*(hash(Vector2i(tick,i))%3-1)
		draw_texture_rect(textures[0],Rect2(p,Vector2(9,9)*s),false)
		if value>0:draw_texture_rect(textures[value],Rect2(p,Vector2(9,9)*s),false)
