class_name SkinListRow
extends WorldListRow

var preview_settings := PlayerSettings.new()

func configure_skin(entry: Dictionary, scale: int) -> void:
	preview_settings.skin_texture = entry["texture"]
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	focus_mode = Control.FOCUS_NONE
	configure(str(entry["name"]), "Built-in skin" if entry["id"] == "default" else "Saved skin", scale)

func _layout() -> void:
	super._layout()
	if title_label == null: return
	for label in [title_label, detail_label]:
		label.position.x = 42 * gui_scale
		label.size.x = maxf(1, size.x - 48 * gui_scale)
	queue_redraw()

func _draw() -> void:
	PlayerSkinDrawing.draw_model(self, preview_settings, Vector2(22, 23) * gui_scale, float(gui_scale))
