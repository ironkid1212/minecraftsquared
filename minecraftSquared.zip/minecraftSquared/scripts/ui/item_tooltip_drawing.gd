class_name ItemTooltipDrawing
extends RefCounted

static var _config: InterfaceSettings
static var _background: StyleBoxTexture
static var _frame: StyleBoxTexture

static func _style(texture: Texture2D, border: int) -> StyleBoxTexture:
	var style := StyleBoxTexture.new()
	style.texture = texture
	for side in [SIDE_LEFT,SIDE_TOP,SIDE_RIGHT,SIDE_BOTTOM]:
		style.set_texture_margin(side,border)
	style.axis_stretch_horizontal = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
	style.axis_stretch_vertical = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
	return style

static func _configure(config: InterfaceSettings) -> void:
	if _config == config:
		return
	_config = config
	_background = _style(config.tooltip_background,config.tooltip_background_border)
	_frame = _style(config.tooltip_frame,config.tooltip_frame_border)

static func _wrap(font: Font, text: String, font_size: int, width: float) -> PackedStringArray:
	var result := PackedStringArray()
	for paragraph in text.split("\n"):
		var line: String = ""
		for word in paragraph.split(" ",false):
			var candidate: String = word if line.is_empty() else line+" "+word
			if font.get_string_size(candidate,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x <= width:
				line = candidate
				continue
			if not line.is_empty():
				result.append(line)
				line = ""
			# Split a single over-wide identifier as well as ordinary words.
			for character in word:
				if not line.is_empty() and font.get_string_size(line+character,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x > width:
					result.append(line)
					line = ""
				line += character
		result.append(line)
	return result

static func layout(font: Font, config: InterfaceSettings, lines: PackedStringArray,
		mouse: Vector2, viewport: Rect2, scale: float) -> Dictionary:
	scale = maxf(1,roundf(scale))
	var font_size: int = maxi(1,roundi(config.tooltip_font_size*scale))
	var padding: Vector2 = (config.tooltip_padding.max(Vector2.ZERO)+Vector2.ONE*config.tooltip_outer_margin)*scale
	var edge: float = config.tooltip_screen_margin*scale
	var max_width: float = maxf(1,viewport.size.x - 2*edge - 2*padding.x)
	var line_height: float = ceilf(font.get_height(font_size)/scale)*scale
	var ascent: float = roundf(font.get_ascent(font_size))
	var rows: Array[Dictionary] = []
	var text_size := Vector2.ZERO
	for index in range(lines.size()):
		for text in _wrap(font,lines[index],font_size,max_width):
			if not rows.is_empty():
				text_size.y += config.tooltip_line_gap*scale
			rows.append({"text":text,"offset":Vector2(0,text_size.y+ascent),"primary":index==0,"line_index":index})
			text_size.x = maxf(text_size.x,font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x)
			text_size.y += line_height
	var gap: float = config.tooltip_line_gap*scale
	var available_height: float = viewport.size.y-2*edge-2*padding.y
	var max_rows: int = maxi(1,floori((available_height+gap)/(line_height+gap)))
	if rows.size() > max_rows:
		rows.resize(max_rows)
		var last: String = rows[-1]["text"]
		while not last.is_empty() and font.get_string_size(last+"...",HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x > max_width:
			last = last.substr(0,last.length()-1)
		rows[-1]["text"] = last+"..."
		text_size.y = rows.size()*line_height+maxi(0,rows.size()-1)*gap
		text_size.x = 0
		for row in rows:
			text_size.x = maxf(text_size.x,font.get_string_size(row["text"],HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x)
	text_size.x = ceilf(text_size.x/scale)*scale
	var origin: Vector2 = (mouse+config.tooltip_cursor_offset*scale).round()
	var box := Rect2(origin-padding,text_size+2*padding)
	if box.end.x > viewport.end.x-edge:
		box.position.x = roundf(mouse.x-text_size.x-absf(config.tooltip_cursor_offset.x)*scale-padding.x)
	box.position.x = roundf(clampf(box.position.x,viewport.position.x+edge,maxf(viewport.position.x+edge,viewport.end.x-edge-box.size.x)))
	box.position.y = roundf(clampf(box.position.y,viewport.position.y+edge,maxf(viewport.position.y+edge,viewport.end.y-edge-box.size.y)))
	return {"rect":box,"origin":box.position+padding,"rows":rows,"font_size":font_size,"scale":scale}

static func draw_tooltip(canvas: CanvasItem, font: Font, config: InterfaceSettings,
		name_text: String, detail: String, mouse: Vector2, viewport: Rect2, scale: float, colors: PackedColorArray = PackedColorArray()) -> void:
	if font == null or config.tooltip_frame == null or config.tooltip_background == null:
		return
	_configure(config)
	var lines := PackedStringArray([name_text])
	if not detail.is_empty():
		lines.append_array(detail.split("\n"))
	var data: Dictionary = layout(font,config,lines,mouse,viewport,scale)
	var box: Rect2 = data["rect"]
	var gui_scale: float = data["scale"]
	# Nine-slice at native GUI scale, retaining source corners, alpha and gradient.
	canvas.draw_set_transform(box.position,0,Vector2.ONE*gui_scale)
	canvas.draw_style_box(_background,Rect2(Vector2.ZERO,box.size/gui_scale))
	canvas.draw_style_box(_frame,Rect2(Vector2.ZERO,box.size/gui_scale))
	# Final-size text avoids stretching a font rendered at a smaller resolution.
	canvas.draw_set_transform(Vector2.ZERO)
	for row in data["rows"]:
		var color: Color = colors[row["line_index"]] if row["line_index"] < colors.size() else config.tooltip_name_color if row["primary"] else config.tooltip_detail_color
		var position: Vector2 = (Vector2(data["origin"])+Vector2(row["offset"])).round()
		if config.tooltip_text_shadow:
			var shadow := Color(color.r*0.25,color.g*0.25,color.b*0.25,color.a)
			canvas.draw_string(font,position+Vector2.ONE*gui_scale,row["text"],HORIZONTAL_ALIGNMENT_LEFT,-1,data["font_size"],shadow)
		canvas.draw_string(font,position,row["text"],HORIZONTAL_ALIGNMENT_LEFT,-1,data["font_size"],color)

## Shared by inventory, crafting results, and furnace inventory slots.
static func item_lines(id: int, remaining: int, durability_visible: bool, metadata: Dictionary = {}) -> Array[Dictionary]:
	var rows: Array[Dictionary] = [{"text":ItemTags.name(id,metadata),"color":Color.WHITE}]
	var enchantments: Dictionary=EnchantmentDatabase.read(metadata,BlockDatabase.BLOCKS[id].key=="enchanted_book")
	for key in enchantments:rows.append({"text":EnchantmentDatabase.label(key,int(enchantments[key])),"color":Color("aaaaaa")})
	for line in ItemTags.lore(metadata):rows.append({"text":line,"color":Color("aa00aa")})
	if ItemTags.unbreakable(metadata):rows.append({"text":"Unbreakable","color":Color("5555ff")})
	var armor: Dictionary=BlockDatabase.BLOCKS[id].get("armor",{})
	if not armor.is_empty():
		rows.append({"text":"","color":Color.WHITE})
		rows.append({"text":"When on "+str(armor["slot"]).capitalize()+":","color":Color("aaaaaa")})
		rows.append({"text":"+%d Armor" % int(armor["points"]),"color":Color("5555ff")})
		if float(armor["toughness"])>0:rows.append({"text":"+%d Armor Toughness" % int(armor["toughness"]),"color":Color("5555ff")})
		if durability_visible and remaining>=0 and remaining<int(armor["durability"]):rows.append({"text":"Durability: %d / %d" % [remaining,int(armor["durability"])],"color":Color.WHITE})
	var potion: String=BrewingData.key_for(id)
	if not potion.is_empty():
		var p: Dictionary=BrewingData.DATA.potions[potion]
		if str(p.effect).is_empty():rows.append({"text":"No Effects","color":Color("aaaaaa")})
		else:
			var amplifier: int=int(p.get("amplifier",0))
			var label: String="Instant Health" if p.effect=="instant_health" else str(p.effect).replace("_"," ").capitalize()
			if amplifier>0:label+=" "+["I","II","III","IV","V"][mini(amplifier,4)]
			if p.effect!="instant_health":label+=" (%d:%02d)"%[int(p.seconds)/60,int(p.seconds)%60]
			rows.append({"text":label,"color":Color("5555ff")})
			if p.effect in ["speed","strength"]:
				rows.append({"text":"","color":Color.WHITE})
				rows.append({"text":"When Applied:","color":Color("aa00aa")})
				rows.append({"text":("+%d%% Speed"%[20*(amplifier+1)] if p.effect=="speed" else "+%d Attack Damage"%[3*(amplifier+1)]),"color":Color("5555ff")})
	var tool: Dictionary = ToolDatabase.TOOLS.get(id,{})
	if not tool.is_empty():
		if tool.get("kind")!="shears":
			rows.append({"text":"","color":Color.WHITE})
			rows.append({"text":"When in Main Hand:","color":Color("aaaaaa")})
			rows.append({"text":"%s Attack Damage" % String.num(float(tool["attack_damage"]),2).trim_suffix(".0"),"color":Color("00aa00")})
			rows.append({"text":"%s Attack Speed" % String.num(float(tool["attack_speed"]),2).trim_suffix(".0"),"color":Color("00aa00")})
		var maximum: int = ToolDatabase.max_durability(id)
		# Vanilla only shows the numeric line after the tool has taken damage.
		if durability_visible and remaining >= 0 and remaining < maximum:
			rows.append({"text":"Durability: %d / %d" % [remaining,maximum],"color":Color.WHITE})
	if tool.is_empty() and armor.is_empty():
		var maximum: int=ToolDatabase.max_durability(id)
		if durability_visible and maximum>0 and remaining>=0 and remaining<maximum:rows.append({"text":"Durability: %d / %d" % [remaining,maximum],"color":Color.WHITE})
	return rows

static func draw_item_tooltip(canvas: CanvasItem, font: Font, config: InterfaceSettings,
		id: int, remaining: int, mouse: Vector2, viewport: Rect2, scale: float, metadata: Dictionary = {}) -> void:
	if id==0:return
	var rows: Array[Dictionary] = item_lines(id,remaining,config.durability_tooltips,metadata)
	var detail := PackedStringArray()
	var colors := PackedColorArray()
	for index in range(rows.size()):
		colors.append(rows[index]["color"])
		if index > 0: detail.append(rows[index]["text"])
	draw_tooltip(canvas,font,config,rows[0]["text"],"\n".join(detail),mouse,viewport,scale,colors)


