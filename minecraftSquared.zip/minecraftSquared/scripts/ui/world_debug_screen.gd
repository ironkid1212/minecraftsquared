class_name WorldDebugScreen
extends Control

var world: Node2D
var left_lines := PackedStringArray()
var right_lines := PackedStringArray()
var _timer: float = 0.0

func setup(game: Node2D) -> void:
	world = game
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	visible = false
	set_process(false)
	visibility_changed.connect(func():
		set_process(visible)
		if visible: refresh()
	)
	get_viewport().size_changed.connect(queue_redraw)

func _process(delta: float) -> void:
	_timer -= delta
	if _timer <= 0:
		_timer = .2
		refresh()

func refresh() -> void:
	if world == null or world.lighting == null: return
	var p: Vector2 = world.ground.to_local(world.player.global_position + Vector2(0,14))
	var coordinates: Vector2=world.chunks.world_coordinates(p)
	var block: Vector2i = world.chunks.cell_from_coordinates(Vector2i(coordinates.floor()))
	var chunk: Vector2i = world.chunks.cell_to_chunk(block)
	var light: Vector2i = world.lighting.sample_levels(block)
	var levels: String = "%d sky, %d block" % [light.x,light.y] if world.lighting.has_light_sample(block) else "not sampled"
	var mode: String = "Spectator (Fullbright)" if world.player.spectator else "Creative" if world.player.creative else "Survival"
	var fps: int = Engine.get_frames_per_second()
	left_lines = PackedStringArray([
		"2D Minecraft / Godot " + str(Engine.get_version_info()["string"]),
		"%d FPS | process %.2f ms | physics %.2f ms" % [fps, Performance.get_monitor(Performance.TIME_PROCESS) * 1000, Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000],
		"Position: %.2f / %.2f" % [coordinates.x,coordinates.y],
		"Block: %d %d" % [block.x,world.chunks.world_y(block)],
		"Chunk: %d %d | local: %d %d" % [chunk.x,chunk.y,posmod(block.x,32),posmod(block.y,32)],
		"Facing: " + ("east (+X)" if world.player.facing > 0 else "west (-X)"),
		"Biome: " + ("Lush Caves" if world.chunks.biome_at_cell(block)=="lush_caves" else world.chunks.biome_name(block.x)),
		"Light: " + levels,
		"Mode: " + mode,
		"Day %d | %s | time %d" % [world.clock.day_number(),world.clock.clock_text(),floori(world.clock.time_of_day())],
		"Seed: %d" % world.world_seed,
		"Chunks: %d loaded / %d cached / %d pending" % [world.chunks.loaded_chunks.size(),world.chunks._block_cache.size(),world.chunks._pending.size()],
		"Visible chunk meshes: %d" % world.lighting._renderer._meshes.size(),
		"Drops: %d | falling blocks: %d" % [world.dropped_items.drops.size(),world.world_updates.falling.bodies.size()]
	])
	if world.mobs!=null:left_lines.append("Mobs: %d active / %d sleeping / %d visible" % [world.mobs.active.size(),world.mobs.sleeping.size(),world.mobs.renderer.drawn])
	if world.fluids != null: left_lines.append("Fluids: %d queued | %d updated | %d visible" % [world.fluids._scheduled.size(),world.fluids.last_updates,world.fluids.renderer.drawn_cells])
	if world.player.spectator: left_lines.append("Flight speed: %d%% (boost while held)" % roundi(world.player.spectator_speed * 100))
	if world.chunks.biomes != null:
		var info: Dictionary = world.chunks.biomes.column(block.x)
		if info.get("blend_from",info["biome"]) != info.get("blend_to",info["biome"]):
			left_lines.append("Border: %s -> %s (%d%%)" % [info["blend_from"],info["blend_to"],roundi(float(info["blend"]) * 100)])
	right_lines = PackedStringArray([
		OS.get_name() + " | " + RenderingServer.get_current_rendering_method(),
		"Viewport: %d x %d" % [world.get_viewport_rect().size.x,world.get_viewport_rect().size.y],
		"Frame draw calls: %d" % int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME))
	])
	var memory: int = OS.get_static_memory_usage()
	if memory > 0: right_lines.append("Godot static memory: %.1f MiB" % (memory / 1048576.0))
	var target: Vector2i = world.get_mouse_cell()
	right_lines.append("")
	right_lines.append("Targeted Block")
	right_lines.append("%d / %d" % [target.x,world.chunks.world_y(target)])
	if world.chunks.is_cell_loaded(target):
		var id: int = world.get_block(target)
		var record: Dictionary = BlockDatabase.BLOCKS.get(id,{})
		right_lines.append(str(record.get("name","Air")))
		right_lines.append("ID: %d | %s" % [id,record.get("key","air")])
		right_lines.append("Solid: %s | platform: %s" % [record.get("solid",false),record.get("platform",false)])
		if world.lighting.has_light_sample(target):
			var target_light: Vector2i = world.lighting.sample_levels(target)
			right_lines.append("Light: %d sky / %d block" % [target_light.x,target_light.y])
	else: right_lines.append("Outside loaded terrain")
	queue_redraw()

func _draw() -> void:
	if not visible: return
	var window_size: Vector2 = get_viewport_rect().size
	var scale_value: int = clampi(floori(window_size.x / 600.0), 1, 2)
	var font: Font = ItemDrawing.settings.font
	var font_size: int = 8 * scale_value
	var line_height: int = 10 * scale_value
	for column in range(2 if window_size.x >= 640 else 1):
		var lines: PackedStringArray = left_lines if column == 0 else right_lines
		for i in range(lines.size()):
			var text: String = lines[i]
			if text.is_empty(): continue
			var width: float = font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x
			var x: float = 3 * scale_value if column == 0 else window_size.x - width - 3 * scale_value
			var y: float = (3 + i * 10) * scale_value
			if y + line_height > HudLayout.text_bottom(world): break
			draw_rect(Rect2(x - scale_value,y - scale_value,width + scale_value * 2,line_height),Color(0,0,0,.62))
			var at := Vector2(x,y + font.get_ascent(font_size))
			draw_string(font,at + Vector2.ONE * scale_value,text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,Color(0.15,0.15,0.15))
			draw_string(font,at,text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,Color(.9,.9,.9))
