class_name InventoryScreen
extends Control

signal open_changed(open: bool)
signal drop_requested(id: int, count: int, remaining_durability: int, metadata: Dictionary)

var UI_FONT: Font
var player_style: PlayerSettings
var preview_facing: int = 1
# Source supplies equipment only; the inventory owns its pose and animation.
var preview_presentation: PlayerPresentation
class InventoryPreviewPose extends PlayerPresentation:
	var idle_time: float = 0.0
	func main_arm_angle(walk_angle: float) -> float:
		return super.main_arm_angle(walk_angle) + sin(idle_time * 2.0) * 0.025

var _preview_pose := InventoryPreviewPose.new()
const PREVIEW_ORIGIN := Vector2(51, 47)
const PREVIEW_SCALE: float = 2.0
const PANEL_SIZE := Vector2(176, 166)
const EMPTY_EQUIPMENT_ICONS: Array[Texture2D]=[
	preload("res://assets/ui/empty_slot_helmet.png"),
	preload("res://assets/ui/empty_slot_chestplate.png"),
	preload("res://assets/ui/empty_slot_leggings.png"),
	preload("res://assets/ui/empty_slot_boots.png"),
	preload("res://assets/ui/empty_slot_shield.png")]
var items: BlockInventory
var atlas_source: TileSetAtlasSource
var crafting: CraftingGrid
var is_open: bool = false
## Spectators may inspect stacks and tooltips, but cannot move or craft items.
var read_only: bool = false
var is_table_mode: bool = false
var ui_scale: float = 3.0
var panel_position := Vector2.ZERO


func setup(data: BlockInventory, source: TileSetAtlasSource, style: PlayerSettings = null) -> void:
	UI_FONT = ItemDrawing.settings.font
	player_style = style if style != null else PlayerSettings.new()
	_preview_pose.configure(player_style)
	items = data
	atlas_source = source
	crafting = CraftingGrid.new(items)
	crafting.changed.connect(queue_redraw)
	items.changed.connect(queue_redraw)
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_force_pass_scroll_events = false
	set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	get_viewport().size_changed.connect(_resize)
	get_viewport().mouse_exited.connect(_ui_pointer_exited)
	get_viewport().mouse_entered.connect(_ui_pointer_entered)
	_resize()
	visible = false
	set_process(false)


func _resize() -> void:
	size = get_viewport_rect().size
	ui_scale = ItemDrawing.settings.gui_scale(size)
	panel_position = ((size - PANEL_SIZE * ui_scale) / 2.0).floor()
	queue_redraw()


func set_open(value: bool, table_mode: bool = false) -> void:
	if is_open == value:
		if not value or is_table_mode == table_mode:
			return
		# Returning ingredients first makes switching grids safe.
		set_open(false)
	if value:
		is_table_mode = table_mode
		var grid_width: int = 3 if table_mode else 2
		if crafting.width != grid_width:
			crafting = CraftingGrid.new(items, grid_width)
			crafting.changed.connect(queue_redraw)
	if not value and not read_only:
		var remainder: Dictionary = items.return_held()
		if remainder["count"] > 0:
			drop_requested.emit(remainder["id"], remainder["count"], remainder["durability"],remainder.get("tags",{}))
		for overflow in crafting.return_items():
			drop_requested.emit(overflow["id"], overflow["count"], overflow["durability"],overflow.get("tags",{}))
	if value:
		_preview_pose.cancel_actions()
		_preview_pose.head_pitch = 0.0
		_preview_pose.facing = preview_facing
		_preview_pose.idle_time = 0.0
	is_open = value
	visible = value
	set_process(value)
	open_changed.emit(value)
	queue_redraw()


func _input(event: InputEvent) -> void:
	_track_pointer(event)
	if not event is InputEventKey and not event is InputEventMouseButton: return
	if not event.pressed or event is InputEventKey and event.echo: return
	var cancel: bool = event is InputEventKey and event.physical_keycode == KEY_ESCAPE
	if GameBindings.matches(event,"inventory") or is_open and cancel:
		set_open(not is_open)
		get_viewport().set_input_as_handled()
	elif is_open:
		var hovered: int=slot_at(_pointer_position())
		if not read_only and GameBindings.matches(event,"swap_offhand") and hovered>=0:
			items.swap_slots(hovered,BlockInventory.OFFHAND);get_viewport().set_input_as_handled();return
		if not read_only and GameBindings.matches(event,"drop_item"):
			drop_hovered(event.ctrl_pressed);get_viewport().set_input_as_handled();return
		for index in range(9):
			if GameBindings.matches(event,"hotbar_" + str(index+1)):
				get_viewport().set_input_as_handled()
				return


func slot_rect(index: int) -> Rect2:
	if index>=BlockInventory.HEAD:
		return Rect2(77,62,16,16) if index==BlockInventory.OFFHAND else Rect2(8,8+(index-BlockInventory.HEAD)*18,16,16)
	if index < 9:
		return Rect2(Vector2(8 + index * 18, 142), Vector2(16, 16))
	var backpack: int = index - 9
	return Rect2(Vector2(8 + (backpack % 9) * 18, 84 + (backpack / 9) * 18), Vector2(16, 16))


func slot_at(local_position: Vector2) -> int:
	var p: Vector2 = (local_position - panel_position) / ui_scale
	for index in range(BlockInventory.MAIN_COUNT if is_table_mode else BlockInventory.SLOT_COUNT):
		if slot_rect(index).has_point(p):
			return index
	return -1


func craft_slot_rect(index: int) -> Rect2:
	var origin := Vector2(30, 17) if is_table_mode else Vector2(98, 18)
	return Rect2(origin + Vector2(index % crafting.width, floori(index / float(crafting.width))) * 18.0, Vector2(16, 16))


func craft_slot_at(local_position: Vector2) -> int:
	var p: Vector2 = (local_position - panel_position) / ui_scale
	for index in range(crafting.ids.size()):
		if craft_slot_rect(index).has_point(p):
			return index
	return -1


func result_rect() -> Rect2:
	if is_table_mode:
		return Rect2(Vector2(120, 31), Vector2(24, 24))
	return Rect2(Vector2(154, 28), Vector2(16, 16))


func _gui_input(event: InputEvent) -> void:
	_track_pointer(event)
	if read_only:
		accept_event()
		return
	if not is_open:
		return
	if event is InputEventMouseButton:
		var mouse := event as InputEventMouseButton
		if mouse.pressed and mouse.button_index in [MOUSE_BUTTON_LEFT, MOUSE_BUTTON_RIGHT]:
			var craft_index: int = craft_slot_at(mouse.position)
			var p: Vector2 = (mouse.position - panel_position) / ui_scale
			if result_rect().has_point(p):
				crafting.take_result(mouse.shift_pressed)
			elif craft_index >= 0:
				if mouse.shift_pressed:
					crafting.quick_move(craft_index)
				else:
					crafting.click_slot(craft_index, mouse.button_index == MOUSE_BUTTON_RIGHT)
			else:
				var index: int = slot_at(mouse.position)
				if index >= 0:
					if mouse.shift_pressed:
						items.quick_move(index)
					else:
						items.click_slot(index, mouse.button_index == MOUSE_BUTTON_RIGHT)
				elif not Rect2(Vector2.ZERO,panel_dimensions()).has_point(p) and items.held_count>0:
					var amount: int=1 if mouse.button_index==MOUSE_BUTTON_RIGHT else items.held_count
					drop_requested.emit(items.held_id,amount,items.held_durability,items.held_tags.duplicate(true))
					items.held_count-=amount
					if items.held_count==0:items.held_id=0;items.held_durability=0;items.held_tags={}
					items.changed.emit()
		accept_event()


func _process(delta: float) -> void:
	if is_open and not is_table_mode:
		_update_preview(delta)
	queue_redraw()


func _update_preview(delta: float) -> void:
	# Convert the screen pointer through the same transforms used to draw the rig.
	# Never aim or advance the live player's presentation from the inventory.
	var target: Vector2 = ((_pointer_position() - panel_position) / ui_scale - PREVIEW_ORIGIN) / PREVIEW_SCALE
	_preview_pose.look_at(target, delta)
	_preview_pose.idle_time += delta
	_preview_pose.inventory=items
	if _preview_pose.offhand==null:_preview_pose.offhand=PlayerPresentation.new();_preview_pose.offhand.configure(player_style)
	_preview_pose.offhand.is_offhand=true
	_preview_pose.offhand.held_tags=items.tags[BlockInventory.OFFHAND]
	_preview_pose.offhand.set_held_item(items.ids[BlockInventory.OFFHAND],atlas_source)
	if preview_presentation != null:
		_preview_pose.set_held_item(preview_presentation.held_id, preview_presentation.block_source)
		_preview_pose.held_tags=preview_presentation.held_tags
	else:
		_preview_pose.set_held_item(BlockDatabase.ID.AIR, atlas_source)


func _draw() -> void:
	if not is_open or items == null:
		return
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.55))
	draw_set_transform(panel_position, 0.0, Vector2.ONE * ui_scale)
	var panel: Texture2D = ItemDrawing.settings.crafting_table_texture if is_table_mode else preload("res://assets/ui/equipment_inventory.png")
	draw_texture_rect_region(panel, Rect2(Vector2.ZERO, PANEL_SIZE), Rect2(Vector2.ZERO, PANEL_SIZE))
	if not is_table_mode and not read_only:
		# Reuse the exact skin rig, at integer scale, inside the preview window.
		var panel_transform := Transform2D(0.0, Vector2.ONE * ui_scale, 0.0, panel_position)
		PlayerSkinDrawing.draw_model(self, player_style, PREVIEW_ORIGIN, PREVIEW_SCALE,
			_preview_pose.facing, 0.0, 0.0, panel_transform, _preview_pose)
	var hovered: int = slot_at(_pointer_position())
	for index in range(BlockInventory.MAIN_COUNT if is_table_mode else BlockInventory.SLOT_COUNT):
		var rect: Rect2 = slot_rect(index)
		if not is_table_mode and index>=BlockInventory.HEAD and items.counts[index]==0:
			draw_texture_rect(EMPTY_EQUIPMENT_ICONS[index-BlockInventory.HEAD],rect,false)
		if index == hovered:
			draw_rect(rect, Color(1, 1, 1, 0.3))
	var craft_hovered: int = craft_slot_at(_pointer_position())
	if craft_hovered >= 0:
		draw_rect(craft_slot_rect(craft_hovered), Color(1, 1, 1, 0.3))
	var result_hovered: bool = result_rect().has_point((_pointer_position() - panel_position) / ui_scale)
	if result_hovered:
		draw_rect(result_rect(), Color(1, 1, 1, 0.3))
	# Draw all text at its final size, matching the hotbar rendering.
	draw_set_transform(Vector2.ZERO)
	ItemDrawing.draw_panel_label(self,UI_FONT,"Crafting",Vector2(28,6) if is_table_mode else Vector2(97,8),ui_scale,panel_position)
	if is_table_mode:ItemDrawing.draw_panel_label(self,UI_FONT,"Inventory",Vector2(8,72),ui_scale,panel_position)
	for index in range(BlockInventory.MAIN_COUNT if is_table_mode else BlockInventory.SLOT_COUNT):
		var rect: Rect2 = slot_rect(index)
		var screen_rect := Rect2(panel_position + rect.position * ui_scale, rect.size * ui_scale)
		ItemDrawing.draw_stack(self, atlas_source, UI_FONT,
			items.ids[index], items.counts[index], screen_rect, ui_scale, -1.0, items.durability[index],items.tags[index])
	for index in range(crafting.ids.size()):
		var rect: Rect2 = craft_slot_rect(index)
		var screen_rect := Rect2(panel_position + rect.position * ui_scale, rect.size * ui_scale)
		ItemDrawing.draw_stack(self, atlas_source, UI_FONT,
			crafting.ids[index], crafting.counts[index], screen_rect, ui_scale, -1.0, crafting.durability[index],crafting.tags[index])
	if not crafting.recipe.is_empty():
		var rect: Rect2 = result_rect()
		ItemDrawing.draw_stack(self, atlas_source, UI_FONT,
			crafting.recipe["result"], crafting.recipe["count"],
			Rect2(panel_position + rect.position * ui_scale, rect.size * ui_scale), ui_scale)
	var hovered_tags: Dictionary=items.tags[hovered] if hovered>=0 else {}
	var hovered_durability: int = items.durability[hovered] if hovered >= 0 else 0
	var hovered_id: int = items.ids[hovered] if hovered >= 0 else BlockDatabase.ID.AIR
	if craft_hovered >= 0:
		hovered_tags=crafting.tags[craft_hovered]
		hovered_id = crafting.ids[craft_hovered]
		hovered_durability = crafting.durability[craft_hovered]
	elif result_hovered and not crafting.recipe.is_empty():
		hovered_id = crafting.recipe["result"]
		hovered_durability = ToolDatabase.max_durability(hovered_id)
	if items.held_count > 0:
		var rect := Rect2(_pointer_position() - Vector2.ONE * 8 * ui_scale, Vector2.ONE * 16 * ui_scale)
		ItemDrawing.draw_stack(self, atlas_source, UI_FONT, items.held_id, items.held_count, rect, ui_scale, -1.0, items.held_durability,items.held_tags)
	elif hovered_id != BlockDatabase.ID.AIR:
		ItemTooltipDrawing.draw_item_tooltip(self, UI_FONT, ItemDrawing.settings, hovered_id, hovered_durability,
			_pointer_position(), Rect2(Vector2.ZERO, size), ui_scale,hovered_tags)


func _pointer_position() -> Vector2:
	if not get_viewport().get_meta("inventory_pointer_present",true):return Vector2(-10000,-10000)
	return get_viewport().get_meta("inventory_pointer_position",get_local_mouse_position())
func _track_pointer(event: InputEvent) -> void:
	if event is InputEventMouseMotion or event is InputEventMouseButton:
		get_viewport().set_meta("inventory_pointer_position",event.position)
		get_viewport().set_meta("inventory_pointer_present",true)
		if is_open:queue_redraw()
func _ui_pointer_exited() -> void:
	get_viewport().set_meta("inventory_pointer_present",false)
	queue_redraw()
func _ui_pointer_entered() -> void:
	if get_viewport().has_meta("inventory_pointer_position"):get_viewport().remove_meta("inventory_pointer_position")
	get_viewport().set_meta("inventory_pointer_present",true)
	queue_redraw()

func panel_dimensions() -> Vector2:return PANEL_SIZE
func drop_hovered(whole: bool) -> void:
	var index: int=slot_at(_pointer_position())
	if index>=0 and items.counts[index]>0:
		var stack: Dictionary=items.stack(index)
		var amount: int=items.counts[index] if whole else 1
		items.remove_from_slot(index,amount);drop_requested.emit(stack["id"],amount,stack["durability"],stack["tags"])
		return
	index=craft_slot_at(_pointer_position())
	if index<0 or crafting.counts[index]<=0:return
	var amount: int=crafting.counts[index] if whole else 1
	drop_requested.emit(crafting.ids[index],amount,crafting.durability[index],crafting.tags[index].duplicate(true))
	crafting.counts[index]-=amount
	if crafting.counts[index]==0:crafting.ids[index]=0;crafting.durability[index]=0;crafting.tags[index]={}
	crafting._refresh()
