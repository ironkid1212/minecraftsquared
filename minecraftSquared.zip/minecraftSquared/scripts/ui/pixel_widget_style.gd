class_name PixelWidgetStyle
extends StyleBox

## Explicit pixel-aligned slices avoid UV remapping on a single nine-patch quad.
## The supplied widget pixels remain unchanged, including the white hover edge.
var texture: Texture2D
var margins := Vector4(3,3,3,3)

func set_texture_margin(side: int, value: float) -> void:
	margins[side] = value

func _get_minimum_size() -> Vector2:
	return Vector2(margins.x + margins.z, margins.y + margins.w)

func _draw(canvas: RID, bounds: Rect2) -> void:
	if texture == null: return
	var rect := Rect2(bounds.position.round(), bounds.size.round())
	var size: Vector2 = texture.get_size()
	var left: float = minf(margins.x, rect.size.x * .5)
	var right: float = minf(margins.z, rect.size.x - left)
	var top: float = minf(margins.y, rect.size.y * .5)
	var bottom: float = minf(margins.w, rect.size.y - top)
	var dx := PackedFloat32Array([0,left,rect.size.x-right,rect.size.x])
	var dy := PackedFloat32Array([0,top,rect.size.y-bottom,rect.size.y])
	var sx := PackedFloat32Array([0,margins.x,size.x-margins.z,size.x])
	var sy := PackedFloat32Array([0,margins.y,size.y-margins.w,size.y])
	for y in range(3):
		for x in range(3):
			var destination := Rect2(rect.position + Vector2(dx[x],dy[y]),Vector2(dx[x+1]-dx[x],dy[y+1]-dy[y]))
			var source := Rect2(Vector2(sx[x],sy[y]),Vector2(sx[x+1]-sx[x],sy[y+1]-sy[y]))
			if destination.has_area() and source.has_area():
				RenderingServer.canvas_item_add_texture_rect_region(canvas,destination,texture.get_rid(),source,Color.WHITE,false,true)
