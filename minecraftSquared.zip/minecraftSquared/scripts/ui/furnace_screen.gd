class_name FurnaceScreen
extends InventoryScreen
var cell := Vector2i.ZERO
var system: FurnaceSystem
const PANEL: Texture2D = preload("res://assets/ui/furnace/panel.png")
const FLAME: Texture2D = preload("res://assets/ui/furnace/lit_progress.png")
const ARROW: Texture2D = preload("res://assets/ui/furnace/burn_progress.png")

func open_furnace(at: Vector2i, host: FurnaceSystem) -> void:
	cell = at
	system = host
	set_open(true,true)
	crafting = FurnaceGrid.new(items, system.state_at(cell), system)
	crafting.changed.connect(queue_redraw)

func _input(event: InputEvent) -> void:
	_track_pointer(event)
	if not is_open: return
	if not event is InputEventKey and not event is InputEventMouseButton: return
	if not event.pressed or event is InputEventKey and event.echo: return
	if GameBindings.matches(event,"inventory") or event is InputEventKey and event.physical_keycode == KEY_ESCAPE:
		set_open(false)
		get_viewport().set_input_as_handled()
	else:super._input(event)

func craft_slot_rect(index: int) -> Rect2:
	return Rect2([Vector2(56, 17), Vector2(56, 53), Vector2(116, 35)][index], Vector2(16, 16))

func result_rect() -> Rect2:
	return Rect2(-1000, -1000, 1, 1)

func _gui_input(event: InputEvent) -> void:
	_track_pointer(event)
	if is_open and not read_only and crafting is FurnaceGrid and event is InputEventMouseButton and event.pressed and event.shift_pressed and event.button_index in [MOUSE_BUTTON_LEFT,MOUSE_BUTTON_RIGHT]:
		var index: int=slot_at(event.position)
		if index>=0:crafting.deposit(index);accept_event();return
	super._gui_input(event)

func _process(_delta: float) -> void:
	if crafting is FurnaceGrid: crafting.sync()
	queue_redraw()

func _draw() -> void:
	if not is_open or not crafting is FurnaceGrid: return
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.55))
	draw_set_transform(panel_position, 0, Vector2.ONE * ui_scale)
	draw_texture_rect_region(PANEL, Rect2(Vector2.ZERO, PANEL_SIZE), Rect2(Vector2.ZERO, PANEL_SIZE))
	var state: FurnaceState = crafting.state
	if state.burn > 0:
		var fraction: float = clampf(state.burn / maxf(.000001, state.burn_total), 0, 1)
		var h: int = maxi(1, ceili(14 * fraction))
		draw_texture_rect_region(FLAME, Rect2(56, 36 + 14 - h, 14, h), Rect2(0, 14 - h, 14, h))
	var width: int = clampi(floori(24 * state.cook / system.cook_seconds(state.ids[0])), 0, 24)
	if width > 0: draw_texture_rect_region(ARROW, Rect2(79, 34, width, 16), Rect2(0, 0, width, 16))
	var hover: int = slot_at(_pointer_position())
	var furnace_hover: int = craft_slot_at(_pointer_position())
	if hover >= 0: draw_rect(slot_rect(hover), Color(1, 1, 1, 0.3))
	if furnace_hover >= 0: draw_rect(craft_slot_rect(furnace_hover), Color(1, 1, 1, 0.3))
	draw_set_transform(Vector2.ZERO)
	ItemDrawing.draw_panel_label(self,UI_FONT,"Furnace",Vector2(0,6),ui_scale,panel_position,true)
	ItemDrawing.draw_panel_label(self,UI_FONT,"Inventory",Vector2(8,72),ui_scale,panel_position)
	for index in range(36):
		var bounds: Rect2 = slot_rect(index)
		ItemDrawing.draw_stack(self, atlas_source, UI_FONT, items.ids[index], items.counts[index], Rect2(panel_position + bounds.position * ui_scale, bounds.size * ui_scale), ui_scale, -1, items.durability[index],items.tags[index])
	for index in range(3):
		var bounds: Rect2 = craft_slot_rect(index)
		ItemDrawing.draw_stack(self, atlas_source, UI_FONT, state.ids[index], state.counts[index], Rect2(panel_position + bounds.position * ui_scale, bounds.size * ui_scale), ui_scale, -1, state.durability[index],state.tags[index])
	if items.held_count > 0:
		ItemDrawing.draw_stack(self, atlas_source, UI_FONT, items.held_id, items.held_count, Rect2(_pointer_position() - Vector2.ONE * 8 * ui_scale, Vector2.ONE * 16 * ui_scale), ui_scale, -1, items.held_durability,items.held_tags)
	else:
		var id: int = state.ids[furnace_hover] if furnace_hover >= 0 else items.ids[hover] if hover >= 0 else 0
		if id != 0: ItemTooltipDrawing.draw_item_tooltip(self, UI_FONT, ItemDrawing.settings, id, state.durability[furnace_hover] if furnace_hover>=0 else items.durability[hover], _pointer_position(), Rect2(Vector2.ZERO, size), ui_scale,state.tags[furnace_hover] if furnace_hover>=0 else items.tags[hover])
		else:
			var pointer: Vector2=(_pointer_position()-panel_position)/ui_scale
			if Rect2(56,36,14,14).has_point(pointer):
				var message: String="%.1f s remaining"%state.burn if state.burn>0 else "Add fuel to the bottom slot."
				if state.burn<=0 and state.counts[1]>0 and system.fuel_seconds(state.ids[1])>0:message="Fuel is ready; add a smeltable item."
				ItemTooltipDrawing.draw_tooltip(self,UI_FONT,ItemDrawing.settings,"Fuel",message,_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale)
			elif Rect2(79,34,24,16).has_point(pointer):
				var kind: String=system.status(state);var title: String="Smelting";var detail: String=""
				match kind:
					"empty":detail="Add an item to the top slot."
					"recipe":detail="This item has no smelting recipe."
					"output":detail="Make room in the output slot."
					"fuel":detail="Add fuel to the bottom slot."
					"cooling":title="Cooling";detail="Add fuel to keep cooking."
					"cooking":detail=str(BlockDatabase.BLOCKS[system.result_for(state.ids[0])].name)+"\n%.1f s remaining"%maxf(0,system.cook_seconds(state.ids[0])-state.cook)
				ItemTooltipDrawing.draw_tooltip(self,UI_FONT,ItemDrawing.settings,title,detail,_pointer_position(),Rect2(Vector2.ZERO,size),ui_scale)

