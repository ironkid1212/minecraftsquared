class_name ProfilePreview
extends Control

var style := PlayerSettings.new()
var pose := PlayerPresentation.new()
var gui_scale: int = 1

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	pose.configure(style)

func set_skin(texture: Texture2D) -> void:
	style.skin_texture = texture
	queue_redraw()

func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	var origin := Vector2(size.x / 2.0, 72 * gui_scale)
	pose.look_at((get_local_mouse_position() - origin) / (3.0 * gui_scale), delta)
	queue_redraw()

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.7))
	var origin := Vector2(size.x / 2.0, 72 * gui_scale)
	PlayerSkinDrawing.draw_model(self, style, origin, 3.0 * gui_scale, pose.facing, 0, 0, Transform2D.IDENTITY, pose)
