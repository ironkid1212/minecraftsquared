class_name InterfaceAudio
extends Node
const CLICK: String="res://assets/audio/random/click_stereo.ogg"
const SETTINGS: EffectsSettings=preload("res://data/settings/effects.tres")
var voices: Array[AudioStreamPlayer]=[]
static func click() -> void:
	var tree: SceneTree=Engine.get_main_loop() as SceneTree
	if tree==null or SETTINGS.master_volume<=0 or SETTINGS.interface_volume<=0:return
	var host: InterfaceAudio=tree.root.get_node_or_null("InterfaceAudio")
	if host==null:
		host=InterfaceAudio.new();host.name="InterfaceAudio";host.process_mode=Node.PROCESS_MODE_ALWAYS;tree.root.add_child(host)
		for i in range(4):
			var voice:=AudioStreamPlayer.new();voice.stream=load(CLICK);host.add_child(voice);host.voices.append(voice)
	for voice in host.voices:
		if not voice.playing:voice.volume_db=linear_to_db(SETTINGS.master_volume*SETTINGS.interface_volume);voice.play();return
