class_name CommandSystem
extends RefCounted

var world: Node2D
var chat: ChatScreen
var commands: Dictionary = {}
var names := PackedStringArray()
const HANDLERS := ["help","give","clear","gamemode","tp","setblock","spawnpoint","seed","heal","kill","save","say","time","gamerule","weather","itemtag","blocktag","summon","experience","locate","spawner"]

func setup(game: Node2D, screen: ChatScreen) -> void:
	world = game
	chat = screen
	for rule in DataFile.array_from("res://data/commands.json"):
		if not rule is Dictionary or not rule.get("name") is String or rule.get("handler") not in HANDLERS or not rule.get("usage") is String or not rule.get("description") is String or not rule.get("aliases") is Array:
			DataFile.fail("commands.json: invalid command definition.")
			continue
		for key in [rule["name"]] + rule["aliases"]:
			if not key is String or key.is_empty() or " " in key or commands.has(key):
				DataFile.fail("commands.json: invalid/duplicate command alias.")
				continue
			commands[key] = rule
		names.append(rule["name"])
	names.sort()

func reply(text: String, error: bool = false) -> void:
	chat.post(text, Color("ff5555") if error else Color.WHITE)

func execute(line: String) -> void:
	var words: PackedStringArray = line.trim_prefix("/").replace("\t"," ").split(" ",false)
	if words.is_empty(): return
	var key: String = words[0].to_lower()
	if not commands.has(key):
		reply("Unknown command: /" + key + ". Type /help.",true)
		return
	var rule: Dictionary = commands[key]
	var args: Array[String] = []
	for i in range(1,words.size()): args.append(words[i])
	var handler: String = rule["handler"]
	if handler in ["give","clear","tp"] and not args.is_empty() and args[0] in ["@s","@p","@a",chat.username()]: args.pop_front()
	if handler in ["gamemode","kill"] and not args.is_empty() and args[-1] in ["@s","@p","@a",chat.username()]: args.pop_back()
	# Preserve quoted whitespace inside SNBT instead of rebuilding it from words.
	var tag_index: int=2 if handler=="give" else 1
	if handler in ["give","itemtag","blocktag"] and args.size()>tag_index and args[tag_index].begins_with("{"):
		args.resize(tag_index);args.append(line.substr(line.find("{")))
	if world.player.survival_dead and handler not in ["help","seed","save","say","time","gamerule","weather","itemtag","blocktag"]:
		reply("Respawn before using this command.",true)
		return
	match handler:
		"experience": experience_command(args,rule)
		"locate": locate_structure(args,rule)
		"spawner": spawner_command(args,rule)
		"summon": summon_mob(args,rule)
		"weather": weather_command(args,rule)
		"itemtag", "blocktag": tag_command(args,rule,handler=="blocktag")
		"time": time_command(args,rule)
		"gamerule": cycle_rule(args,rule)
		"help":
			if args.is_empty():
				reply("Commands: " + ", ".join(names) + ". Use /help <command>.")
			elif args.size() == 1 and commands.has(args[0].trim_prefix("/")):
				var found: Dictionary = commands[args[0].trim_prefix("/")]
				reply(found["usage"] + " — " + found["description"])
			else: usage(rule)
		"give": give(args,rule)
		"clear": clear_items(args,rule)
		"gamemode":
			var modes: Dictionary={"0":"survival","1":"creative","3":"spectator","survival":"survival","creative":"creative","spectator":"spectator"}
			if args.size()!=1 or not modes.has(args[0]):usage(rule)
			elif world.set_game_mode(modes[args[0]]):reply("Game mode: "+world.game_mode().capitalize())
			else:reply("Close open screens and move into clear, loaded space first.",true)
		"tp": teleport(args,rule)
		"setblock": set_cell(args,rule)
		"spawnpoint":
			if not args.is_empty(): usage(rule)
			else:
				var floor_cell: Vector2i = world.ground.local_to_map(world.ground.to_local(world.player.global_position)+Vector2(0,14.1))
				var point: Variant = world.beds.safe_on(floor_cell)
				if point == null: reply("Stand on clear, supported ground first.",true)
				else:
					world.survival.world_spawn = point
					world.player.spawn_position = point
					world.survival.has_bed = false
					reply("Respawn point set at your feet.")
		"seed":
			if not args.is_empty(): usage(rule)
			else: reply("Seed: " + str(world.world_seed))
		"heal":
			if args.size() > 1 or args.size() == 1 and (not args[0].is_valid_int() or int(args[0]) < 1 or int(args[0]) > 40): usage(rule)
			else:
				world.survival.heal(int(args[0]) if not args.is_empty() else world.settings.survival.maximum_health)
				reply("Health: %d/%d" % [world.survival.health,world.settings.survival.maximum_health])
		"kill":
			if not args.is_empty(): usage(rule)
			else:
				if world.player.spectator: world.set_spectator(false,true)
				world.survival.take_damage(world.settings.survival.maximum_health,"You were killed by a command",true)
				reply("Killed your player.")
		"save":
			if not args.is_empty(): usage(rule)
			else:
				var scene: Node = world.get_tree().current_scene
				if scene != null and scene.has_method("save_current"):
					if scene.save_current(): reply("World saved.")
					else: reply("Save failed: " + str(scene.store.last_error),true)
				else: reply("Open a saved world from the title screen to use /save.",true)
		"say":
			if args.is_empty(): usage(rule)
			else: chat.post("[" + chat.username() + "] " + " ".join(args))

func usage(rule: Dictionary) -> void: reply("Usage: " + str(rule["usage"]),true)

func item_id(key: String) -> int:
	key = key.trim_prefix("minecraft:")
	var id: int = int(key) if key.is_valid_int() else BlockDatabase.id_for(key)
	if not BlockDatabase.BLOCKS.has(id): return 0
	if world.beds.parts.has(id) and not world.beds.is_item(id): return 0
	return id

func give(args: Array[String], rule: Dictionary) -> void:
	var metadata: Dictionary={}
	if args.size()>2:
		var tag: Dictionary=NBT.parse(" ".join(args.slice(2)))
		if tag.is_empty() or int(tag["t"])!=NBT.COMPOUND or not ItemTags.valid(tag["v"]):reply("Invalid item NBT: "+NBT.error,true);return
		metadata=tag["v"];args=args.slice(0,2)
	if args.size() < 1 or args.size() > 2: usage(rule); return
	var id: int = item_id(args[0])
	if id == 0: reply("Unknown or internal item: " + args[0],true); return
	if args.size() == 2 and (not args[1].is_valid_int() or int(args[1]) < 1 or int(args[1]) > int(chat.config["maximum_give_count"])):
		reply("Count must be 1–%d." % int(chat.config["maximum_give_count"]),true); return
	var count: int = int(args[1]) if args.size() == 2 else 1
	var uses: int=ToolDatabase.max_durability(id)
	if metadata.has("Damage"):
		var damage: int=int(NBT.value(metadata,"Damage",0))
		if uses==0 or damage<0 or damage>=uses:reply("Damage is outside this item's durability range.",true);return
		uses-=damage
	var overflow: int = world.inventory.add_item(id,count,0,36,uses,metadata)
	if overflow > 0:
		world.dropped_items.spawn_item(id,overflow,world.player.global_position,Vector2.ZERO,uses,metadata)
	var name_text: String = BlockDatabase.BLOCKS[id]["name"]
	reply("Gave %d %s%s" % [count,name_text," (%d dropped: inventory full)" % overflow if overflow > 0 else ""])

func clear_items(args: Array[String], rule: Dictionary) -> void:
	if args.size() > 1: usage(rule); return
	var id: int = item_id(args[0]) if args.size() == 1 else 0
	if args.size() == 1 and id == 0: reply("Unknown item: " + args[0],true); return
	var count: int = 0
	for i in range(world.inventory.SLOT_COUNT):
		if id == 0 or world.inventory.ids[i] == id:
			count += world.inventory.counts[i]
			world.inventory.ids[i] = 0
			world.inventory.counts[i] = 0
			world.inventory.durability[i] = 0
			world.inventory.tags[i]={}
	world.inventory.changed.emit()
	reply("Removed %d items." % count)

func feet_coordinates() -> Vector2:
	var local: Vector2 = world.ground.to_local(world.player.global_position)+Vector2(0,14)
	return world.chunks.world_coordinates(local)

func top_y() -> int: return world.chunks.top_world_y()

func coordinate(text: String, base: float) -> Variant:
	var relative: bool = text.begins_with("~")
	var number: String = text.trim_prefix("~") if relative else text
	if number.is_empty() and relative: return base
	if not number.is_valid_float(): return null
	var value: float = float(number) + (base if relative else 0.0)
	return value if is_finite(value) and absf(value) <= 1000000 else null

func teleport(args: Array[String], rule: Dictionary) -> void:
	if args.size() != 2: usage(rule); return
	var current: Vector2 = feet_coordinates()
	var x: Variant = coordinate(args[0],current.x)
	var y: Variant = coordinate(args[1],current.y)
	# Integer absolute horizontal destinations refer to the block center.
	if x!=null and args[0].is_valid_int():x=float(x)+.5
	if x == null or y == null or float(y) < top_y()+1-world.chunks.world_depth or float(y) > top_y()+1-world.chunks.min_world_y:
		reply("Invalid coordinates or destination outside world height.",true); return
	var point: Vector2 = world.ground.to_global(world.chunks.local_from_coordinates(Vector2(x,y))-Vector2(0,14))
	world.chunks.update_around(point)
	if not world.player.spectator:
		var body: Rect2=world.player_collision.global_transform*world.player_collision.shape.get_rect()
		body.position+=point-world.player.global_position
		var bounds: Rect2 = world.ground.global_transform.affine_inverse()*body.grow(-.02)
		var first: Vector2i = world.ground.local_to_map(bounds.position+Vector2(.1,.1))
		var last: Vector2i = world.ground.local_to_map(bounds.end-Vector2(.1,.1))
		for cy in range(first.y,last.y+1):
			for cx in range(first.x,last.x+1):
				var cell := Vector2i(cx,cy)
				var blocked: bool=not world.chunks.is_cell_loaded(cell)
				var entry: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(cell),{})
				if entry.get("solid",false):
					var origin: Vector2=world.ground.map_to_local(cell)-Vector2(8,8)
					for box in entry.get("collision_boxes",[[0,0,16,16]]):
						if bounds.intersects(Rect2(origin+Vector2(box[0],box[1]),Vector2(box[2],box[3]))):blocked=true;break
				if blocked:
					world.chunks.update_around(world.player.global_position)
					reply("Destination is obstructed. Use Spectator to teleport through terrain.",true); return
	world.player.teleport_to(point)
	world.survival.reset_fall()
	world.lighting.invalidate()
	reply("Teleported to %.2f, %.2f." % [float(x),float(y)])

func set_cell(args: Array[String], rule: Dictionary) -> void:
	if args.size() != 3: usage(rule); return
	var current: Vector2=feet_coordinates().floor()
	var x: Variant = coordinate(args[0],current.x)
	var y: Variant = coordinate(args[1],current.y)
	if x == null or y == null or float(x) != floorf(float(x)) or float(y) != floorf(float(y)):
		reply("Block coordinates must be whole numbers.",true); return
	var cell: Vector2i=world.chunks.cell_from_coordinates(Vector2i(int(x),int(y)))
	if not world.chunks.is_cell_loaded(cell): reply("That block is outside loaded terrain.",true); return
	if not world.beds.can_break(cell): reply("Both bed halves must be loaded before replacing a bed.",true); return
	var id: int = item_id(args[2])
	if args[2] in ["air","minecraft:air","0"]: id = 0
	elif id == 0 or not BlockDatabase.BLOCKS[id].get("placeable",false): reply("Unknown or non-placeable block.",true); return
	if world.beds.is_item(id):
		if not world.beds.place(cell,id,world.player.facing): reply("Bed needs two empty supported cells.",true); return
	else:
		if id != 0 and BlockDatabase.BLOCKS[id].get("solid",false):
			var bounds: Rect2 = world.ground.global_transform * Rect2(world.ground.map_to_local(cell)-Vector2(8,8),Vector2(16,16))
			if bounds.intersects(world.player_collision.global_transform*world.player_collision.shape.get_rect()): reply("Cannot put a solid block inside the player.",true); return
		if world.world_updates.falling.overlaps_cell(cell): reply("A falling block occupies that cell.",true); return
		world.set_block(cell,id)
		if BlockDatabase.has_tag(id,"fluid"): world.fluids.set_fluid(cell,id,0)
		if id != 0: world.world_updates.note_player_placement(cell,id)
	reply("Block set at %d, %d." % [int(x),int(y)])

func complete(text: String) -> PackedStringArray:
	var result := PackedStringArray()
	if not text.begins_with("/"): return result
	var words: PackedStringArray = text.substr(1).split(" ",true)
	if words.size() == 1:
		for name_text in names:
			if name_text.begins_with(words[0]): result.append("/"+name_text)
		return result
	if not commands.has(words[0]): return result
	var handler: String = commands[words[0]]["handler"]
	var prefix: String = words[-1]
	var stem: String = text.substr(0,text.length()-prefix.length())
	var argument: int = words.size()-1
	if words.size()>2 and words[1]=="@s": argument -= 1
	if handler in ["give","clear"] and argument == 1 or handler == "setblock" and argument == 3:
		for id in BlockDatabase.BLOCKS:
			var record: Dictionary = BlockDatabase.BLOCKS[id]
			if item_id(record["key"]) == 0: continue
			if record.get("internal",false): continue
			if handler == "setblock" and not record["placeable"]: continue
			var key: String = record["key"]
			if prefix.begins_with("minecraft:"): key = "minecraft:"+key
			if key.begins_with(prefix): result.append(stem+key)
	elif handler == "gamemode" and argument == 1:
		for mode in ["survival","creative","spectator"]:
			if mode.begins_with(prefix): result.append(stem+mode)
	elif handler=="experience":
		var values: Array=["add","set","query"] if argument==1 else ["@s","@p",chat.username()] if argument==2 else ["points","levels"] if argument==4 or argument==3 and words[1]=="query" else []
		for value in values:
			if str(value).begins_with(prefix):result.append(stem+str(value))
	elif handler == "summon" and argument == 1:
		for mob in MobCatalog.definitions:
			var key: String=("minecraft:" if prefix.begins_with("minecraft:") else "")+mob
			if key.begins_with(prefix):result.append(stem+key)
	elif handler == "help" and argument == 1:
		for name_text in names:
			if name_text.begins_with(prefix): result.append(stem+name_text)
	elif handler == "time":
		var values: Array = ["set","add","query"] if argument==1 else ["day","noon","sunset","night","midnight","sunrise"] if words[1]=="set" else ["daytime","day","gametime"] if words[1]=="query" else []
		for value in values:
			if str(value).begins_with(prefix): result.append(stem+str(value))
	elif handler in ["itemtag","blocktag"] and argument==1:
		for value in ["get","set","merge","clear"]:
			if value.begins_with(prefix):result.append(stem+value)
	elif handler=="locate":
		for value in ["structure"] if argument==1 else ["mineshaft","monster_room","fortress","stronghold"]:
			if value.begins_with(prefix):result.append(stem+value)
	elif handler=="spawner" and argument==1:
		for value in ["zombie","skeleton","spider","cave_spider","blaze","silverfish"]:
			if value.begins_with(prefix):result.append(stem+value)
	elif handler == "weather" and argument==1:
		for value in ["clear","rain","snow","thunder"]:
			if value.begins_with(prefix): result.append(stem+value)
	elif handler == "gamerule":
		for value in ["doDaylightCycle","doWeatherCycle","mobGriefing"] if argument==1 else ["true","false"]:
			if value.begins_with(prefix): result.append(stem+value)
	result.sort()
	return result

func time_command(args: Array[String], rule: Dictionary) -> void:
	if args.size()!=2: usage(rule); return
	var presets: Dictionary = {"day":1000,"noon":6000,"sunset":12000,"night":13000,"midnight":18000,"sunrise":23000}
	match args[0]:
		"set":
			if args[1] in presets: world.clock.set_daytime(presets[args[1]])
			elif args[1].is_valid_int() and int(args[1])>=0 and int(args[1])<24000: world.clock.set_daytime(int(args[1]))
			else: reply("Choose a time preset or 0–23999 ticks.",true); return
		"add":
			if not args[1].is_valid_int() or int(args[1])<0 or int(args[1])>2400000 or world.clock.total_ticks+int(args[1])>1000000000000: reply("Add 0–2400000 ticks.",true); return
			world.clock.total_ticks += int(args[1])
			world.clock.apply()
		"query":
			match args[1]:
				"daytime": reply("Daytime: %d" % floori(world.clock.time_of_day()))
				"day": reply("Day: %d" % world.clock.day_number())
				"gametime": reply("World time: %d" % floori(world.clock.total_ticks))
				_: usage(rule)
			return
		_: usage(rule); return
	reply("Time: %s (day %d, tick %d)" % [world.clock.clock_text(),world.clock.day_number(),floori(world.clock.time_of_day())])

func cycle_rule(args: Array[String], rule: Dictionary) -> void:
	if args.size()<1 or args.size()>2 or args[0] not in ["doDaylightCycle","doWeatherCycle","mobGriefing"] or args.size()==2 and args[1] not in ["true","false"]: usage(rule); return
	if args[0]=="doDaylightCycle":
		if args.size()==2: world.clock.running=args[1]=="true"
		reply(args[0]+" = "+str(world.clock.running))
	elif args[0]=="doWeatherCycle":
		if args.size()==2: world.weather.cycling=args[1]=="true"
		reply(args[0]+" = "+str(world.weather.cycling))
	else:
		if args.size()==2:world.mobs.mob_griefing=args[1]=="true"
		reply(args[0]+" = "+str(world.mobs.mob_griefing))

func weather_command(args: Array[String], rule: Dictionary) -> void:
	if args.size()<1 or args.size()>2 or args[0] not in ["clear","rain","snow","thunder"] or args.size()==2 and (not args[1].is_valid_float() or not ContentCatalog._number(float(args[1]),1,1000000)):
		usage(rule)
		return
	world.weather.set_weather(args[0],float(args[1]) if args.size()==2 else -1)
	reply("Weather: "+args[0])

func tag_command(args: Array[String],rule: Dictionary,block: bool) -> void:
	if args.is_empty() or args[0] not in ["get","set","merge","clear"]:usage(rule);return
	var cell: Vector2i=world.get_mouse_cell()
	var slot: int=world.hotbar.selected_slot
	if block and (not world.cell_is_reachable(cell) or not world.storage.is_storage(world.get_block(cell))):reply("Point at a reachable chest or barrel.",true);return
	if not block and world.inventory.counts[slot]<=0:reply("Select a nonempty item stack.",true);return
	var current: Dictionary=world.storage.block_tags.get(cell,{}) if block else world.inventory.tags[slot]
	if args[0]=="get":
		reply(NBT.snbt(NBT.node(NBT.COMPOUND,world.storage.inspect_nbt(cell) if block else current)))
		return
	var metadata: Dictionary={}
	if args[0]!="clear":
		var tag: Dictionary=NBT.parse(" ".join(args.slice(1)))
		if tag.is_empty() or int(tag["t"])!=NBT.COMPOUND:reply("Expected an SNBT compound: "+NBT.error,true);return
		metadata=tag["v"]
		if args[0]=="merge":metadata=ContentCatalog.merge(current,metadata)
	if not NBT.valid_tags(metadata):reply("NBT exceeds the supported size or nesting limits.",true);return
	if block:
		for key in ["Items","id","x","y"]:
			if metadata.has(key):reply("Container inventory/position fields are managed by the game.",true);return
		if metadata.has("CustomName") and int(metadata["CustomName"]["t"])!=NBT.STRING:reply("CustomName must be a string.",true);return
		world.storage.block_tags[cell]=metadata.duplicate(true)
	elif not world.inventory.apply_tags(slot,metadata):reply("Invalid item tags or Damage value.",true);return
	reply("Updated "+("block" if block else "item")+" NBT.")

func summon_mob(args: Array[String],rule: Dictionary) -> void:
	if args.size() not in [1,3] or not MobCatalog.definitions.has(args[0].trim_prefix("minecraft:")):usage(rule);return
	var kind: String=args[0].trim_prefix("minecraft:");var point: Vector2=world.pointer_global_position()
	if args.size()==3:
		var current: Vector2=feet_coordinates();var x: Variant=coordinate(args[1],current.x);var y: Variant=coordinate(args[2],current.y)
		if x==null or y==null:usage(rule);return
		if args[1].is_valid_int():x=float(x)+.5
		point=world.ground.to_global(world.chunks.local_from_coordinates(Vector2(x,y)))
	if not world.mobs.can_fit(kind,point):reply("That mob needs clear, loaded space.",true);return
	if world.mobs.spawn(kind,point)==null:reply("Mob capacity reached.",true);return
	reply("Summoned "+kind+".")

func experience_command(args: Array[String],rule: Dictionary) -> void:
	var values: Array[String]=args.duplicate()
	# Also accept the familiar local shorthand /xp 10 or /xp 10L.
	if values.size()==1 and (values[0].is_valid_int() or values[0].trim_suffix("L").trim_suffix("l").is_valid_int()):
		var unit: String="levels" if values[0].to_lower().ends_with("l") else "points"
		var amount_text: String=values[0].trim_suffix("L").trim_suffix("l")
		values.assign(["add","@s",amount_text,unit])
	if values.size()>=2 and values[1].is_valid_int():values.insert(1,"@s")
	if values.size()<2 or values[0] not in ["add","set","query"]:usage(rule);return
	if values[1] not in ["@s","@p","@a",chat.username()]:reply("Only the local player (@s, @p or your username) is available.",true);return
	var operation: String=values[0]
	if operation=="query":
		if values.size()!=3 or values[2] not in ["points","levels"]:usage(rule);return
		reply("Experience "+values[2]+": "+str(world.experience.level() if values[2]=="levels" else world.experience.total-PlayerExperience.threshold(world.experience.level())));return
	if values.size()==3:values.append("points")
	if values.size()!=4 or not values[2].is_valid_int() or values[3] not in ["points","levels"]:usage(rule);return
	var amount: int=int(values[2]);var unit: String=values[3]
	if amount < (-100000 if operation=="add" else 0) or amount>100000:reply("Amount must be between "+("-100000" if operation=="add" else "0")+" and 100000.",true);return
	if unit=="points":
		if operation=="set":
			if amount>=PlayerExperience.cost(world.experience.level()):reply("Points must be below "+str(PlayerExperience.cost(world.experience.level()))+" for your current level.",true);return
			world.experience.total=PlayerExperience.threshold(world.experience.level())+amount
		else:world.experience.total=clampi(world.experience.total+amount,0,2000000000)
	else:
		var progress: float=world.experience.progress()
		var level: int=clampi(amount if operation=="set" else world.experience.level()+amount,0,20000)
		world.experience.total=PlayerExperience.threshold(level)+floori(PlayerExperience.cost(level)*progress)
	reply("Experience level: "+str(world.experience.level()))
func locate_structure(args: Array[String],rule: Dictionary) -> void:
	if args.size()!=2 or args[0]!="structure" or args[1] not in ["mineshaft","monster_room","fortress","stronghold"]:usage(rule);return
	if (args[1]=="fortress")!=world.is_nether():reply("Search for fortresses in the Nether and Overworld structures in the Overworld.",true);return
	if args[1]=="stronghold":
		var p: Dictionary=world.chunks.strongholds.nearest(world.mobs.cell(world.player.global_position))
		if p.blocks.is_empty():reply("No stronghold generation in this world.",true);return
		reply("Nearest stronghold: "+str(p.origin.x)+", "+str(world.chunks.world_y(p.origin)+1)+" (X, Y)");return
	var generator: RefCounted=world.chunks.nether.fortresses if world.is_nether() else world.chunks.structures
	var start: int=generator.region_at(world.mobs.cell(world.player.global_position).x)
	for distance in range(32):
		for sign_value in [1,-1] if distance>0 else [1]:
			var plan: Dictionary=generator.plan(start+distance*sign_value)
			if plan.kind==args[1] and not plan.blocks.is_empty():
				var cell: Vector2i=plan.origin;reply("Nearest "+args[1]+": "+str(cell.x)+", "+str(world.chunks.world_y(cell)+1)+" (X, Y)")
				if not world.is_nether():generator.retain(world.mobs.cell(world.player.global_position).x)
				return
	reply("No matching structure found nearby.",true)
	if not world.is_nether():generator.retain(world.mobs.cell(world.player.global_position).x)
func spawner_command(args: Array[String],rule: Dictionary) -> void:
	if args.size()!=1 or args[0] not in ["zombie","skeleton","spider","cave_spider","blaze","silverfish"]:usage(rule);return
	var cell: Vector2i=world.get_mouse_cell()
	if world.get_block(cell)!=BlockDatabase.id_for("spawner") or not world.cell_is_reachable(cell):reply("Point at a reachable spawner.",true);return
	world.structures.spawners.erase(cell);world.structures.register(cell,args[0]);reply("Spawner: "+args[0])
