class_name PlayerProfileStore
extends RefCounted

var directory: String = "user://profile"
var username: String = "Steve"
var slim: bool = false
var texture: Texture2D = preload("res://assets/skins/steve_2d.png")
var default_texture: Texture2D = preload("res://assets/skins/steve_2d.png")
var last_error: String = ""
var selected_skin_id: String = "default"
const STEVE: Texture2D = preload("res://assets/skins/steve_2d.png")

static func valid_username(value: String) -> bool:
	if value.length() < 3 or value.length() > 16:
		return false
	for character in value:
		var code: int = character.unicode_at(0)
		if not (code >= 65 and code <= 90 or code >= 97 and code <= 122 or code >= 48 and code <= 57 or code == 95):
			return false
	return true

static func valid_2d_image(image: Image) -> bool:
	return image != null and not image.is_empty() and image.get_width() >= 48 and image.get_width() <= 4096 and image.get_width() % 48 == 0 and image.get_height() * 48 == image.get_width() * 32

func load_profile(default: Texture2D = null) -> void:
	last_error = ""
	if default != null and PlayerSkinDrawing.valid_texture(default):
		default_texture = default
	selected_skin_id = "default"
	texture = default_texture
	username = "Steve"
	slim = false
	var config := ConfigFile.new()
	if config.load(directory.path_join("profile.cfg")) != OK:
		return
	var saved_name: String = str(config.get_value("profile", "username", "Steve"))
	if valid_username(saved_name): username = saved_name
	slim = bool(config.get_value("profile", "slim", false))
	var filename: String = str(config.get_value("profile", "skin", ""))
	if filename.is_empty():
		if bool(config.get_value("profile", "builtin_steve", false)): texture = STEVE
		return
	if filename != filename.get_file() or not filename.begins_with("skin_") or not filename.ends_with(".png"):
		last_error = "Saved skin path was invalid; the project skin is being used."
		return
	var image := Image.new()
	if image.load(directory.path_join(filename)) != OK or not valid_2d_image(image):
		last_error = "Saved skin could not be loaded; the project skin is being used."
		return
	texture = ImageTexture.create_from_image(image)
	selected_skin_id = filename

func save_profile(name: String, image: Image, use_slim: bool) -> bool:
	last_error = ""
	if not valid_username(name):
		last_error = "Use 3-16 letters, numbers or underscores for your username."
		return false
	if not valid_2d_image(image):
		last_error = "A 2D skin must be 48N x 32N pixels."
		return false
	var filename: String = ""
	if not _same_image(image, STEVE.get_image()):
		filename = remember_skin(image, "", use_slim)
		if filename.is_empty():
			return false
	var folder: String = ProjectSettings.globalize_path(directory)
	if DirAccess.make_dir_recursive_absolute(folder) != OK:
		last_error = "Could not create the profile folder."
		return false
	var config := ConfigFile.new()
	config.set_value("profile", "username", name)
	config.set_value("profile", "skin", filename)
	config.set_value("profile", "builtin_steve", filename.is_empty())
	config.set_value("profile", "slim", use_slim)
	var config_path: String = folder.path_join("profile.cfg")
	if config.save(config_path + ".tmp") != OK or DirAccess.rename_absolute(config_path + ".tmp", config_path) != OK:
		last_error = "Could not save the profile; the previous profile remains selected."
		return false
	selected_skin_id = filename if not filename.is_empty() else "default"
	username = name
	slim = use_slim
	texture = ImageTexture.create_from_image(image)
	return true

func apply_to(world: Node2D) -> void:
	world.player.set_meta("username", username)
	world.settings.player.skin_texture = texture
	world.player.settings.skin_texture = texture
	world.player.queue_redraw()
	world.inventory_screen.queue_redraw()


static func _same_image(a: Image, b: Image) -> bool:
	if a.get_size() != b.get_size(): return false
	var first: Image = a.duplicate() as Image
	var second: Image = b.duplicate() as Image
	first.convert(Image.FORMAT_RGBA8)
	second.convert(Image.FORMAT_RGBA8)
	return first.get_data() == second.get_data()


func remember_skin(image: Image, display_name: String, use_slim: bool) -> String:
	last_error = ""
	if not valid_2d_image(image):
		last_error = "A 2D skin must be 48N x 32N pixels."
		return ""
	var folder: String = ProjectSettings.globalize_path(directory)
	if DirAccess.make_dir_recursive_absolute(folder) != OK:
		last_error = "Could not create the skin library folder."
		return ""
	var bytes: PackedByteArray = image.save_png_to_buffer()
	var hash := HashingContext.new()
	hash.start(HashingContext.HASH_SHA256)
	hash.update(bytes)
	var filename: String = "skin_" + hash.finish().hex_encode().left(24) + ".png"
	var path: String = folder.path_join(filename)
	if not FileAccess.file_exists(path):
		var file := FileAccess.open(path + ".tmp", FileAccess.WRITE)
		if file == null:
			last_error = "Could not write the imported skin."
			return ""
		file.store_buffer(bytes)
		file.flush()
		var error: Error = file.get_error()
		file.close()
		if error != OK or DirAccess.rename_absolute(path + ".tmp", path) != OK:
			last_error = "Could not finish saving the imported skin."
			return ""
	var catalog := ConfigFile.new()
	var catalog_path: String = folder.path_join("skins.cfg")
	if FileAccess.file_exists(catalog_path) and catalog.load(catalog_path) != OK:
		last_error = "Could not read the skin library index. The PNG has been retained."
		return ""
	var label: String = display_name.strip_edges().left(64).replace("\n", " ").replace("\r", " ")
	if not catalog.has_section(filename):
		catalog.set_value(filename, "name", label if not label.is_empty() else "Imported skin " + filename.substr(5, 6))
		catalog.set_value(filename, "slim", use_slim)
	elif not label.is_empty() and str(catalog.get_value(filename, "name", "")).begins_with("Imported skin "):
		catalog.set_value(filename, "name", label)
	if catalog.save(catalog_path + ".tmp") != OK or DirAccess.rename_absolute(catalog_path + ".tmp", catalog_path) != OK:
		last_error = "Could not save the skin library index. The PNG has been retained."
		return ""
	return filename


func list_skins() -> Array[Dictionary]:
	var result: Array[Dictionary] = [{"id": "default", "name": "Steve (Default)", "slim": false, "texture": STEVE}]
	var folder := DirAccess.open(directory)
	if folder == null: return result
	var catalog := ConfigFile.new()
	catalog.load(directory.path_join("skins.cfg"))
	var filenames: PackedStringArray = folder.get_files()
	filenames.sort()
	for filename in filenames:
		if not filename.begins_with("skin_") or not filename.ends_with(".png") or folder.is_link(filename):
			continue
		var file := FileAccess.open(directory.path_join(filename), FileAccess.READ)
		if file == null: continue
		var enough_data: bool = file.get_length() >= 24
		file.close()
		if not enough_data: continue
		var image := Image.new()
		if image.load(directory.path_join(filename)) != OK or not valid_2d_image(image): continue
		# Older profile versions retained PNGs without an index; recover those too.
		result.append({"id": filename,
			"name": str(catalog.get_value(filename, "name", "Imported skin " + filename.substr(5, 6))),
			"slim": bool(catalog.get_value(filename, "slim", slim if filename == selected_skin_id else false)),
			"texture": ImageTexture.create_from_image(image)})
	return result

func _managed_skin(filename: String) -> bool:
	if filename!=filename.get_file() or filename.length()<10 or filename.length()>128 or not filename.begins_with("skin_") or not filename.ends_with(".png"):return false
	for character in filename.get_basename():
		if character not in "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-":return false
	var folder:=DirAccess.open(directory)
	return folder!=null and not folder.is_link(filename) and FileAccess.file_exists(directory.path_join(filename))

func rename_skin(filename: String,display_name: String) -> bool:
	last_error=""
	if not _managed_skin(filename):last_error="Choose an imported skin. Default Steve cannot be renamed.";return false
	var label: String=display_name.strip_edges()
	if label.is_empty() or label.length()>64 or "\n" in label or "\r" in label or "\t" in label:last_error="Use a skin name of 1–64 characters on one line.";return false
	var catalog:=ConfigFile.new();var path: String=directory.path_join("skins.cfg")
	if FileAccess.file_exists(path) and catalog.load(path)!=OK:last_error="Could not read the skin library index.";return false
	catalog.set_value(filename,"name",label)
	if catalog.save(path+".tmp")!=OK or DirAccess.rename_absolute(ProjectSettings.globalize_path(path+".tmp"),ProjectSettings.globalize_path(path))!=OK:last_error="Could not save the skin name.";return false
	return true

func delete_skin(filename: String) -> bool:
	last_error=""
	if not _managed_skin(filename):last_error="Choose an imported skin. Default Steve cannot be deleted.";return false
	var catalog:=ConfigFile.new();var path: String=directory.path_join("skins.cfg")
	if FileAccess.file_exists(path) and catalog.load(path)!=OK:last_error="Could not read the skin library index.";return false
	# Select a valid fallback before removing the active skin's library copy.
	if selected_skin_id==filename and not save_profile(username,STEVE.get_image(),false):return false
	var managed_path: String=ProjectSettings.globalize_path(directory.path_join(filename))
	if DirAccess.remove_absolute(managed_path)!=OK:last_error="Could not delete the skin library copy.";return false
	if catalog.has_section(filename):catalog.erase_section(filename)
	if catalog.save(path+".tmp")!=OK or DirAccess.rename_absolute(ProjectSettings.globalize_path(path+".tmp"),ProjectSettings.globalize_path(path))!=OK:last_error="Skin removed; its unused index entry could not be cleaned up."
	return true
