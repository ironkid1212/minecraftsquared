class_name WorldSaveStore
extends RefCounted

const VERSION: int = 1
var save_root: String = UserFiles.SAVES
var last_error: String = ""
var _ids: Dictionary = {}

func _content_ids() -> void:
	_ids = {"air": 0}
	for id in BlockDatabase.BLOCKS:
		_ids[str(BlockDatabase.BLOCKS[id]["key"])] = int(id)

func seed_from_text(text: String) -> int:
	var clean: String = text.strip_edges()
	var number: int
	if clean.is_empty():
		var rng := RandomNumberGenerator.new()
		rng.randomize()
		number = rng.randi()
	elif clean.is_valid_int():
		number = clean.to_int()
	else:
		# Stable UTF-8 FNV-1a, independent of the engine's String.hash version.
		number = 2166136261
		for byte in clean.to_utf8_buffer():
			number = ((number ^ byte) * 16777619) & 0xffffffff
	number = number & 0xffffffff
	return number - 4294967296 if number >= 2147483648 else number

func new_document(name: String, seed_text: String, settings: Resource) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var id: String = "%x_%x" % [int(Time.get_unix_time_from_system()), rng.randi()]
	var title: String = name.strip_edges().left(64)
	return {"version": VERSION, "id": id, "name": title if not title.is_empty() else "New World",
		"seed": seed_from_text(seed_text), "seed_text": seed_text.left(128),
		"created": int(Time.get_unix_time_from_system()), "last_played": 0,
		"generation": snapshot_generation(settings), "state": {}}

func snapshot_generation(settings: Resource) -> Dictionary:
	var result: Dictionary = {}
	for group in ["terrain", "cave", "tree", "fluid"]:
		var resource: Resource = settings.get(group)
		var fields: Dictionary = {}
		for property in resource.get_property_list():
			if not (int(property["usage"]) & PROPERTY_USAGE_SCRIPT_VARIABLE) or not (int(property["usage"]) & PROPERTY_USAGE_STORAGE):
				continue
			var value: Variant = resource.get(property["name"])
			if value is Vector2i or value is Vector2:
				fields[property["name"]] = [value.x, value.y]
			elif value is int or value is float or value is bool or value is String:
				fields[property["name"]] = value
		result[group] = fields
	return result

func settings_for(document: Dictionary, base: Resource) -> Resource:
	var settings: Resource = base.duplicate(true)
	# External .tres references can remain shared after duplicate(true). Give
	# each session its own system resources before applying generation values.
	for group in ["terrain", "cave", "tree", "interface", "lighting", "player", "drop", "world_updates", "survival", "day_night", "fluid", "farming", "weather"]:
		var original: Resource = base.get(group)
		settings.set(group, original.duplicate(true))
	var generation: Dictionary = document.get("generation", {})
	for group in ["terrain", "cave", "tree", "fluid"]:
		var resource: Resource = settings.get(group)
		var fields: Dictionary = generation.get(group, {})
		# Keep older worlds' original material generation unchanged.
		if group == "terrain":
			if not fields.has("lush_revision"):resource.set("lush_revision",1)
			if not fields.has("stronghold_revision"):resource.set("stronghold_revision",1)
			if not fields.has("strongholds_enabled"):resource.set("strongholds_enabled",false)
			if not fields.has("lush_caves_enabled"):resource.set("lush_caves_enabled",false)
			if not fields.has("structures_revision"): resource.set("structures_revision",1)
			if not fields.has("structures_enabled"): resource.set("structures_enabled",false)
			if not fields.has("biome_revision"): resource.set("biome_revision",1)
			if not fields.has("generation_revision"): resource.set("generation_revision", 1)
			if not fields.has("coherent_biomes"): resource.set("coherent_biomes", false)
			if not fields.has("biome_size"): resource.set("biome_size", 1.0)
			if not fields.has("terrain_region_size"): resource.set("terrain_region_size", 1.0)
			if not fields.has("minimum_dirt_depth"): resource.set("minimum_dirt_depth", 0)
		if group == "tree" and not fields.has("fancy_revision"): resource.set("fancy_revision",1)
		if group == "fluid" and not fields.has("shore_revision"): resource.set("shore_revision",1)
		if group == "fluid" and not fields.has("generation_enabled"): resource.set("generation_enabled",false)
		if group == "cave" and not fields.has("layered_caverns"): resource.set("layered_caverns", false)
		if group == "cave" and not fields.has("noise_caves"): resource.set("noise_caves", false)
		if group == "terrain" and not fields.has("modern_generation"): resource.set("modern_generation", false)
		if group == "terrain" and not fields.has("biome_generation"): resource.set("biome_generation", false)
		if group == "terrain" and not fields.has("gravel_enabled"): resource.set("gravel_enabled", false)
		for property in resource.get_property_list():
			var name: String = property["name"]
			if not fields.has(name) or not (int(property["usage"]) & PROPERTY_USAGE_SCRIPT_VARIABLE):
				continue
			var original: Variant = resource.get(name)
			var value: Variant = fields[name]
			if original is Vector2i and _valid_pair(value):
				resource.set(name, Vector2i(int(value[0]), int(value[1])))
			elif original is Vector2 and _valid_pair(value):
				resource.set(name, Vector2(float(value[0]), float(value[1])))
			elif original is bool and value is bool:
				resource.set(name, value)
			elif original is int and (value is int or value is float):
				resource.set(name, int(value))
			elif original is float and (value is int or value is float):
				resource.set(name, float(value))
			elif original is String and value is String:
				resource.set(name, value)
	settings.get("terrain").set("seed", int(document["seed"]))
	return settings

func _valid_id(id: String) -> bool:
	if id.is_empty() or id.length() > 64:
		return false
	for character in id:
		if not character in "0123456789abcdef_":
			return false
	return true

func _path(id: String) -> String:
	return save_root.path_join(id).path_join("world.json")

func list_worlds() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var directory: DirAccess = DirAccess.open(save_root)
	if directory == null:
		return result
	for id in directory.get_directories():
		if not _valid_id(id) or not FileAccess.file_exists(_path(id)):
			continue
		var document: Dictionary = load_world(id)
		if document.is_empty():
			result.append({"id": id, "name": "Unreadable world", "last_played": 0, "seed": 0, "broken": true})
		else:
			result.append({"id": id, "name": document["name"], "last_played": document.get("last_played", 0), "seed": int(document["seed"]), "broken": false})
	result.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a["last_played"]) > int(b["last_played"]))
	last_error = ""
	return result

func load_world(id: String) -> Dictionary:
	last_error = ""
	if not _valid_id(id):
		last_error = "Invalid world identifier."
		return {}
	var file: FileAccess = FileAccess.open(_path(id), FileAccess.READ)
	if file == null:
		last_error = "Could not open this world."
		return {}
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if not parsed is Dictionary or int(parsed.get("version", 0)) != VERSION or parsed.get("id", "") != id or not parsed.get("name") is String or not parsed.has("seed") or not parsed.get("state") is Dictionary or not parsed.get("generation") is Dictionary:
		last_error = "This world save is damaged or uses an unsupported format."
		return {}
	if not _validate_state(parsed["state"]):
		return {}
	return parsed

func delete_world(id: String) -> bool:
	last_error = ""
	if not _valid_id(id):
		last_error = "Invalid world identifier."
		return false
	var root_path: String = ProjectSettings.globalize_path(save_root).simplify_path().trim_suffix("/")
	var target: String = root_path.path_join(id).simplify_path()
	if target.get_base_dir() != root_path:
		last_error = "World folder is outside the save directory."
		return false
	var root_directory: DirAccess = DirAccess.open(root_path)
	if root_directory == null or root_directory.is_link(id):
		last_error = "Cannot delete a missing or linked world directory."
		return false
	var directory: DirAccess = DirAccess.open(target)
	if directory == null:
		last_error = "Could not open this world's folder."
		return false
	# Delete this save format's known files only. Never recursively follow a
	# user-created subdirectory or remove unrelated files from the save root.
	var known: PackedStringArray = ["world.json", "world.json.bak", "world.json.tmp"]
	if not directory.get_directories().is_empty():
		last_error = "World folder contains extra subfolders; it was left untouched."
		return false
	for filename in directory.get_files():
		if not filename in known:
			last_error = "World folder contains extra files; it was left untouched."
			return false
	for filename in ["world.json.tmp", "world.json.bak", "world.json"]:
		var path: String = target.path_join(filename)
		if FileAccess.file_exists(path) and DirAccess.remove_absolute(path) != OK:
			last_error = "Could not delete a world-save file."
			return false
	if DirAccess.remove_absolute(target) != OK:
		last_error = "Save files were removed, but the empty folder could not be deleted."
		return false
	return true

func _valid_pair(value: Variant) -> bool:
	return value is Array and value.size() == 2 and (value[0] is int or value[0] is float) and (value[1] is int or value[1] is float) and is_finite(float(value[0])) and is_finite(float(value[1]))

func _valid_stack(stack: Variant) -> bool:
	if not stack is Dictionary or not stack.get("item") is String or not _ids.has(stack["item"]):
		last_error = "World contains a missing or invalid item: " + str(stack.get("item", "unknown") if stack is Dictionary else "unknown")
		return false
	if not ItemTags.valid(stack.get("tags",{})):
		last_error="World contains invalid item NBT."
		return false
	var id: int = _ids[stack["item"]]
	if not (stack.get("count") is int or stack.get("count") is float) or not (stack.get("durability", 0) is int or stack.get("durability", 0) is float):
		last_error = "World contains invalid stack counts or tool durability."
		return false
	var amount: int = int(stack.get("count", 0))
	if not ContentCatalog._number(stack.get("count"),0,999,true) or not ContentCatalog._number(stack.get("durability",0),0,ToolDatabase.max_durability(id),true):
		last_error="World contains invalid stack count or durability.";return false
	var maximum: int = int(BlockDatabase.BLOCKS.get(id, {}).get("max_stack", 64))
	if amount < 0 or amount > maximum or (amount > 0 and id == 0):
		last_error = "World contains an invalid inventory stack."
		return false
	return true

func _validate_state(state: Dictionary, validate_dimensions: bool=true) -> bool:
	_content_ids()
	if not EndCitySystem.valid(state.get("end_cities",{})):last_error="Invalid End city state.";return false
	if not EndGateways.valid(state.get("end_gateways",{})):last_error="Invalid End gateway state.";return false
	if not EndFightState.valid(state.get("end_fight",{})):last_error="Invalid End fight state.";return false
	if not state.get("end_portals",[]) is Array or state.get("end_portals",[]).size()>1024:return false
	for cell in state.get("end_portals",[]):
		if not ContentCatalog._vector(cell,2,-10000000,10000000,true):return false
	if not BrewingSystem.valid(state.get("brewing",[]),self) or not PlayerPearls.valid(state.get("pearls",[])) or not EndProgression.valid(state.get("eyes",[])):last_error="Invalid brewing or pearl state.";return false
	if not NetherPortals.valid(state.get("portals",{})) or validate_dimensions and not WorldDimensions.valid(state.get("dimensions",{}),self,state):
		last_error="Invalid dimension or portal data.";return false
	_content_ids()
	if state.is_empty():
		return true
	if state.get("pose","standing") not in ["standing","crouching","swimming"]:
		last_error="World contains an invalid player pose."
		return false
	var weather: Variant=state.get("weather",{})
	if weather is Dictionary and not ContentCatalog._number(weather.get("storm_strength",0),0,1):
		last_error="World contains invalid storm fade data."
		return false
	if not weather is Dictionary or not weather.is_empty() and (weather.get("state") not in ["clear","rain","snow","thunder"] or not ContentCatalog._number(weather.get("remaining"),0,1000000) or not ContentCatalog._number(weather.get("strength"),0,1) or not weather.get("cycling") is bool or not weather.get("rng","") is String or not str(weather.get("rng","")).is_valid_int()):
		last_error="World contains invalid weather data."
		return false
	var clock: Variant = state.get("clock",{})
	if not clock is Dictionary or not clock.is_empty() and (not ContentCatalog._number(clock.get("ticks"),0,1000000000000) or not clock.get("running") is bool):
		last_error = "World contains invalid day/night clock data."
		return false
	for field in ["waterlogged","plant_ages","farm_moisture"]:
		var records: Variant=state.get(field,[])
		if not records is Array:
			last_error="World contains invalid "+field+" records."
			return false
		var seen: Dictionary={}
		for record in records:
			if not record is Array or record.size()!=(2 if field=="waterlogged" else 3):
				last_error="World contains malformed "+field+" records."
				return false
			if not ContentCatalog._number(record[0],-10000000,10000000,true) or not ContentCatalog._number(record[1],-512,4096,true) or field in ["plant_ages","farm_moisture"] and not ContentCatalog._number(record[2],0,7 if field=="farm_moisture" else 255,true):
				last_error="World contains invalid "+field+" coordinates or age."
				return false
			var point:=Vector2i(int(record[0]),int(record[1]))
			if seen.has(point):
				last_error="World contains duplicate "+field+" records."
				return false
			seen[point]=true
	var flow: Variant = state.get("fluid_levels",[])
	if not flow is Array:
		last_error = "World contains invalid fluid data."
		return false
	var seen_flows: Dictionary = {}
	for entry in flow:
		if not entry is Array or entry.size()!=3 or not ContentCatalog._number(entry[0],-10000000,10000000,true) or not ContentCatalog._number(entry[1],-512,4096,true) or not ContentCatalog._number(entry[2],1,8,true):
			last_error = "World contains invalid fluid coordinates or levels."
			return false
		var point := Vector2i(int(entry[0]),int(entry[1]))
		if seen_flows.has(point):
			last_error = "World contains duplicate fluid records."
			return false
		seen_flows[point]=true
	if not AdventureSave.valid(state):last_error="Invalid food, XP or structure state.";return false
	var survival: Variant = state.get("survival", {})
	if not survival is Dictionary:
		last_error = "World contains invalid survival state."
		return false
	if not EntityEffects.valid(survival.get("effects",{})) or not EntityEffects.valid_amplifiers(survival.get("effect_amplifiers",{})):last_error="Invalid status effects.";return false
	if not survival.is_empty():
		if not ContentCatalog._number(survival.get("health"),0,40) or not survival.get("dead") is bool or not survival.get("has_bed") is bool or not survival.get("tracking_fall") is bool or not survival.get("reason") is String or str(survival["reason"]).length() > 512 or not _valid_pair(survival.get("world_spawn")) or not _valid_pair(survival.get("bed")) or not ContentCatalog._number(survival.get("fall_peak_y"),-1000000000,1000000000):
			last_error = "World contains invalid health or respawn data."
			return false
		if bool(survival["dead"]) != (float(survival["health"]) <= 0) or float(survival["bed"][0]) != int(survival["bed"][0]) or float(survival["bed"][1]) != int(survival["bed"][1]):
			last_error = "World contains inconsistent death or bed coordinates."
			return false
	if not state.get("creative_flying",false) is bool or not state.get("creative_before_spectator",false) is bool:last_error="Invalid creative state.";return false
	if state.get("game_mode","survival") not in ["survival","creative","spectator"]:last_error="Invalid game mode.";return false
	if not state.get("spectator", false) is bool or not ContentCatalog._number(state.get("spectator_speed", 0.4), 0.05, 1.0):
		last_error = "World contains invalid spectator state."
		return false
	if not _valid_pair(state.get("position")) or not _valid_pair(state.get("spawn")) or not state.get("inventory") is Array or state["inventory"].size() not in [36,BlockInventory.SLOT_COUNT] or not state.get("edits") is Array or not state.get("drops") is Array or not state.get("extra_stacks", []) is Array:
		last_error = "World contains invalid player or block data."
		return false
	if state["inventory"].size()==BlockInventory.SLOT_COUNT:
		for slot in range(BlockInventory.HEAD,BlockInventory.FEET+1):
			var stack: Variant=state["inventory"][slot]
			if not _valid_stack(stack):return false
			if int(stack["count"])>0 and BlockDatabase.BLOCKS[_ids[stack["item"]]].get("armor",{}).get("slot","")!=["head","chest","legs","feet"][slot-BlockInventory.HEAD]:
				last_error="World contains an item in the wrong armor slot.";return false
	for stack in state["inventory"] + state.get("extra_stacks", []):
		if not _valid_stack(stack):
			return false
	for edit in state["edits"]:
		if not edit is Array or edit.size() != 3 or not (edit[0] is int or edit[0] is float) or not (edit[1] is int or edit[1] is float) or not _ids.has(str(edit[2])):
			last_error = "World contains an invalid block edit or missing block type."
			return false
	if not state.get("wall_edits",[]) is Array or state.get("wall_edits",[]).size()>1000000:last_error="Invalid background edits.";return false
	for edit in state.get("wall_edits",[]):
		if not edit is Array or edit.size()!=3 or not ContentCatalog._number(edit[0],-10000000,10000000,true) or not ContentCatalog._number(edit[1],-512,4096,true) or not _ids.has(str(edit[2])):last_error="Invalid background block edit.";return false
	if not state.get("persistent_leaves", []) is Array:
		last_error = "World contains invalid placed-leaf data."
		return false
	for cell in state.get("persistent_leaves", []):
		if not _valid_pair(cell) or float(cell[0]) != int(cell[0]) or float(cell[1]) != int(cell[1]):
			last_error = "World contains invalid placed-leaf coordinates."
			return false
	if not MobCatalog.valid_state(state.get("mobs",{})):last_error="Invalid saved mob data.";return false
	var storage: Variant=state.get("storage",[])
	if not storage is Array or storage.size()>100000:last_error="Invalid storage records.";return false
	var containers: Dictionary={}
	for container in storage:
		if not container is Dictionary or not _valid_pair(container.get("cell")) or not container.get("slots") is Array or container["slots"].size()!=27 or not NBT.valid_tags(container.get("tags",{})):
			last_error="Invalid container data.";return false
		var cell: Array=container["cell"]
		if not ContentCatalog._number(cell[0],-10000000,10000000,true) or not ContentCatalog._number(cell[1],-512,4096,true) or containers.has(str(cell)):
			last_error="Invalid or duplicate container position.";return false
		containers[str(cell)]=true
		var partner: Variant=container.get("partner",[])
		if not partner is Array or partner.size() not in [0,2] or partner.size()==2 and (not _valid_pair(partner) or partner[1]!=cell[1] or absf(float(partner[0])-float(cell[0]))!=1):
			last_error="Invalid double chest partner.";return false
		for slot in container["slots"]:
			if not _valid_stack(slot):return false
	if not state.get("furnaces", []) is Array:
		last_error = "World contains invalid furnace data."
		return false
	for furnace in state.get("furnaces", []):
		if not furnace is Dictionary or not _valid_pair(furnace.get("cell")) or not furnace.get("slots") is Array or furnace["slots"].size() != 3:
			last_error = "World contains an invalid furnace."
			return false
		for slot in furnace["slots"]:
			if not _valid_stack(slot): return false
		if not ContentCatalog._number(furnace.get("recipe_durability",0),0,100000,true) or not ItemTags.valid(furnace.get("recipe_tags",{})) or not ContentCatalog._number(furnace.get("experience",0),0,2000000000) or not furnace.get("recipe_key","") is String or str(furnace.get("recipe_key","")).length()>128:
			last_error="World contains invalid furnace XP/recipe data.";return false
		for field in ["burn", "burn_total", "cook"]:
			if not ContentCatalog._number(furnace.get(field), 0, 100000):
				last_error = "World contains an invalid furnace timer."
				return false
	if not state.get("torch_mounts", []) is Array:
		last_error = "World contains invalid torch mount data."
		return false
	for mount in state.get("torch_mounts", []):
		if not mount is Array or mount.size() != 4 or not _valid_pair([mount[0], mount[1]]) or not _valid_pair([mount[2], mount[3]]) or float(mount[0]) != int(mount[0]) or float(mount[1]) != int(mount[1]) or float(mount[2]) != int(mount[2]) or float(mount[3]) != int(mount[3]) or Vector2i(int(mount[2]), int(mount[3])) not in [Vector2i.ZERO, Vector2i.DOWN, Vector2i.LEFT, Vector2i.RIGHT]:
			last_error = "World contains an invalid torch support direction."
			return false
	if not state.get("falling_blocks", []) is Array:
		last_error = "World contains invalid falling-block data."
		return false
	for body in state.get("falling_blocks", []):
		if not body is Dictionary or not _ids.has(str(body.get("item", ""))) or not _valid_pair(body.get("position")) or not ContentCatalog._number(body.get("speed"), 0, 8192):
			last_error = "World contains an invalid falling block."
			return false
		if BlockDatabase.UPDATE_RULES.get("blocks", {}).get(str(body["item"]), {}).get("behavior") != "falling":
			last_error = "A saved falling-block type no longer has gravity."
			return false
	for drop in state["drops"]:
		if not _valid_stack(drop) or not _valid_pair(drop.get("position")) or not _valid_pair(drop.get("velocity")):
			last_error = "World contains invalid dropped-item data."
			return false
	return true

func _stack(id: int, count: int, durability: int, metadata: Dictionary = {}) -> Dictionary:
	return {"item": str(BlockDatabase.BLOCKS[id]["key"]) if id != 0 else "air", "count": count, "durability": durability,"tags":metadata.duplicate(true)}

func save_world(document: Dictionary, world: Node2D) -> bool:
	last_error = ""
	if not _valid_id(str(document.get("id", ""))):
		last_error = "Invalid world identifier."
		return false
	var next: Dictionary=document.duplicate(true)
	next["last_played"]=int(Time.get_unix_time_from_system())
	next["state"]=capture_state(world)
	next.state.dimensions=world.dimensions.snapshot()
	if not _validate_state(next["state"]):
		return false
	var path: String = _path(str(next["id"]))
	var directory_error: Error = DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(path.get_base_dir()))
	if directory_error != OK:
		last_error = "Could not create the world save folder."
		return false
	var temporary: String = path + ".tmp"
	var file: FileAccess = FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		last_error = "Could not write this world. Check the save folder's permissions."
		return false
	file.store_string(JSON.stringify(next))
	file.flush()
	var write_error: Error = file.get_error()
	file.close()
	if write_error != OK:
		last_error = "Could not finish writing this world."
		return false
	if FileAccess.file_exists(path):
		if DirAccess.copy_absolute(ProjectSettings.globalize_path(path), ProjectSettings.globalize_path(path + ".bak")) != OK:
			last_error = "Could not preserve the previous save; the current world has not been replaced."
			return false
	if DirAccess.rename_absolute(ProjectSettings.globalize_path(temporary), ProjectSettings.globalize_path(path)) != OK:
		last_error = "Could not commit the new save. Your previous world is still available."
		return false
	document["last_played"] = next["last_played"]
	document["state"] = next["state"]
	return true

func restore_world(document: Dictionary, world: Node2D) -> bool:
	var state: Dictionary = document.get("state", {})
	if not _validate_state(state):
		return false
	if not world.dimensions.swapping:world.dimensions.restore_saved(state.get("dimensions",{}))
	world.mobs.restore({})
	world.clock.restore(state.get("clock",{}))
	if state.is_empty():
		# Spawn immediately above a solid surface, away from cave entrances.
		var cell: Vector2i = world.chunks.find_spawn_surface(32)
		world.player.global_position = world.ground.to_global(world.ground.map_to_local(cell)) - Vector2(0, 23)
		world.player.spawn_position = world.player.global_position
		world.survival.world_spawn = world.player.spawn_position
		world.survival.reset_fall()
		world.chunks.update_around(world.player.global_position)
		return true
	for edit in state.get("wall_edits",[]):world.chunks.set_wall_block(Vector2i(int(edit[0]),int(edit[1])),int(_ids[str(edit[2])]))
	for edit in state["edits"]:
		var cell := Vector2i(int(edit[0]), int(edit[1]))
		var id: int = _ids[str(edit[2])]
		if world.chunks.is_cell_loaded(cell):
			world.chunks.set_block(cell, id)
		else:
			world.chunks.edits[cell] = id
			# A retained unloaded chunk must not hide a restored host/plant edit.
			world.chunks._block_cache.erase(world.chunks.cell_to_chunk(cell))
	world.chunks.torch_mounts.clear()
	for mount in state.get("torch_mounts", []):
		var cell := Vector2i(int(mount[0]), int(mount[1]))
		if TorchMounting.is_attached(world.chunks.get_block(cell)):
			world.chunks.torch_mounts[cell] = Vector2i(int(mount[2]), int(mount[3]))
	var placed_leaves: Array = state.get("persistent_leaves", []).duplicate(true)
	if not state.has("persistent_leaves"):
		# Before simulation existed, every explicit leaf edit was player-placed.
		for edit in state["edits"]:
			if world.world_updates.rule_for(_ids[str(edit[2])]).get("behavior") == "leaves":
				placed_leaves.append([int(edit[0]), int(edit[1])])
	world.world_updates.restore_persistent_leaves(placed_leaves)
	world.player.global_position = Vector2(float(state["position"][0]), float(state["position"][1]))
	world.player.spawn_position = Vector2(float(state["spawn"][0]), float(state["spawn"][1]))
	world.set_game_mode(str(state.get("game_mode","spectator" if state.get("spectator",false) else "survival")), true)
	if world.player.spectator and state.get("creative_before_spectator",false):world.player.creative=true;world.inventory.creative_mode=true
	world.player.creative_flying=world.player.creative and not world.player.spectator and bool(state.get("creative_flying",false))
	world.player.spectator_speed = clampf(float(state.get("spectator_speed", 0.4)), 0.05, 1.0)
	world.player.locomotion.restore_pose(str(state.get("pose","standing")))
	world.player.velocity = Vector2.ZERO
	world.player.facing = -1 if int(state.get("facing", 1)) < 0 else 1
	world.player.presentation.facing = world.player.facing
	world.chunks.update_around(world.player.global_position)
	if world.upgrade_is_open():world.upgrade_screen.set_open(false)
	var inventory: BlockInventory = world.inventory
	for index in range(BlockInventory.SLOT_COUNT):inventory.clear_slot(index)
	for index in range(state["inventory"].size()):
		var stack: Dictionary = state["inventory"][index]
		var id: int = _ids[stack["item"]]
		inventory.tags[index]=stack.get("tags",{}).duplicate(true)
		inventory.ids[index] = id
		inventory.counts[index] = int(stack["count"])
		inventory.durability[index] = ToolDatabase.initial_durability(id, int(stack.get("durability", 0))) if id != 0 else 0
	world.dropped_items.drops.clear()
	for record in state["drops"]:
		world.dropped_items.drops.append({"id": _ids[record["item"]], "count": int(record["count"]), "durability": int(record.get("durability", 0)),
			"position": Vector2(record["position"][0], record["position"][1]), "velocity": Vector2(record["velocity"][0], record["velocity"][1]),
			"age": float(record.get("age", 0)), "resting": bool(record.get("resting", false)),"tags":record.get("tags",{}).duplicate(true),"pickup_delay":float(record.get("pickup_delay",world.settings.drop.pickup_delay))})
	world.fluids.restore(state.get("fluid_levels",[]))
	world.fluids.restore_waterlogged(state.get("waterlogged",[]))
	world.world_updates.restore_plant_ages(state.get("plant_ages",[]))
	world.farming.restore(state.get("farm_moisture",[]))
	world.weather.restore(state.get("weather",{}))
	world.world_updates.falling.restore(state.get("falling_blocks", []))
	world.furnaces.restore(state.get("furnaces", []))
	world.brewing.restore(state.get("brewing",[]));world.pearls.restore(state.get("pearls",[]));world.end_progression.restore(state.get("eyes",[]),state.get("end_portals",[]))
	world.storage.restore(state.get("storage",[]))
	world.structures.restore(state.get("structures",{}))
	world.food.restore(state.get("food",{}))
	world.experience.restore(state.get("experience",{}))
	world.ranged.cancel()
	world.mobs.restore(state.get("mobs",{}))
	world.mobs.projectiles.restore_player(state.get("player_arrows",[]))
	world.portals.restore(state.get("portals",{}))
	world.end_fight.restore(state.get("end_fight",{}));world.gateways.restore(state.get("end_gateways",{}));world.end_city_system.restore(state.get("end_cities",{}))
	world.survival.restore_state(state.get("survival", {}))
	if not state.has("survival"): world.survival.grant_upgrade_supplies()
	# Autosaves can happen while crafting or carrying a stack. Return these items
	# on load; any inventory overflow becomes a real drop, preserving tool wear.
	for stack in state.get("extra_stacks", []):
		var id: int = _ids[stack["item"]]
		var uses: int = int(stack.get("durability", 0))
		var overflow: int = inventory.add_item(id, int(stack["count"]), 0, 36, uses,stack.get("tags",{}))
		if overflow > 0:
			world.dropped_items.spawn_item(id, overflow, world.player.global_position, Vector2.ZERO, uses,stack.get("tags",{}))
	inventory.changed.emit()
	world.hotbar.select_slot(clampi(int(state.get("selected_slot", 0)), 0, 8))
	world.dropped_items.queue_redraw()
	world.lighting.invalidate()
	if world.effects!=null:world.effects.clear()
	return true

func capture_state(world: Node2D) -> Dictionary:
	if world.upgrade_is_open():world.upgrade_screen.set_open(false)
	var inventory: BlockInventory = world.inventory
	var slots: Array = []
	for index in range(BlockInventory.SLOT_COUNT):
		slots.append(_stack(inventory.ids[index], inventory.counts[index], inventory.durability[index],inventory.tags[index]))
	var extras: Array = []
	if inventory.held_count > 0:
		extras.append(_stack(inventory.held_id, inventory.held_count, inventory.held_durability,inventory.held_tags))
	var craft: CraftingGrid = world.inventory_screen.crafting
	for index in range(craft.ids.size()):
		if craft.counts[index] > 0:
			extras.append(_stack(craft.ids[index], craft.counts[index], craft.durability[index],craft.tags[index]))
	var edits: Array = []
	for cell in world.chunks.edits:
		var id: int = world.chunks.edits[cell]
		edits.append([cell.x, cell.y, str(BlockDatabase.BLOCKS[id]["key"]) if id != 0 else "air"])
	var walls: Array=[]
	for cell in world.chunks.wall_edits:
		var id: int=int(world.chunks.wall_edits[cell]);walls.append([cell.x,cell.y,str(BlockDatabase.BLOCKS[id].key) if id!=0 else "air"])
	var drops: Array = []
	for item in world.dropped_items.drops:
		var drop: Dictionary = _stack(item["id"], item["count"], item["durability"],item.get("tags",{}))
		drop.merge({"position": [item["position"].x, item["position"].y], "velocity": [item["velocity"].x, item["velocity"].y], "age": item["age"], "resting": item["resting"],"pickup_delay":item.get("pickup_delay",world.settings.drop.pickup_delay)})
		drops.append(drop)
	var mounts: Array = []
	for cell in world.chunks.torch_mounts:
		if not TorchMounting.is_attached(world.chunks.get_block(cell)): continue
		var side: Vector2i = world.chunks.torch_mounts[cell]
		if side != TorchMounting.INVALID: mounts.append([cell.x, cell.y, side.x, side.y])
	var p: Vector2 = world.player.global_position
	var spawn: Vector2 = world.player.spawn_position
	var state: Dictionary = {"spectator": world.player.spectator, "game_mode":world.game_mode(), "creative_flying":world.player.creative_flying, "creative_before_spectator":world.player.creative and world.player.spectator, "spectator_speed": world.player.spectator_speed, "position": [p.x, p.y], "spawn": [spawn.x, spawn.y], "facing": world.player.facing,
		"selected_slot": world.hotbar.selected_slot, "inventory": slots, "extra_stacks": extras, "edits": edits, "wall_edits":walls, "drops": drops, "persistent_leaves": world.world_updates.save_persistent_leaves(), "falling_blocks": world.world_updates.falling.snapshot(), "torch_mounts": mounts, "furnaces": world.furnaces.snapshot()}
	state["food"]=world.food.snapshot()
	state["experience"]=world.experience.snapshot()
	state["player_arrows"]=world.mobs.projectiles.snapshot_player()
	state["structures"]=world.structures.snapshot()
	state["storage"]=world.storage.snapshot()
	state["mobs"]=world.mobs.snapshot()
	state["pose"] = world.player.locomotion.pose
	state["survival"] = world.survival.snapshot()
	state["clock"] = world.clock.snapshot()
	state["weather"] = world.weather.snapshot()
	state["farm_moisture"] = world.farming.snapshot()
	state["fluid_levels"] = world.fluids.snapshot()
	state["waterlogged"] = world.fluids.snapshot_waterlogged()
	state["plant_ages"] = world.world_updates.save_plant_ages()
	state["portals"]=world.portals.snapshot()
	state["brewing"]=world.brewing.snapshot();state["pearls"]=world.pearls.snapshot();state["eyes"]=world.end_progression.snapshot();state["end_portals"]=world.end_progression.portal_snapshot();state["end_fight"]=world.end_fight.snapshot();state["end_gateways"]=world.gateways.snapshot();state["end_cities"]=world.end_city_system.snapshot()
	return state
