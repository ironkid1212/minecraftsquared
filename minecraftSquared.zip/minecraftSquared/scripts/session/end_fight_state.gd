class_name EndFightState
extends RefCounted
const SCALARS: Array[String]=["initialized","health","defeated","previously_killed","egg_awarded","phase","phase_time","facing","pitch","wing_phase","head_pitch","orbit","phase_limit","perch_damage","breath_cycles","healing","heal_clock","death_time","xp_paid","restored_pillars","next_crystal"]
static func snapshot(f: EndFight) -> Dictionary:
	if not f.initialized and f.placed.is_empty():return {}
	var result: Dictionary={"version":1,"rng":str(f.rng.state),"crystals":f.crystals.duplicate(),"placed":[],"projectiles":[],"clouds":[]}
	for key in SCALARS:result[key]=f.get(key)
	for key in ["position_world","velocity","target_point"]:
		var v: Vector2=f.get(key);result[key]=[v.x,v.y]
	for c in f.placed:result.placed.append({"id":c.id,"cell":[c.cell.x,c.cell.y]})
	for ball in f.projectiles:result.projectiles.append({"position":[ball.position.x,ball.position.y],"velocity":[ball.velocity.x,ball.velocity.y],"life":ball.life})
	for cloud in f.clouds:result.clouds.append({"position":[cloud.position.x,cloud.position.y],"radius":cloud.radius,"age":cloud.age,"life":cloud.life})
	return result
static func restore(f: EndFight,data: Dictionary) -> void:
	f.clear();f.rng.seed=f.world.world_seed^72741
	if data.is_empty():return
	for key in SCALARS:
		if data.has(key):f.set(key,data[key])
	for key in ["position_world","velocity","target_point"]:
		var v: Array=data.get(key,[0,0]);f.set(key,Vector2(v[0],v[1]))
	f.previous_position=f.position_world;f.crystals.assign(data.crystals);f.rng.state=int(data.rng)
	for c in data.placed:f.placed.append({"id":int(c.id),"cell":Vector2i(c.cell[0],c.cell[1])})
	for ball in data.projectiles:f.projectiles.append({"position":Vector2(ball.position[0],ball.position[1]),"velocity":Vector2(ball.velocity[0],ball.velocity[1]),"life":float(ball.life)})
	for cloud in data.clouds:f.clouds.append({"position":Vector2(cloud.position[0],cloud.position[1]),"radius":float(cloud.radius),"age":float(cloud.age),"life":float(cloud.life)})
	if f.world.is_end() and f.initialized:f._set_exit(f.defeated and f.phase!="respawning")
	f.update_pose();f.renderer.queue_redraw()
static func valid(data: Variant) -> bool:
	if not data is Dictionary:return false
	if data.is_empty():return true
	if data.get("version")!=1 or data.get("phase") not in EndFight.PHASES or not data.get("rng") is String or not data.rng.is_valid_int():return false
	for field in ["initialized","defeated","previously_killed","egg_awarded"]:
		if not data.get(field) is bool:return false
	if not ContentCatalog._number(data.get("health"),0,float(EndFight.RULES.health)) or not ContentCatalog._number(data.get("facing"),-1,1,true) or int(data.facing)==0:return false
	for field in ["phase_time","phase_limit","perch_damage","heal_clock","death_time","wing_phase"]:
		if not ContentCatalog._number(data.get(field),0,1000000000):return false
	for field in ["pitch","head_pitch","orbit"]:
		if not ContentCatalog._number(data.get(field),-1000000000,1000000000):return false
	for field in ["position_world","velocity","target_point"]:
		if not ContentCatalog._vector(data.get(field),2,-160000000,160000000):return false
	if not ContentCatalog._number(data.get("xp_paid"),0,12000,true) or not ContentCatalog._number(data.get("restored_pillars"),0,10,true) or not ContentCatalog._number(data.get("next_crystal"),1,2147483646,true):return false
	if not ContentCatalog._number(data.get("healing"),-1,9,true) or not ContentCatalog._number(data.get("breath_cycles"),0,100,true):return false
	if not data.get("crystals") is Array or data.crystals.size()!=(10 if data.initialized else 0):return false
	for alive in data.crystals:
		if not alive is bool:return false
	if not data.get("placed") is Array or data.placed.size()>int(EndFight.RULES.crystal_limit):return false
	var ids: Dictionary={};var cells: Dictionary={}
	for c in data.placed:
		if not c is Dictionary or not ContentCatalog._number(c.get("id"),1,int(data.next_crystal)-1,true) or not ContentCatalog._vector(c.get("cell"),2,-10000000,10000000,true):return false
		var cell:=Vector2i(c.cell[0],c.cell[1])
		if ids.has(int(c.id)) or cells.has(cell):return false
		ids[int(c.id)]=true;cells[cell]=true
	if not data.get("projectiles") is Array or data.projectiles.size()>int(EndFight.RULES.projectile_limit) or not data.get("clouds") is Array or data.clouds.size()>int(EndFight.RULES.cloud_limit):return false
	for ball in data.projectiles:
		if not ball is Dictionary or not ContentCatalog._vector(ball.get("position"),2,-160000000,160000000) or not ContentCatalog._vector(ball.get("velocity"),2,-2000,2000) or not ContentCatalog._number(ball.get("life"),0,8):return false
	for cloud in data.clouds:
		if not cloud is Dictionary or not ContentCatalog._vector(cloud.get("position"),2,-160000000,160000000) or not ContentCatalog._number(cloud.get("radius"),0,160) or not ContentCatalog._number(cloud.get("age"),0,60) or not ContentCatalog._number(cloud.get("life"),.05,60) or cloud.age>cloud.life:return false
	return true
static func valid_rules() -> bool:
	var r: Dictionary=EndFight.RULES
	if r.get("version")!=1:return false
	for key in ["health","heal_interval","heal_amount","heal_radius","linked_crystal_damage","crystal_power","crystal_limit","head_damage","wing_damage","contact_interval","contact_knockback","body_damage_divisor","body_damage_bonus","perch_damage_limit","orbit_radius","cruise_height","cruise_variation","flight_speed","charge_speed","strafe_seconds","charge_warning_seconds","charge_seconds","scan_seconds","roar_seconds","breath_seconds","maximum_breath_cycles","takeoff_seconds","fireball_speed","cloud_radius","perched_cloud_radius","cloud_seconds","cloud_warmup","cloud_damage","cloud_interval","projectile_limit","cloud_limit","death_seconds","first_xp","repeat_xp","respawn_prepare_seconds","respawn_pillar_seconds","respawn_finish_seconds","destroy_budget"]:
		if not ContentCatalog._number(r.get(key),.01,12000):return false
	if not ContentCatalog._vector(r.get("holding_seconds"),2,.1,60) or r.holding_seconds[1]<r.holding_seconds[0]:return false
	if not ContentCatalog._vector(r.get("respawn_slots"),4,-3,3,true) or r.respawn_slots.size()!=4 or not r.get("dragon_immune") is Array:return false
	for key in r.dragon_immune:
		if not key is String or BlockDatabase.id_for(key)==0:return false
	return true
