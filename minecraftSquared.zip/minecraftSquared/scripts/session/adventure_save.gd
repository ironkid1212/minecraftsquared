class_name AdventureSave
extends RefCounted
static func valid(state: Dictionary) -> bool:
	if not state.get("player_arrows",[]) is Array or state.get("player_arrows",[]).size()>128:return false
	for arrow in state.get("player_arrows",[]):
		if not arrow is Dictionary or not ContentCatalog._vector(arrow.get("position"),2,-1000000000,1000000000) or not ContentCatalog._vector(arrow.get("velocity"),2,-10000,10000) or not ContentCatalog._number(arrow.get("gravity"),0,2000) or not ContentCatalog._number(arrow.get("life"),0,60) or not arrow.get("stuck") is bool or not arrow.get("critical") is bool or not ContentCatalog._number(arrow.get("power_level",0),0,5,true):return false
	if state.get("survival",{}) is Dictionary and not ContentCatalog._number(state.get("survival",{}).get("absorption",0),0,16):return false
	var food: Variant=state.get("food",{})
	if not food is Dictionary:return false
	if not food.is_empty():
		if not ContentCatalog._number(food.get("level"),0,20,true) or not ContentCatalog._number(food.get("saturation"),0,float(food.get("level",0))) or not ContentCatalog._number(food.get("exhaustion"),0,40):return false
	var xp: Variant=state.get("experience",{})
	if not xp is Dictionary or not ContentCatalog._number(xp.get("total",0),0,2000000000,true) or not ContentCatalog._number(xp.get("enchant_seed",1),1,2147483646,true) or not xp.get("orbs",[]) is Array or xp.get("orbs",[]).size()>128:return false
	for orb in xp.get("orbs",[]):
		if not orb is Dictionary or not ContentCatalog._vector(orb.get("position"),2,-1000000000,1000000000) or not ContentCatalog._vector(orb.get("velocity"),2,-10000,10000) or not ContentCatalog._number(orb.get("value"),1,2000000000,true) or not ContentCatalog._number(orb.get("age"),0,300):return false
	var structures: Variant=state.get("structures",{})
	if not structures is Dictionary or not structures.get("initialized",[]) is Array or not structures.get("spawners",[]) is Array:return false
	if structures.get("initialized",[]).size()>100000 or structures.get("spawners",[]).size()>10000:return false
	for cell in structures.get("initialized",[]):
		if not ContentCatalog._vector(cell,2,-1000000000,1000000000,true):return false
	for spawner in structures.get("spawners",[]):
		if not spawner is Dictionary or not ContentCatalog._vector(spawner.get("cell"),2,-1000000000,1000000000,true) or spawner.get("kind") not in ["zombie","skeleton","spider","cave_spider","blaze","silverfish"] or not ContentCatalog._number(spawner.get("delay"),0,40):return false
	for furnace in state.get("furnaces",[]):
		if not furnace is Dictionary or not ContentCatalog._number(furnace.get("experience",0),0,1000000000):return false
	return true
