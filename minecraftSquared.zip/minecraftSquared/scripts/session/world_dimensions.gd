class_name WorldDimensions
extends RefCounted

const ENV_FIELDS: Array=["edits","drops","persistent_leaves","falling_blocks","torch_mounts","furnaces","player_arrows","structures","storage","mobs","weather","farm_moisture","fluid_levels","waterlogged","plant_ages","portals","experience_orbs","brewing","pearls","eyes","end_portals"]
static var DATA: Dictionary=DataFile.object_from("res://data/nether.json")
var world: Node2D
var active: String="overworld"
var states: Dictionary={}
var generation: Dictionary=DATA.generation.duplicate(true)
var swapping: bool=false
func setup(game: Node2D) -> bool:
	world=game
	if not generation_valid(DATA.get("generation")) or not DATA.get("portal") is Dictionary or not DATA.get("environment") is Dictionary or not DATA.get("biomes") is Dictionary:
		DataFile.fail("nether.json: invalid generation, portal or environment settings.");return false
	for key in ["minimum_width","minimum_height","maximum_width","maximum_height","survival_seconds","creative_seconds","cooldown_seconds","horizontal_scale","nether_link_radius","overworld_link_radius","create_radius"]:
		if not ContentCatalog._number(DATA.portal.get(key),.01,128):DataFile.fail("nether.json: invalid portal setting "+key);return false
	if DATA.portal.minimum_width!=2 or DATA.portal.minimum_height!=3 or DATA.portal.maximum_width!=21 or DATA.portal.maximum_height!=21:
		DataFile.fail("nether.json: supported opening range is 2x3 through 21x21.");return false
	for key in ["ambient_level","bed_explosion_power","lava_tick_seconds","lava_dropoff","lava_search","fire_seconds"]:
		if not ContentCatalog._number(DATA.environment.get(key),.05,300):DataFile.fail("nether.json: invalid environment setting "+key);return false
	if not ContentCatalog._number(DATA.environment.get("fog_blend_radius",24),0,64,true) or not ContentCatalog._number(DATA.environment.get("fog_transition_seconds",.35),.01,10):DataFile.fail("nether.json: invalid fog blend settings.");return false
	for key in ["nether_wastes","soul_sand_valley","basalt_deltas","warped_forest","crimson_forest"]:
		if not DATA.biomes.get(key) is Dictionary or not ContentCatalog._vector(DATA.biomes[key].get("fog"),3,0,1):DataFile.fail("nether.json: invalid biome "+key);return false
	var fortress: Variant=DATA.get("fortress")
	if not fortress is Dictionary or not ContentCatalog._number(fortress.get("region_width"),192,1024,true) or not ContentCatalog._number(fortress.get("chance"),0,1) or not ContentCatalog._number(fortress.get("half_width"),16,64,true) or not ContentCatalog._number(fortress.get("level_spacing"),8,16,true):DataFile.fail("nether.json: invalid fortress settings.");return false
	return true
static func generation_valid(value: Variant) -> bool:
	if not value is Dictionary or not ContentCatalog._number(value.get("revision"),1,3,true) or value.get("height")!=128:return false
	for key in ["lava_y","biome_width","ceiling_base","ceiling_amplitude","floor_base","floor_amplitude"]:
		if not ContentCatalog._number(value.get(key),1,512,true):return false
	for key in ["cavern_frequency","cave_threshold","quartz_threshold","gold_threshold"]:
		if not ContentCatalog._number(value.get(key),.001,1):return false
	if not value.get("warped_forests",true) is bool or not value.get("fortresses",true) is bool or not ContentCatalog._number(value.get("forest_spacing",11),8,64,true):return false
	if value.revision>=2:
		if not ContentCatalog._number(value.get("density_frequency"),.003,.06) or not ContentCatalog._number(value.get("cavern_opening"),.05,.5):return false
		if not value.get("climate") is Dictionary or value.climate.size()!=5:return false
		for key in ["nether_wastes","soul_sand_valley","basalt_deltas","crimson_forest","warped_forest"]:
			if not ContentCatalog._vector(value.climate.get(key),3,-1,1):return false
		var layout: Variant=value.get("fortress_layout")
		if not layout is Dictionary or not ContentCatalog._number(layout.get("region_width"),320,1024,true) or not ContentCatalog._number(layout.get("chance"),0,1) or not ContentCatalog._number(layout.get("minimum_pieces"),4,7,true) or not ContentCatalog._number(layout.get("maximum_pieces"),4,7,true):return false
		if layout.minimum_pieces>layout.maximum_pieces:return false
	if not value.get("pillars_background",true) is bool or not ContentCatalog._number(value.get("pillar_spacing",72),32,256,true) or not ContentCatalog._number(value.get("pillar_chance",.4),0,1):return false
	return value.lava_y<60 and value.ceiling_base<value.floor_base and value.floor_base<120
func snapshot() -> Dictionary:
	var inactive: Dictionary=states.duplicate(true);inactive.erase(active)
	return {"active":active,"states":inactive,"nether_generation":generation.duplicate(true)}
static func valid(record: Variant,store: RefCounted,root_state: Dictionary) -> bool:
	if not record is Dictionary:return false
	if record.is_empty():return true
	if record.get("active") not in ["overworld","nether"] or not record.get("states") is Dictionary or record.states.size()>2 or not generation_valid(record.get("nether_generation")):return false
	for dimension in record.states:
		if dimension not in ["overworld","nether"] or dimension==record.active or not record.states[dimension] is Dictionary:return false
		var local: Dictionary=root_state.duplicate(true);local.erase("dimensions")
		for key in record.states[dimension]:
			if key not in ENV_FIELDS:return false
			if key=="experience_orbs":
				if not local.get("experience") is Dictionary:return false
				local.experience.orbs=record.states[dimension][key]
			else:local[key]=record.states[dimension][key]
		if not store._validate_state(local,false):return false
	return true
func restore_saved(record: Dictionary) -> void:
	active=str(record.get("active","overworld"));states=record.get("states",{}).duplicate(true)
	generation=record.get("nether_generation",DATA.generation).duplicate(true)
	reset_environment()
func reset_environment() -> void:
	world.mining_held=false;world.reset_mining();world.ranged.cancel();world.held_use.cancel()
	world.inventory_screen.set_open(false);world.furnace_screen.set_open(false);world.storage_screen.set_open(false);world.upgrade_screen.set_open(false)
	world.portals.clear()
	world.mobs.restore({});world.mobs.explosions.effects.clear();world.experience.orbs.clear()
	world.brewing.states.clear();world.pearls.restore([]);world.end_progression.clear();
	world.furnaces.states.clear();world.dropped_items.drops.clear();world.storage.restore([]);world.structures.restore({})
	for key in ["_scheduled","_decay","_dark_since","_scan_jobs","_known_chunks"]:world.world_updates.get(key).clear()
	world.world_updates._active_chunks.clear();world.world_updates._random_remaining=0;world.world_updates._last_sim_center=Vector2i(2147483647,2147483647)
	world.world_updates.persistent_leaves.clear();world.world_updates.plant_ages.clear();world.world_updates.falling.restore([])
	world.chunks.dimension=active;world.chunks.nether_generation=generation
	world.chunks.setup(world.ground,world.source_id,world.noise,world.settings.terrain.depth,world.surface_level,world.hill_height,world.dirt_depth,world.settings)
	world.world_depth=world.chunks.world_depth
	world.player.fall_limit_y=world.world_depth*16+world.settings.player.recovery_margin
	world.fluids.configure_dimension();world.fluids.restore([]);world.fluids.burning=0;world.weather.clear_roofs()
	world.player.climbing.active=false;world.player.velocity=Vector2.ZERO
	world.lighting.invalidate();world.clock.apply()
func travel(destination: String,source_portal: Dictionary={},respawning: bool=false) -> bool:
	if swapping or destination not in ["overworld","nether"] or destination==active:return false
	swapping=true
	var store:=WorldSaveStore.new();var current: Dictionary=store.capture_state(world)
	var environment: Dictionary={}
	for key in ENV_FIELDS:environment[key]=current.get(key,{} if key in ["mobs","structures","weather","portals"] else []).duplicate(true)
	environment.experience_orbs=current.experience.orbs.duplicate(true)
	states[active]=environment
	var old_dimension: String=active;var old_cell: Vector2i=world.ground.local_to_map(world.ground.to_local(world.player.global_position))
	var real_y: int=world.chunks.world_y(old_cell)
	active=destination;reset_environment()
	world.inventory.held_id=0;world.inventory.held_count=0;world.inventory.held_tags={};world.inventory.held_durability=0
	var craft: CraftingGrid=world.inventory_screen.crafting
	craft.ids.fill(0);craft.counts.fill(0);craft.durability.fill(0)
	for i in range(craft.tags.size()):craft.tags[i]={}
	craft._refresh()
	var state: Dictionary=current.duplicate(true)
	var target: Dictionary=states.get(destination,{})
	for key in ENV_FIELDS:state[key]=target.get(key,{} if key in ["mobs","structures","weather","portals"] else []).duplicate(true)
	state.experience.orbs=target.get("experience_orbs",[]).duplicate(true)
	state.erase("dimensions");state.erase("experience_orbs")
	var scale: float=float(DATA.portal.horizontal_scale)
	var x: int=floori(old_cell.x/scale) if destination=="nether" else old_cell.x*int(scale)
	var y: int=world.chunks.world_depth-1-real_y if destination=="nether" else world.settings.terrain.top_y-real_y
	var desired:=Vector2i(x,clampi(y,6,world.chunks.world_depth-7))
	state.position=[desired.x*16+8,desired.y*16+8]
	if not store.restore_world({"state":state},world):
		active=old_dimension;reset_environment();store.restore_world({"state":current},world);swapping=false;return false
	if respawning:
		world.player.teleport_to(world.survival.world_spawn);world.chunks.update_around(world.player.global_position)
		world.lighting.invalidate();world.clock.apply();swapping=false;return true
	var landing: Dictionary=world.portals.destination(desired,source_portal)
	if landing.is_empty():
		active=old_dimension;reset_environment();store.restore_world({"state":current},world);swapping=false;return false
	world.player.teleport_to(world.portals.arrival(landing));world.player.velocity=Vector2.ZERO
	world.chunks.update_around(world.player.global_position);world.portals.cooldown=float(DATA.portal.cooldown_seconds)
	world.portals.dwell=0;world.survival.reset_fall();world.lighting.invalidate();world.clock.apply()
	world.show_mode_notice("Entered the Nether" if active=="nether" else "Returned to the Overworld")
	swapping=false;return true
func return_for_respawn() -> void:
	if active!="overworld":travel("overworld",{},true)
