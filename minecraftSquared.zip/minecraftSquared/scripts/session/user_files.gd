class_name UserFiles
extends RefCounted

const SAVES: String="user://saves"
const SKINS: String="user://skins"
static var prepared: bool=false
static var migration_errors: PackedStringArray=[]

static func prepare() -> void:
	if prepared:return
	prepared=true
	var root: String=OS.get_user_data_dir()
	for folder in [root,ProjectSettings.globalize_path(SAVES),ProjectSettings.globalize_path(SKINS)]:
		if DirAccess.make_dir_recursive_absolute(folder)!=OK:migration_errors.append("Could not create "+folder)
	if FileAccess.file_exists("user://migration_v1.cfg"):return
	var parent: String=root.get_base_dir()
	var legacy: Array[String]=[parent.path_join("Godot/app_userdata/Minecraft Squared"),parent.path_join("godot/app_userdata/Minecraft Squared")]
	if OS.get_name()=="macOS":legacy.append(parent.path_join("Godot/app_userdata/Minecraft Squared"))
	# Also recognize older folders already stored in the custom user directory.
	legacy.append(root)
	var visited: Dictionary={}
	for source in legacy:
		if visited.has(source) or not DirAccess.dir_exists_absolute(source):continue
		visited[source]=true
		migrate(source,root)
	if migration_errors.is_empty():
		var marker:=ConfigFile.new();marker.set_value("migration","version",1);marker.save("user://migration_v1.cfg")
	else:
		for message in migration_errors:push_warning(message)

static func migrate(source: String,target: String) -> void:
	for pair in [["worlds","saves"],["profile","skins"]]:copy_missing(source.path_join(pair[0]),target.path_join(pair[1]))
	if source!=target:
		for filename in ["options.cfg","saved_hotbars.json","hotbars.json","hotbars.cfg"]:copy_missing(source.path_join(filename),target.path_join(filename))

static func copy_missing(source: String,target: String,depth: int=0) -> void:
	if depth>12:migration_errors.append("Migration folder nesting limit: "+source);return
	if FileAccess.file_exists(source):
		if FileAccess.file_exists(target):return
		if DirAccess.make_dir_recursive_absolute(target.get_base_dir())!=OK or DirAccess.copy_absolute(source,target)!=OK:migration_errors.append("Could not copy "+source)
		return
	var directory:=DirAccess.open(source)
	if directory==null:return
	if DirAccess.make_dir_recursive_absolute(target)!=OK:migration_errors.append("Could not create "+target);return
	directory.list_dir_begin()
	var filename: String=directory.get_next()
	while not filename.is_empty():
		if filename not in [".",".."] and not directory.is_link(filename):copy_missing(source.path_join(filename),target.path_join(filename),depth+1)
		filename=directory.get_next()
	directory.list_dir_end()

static func open_folder(path: String="user://") -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(path))
	OS.shell_open(ProjectSettings.globalize_path(path))
