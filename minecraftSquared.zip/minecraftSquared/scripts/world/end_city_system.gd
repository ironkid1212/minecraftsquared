class_name EndCitySystem
extends Node2D
const SHELL: Texture2D=preload("res://assets/mobs/shulker.png")
const BULLET: Texture2D=preload("res://assets/mobs/shulker_bullet.png")
var world: Node2D
var spawned: Dictionary={}
var supplied: Dictionary={}
var bullets: Array[Dictionary]=[]
var scan_time: float=0
var rule: Dictionary
var rockets: Array[Dictionary]=[]
func launch_rocket(at: Vector2) -> void:
	if rockets.size()<16:rockets.append({"position":at,"life":1.3})
func setup(game: Node2D) -> void:world=game;rule=EndCityGenerator.RULES.shulker;z_index=19;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
func clear() -> void:spawned.clear();supplied.clear();bullets.clear();rockets.clear();scan_time=0;queue_redraw()
func discover() -> void:
	if not world.is_end():return
	var gen: EndCityGenerator=world.chunks.end.cities;var region: int=gen.region_at(world.mobs.cell(world.player.global_position).x)
	for index in range(region-1,region+2):
		var plan: Dictionary=gen.plan(index)
		for cell: Vector2i in plan.guardians:
			if spawned.has(cell) or not world.chunks.is_cell_loaded(cell) or world.mobs.active.size()>=int(MobCatalog.rules.maximum_active):continue
			var at: Vector2=world.mobs.feet(cell)
			if at.distance_to(world.player.global_position)>float(MobCatalog.rules.active_distance)*16 or not world.mobs.can_fit("shulker",at):continue
			var mob: MobActor=world.mobs.spawn("shulker",at)
			if mob!=null:spawned[cell]=true
		for cell: Vector2i in plan.potions:
			if supplied.has(cell) or not world.chunks.is_cell_loaded(cell) or world.get_block(cell)!=BlockDatabase.id_for("brewing_stand"):continue
			var state: BrewingState=world.brewing.state_at(cell)
			for slot in [0,2]:state.set_stack(slot,{"id":BlockDatabase.id_for("potion_strong_healing"),"count":1})
			supplied[cell]=true
static func support(mob: MobActor,cell: Vector2i) -> Vector2i:
	for side in [mob.shulker_attach,Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT,Vector2i.UP]:
		var chunks: ChunkWorld=mob.system.world.chunks
		if not chunks.is_cell_loaded(cell+side):continue
		var entry: Dictionary=BlockDatabase.BLOCKS.get(chunks.get_block(cell+side),{})
		if entry.get("solid",false) and not entry.has("door") and not entry.has("gate"):
			for box in entry.get("collision_boxes",[[0,0,16,16]]):
				if side==Vector2i.DOWN and box[1]==0 and box[2]==16 or side==Vector2i.UP and box[1]+box[3]==16 and box[2]==16 or side==Vector2i.LEFT and box[0]+box[2]==16 and box[3]==16 or side==Vector2i.RIGHT and box[0]==0 and box[3]==16:return side
	return Vector2i.ZERO
static func teleport_shulker(mob: MobActor) -> bool:
	var system: MobSystem=mob.system;var center: Vector2i=system.cell(mob.global_position-Vector2(0,8));var r: Dictionary=EndCityGenerator.RULES.shulker
	for i in range(int(r.teleport_attempts)):
		var cell: Vector2i=center+Vector2i(system.rng.randi_range(-int(r.teleport_range),int(r.teleport_range)),system.rng.randi_range(-int(r.teleport_range),int(r.teleport_range)))
		if cell.y<1 or cell.y>=system.world.chunks.world_depth-1 or not system.can_fit("shulker",system.feet(cell)) or support(mob,cell)==Vector2i.ZERO:continue
		system.renderer.portal_burst(mob.center());
		if system.world.effects!=null:system.world.effects.sound("entity.shulker.teleport",mob.center(),"entities",.7,1,2,.3)
		mob.global_position=system.feet(cell);mob.previous_position=mob.global_position;mob.shulker_attach=support(mob,cell);mob.shulker_peek=0;mob.goal="idle";mob.attack_time=1;mob.reset_physics_interpolation();system.renderer.portal_burst(mob.center());return true
	return false
static func step_shulker(mob: MobActor,dt: float) -> void:
	var world: Node2D=mob.system.world;var cell: Vector2i=mob.system.cell(mob.global_position-Vector2(0,8));var side: Vector2i=support(mob,cell)
	if side==Vector2i.ZERO:teleport_shulker(mob)
	else:mob.shulker_attach=side
	mob.velocity=Vector2.ZERO;mob.knockback_x=0
	var r: Dictionary=EndCityGenerator.RULES.shulker
	var valid_target: bool=not world.player.creative and not world.player.spectator and not world.player.survival_dead and mob.center().distance_to(world.player.global_position)<float(r.range)*16
	if valid_target and mob.system.visible(mob.center(),world.player.eye_position()):mob.aggro_time=5
	else:mob.aggro_time=maxf(0,mob.aggro_time-dt)
	var wanted: float=0
	var opened: Rect2=mob.bounds(mob.global_position).grow(0)
	var center: Vector2=mob.global_position-Vector2(0,8)
	opened=Rect2(center+Vector2(-24 if mob.shulker_attach==Vector2i.RIGHT else -8,-24 if mob.shulker_attach==Vector2i.DOWN else -8),Vector2(32 if mob.shulker_attach.x!=0 else 16,32 if mob.shulker_attach.x==0 else 16))
	var shape_query:=PhysicsShapeQueryParameters2D.new();var full_shape:=RectangleShape2D.new();full_shape.size=opened.size-Vector2.ONE*.1;shape_query.shape=full_shape;shape_query.transform=Transform2D(0,opened.get_center());shape_query.collision_mask=1;shape_query.exclude=[mob.get_rid(),world.player.get_rid()]
	if not mob.get_world_2d().direct_space_state.intersect_shape(shape_query,1).is_empty():valid_target=false
	if valid_target and mob.aggro_time>0:
		if mob.goal!="ranged":mob.attack_time=float(r.first_shot)
		mob.goal="ranged";wanted=1;mob.facing=1 if world.player.global_position.x>=mob.global_position.x else -1
		if mob.attack_time<=0:world.end_city_system.shoot(mob);mob.attack_time=mob.system.rng.randf_range(r.shot_interval[0],r.shot_interval[1])
	else:
		mob.wander_time-=dt
		if mob.wander_time<=0:mob.goal="peek" if mob.system.rng.randf()<.25 else "idle";mob.wander_time=mob.system.rng.randf_range(1,3)
		wanted=.3 if mob.goal=="peek" else 0
	var old_peek: float=mob.shulker_peek
	mob.shulker_peek=move_toward(mob.shulker_peek,wanted,dt)
	if world.effects!=null and (old_peek<=.05 and mob.shulker_peek>.05 or old_peek>.05 and mob.shulker_peek<=.05):world.effects.sound("entity.shulker.open" if mob.shulker_peek>.05 else "entity.shulker.close",mob.center(),"entities",.6,1,1,.3)
	var shape: CollisionShape2D=mob.get_node("CollisionShape2D");var bounds: Rect2=mob.bounds(mob.global_position);shape.shape.size=bounds.size;shape.position=bounds.get_center()-mob.global_position
static func draw_shulker(canvas: MobDrawing,mob: MobActor,t: Transform2D,tint: Color) -> void:
	var angle: float=PI if mob.shulker_attach==Vector2i.UP else PI/2 if mob.shulker_attach==Vector2i.LEFT else -PI/2 if mob.shulker_attach==Vector2i.RIGHT else 0
	var pose: Transform2D=t*Transform2D(0,Vector2(1.0/mob.facing,1),0,Vector2.ZERO)*Transform2D(angle,Vector2(0,-8))
	canvas.part(SHELL,Rect2(16,44,16,8),Rect2(-8,0,16,8),pose,tint)
	if mob.shulker_peek>.05:canvas.part(SHELL,Rect2(6,58,6,6),Rect2(-3,-3-mob.shulker_peek*3,6,6),pose,tint)
	canvas.part(SHELL,Rect2(16,16,16,12),Rect2(-8,-8-mob.shulker_peek*16,16,12),pose,tint)
func shoot(mob: MobActor) -> void:
	if world.effects!=null:world.effects.sound("entity.shulker.shoot",mob.center(),"entities",.7,1,2,.2)
	if bullets.size()>=int(rule.bullet_cap):return
	bullets.append({"position":mob.center(),"velocity":Vector2(0,-16),"life":float(rule.bullet_life),"turn":0.0,"axis":0,"owner":mob.serial})
func attack_pointer() -> bool:
	if world.player.spectator or world.player.survival_dead:return false
	var point: Vector2=world.pointer_global_position();var eye: Vector2=world.player.eye_position()
	for i in range(bullets.size()):
		if point.distance_to(bullets[i].position)<7 and eye.distance_to(bullets[i].position)<=float(MobCatalog.rules.attack_reach)*16 and world.mobs.visible(eye,bullets[i].position):world.combat.prepare_strike(bullets[i].position);world.mobs.renderer.burst(bullets[i].position,false);bullets.remove_at(i);return true
	return false
func intercept(from: Vector2,to: Vector2,limit: float) -> bool:
	for i in range(bullets.size()):
		if is_finite(PlayerCombat.ray_entry(from,to,Rect2(Vector2(bullets[i].position)-Vector2(3,3),Vector2(6,6)),minf(limit,from.distance_to(to)))):bullets.remove_at(i);return true
	return false
func _physics_process(dt: float) -> void:
	for i in range(rockets.size()-1,-1,-1):
		rockets[i].life-=dt;rockets[i].position.y-=80*dt
		if world.effects!=null:world.effects.emit_particle("spark",rockets[i].position,Vector2(world.effects.rng.randf_range(-3,3),10),.35,2)
		if rockets[i].life<=0:
			if world.effects!=null:world.effects.sound("entity.firework_rocket.blast",rockets[i].position,"entities",.6,1,2,.1);world.effects.puff("spark",rockets[i].position,18)
			world.mobs.renderer.burst(rockets[i].position,true);rockets.remove_at(i)
	scan_time-=dt
	if scan_time<=0:scan_time=.4;discover()
	for i in range(bullets.size()-1,-1,-1):
		var b: Dictionary=bullets[i];b.life-=dt
		if b.life<=0 or world.player.survival_dead or world.player.spectator:bullets.remove_at(i);continue
		if not world.chunks.is_cell_loaded(world.mobs.cell(b.position)):continue
		b.turn-=dt
		if b.turn<=0:
			b.turn=randf_range(.4,1.2);b.axis=1-int(b.axis)
		var aim: Vector2=world.player.global_position-Vector2(b.position);var direction:=Vector2(signf(aim.x),0) if int(b.axis)==0 else Vector2(0,signf(aim.y))
		if aim.length()<24:direction=aim.normalized()
		var query:=PhysicsRayQueryParameters2D.create(b.position,Vector2(b.position)+direction*16,1);query.exclude=[world.player.get_rid()]
		if not get_world_2d().direct_space_state.intersect_ray(query).is_empty():b.axis=1-int(b.axis);b.turn=.3;direction=Vector2(0,signf(aim.y)) if int(b.axis)==1 else Vector2(signf(aim.x),0)
		b.velocity=Vector2(b.velocity).lerp(direction*float(rule.bullet_speed),1-pow(.8,dt*20))
		var from: Vector2=b.position;var to: Vector2=from+Vector2(b.velocity)*dt
		query=PhysicsRayQueryParameters2D.create(from,to,1);query.exclude=[world.player.get_rid()]
		var hit: Dictionary=get_world_2d().direct_space_state.intersect_ray(query);var limit: float=from.distance_to(hit.position) if not hit.is_empty() else from.distance_to(to)
		var box: Rect2=world.player_collision.global_transform*world.player_collision.shape.get_rect()
		var target: MobActor=null
		for mob: MobActor in world.mobs.active.values():
			if mob.dead or mob.serial==int(b.owner):continue
			var distance: float=PlayerCombat.ray_entry(from,to,mob.bounds(mob.global_position),limit)
			if is_finite(distance) and distance<limit:limit=distance;target=mob
		if not world.player.creative and is_finite(PlayerCombat.ray_entry(from,to,box,limit)):
			if not world.shields.block(float(rule.damage),from,"projectile") and world.survival.take_damage(float(rule.damage),"You were hit by a Shulker bullet"):world.survival.apply_effect({"name":"levitation","seconds":float(rule.levitation_seconds)})
			bullets.remove_at(i);continue
		if target!=null:
			var old_position: Vector2=target.global_position;var opened: bool=target.definition.rig=="shulker" and target.shulker_peek>.05
			if target.hurt(float(rule.damage),from,"shulker_bullet"):
				target.effects.apply({"name":"levitation","seconds":float(rule.levitation_seconds)})
				if opened and not target.dead and target.global_position==old_position:
					var count: int=0
					for other in world.mobs.active.values():
						if other.definition.rig=="shulker" and other.global_position.distance_to(old_position)<8*16:count+=1
					if count<5 and world.mobs.active.size()<int(MobCatalog.rules.maximum_active) and teleport_shulker(target) and world.mobs.rng.randf()>=float(count-1)/5:world.mobs.spawn("shulker",old_position)
			bullets.remove_at(i);continue
		if not hit.is_empty():world.mobs.renderer.burst(hit.position,false);bullets.remove_at(i);continue
		b.position=to
	queue_redraw()
func _draw() -> void:
	var view: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	for b in bullets:
		if view.grow(5).has_point(b.position):draw_texture_rect_region(BULLET,Rect2(Vector2(b.position).floor()-Vector2(3,3),Vector2(6,6)),Rect2(0,0,8,8))
	for rocket in rockets:
		if view.grow(8).has_point(rocket.position):ItemDrawing.draw_icon(self,world.atlas_source,BlockDatabase.id_for("firework_rocket"),Rect2(Vector2(rocket.position)-Vector2(4,4),Vector2(8,8)))
func snapshot() -> Dictionary:
	var seen: Array=[];var stocked: Array=[];var shots: Array=[]
	for cell: Vector2i in spawned:seen.append([cell.x,cell.y])
	for cell: Vector2i in supplied:stocked.append([cell.x,cell.y])
	for b in bullets:shots.append({"position":[b.position.x,b.position.y],"velocity":[b.velocity.x,b.velocity.y],"life":b.life,"turn":b.turn,"axis":b.axis,"owner":b.owner})
	return {"version":1,"spawned":seen,"supplied":stocked,"bullets":shots}
func restore(data: Dictionary) -> void:
	clear()
	for a in data.get("spawned",[]):spawned[Vector2i(a[0],a[1])]=true
	for a in data.get("supplied",[]):supplied[Vector2i(a[0],a[1])]=true
	for b in data.get("bullets",[]):bullets.append({"position":Vector2(b.position[0],b.position[1]),"velocity":Vector2(b.velocity[0],b.velocity[1]),"life":float(b.life),"turn":float(b.turn),"axis":int(b.axis),"owner":int(b.owner)})
static func valid(data: Variant) -> bool:
	if not data is Dictionary:return false
	if data.is_empty():return true
	if data.get("version")!=1:return false
	for key in ["spawned","supplied"]:
		if not data.get(key) is Array or data[key].size()>100000:return false
		for cell in data[key]:
			if not ContentCatalog._vector(cell,2,-10000000,10000000,true):return false
	if not data.get("bullets") is Array or data.bullets.size()>32:return false
	for b in data.bullets:
		if not b is Dictionary or not ContentCatalog._vector(b.get("position"),2,-160000000,160000000) or not ContentCatalog._vector(b.get("velocity"),2,-1024,1024) or not ContentCatalog._number(b.get("life"),0,20) or not ContentCatalog._number(b.get("turn"),-1,2) or not ContentCatalog._number(b.get("axis"),0,1,true) or not ContentCatalog._number(b.get("owner"),1,2147483646,true):return false
	return true

static func rod_placement(world: Node2D,cell: Vector2i,id: int) -> int:
	if id!=BlockDatabase.id_for("end_rod"):return id
	var nearest: float=INF;var result: int=0
	var pointer: Vector2=world.ground.to_local(world.pointer_global_position())
	var center: Vector2=world.ground.map_to_local(cell)
	for variant in {"end_rod":Vector2i.DOWN,"end_rod_ceiling":Vector2i.UP,"end_rod_left":Vector2i.LEFT,"end_rod_right":Vector2i.RIGHT}:
		var offset: Vector2i={"end_rod":Vector2i.DOWN,"end_rod_ceiling":Vector2i.UP,"end_rod_left":Vector2i.LEFT,"end_rod_right":Vector2i.RIGHT}[variant]
		var block: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(cell+offset),{})
		if not block.get("solid",false) and not block.get("platform",false):continue
		var distance: float=pointer.distance_squared_to(center+Vector2(offset)*8)
		if distance<nearest:nearest=distance;result=BlockDatabase.id_for(variant)
	return result
