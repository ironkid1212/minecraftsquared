class_name NetherPortals
extends Node2D

var world: Node2D
var records: Array[Dictionary]=[]
var fires: Dictionary={}
var dwell: float=0
var cooldown: float=0
var _busy: bool=false
var _pending: bool=false
var _animation: float=0
var _fire_damage: float=0
const PORTAL: Texture2D=preload("res://assets/environment/nether/nether_portal.png")
const FIRE: Texture2D=preload("res://assets/environment/nether/fire_0.png")
func setup(game: Node2D) -> void:
	world=game;z_index=4;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	world.chunks.cell_changed.connect(_changed)
func id(key: String) -> int:return BlockDatabase.id_for(key)
func clear() -> void:records.clear();fires.clear();dwell=0;cooldown=0;_pending=false;queue_redraw()
func frame_id(value: int) -> bool:return value==id("obsidian") or value==id("obsidian_portal_frame")
func empty(value: int) -> bool:return value==0 or value==id("fire") or value==id("nether_portal")
func origin(record: Dictionary) -> Vector2i:return Vector2i(record.origin[0],record.origin[1])
func interior(record: Dictionary) -> Rect2i:
	var at: Vector2i=origin(record);return Rect2i(at-Vector2i(0,int(record.height)-1),Vector2i(record.width,record.height))
func frame_cells(record: Dictionary,corners: bool=false) -> Array[Vector2i]:
	var cells: Array[Vector2i]=[];var at: Vector2i=origin(record)
	for x in range(int(record.width)):
		cells.append(at+Vector2i(x,1));cells.append(at+Vector2i(x,-int(record.height)))
	for y in range(int(record.height)):
		cells.append(at+Vector2i(-1,-y));cells.append(at+Vector2i(int(record.width),-y))
	if corners:
		for x in [-1,int(record.width)]:
			for y in [1,-int(record.height)]:
				var cell: Vector2i=at+Vector2i(x,y)
				if frame_id(world.get_block(cell)):cells.append(cell)
	return cells
func shape(at: Vector2i) -> Dictionary:
	var rules: Dictionary=WorldDimensions.DATA.portal
	if not empty(world.get_block(at)):return {}
	var bottom: Vector2i=at
	for i in range(int(rules.maximum_height)):
		if not empty(world.get_block(bottom+Vector2i.DOWN)):break
		bottom+=Vector2i.DOWN
	if not frame_id(world.get_block(bottom+Vector2i.DOWN)):return {}
	for i in range(int(rules.maximum_width)):
		var left: Vector2i=bottom+Vector2i.LEFT
		if not empty(world.get_block(left)) or not frame_id(world.get_block(left+Vector2i.DOWN)):break
		bottom=left
	if not frame_id(world.get_block(bottom+Vector2i.LEFT)):return {}
	var width: int=0
	while width<=int(rules.maximum_width) and empty(world.get_block(bottom+Vector2i(width,0))) and frame_id(world.get_block(bottom+Vector2i(width,1))):width+=1
	if width<int(rules.minimum_width) or width>int(rules.maximum_width) or not frame_id(world.get_block(bottom+Vector2i(width,0))):return {}
	for height in range(1,int(rules.maximum_height)+1):
		var top: bool=true
		for x in range(width):
			if not frame_id(world.get_block(bottom+Vector2i(x,-height))):top=false;break
		if top and height>=int(rules.minimum_height):return {"origin":[bottom.x,bottom.y],"width":width,"height":height}
		if not frame_id(world.get_block(bottom+Vector2i(-1,-height))) or not frame_id(world.get_block(bottom+Vector2i(width,-height))):return {}
		for x in range(width):
			if not empty(world.get_block(bottom+Vector2i(x,-height))):return {}
	return {}
func intact(record: Dictionary) -> bool:
	for cell in frame_cells(record):
		if not frame_id(world.get_block(cell)):return false
	var area: Rect2i=interior(record)
	for y in range(area.position.y,area.end.y):
		for x in range(area.position.x,area.end.x):
			if world.get_block(Vector2i(x,y))!=id("nether_portal"):return false
	return true
func put(cell: Vector2i,value: int) -> void:
	if world.chunks.is_cell_loaded(cell):world.set_block(cell,value)
	else:world.chunks.edits[cell]=value;world.chunks._block_cache.erase(world.chunks.cell_to_chunk(cell))
func activate(record: Dictionary) -> void:
	for existing in records:
		if existing==record:return
	_busy=true
	for cell in frame_cells(record,true):put(cell,id("obsidian_portal_frame"))
	var area: Rect2i=interior(record)
	for y in range(area.position.y,area.end.y):
		for x in range(area.position.x,area.end.x):put(Vector2i(x,y),id("nether_portal"));fires.erase(Vector2i(x,y))
	records.append(record.duplicate(true));_busy=false;queue_redraw()
func deactivate(record: Dictionary) -> void:
	_busy=true;records.erase(record)
	var area: Rect2i=interior(record)
	for y in range(area.position.y,area.end.y):
		for x in range(area.position.x,area.end.x):
			if world.get_block(Vector2i(x,y))==id("nether_portal"):put(Vector2i(x,y),0)
	for cell in frame_cells(record,true):
		var shared: bool=false
		for other in records:
			if cell in frame_cells(other,true):shared=true;break
		if not shared and world.get_block(cell)==id("obsidian_portal_frame"):put(cell,id("obsidian"))
	_busy=false;queue_redraw()
func _changed(cell: Vector2i,_old: int,value: int) -> void:
	if _busy:return
	if value==id("fire"):fires[cell]=float(WorldDimensions.DATA.environment.fire_seconds)
	else:fires.erase(cell)
	for record in records.duplicate():
		if interior(record).grow(1).has_point(cell) and not intact(record):deactivate(record)
func use_igniter(cell: Vector2i) -> bool:
	if world.get_interaction_item()!=id("flint_and_steel") or not world.cell_is_reachable(cell):return false
	for offset in [Vector2i.ZERO,Vector2i.LEFT,Vector2i.RIGHT,Vector2i.UP,Vector2i.DOWN]:
		var found: Dictionary=shape(cell+offset)
		if not found.is_empty():
			var already: bool=found in records
			activate(found)
			if not already:world.inventory.damage_tool(world.use_slot(),1)
			world.player.swing_hand("place",world.ground.to_global(world.ground.map_to_local(cell)));return true
	var target: Vector2i=cell
	if world.get_block(target)!=0:
		var direction: Vector2=world.pointer_global_position()-world.ground.to_global(world.ground.map_to_local(cell))
		if direction.is_zero_approx():direction=world.player.eye_position()-world.ground.to_global(world.ground.map_to_local(cell))
		target+=Vector2i(signi(roundi(direction.x)),0) if absf(direction.x)>absf(direction.y) else Vector2i(0,signi(roundi(direction.y)))
	if not world.cell_is_reachable(target) or world.get_block(target)!=0 or world.get_block(target+Vector2i.DOWN)==0:return false
	put(target,id("fire"));world.inventory.damage_tool(world.use_slot(),1);world.player.swing_hand("place",world.ground.to_global(world.ground.map_to_local(target)));return true
func arrival(record: Dictionary) -> Vector2:
	var at: Vector2i=origin(record)
	return world.ground.to_global(Vector2((at.x+float(record.width)*.5)*16,(at.y+1)*16-14.05))
func _can_host(at: Vector2i) -> bool:
	for x in range(-2,4):
		if world.chunks.edits.get(at+Vector2i(x,1),0)!=0:return false
		if not BlockDatabase.BLOCKS.get(world.get_block(at+Vector2i(x,1)),{}).get("solid",false):return false
		for y in range(-3,1):
			if world.get_block(at+Vector2i(x,y))!=0:return false
	return true
func destination(desired: Vector2i,_source: Dictionary={}) -> Dictionary:
	var radius: int=int(WorldDimensions.DATA.portal.nether_link_radius if world.dimensions.active=="nether" else WorldDimensions.DATA.portal.overworld_link_radius)
	var nearest: Dictionary={};var distance: float=INF
	for record in records:
		var at: Vector2i=origin(record)
		if absf(at.x-desired.x)>radius or not intact(record):continue
		var d: float=at.distance_squared_to(desired)
		if d<distance:distance=d;nearest=record
	if not nearest.is_empty():world.chunks.update_around(arrival(nearest));return nearest
	var chosen:=Vector2i(2147483647,0);distance=INF
	var create_radius: int=int(WorldDimensions.DATA.portal.create_radius)
	for x in range(desired.x-create_radius,desired.x+create_radius+1):
		for y in range(5,world.chunks.world_depth-5):
			var at:=Vector2i(x,y);var d: float=at.distance_squared_to(desired)
			if d<distance and _can_host(at):distance=d;chosen=at
	if chosen.x==2147483647:
		var y: int=clampi(desired.y,8,world.chunks.world_depth-8)
		if world.dimensions.active=="nether":y=mini(y,world.chunks.world_depth-1-70)
		else:y=clampi(world.chunks.get_surface_y(desired.x)-1,5,world.chunks.world_depth-8)
		for dx in range(create_radius+1):
			var at:=Vector2i(desired.x+dx,y);var protected: bool=false
			for xx in range(-2,4):
				for yy in range(-3,2):
					var cell: Vector2i=at+Vector2i(xx,yy)
					if world.get_block(cell)==id("bedrock") or world.chunks.edits.get(cell,0)!=0:protected=true
			if not protected:chosen=at;break
		if chosen.x==2147483647:return {}
	world.chunks.update_around(world.ground.to_global(world.ground.map_to_local(chosen)))
	_busy=true
	for x in range(-2,4):
		put(chosen+Vector2i(x,1),id("obsidian"))
		for y in range(-3,1):put(chosen+Vector2i(x,y),0)
	var result: Dictionary={"origin":[chosen.x,chosen.y],"width":2,"height":3}
	for cell in frame_cells(result,true):put(cell,id("obsidian"))
	# Optional corners are included in generated frames.
	for x in [-1,2]:
		for y in [-3,1]:put(chosen+Vector2i(x,y),id("obsidian"))
	_busy=false;activate(result);return result
func _process(dt: float) -> void:
	if world.dimensions.swapping:return
	_animation+=dt
	if _animation>=.1:_animation=fmod(_animation,.1);queue_redraw()
	for cell in fires.keys():
		if not world.chunks.is_cell_loaded(cell):continue
		var below: int=world.get_block(cell+Vector2i.DOWN)
		if below==id("netherrack") or below==id("soul_sand") or below==id("soul_soil"):continue
		fires[cell]-=dt
		if fires[cell]<=0 or below==0:put(cell,0)
	if world.player.survival_dead or world.player.spectator:dwell=0;return
	var player_cell: Vector2i=world.ground.local_to_map(world.ground.to_local(world.player.global_position))
	if world.get_block(player_cell)==id("fire") or world.get_block(player_cell+Vector2i.DOWN)==id("fire"):world.fluids.burning=maxf(world.fluids.burning,8)
	var touching: Dictionary={}
	var bounds: Rect2=world.player_collision.global_transform*world.player_collision.shape.get_rect()
	for record in records:
		var area: Rect2i=interior(record);var box: Rect2=world.ground.global_transform*Rect2(Vector2(area.position)*16,Vector2(area.size)*16)
		if box.intersects(bounds):touching=record;break
	if touching.is_empty():cooldown=maxf(0,cooldown-dt);dwell=maxf(0,dwell-dt*4);return
	if cooldown>0:cooldown=float(WorldDimensions.DATA.portal.cooldown_seconds);dwell=0;return
	if world.any_inventory_open() or world.chat.is_open:dwell=0;return
	dwell+=dt
	if not _pending and (dwell>=float(WorldDimensions.DATA.portal.creative_seconds if world.player.creative else WorldDimensions.DATA.portal.survival_seconds)):
		_pending=true;_travel.call_deferred(touching.duplicate(true))
func _travel(record: Dictionary) -> void:
	if record in records and intact(record) and not world.player.survival_dead:world.dimensions.travel("nether" if world.dimensions.active=="overworld" else "overworld",record)
	_pending=false;dwell=0
func _draw() -> void:
	if world==null:return
	var visible: Rect2=world.ground.get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	var first:=Vector2i(floori(visible.position.x/16)-1,floori(visible.position.y/16)-1)
	var last:=Vector2i(ceili(visible.end.x/16)+1,ceili(visible.end.y/16)+1)
	var bounds:=Rect2i(first,last-first)
	var frame: int=int(Time.get_ticks_msec()/100)
	for chunk: Vector2i in world.chunks.loaded_chunks:
		if not bounds.intersects(Rect2i(chunk*32,Vector2i(32,32))):continue
		var data: PackedInt32Array=world.chunks._block_cache.get(chunk,PackedInt32Array())
		for key in ["fire","nether_portal"]:
			var value: int=id(key);var index: int=data.find(value)
			while index>=0:
				var cell: Vector2i=chunk*32+Vector2i(index%32,index/32)
				if bounds.has_point(cell):
					if key=="fire" and not fires.has(cell):fires[cell]=float(WorldDimensions.DATA.environment.fire_seconds)
					var texture: Texture2D=FIRE if key=="fire" else PORTAL
					draw_texture_rect_region(texture,Rect2(to_local(world.ground.to_global(world.ground.map_to_local(cell)-Vector2(8,8))),Vector2(16,16)),Rect2(0,posmod(frame,texture.get_height()/16)*16,16,16),Color(1,1,1,.85 if key=="nether_portal" else 1))
				index=data.find(value,index+1)
func snapshot() -> Dictionary:
	var fire_records: Array=[]
	for cell in fires:fire_records.append([cell.x,cell.y,fires[cell]])
	return {"frames":records.duplicate(true),"fires":fire_records,"cooldown":cooldown}
func restore(data: Dictionary) -> void:
	clear();cooldown=float(data.get("cooldown",0))
	for record in data.get("frames",[]):
		if intact(record):records.append(record.duplicate(true))
	for record in data.get("fires",[]):
		var at:=Vector2i(record[0],record[1])
		if world.get_block(at)==id("fire"):fires[at]=float(record[2])
static func valid(data: Variant) -> bool:
	if not data is Dictionary:return false
	if not data.get("frames",[]) is Array or data.get("frames",[]).size()>10000 or not data.get("fires",[]) is Array or data.get("fires",[]).size()>100000 or not ContentCatalog._number(data.get("cooldown",0),0,60):return false
	for record in data.get("frames",[]):
		if not record is Dictionary or not ContentCatalog._vector(record.get("origin"),2,-10000000,10000000,true) or not ContentCatalog._number(record.get("width"),2,21,true) or not ContentCatalog._number(record.get("height"),3,21,true):return false
	for record in data.get("fires",[]):
		if not ContentCatalog._vector(record,3,-10000000,10000000) or not ContentCatalog._number(record[0],-10000000,10000000,true) or not ContentCatalog._number(record[1],-10000000,10000000,true) or record[2]<0 or record[2]>300:return false
	return true
