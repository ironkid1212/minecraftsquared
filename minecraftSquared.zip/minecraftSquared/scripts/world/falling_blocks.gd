class_name FallingBlocks
extends Node2D

## Full-size airborne blocks, separate from item pickups and static terrain.
## Positions are in Ground-local pixels. Swept grid tests prevent tunneling.
var world: Node2D
var updates: WorldUpdates
var bodies: Array[Dictionary] = []
var _next_id: int = 1

func setup(game: Node2D, owner_updates: WorldUpdates) -> void:
	world = game
	updates = owner_updates
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	process_priority = -70
	z_index = 2

func start(cell: Vector2i, block_id: int) -> bool:
	if bodies.size() >= updates.settings.max_falling_blocks or overlaps_cell(cell): return false
	var point: Vector2 = world.ground.map_to_local(cell)
	bodies.append({"uid": _next_id, "id": block_id, "position": point,
		"previous": point, "speed": 0.0})
	_next_id += 1
	# Register the entity first, then remove exactly one static block.
	world.chunks.set_block(cell, 0)
	queue_redraw()
	return true

func overlaps_cell(cell: Vector2i) -> bool:
	var bounds := Rect2(Vector2(world.ground.map_to_local(cell)) - Vector2(8, 8), Vector2(16, 16))
	for body in bodies:
		var current := Rect2(Vector2(body["position"]) - Vector2(8, 8), Vector2(16, 16))
		var previous := Rect2(Vector2(body["previous"]) - Vector2(8, 8), Vector2(16, 16))
		if bounds.intersects(current.merge(previous)): return true
	return false

func _physics_process(delta: float) -> void:
	if bodies.is_empty(): return
	if updates == null or not updates.settings.enabled:
		for body in bodies: body["previous"] = body["position"]
		return
	# Lower bodies settle first, so upper bodies see the new supporting tile.
	var ordered: Array[Dictionary] = bodies.duplicate()
	ordered.sort_custom(func(a: Dictionary, b: Dictionary): return Vector2(a["position"]).y > Vector2(b["position"]).y)
	for body in ordered:
		if body not in bodies: continue
		var point: Vector2 = body["position"]
		body["previous"] = point
		var cell: Vector2i = world.ground.local_to_map(point)
		if not updates._active(cell): continue
		var speed: float = minf(float(body["speed"]) + updates.settings.falling_gravity * delta, updates.settings.falling_terminal_speed)
		speed *= pow(updates.settings.falling_drag, delta * 20.0)
		body["speed"] = speed
		_advance(body, point.y + speed * delta)
	queue_redraw()

func _advance(body: Dictionary, desired_y: float) -> void:
	var point: Vector2 = body["position"]
	var column: int = world.ground.local_to_map(point).x
	var first_row: int = floori((point.y - 8.0 + 0.001) / 16.0)
	var last_row: int = floori((desired_y + 8.0 - 0.001) / 16.0)
	var limit: float = desired_y
	var land: bool = false
	var replaceable: Array[Vector2i] = []
	var through: Array = updates.rule_for(int(body["id"])).get("fall_through", ["air"])
	for row in range(first_row, last_row + 1):
		var cell := Vector2i(column, row)
		if row < world.chunks.min_world_y: continue
		var boundary: float = row * 16.0 - 8.0
		if row >= world.chunks.world_depth:
			limit = minf(limit, boundary)
			land = true
			break
		if not world.chunks.is_cell_loaded(cell):
			limit = maxf(point.y, minf(limit, boundary))
			body["speed"] = 0.0
			break
		var id: int = world.get_block(cell)
		var key: String = str(BlockDatabase.BLOCKS.get(id, {}).get("key", "air"))
		if key not in through:
			if boundary < point.y - 0.01:
				_drop(body)
				return
			limit = minf(limit, boundary)
			land = true
			break
		if id != 0 and not BlockDatabase.has_tag(id,"fluid"): replaceable.append(cell)
	# Dynamic blocks also support the falling column without merging entities.
	for other in bodies:
		if int(other["uid"]) == int(body["uid"]): continue
		var other_point: Vector2 = other["position"]
		if absf(other_point.x - point.x) > 0.01 or other_point.y < point.y + 0.01: continue
		var contact: float = other_point.y - 16.0
		if contact < limit:
			limit = maxf(point.y, contact)
			body["speed"] = minf(float(body["speed"]), float(other["speed"]))
			land = false
	for cell in replaceable:
		if cell.y * 16.0 < limit + 8.0 - 0.001:
			var id: int = world.get_block(cell)
			if id != 0: updates._remove_with_drops(cell, id)
	body["position"] = Vector2(point.x, limit)
	if land: _land(body)

func _land(body: Dictionary) -> void:
	var cell: Vector2i = world.ground.local_to_map(body["position"])
	if not world.chunks.is_cell_loaded(cell):
		body["speed"] = 0.0
		return
	var id: int = world.get_block(cell)
	var key: String = str(BlockDatabase.BLOCKS.get(id, {}).get("key", "air"))
	if key not in updates.rule_for(int(body["id"])).get("fall_through", ["air"]):
		_drop(body)
		return
	if id != 0: updates._remove_with_drops(cell, id)
	world.set_block(cell, int(body["id"]))
	bodies.erase(body)

func _drop(body: Dictionary) -> void:
	world.dropped_items.spawn_item(int(body["id"]), 1, world.ground.to_global(body["position"]))
	bodies.erase(body)

func _process(_delta: float) -> void:
	if not bodies.is_empty(): queue_redraw()

func _draw() -> void:
	if world == null: return
	var source: TileSetAtlasSource = world.atlas_source
	var fraction: float = clampf(Engine.get_physics_interpolation_fraction(), 0.0, 1.0)
	var canvas: Transform2D = get_global_transform_with_canvas()
	var inverse_canvas: Transform2D = canvas.affine_inverse()
	var visible_bounds: Rect2 = (inverse_canvas * get_viewport_rect()).grow(9)
	for body in bodies:
		var current: Vector2 = body["position"]
		var cell: Vector2i = world.ground.local_to_map(current)
		if not world.chunks.is_cell_loaded(cell): continue
		var point: Vector2 = Vector2(body["previous"]).lerp(current, fraction)
		if not visible_bounds.has_point(point): continue
		# Snap only final display pixels, preserving fractional simulation motion.
		point = inverse_canvas * (canvas * point).round()
		var block: Dictionary = BlockDatabase.BLOCKS[int(body["id"])]
		var tile: Vector2i = block["atlas"]
		var origin: Vector2i = source.margins + tile * (source.texture_region_size + source.separation)
		var tint: Color = block.get("tint", Color.WHITE) * world.lighting.render_tint(cell)
		draw_texture_rect_region(source.texture, Rect2(point - Vector2(8, 8), Vector2(16, 16)), Rect2(Vector2(origin), Vector2(source.texture_region_size)), tint)

func snapshot() -> Array:
	var result: Array = []
	for body in bodies:
		var point: Vector2 = body["position"]
		result.append({"item": str(BlockDatabase.BLOCKS[int(body["id"])]["key"]), "position": [point.x, point.y], "speed": float(body["speed"])})
	return result

func restore(records: Array) -> void:
	bodies.clear()
	for record in records:
		var point := Vector2(float(record["position"][0]), float(record["position"][1]))
		bodies.append({"uid": _next_id, "id": BlockDatabase.id_for(str(record["item"])),
			"position": point, "previous": point, "speed": float(record["speed"])})
		_next_id += 1
	queue_redraw()
