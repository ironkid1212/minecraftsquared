class_name StructureLoot
extends RefCounted
static var tables: Dictionary={}
static var enchantments: Array=DataFile.array_from("res://data/loot_enchantments.json")
static func generate(kind: String,seed_value: int) -> Array[Dictionary]:
	if not tables.has(kind):tables[kind]=DataFile.object_from("res://data/"+kind+"_loot.json")
	var rng:=RandomNumberGenerator.new();rng.seed=seed_value
	var stacks: Array[Dictionary]=[]
	for pool: Dictionary in tables[kind].pools:
		for roll in range(rng.randi_range(int(pool.rolls[0]),int(pool.rolls[1]))):
			var total: int=0
			for entry: Dictionary in pool.entries:total+=int(entry.weight)
			var ticket: int=rng.randi_range(1,total)
			for entry: Dictionary in pool.entries:
				ticket-=int(entry.weight)
				if ticket>0:continue
				if entry.item!="air":
					var tags: Dictionary={}
					if entry.get("gear_enchant",false):tags=EnchantmentDatabase.write({},EnchantmentDatabase.roll(BlockDatabase.id_for(entry.item),rng.randi_range(20,39),rng))
					if entry.get("enchant",false):
						var choices: Array=enchantments
						var choice: Dictionary=choices[rng.randi_range(0,choices.size()-1)]
						var level: int=rng.randi_range(1,int(EnchantmentDatabase.definitions()[str(choice.key).trim_prefix("minecraft:")].maximum))
						tags["StoredEnchantments"]=NBT.node(NBT.LIST,[NBT.node(NBT.COMPOUND,{"id":NBT.node(NBT.STRING,choice.key),"lvl":NBT.node(NBT.SHORT,level)})])
					stacks.append({"id":BlockDatabase.id_for(entry.item),"count":rng.randi_range(int(entry.count[0]),int(entry.count[1])),"tags":tags,"durability":ToolDatabase.max_durability(BlockDatabase.id_for(entry.item))})
				break
	return stacks
