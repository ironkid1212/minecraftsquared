class_name ChorusPlants
extends RefCounted
const SIDES: Array[Vector2i]=[Vector2i.LEFT,Vector2i.RIGHT,Vector2i.UP,Vector2i.DOWN]
static func stem(mask_value: int) -> int:return BlockDatabase.id_for("chorus_plant" if mask_value==0 else "chorus_plant_"+str(mask_value))
static func flower(age: int) -> int:return BlockDatabase.id_for("chorus_flower" if age==0 else "chorus_flower_"+str(clampi(age,0,5)))
static func age(id: int) -> int:
	var key: String=BlockDatabase.BLOCKS[id].key
	return int(key.get_slice("_",2)) if key!="chorus_flower" else 0
static func supported(chunks: ChunkWorld,cell: Vector2i) -> bool:
	var pending: Array[Vector2i]=[cell];var seen: Dictionary={cell:true};var cursor: int=0
	while cursor<pending.size() and cursor<256:
		var at: Vector2i=pending[cursor];cursor+=1
		if chunks.get_block(at+Vector2i.DOWN)==BlockDatabase.id_for("end_stone"):return true
		for side in SIDES:
			var next: Vector2i=at+side
			if not chunks.is_cell_loaded(next):return true
			if not seen.has(next) and BlockDatabase.has_tag(chunks.get_block(next),"chorus_stem"):seen[next]=true;pending.append(next)
	return cursor>=256
static func mask(chunks: ChunkWorld,cell: Vector2i) -> int:
	var value: int=0
	for i in range(4):
		var id: int=chunks.get_block(cell+SIDES[i])
		if BlockDatabase.has_tag(id,"chorus") or i==3 and id==BlockDatabase.id_for("end_stone"):value|=1<<i
	return value
static func can_place(chunks: ChunkWorld,cell: Vector2i) -> bool:
	var below: int=chunks.get_block(cell+Vector2i.DOWN)
	if below==BlockDatabase.id_for("end_stone") or BlockDatabase.has_tag(below,"chorus_stem"):return true
	if below!=0:return false
	var count: int=0
	for side in [Vector2i.LEFT,Vector2i.RIGHT]:
		if BlockDatabase.has_tag(chunks.get_block(cell+side),"chorus_stem"):count+=1
	return count==1
static func tick(updates: WorldUpdates,cell: Vector2i,id: int,random_tick: bool) -> void:
	if not supported(updates.chunks,cell):
		if BlockDatabase.has_tag(id,"chorus_flower"):updates.world.set_block(cell,0)
		else:updates._remove_with_drops(cell,id)
		return
	if BlockDatabase.has_tag(id,"chorus_stem"):
		var resolved: int=stem(mask(updates.chunks,cell))
		if resolved!=id:updates.world.set_block(cell,resolved)
		return
	var current_age: int=age(id)
	if not random_tick or current_age>=5:return
	var above: Vector2i=cell+Vector2i.UP
	if not updates.chunks.is_cell_loaded(above+Vector2i.UP) or updates.chunks.get_block(above)!=0 or updates.chunks.get_block(above+Vector2i.UP)!=0:return
	var length: int=1
	for i in range(1,6):
		if not BlockDatabase.has_tag(updates.chunks.get_block(cell+Vector2i.DOWN*i),"chorus_stem"):break
		length+=1
	var clear: bool=updates.chunks.get_block(above+Vector2i.LEFT)==0 and updates.chunks.get_block(above+Vector2i.RIGHT)==0
	if clear and (length<2 or length<=updates._rng.randi_range(0,4)):
		updates.world.set_block(cell,stem(12));updates.world.set_block(above,flower(current_age));return
	var branches: int=0
	if current_age<4:
		for side in [Vector2i.LEFT,Vector2i.RIGHT]:
			var next: Vector2i=cell+side
			if updates._rng.randf()>.6 or not updates.chunks.is_cell_loaded(next+side):continue
			if updates.chunks.get_block(next)==0 and updates.chunks.get_block(next+Vector2i.DOWN)==0 and updates.chunks.get_block(next+side)==0 and updates.chunks.get_block(next+Vector2i.UP)==0:
				updates.world.set_block(next,flower(current_age+1));branches+=1
	updates.world.set_block(cell,stem(mask(updates.chunks,cell)) if branches>0 else flower(5))
static func teleport_fruit(world: Node2D) -> bool:
	var start: Vector2i=world.mobs.cell(world.player.global_position)
	for i in range(16):
		var x: int=start.x+world.mobs.rng.randi_range(-8,8);var top: int=clampi(start.y+world.mobs.rng.randi_range(-8,8),1,world.chunks.world_depth-3)
		for y in range(top,world.chunks.world_depth-1):
			var cell:=Vector2i(x,y)
			if not world.chunks.is_cell_loaded(cell):break
			if not BlockDatabase.BLOCKS.get(world.get_block(cell),{}).get("solid",false):continue
			var target: Vector2=world.ground.to_global(world.ground.map_to_local(cell))-Vector2(0,22.05)
			if world.pearls.fits(target) and not BlockDatabase.has_tag(world.get_block(cell+Vector2i.UP),"fluid"):
				world.mobs.renderer.portal_burst(world.player.global_position);world.player.teleport_to(target);world.survival.reset_fall();world.food.motion_position=target;world.mobs.renderer.portal_burst(target);
				if world.effects!=null:world.effects.arrival("entity.enderman.teleport")
				return true
			break
	return false
