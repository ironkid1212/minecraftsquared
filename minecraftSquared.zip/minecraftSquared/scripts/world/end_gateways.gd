class_name EndGateways
extends Node2D
const PORTAL: Texture2D=preload("res://assets/environment/end/end_portal.png")
const SKY: Texture2D=preload("res://assets/environment/end/end_sky.png")
const BEAM: Texture2D=preload("res://assets/environment/end/gateway_beam.png")
var world: Node2D
var pairs: Array[Dictionary]=[]
var time: float=0
var cooldown: float=0
var order: Array[Vector2i]=[]
var rules: Dictionary
func setup(game: Node2D) -> void:
	world=game;rules=EndOuterGenerator.RULES.gateway;z_index=5;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	var blend:=CanvasItemMaterial.new();blend.blend_mode=CanvasItemMaterial.BLEND_MODE_ADD;material=blend
func clear() -> void:pairs.clear();order.clear();time=0;cooldown=0;queue_redraw()
static func feature(cell: Vector2i,center: Vector2i) -> int:
	var d: Vector2i=cell-center
	if absi(d.x)>1 or absi(d.y)>2:return -1
	if d==Vector2i.ZERO:return BlockDatabase.id_for("end_gateway")
	if absi(d.y)==1 or d.x==0 and absi(d.y)==2:return BlockDatabase.id_for("bedrock")
	return 0
func _make_order() -> void:
	if not order.is_empty():return
	for i in range(int(rules.maximum_pairs)):
		var side: int=1 if i%2==0 else -1
		order.append(Vector2i(side*(int(rules.main_distance)+(i/4)*8),255-int(rules.main_y)-(i/2%2)*8))
	var rng:=RandomNumberGenerator.new();rng.seed=world.world_seed^91471
	for i in range(order.size()-1,0,-1):
		var j: int=rng.randi_range(0,i);var temp: Vector2i=order[i];order[i]=order[j];order[j]=temp
func _place(center: Vector2i) -> void:
	for x in range(-1,2):
		for y in range(-2,3):world.end_fight._write(center+Vector2i(x,y),feature(center+Vector2i(x,y),center))
func award_victory() -> void:
	if not world.is_end() or pairs.size()>=int(rules.maximum_pairs):return
	_make_order();var center: Vector2i=order[pairs.size()]
	pairs.append({"main":center,"outer":Vector2i.ZERO,"linked":false,"age":0.0,"cooldown":0.0});_place(center);queue_redraw()
func _link(pair: Dictionary) -> void:
	var side: int=1 if pair.main.x>0 else -1;var target:=Vector2i.ZERO
	# Search the same 1024-to-1280-block direction as the original gateway.
	var offset: int=(absi(int(pair.main.x))-int(rules.main_distance))*4+absi(int(pair.main.y)-(255-int(rules.main_y)))*4
	for distance in range(int(rules.search_start)+offset,int(rules.search_limit)+1):
		var x: int=side*distance;var c: Dictionary=world.chunks.end.outer.column(x)
		if int(c.top)>=225 or int(c.top)<32:continue
		if int(world.chunks.end.outer.column(x-2).top)>=256 or int(world.chunks.end.outer.column(x+2).top)>=256:continue
		var rogue: Vector2i=world.chunks.end.outer.rogue_center(world.chunks.end.outer.region_at(x))
		if rogue!=Vector2i.ZERO and absi(rogue.x-x)<4:continue
		if world.chunks.end.cities.block_at(Vector2i(x,int(c.top)-int(rules.outer_height)))>=0:continue
		var crowded: bool=false
		for other in pairs:
			if other.linked and absi(int(other.outer.x)-x)<8:crowded=true;break
		if crowded:continue
		target=Vector2i(x,int(c.top)-int(rules.outer_height));break
	if target==Vector2i.ZERO:
		target=Vector2i(side*(int(rules.search_limit)+pairs.find(pair)*16),180)
		for x in range(-6,7):
			for depth in range(0,maxi(1,5-absi(x)/2)):world.end_fight._write(target+Vector2i(x,int(rules.outer_height)+depth),BlockDatabase.id_for("end_stone"))
	pair.outer=target;pair.linked=true;_place(target)
func centers(near_x: int) -> Array[Dictionary]:
	var result: Array[Dictionary]=[]
	for i in range(pairs.size()):
		result.append({"cell":pairs[i].main,"pair":i,"outer":false,"age":pairs[i].age,"cooldown":pairs[i].cooldown})
		if pairs[i].linked:result.append({"cell":pairs[i].outer,"pair":i,"outer":true,"age":pairs[i].age,"cooldown":pairs[i].cooldown})
	if absi(near_x)>=int(EndOuterGenerator.RULES.start_x)-32:
		var region: int=world.chunks.end.outer.region_at(near_x)
		for index in range(region-1,region+2):
			var cell: Vector2i=world.chunks.end.outer.rogue_center(index)
			if cell!=Vector2i.ZERO:result.append({"cell":cell,"pair":-1,"outer":true,"age":time+20,"cooldown":0.0})
	return result
func point(cell: Vector2i) -> Vector2:return world.ground.to_global(world.ground.map_to_local(cell))
func _safe_exit(center: Vector2i) -> Vector2:
	world.chunks.update_around(point(center))
	var candidates: Array[Vector2i]=[]
	for x in range(center.x-5,center.x+6):
		for y in range(maxi(2,center.y-4),mini(world.chunks.world_depth-1,center.y+32)):
			var cell:=Vector2i(x,y);var id: int=world.get_block(cell)
			if id==BlockDatabase.id_for("bedrock") or not BlockDatabase.BLOCKS.get(id,{}).get("solid",false):continue
			var at: Vector2=point(cell)-Vector2(0,22.05)
			if world.pearls.fits(at) and not BlockDatabase.has_tag(world.get_block(cell+Vector2i.UP),"fluid"):candidates.append(cell);break
	if not candidates.is_empty():
		candidates.sort_custom(func(a: Vector2i,b: Vector2i):return a.y<b.y if a.y!=b.y else absi(a.x-center.x)<absi(b.x-center.x))
		return point(candidates[0])-Vector2(0,22.05)
	# Isolated main-island gateway: land above its highest bedrock cap.
	var cap: Vector2i=center+Vector2i(0,-2)
	for dy in range(1,4):
		var cell: Vector2i=cap+Vector2i(0,-dy)
		if world.get_block(cell)!=0:world.end_fight._write(cell,0)
	return point(cap)-Vector2(0,22.05)
func teleport(record: Dictionary) -> bool:
	if not world.is_end() or cooldown>0 or world.player.spectator or world.player.survival_dead or world.get_block(record.cell)!=BlockDatabase.id_for("end_gateway"):return false
	var target: Vector2i
	if int(record.pair)<0:target=Vector2i(int(EndGenerator.RULES.arrival[0]),255-int(EndGenerator.RULES.arrival[1]))
	else:
		var pair: Dictionary=pairs[int(record.pair)]
		if pair.cooldown>0:return false
		if not pair.linked:_link(pair)
		target=pair.main if record.outer else pair.outer;pair.cooldown=float(rules.cooldown_seconds)
	var origin: Vector2=world.player.global_position;var destination: Vector2=_safe_exit(target)
	cooldown=float(rules.cooldown_seconds);world.mobs.renderer.portal_burst(origin);world.player.teleport_to(destination);world.chunks.update_around(destination);world.survival.reset_fall();world.food.motion_position=destination;world.mobs.renderer.portal_burst(destination);world.lighting.invalidate();world.clock.apply();
	if world.effects!=null:world.effects.arrival("entity.enderman.teleport")
	queue_redraw();return true
func pearl_segment(from: Vector2,to: Vector2,limit: float=INF) -> bool:
	if not world.is_end() or cooldown>0:return false
	var nearest: float=minf(from.distance_to(to),limit);var selected: Dictionary={}
	for record in centers(world.mobs.cell(from).x):
		if not world.chunks.is_cell_loaded(record.cell):continue
		var distance: float=PlayerCombat.ray_entry(from,to,Rect2(point(record.cell)-Vector2(8,8),Vector2(16,16)),nearest)
		if is_finite(distance) and distance<=nearest:nearest=distance;selected=record
	return teleport(selected) if not selected.is_empty() else false
func _process(dt: float) -> void:
	if not world.is_end():return
	time+=dt;cooldown=maxf(0,cooldown-dt)
	if pairs.is_empty() and world.end_fight.previously_killed:award_victory()
	for pair in pairs:pair.age+=dt;pair.cooldown=maxf(0,float(pair.cooldown)-dt)
	if not world.player.spectator and not world.player.survival_dead and cooldown==0:
		var body: Rect2=world.player_collision.global_transform*world.player_collision.shape.get_rect()
		for record in centers(world.mobs.cell(world.player.global_position).x):
			if world.chunks.is_cell_loaded(record.cell) and body.intersects(Rect2(point(record.cell)-Vector2(8,8),Vector2(16,16))):
				if teleport(record):break
	queue_redraw()
func _draw() -> void:
	if world==null or not world.is_end():return
	var view: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	for record in centers(world.mobs.cell(world.player.global_position).x):
		var at: Vector2=point(record.cell)
		if not world.chunks.is_cell_loaded(record.cell) or world.get_block(record.cell)!=BlockDatabase.id_for("end_gateway") or not view.grow(16).has_point(at):continue
		var bounds:=Rect2(at-Vector2(8,8),Vector2(16,16));draw_rect(bounds,Color("070817"))
		draw_texture_rect_region(SKY,bounds,Rect2(posmod(int(time*2),112),posmod(int(time),112),16,16),Color(.18,.25,.4))
		for i in range(3):draw_texture_rect_region(PORTAL,bounds,Rect2(posmod(int(time*(3+i))+i*41,240),posmod(int(time*(2+i))+i*71,240),16,16),Color(.3+i*.1,.7-i*.12,.8,.8))
		var pulse: bool=float(record.age)<float(rules.new_beam_seconds) or float(record.cooldown)>0 or fmod(time,float(rules.pulse_seconds))<2
		if pulse:
			var height: float=minf(512,view.size.y);var color:=Color(.8,.1,.8,.55) if float(record.age)<float(rules.new_beam_seconds) else Color(.5,.25,.8,.5)
			var above: float=maxf(0,minf(height,at.y-view.position.y));var below: float=maxf(0,minf(height,view.end.y-at.y))
			if above>0:draw_texture_rect_region(BEAM,Rect2(at.x-1.5,at.y-above,3,above),Rect2(0,0,BEAM.get_width(),BEAM.get_height()),color)
			if below>0:draw_texture_rect_region(BEAM,Rect2(at.x-1.5,at.y,3,below),Rect2(0,0,BEAM.get_width(),BEAM.get_height()),color)
func snapshot() -> Dictionary:
	if pairs.is_empty() and time==0:return {}
	var records: Array=[]
	for pair in pairs:records.append({"main":[pair.main.x,pair.main.y],"outer":[pair.outer.x,pair.outer.y],"linked":pair.linked,"age":pair.age,"cooldown":pair.cooldown})
	return {"version":1,"time":time,"pairs":records}
func restore(data: Dictionary) -> void:
	clear()
	if data.is_empty():return
	time=float(data.time)
	for pair in data.pairs:pairs.append({"main":Vector2i(pair.main[0],pair.main[1]),"outer":Vector2i(pair.outer[0],pair.outer[1]),"linked":pair.linked,"age":float(pair.age),"cooldown":float(pair.cooldown)})
static func valid(data: Variant) -> bool:
	if not data is Dictionary:return false
	if data.is_empty():return true
	if data.get("version")!=1 or not ContentCatalog._number(data.get("time"),0,1000000000) or not data.get("pairs") is Array or data.pairs.size()>20:return false
	var seen: Dictionary={};var exits: Dictionary={}
	for p in data.pairs:
		if not p is Dictionary or not ContentCatalog._vector(p.get("main"),2,-10000000,10000000,true) or not ContentCatalog._vector(p.get("outer"),2,-10000000,10000000,true) or not p.get("linked") is bool or not ContentCatalog._number(p.get("age"),0,1000000000) or not ContentCatalog._number(p.get("cooldown"),0,2):return false
		var center:=Vector2i(p.main[0],p.main[1])
		if center.y<3 or center.y>252 or seen.has(center):return false
		seen[center]=true
		if p.linked and (absf(p.outer[0])<int(EndOuterGenerator.RULES.start_x) or p.outer[1]<3 or p.outer[1]>252):return false
		if p.linked:
			var exit_cell:=Vector2i(p.outer[0],p.outer[1])
			if exits.has(exit_cell):return false
			exits[exit_cell]=true
	return true
