class_name TreeGenerator
extends RefCounted

# 2D adaptation of Java 1.21.1's oak/fancy_oak configured features.
# The parameters guide the shapes; this is not a Java-seed-matched 3D port.
var settings: TreeSettings = TreeSettings.new()
var log_id: int = BlockDatabase.ID.OAK_LOG
var leaf_id: int = BlockDatabase.ID.OAK_LEAVES

var _seed: int
var _trees: Dictionary = {}
var _foliage: Dictionary = {}
var _biomes: BiomeGenerator
var _birch_log: int = 0
var _birch_leaf: int = 0
var _spruce_log: int = 0
var _spruce_leaf: int = 0
var _acacia_log: int=0
var _acacia_leaf: int=0
var _vine: int=0
var _reference_shape: Dictionary = {}
var _variants: Array = []


func setup(world_seed: int, config: TreeSettings = null, biomes: BiomeGenerator = null) -> void:
	settings = config if config != null else TreeSettings.new()
	log_id = BlockDatabase.id_for(settings.log_block)
	leaf_id = BlockDatabase.id_for(settings.leaf_block)
	_reference_shape = DataFile.object_from(settings.fancy_shapes_path).get("reference",{})
	if not _reference_shape.get("rows") is Array or _reference_shape["rows"].is_empty() or not ContentCatalog._number(_reference_shape.get("anchor_column"),0,20,true):
		DataFile.fail("fancy_oak_shapes.json: reference rows and anchor column required.")
		return
	var width: int = str(_reference_shape["rows"][0]).length()
	if width<1 or width>settings.slot_width or int(_reference_shape["anchor_column"])>=width or _reference_shape["rows"].size()>24:
		DataFile.fail("fancy_oak_shapes.json: shape is outside tree-slot bounds.")
		return
	for row in _reference_shape["rows"]:
		if not row is String or row.length()!=width:
			DataFile.fail("fancy_oak_shapes.json: rows must have equal width.")
			return
		for symbol in row:
			if symbol not in [".","L","W","X"]: DataFile.fail("fancy_oak_shapes.json: use . air, L leaves, W logs, X logs with leaves.")
	_variants=[_reference_shape]
	for shape in DataFile.object_from(settings.fancy_shapes_path).get("variants",[]):
		if not shape is Dictionary or not shape.get("rows") is Array or shape["rows"].is_empty():
			DataFile.fail("Fancy oak variant needs nonempty rows.")
			continue
		var w: int=str(shape["rows"][0]).length()
		if w>settings.slot_width or not ContentCatalog._number(shape.get("anchor_column"),0,w-1,true):
			DataFile.fail("Fancy oak variant exceeds slot bounds.")
			continue
		var valid: bool=true
		for row in shape["rows"]:
			if not row is String or row.length()!=w: valid=false
			for symbol in str(row):
				if symbol not in [".","L","W","X"]: valid=false
		if valid: _variants.append(shape)
		else: DataFile.fail("Invalid fancy oak variant.")
	_seed = world_seed
	_biomes = biomes
	_acacia_log=BlockDatabase.id_for("acacia_log");_acacia_leaf=BlockDatabase.id_for("acacia_leaves");_vine=BlockDatabase.id_for("vine")
	_spruce_log=BlockDatabase.id_for("spruce_log")
	_spruce_leaf=BlockDatabase.id_for("spruce_leaves")
	_birch_log = BlockDatabase.id_for("birch_log")
	_birch_leaf = BlockDatabase.id_for("birch_leaves")
	_trees.clear()
	_foliage.clear()


func get_block(cell: Vector2i, surface_sampler: Callable, can_grow: Callable) -> int:
	var slot: int = floori(float(cell.x) / settings.slot_width)
	var result: int = BlockDatabase.ID.AIR
	for offset in range(-1, 2):
		var tree: Dictionary = _get_tree(slot + offset, surface_sampler, can_grow)
		var block_id: int = tree.get(cell, BlockDatabase.ID.AIR)
		if is_log(block_id):
			return block_id
		if block_id==_vine and result==0:result=block_id
		if is_leaf(block_id):
			result = block_id
	return result

func is_log(id: int) -> bool:
	return id == log_id or id == _birch_log or id == _spruce_log or id==_acacia_log

func is_leaf(id: int) -> bool:
	return id == leaf_id or id == _birch_leaf or id == _spruce_leaf or id==_acacia_leaf

func leaf_for_log(id: int) -> int:
	return _acacia_leaf if id==_acacia_log else _spruce_leaf if id==_spruce_log else _birch_leaf if id == _birch_log else leaf_id

func column_top(x: int, surface: int, surface_sampler: Callable, can_grow: Callable) -> int:
	# Use the generated shapes, so customized/fancy crowns cannot be skipped.
	var top: int = surface
	var slot: int = floori(float(x) / settings.slot_width)
	for offset in range(-1, 2):
		var tree: Dictionary = _get_tree(slot + offset, surface_sampler, can_grow)
		for cell in tree:
			if cell.x == x: top = mini(top, cell.y)
	return top


func has_leaf_overlay(cell: Vector2i, surface_sampler: Callable, can_grow: Callable) -> bool:
	var slot: int = floori(float(cell.x) / settings.slot_width)
	var inside_canopy: bool = false
	for offset in range(-1, 2):
		_get_tree(slot + offset, surface_sampler, can_grow)
		var canopy: Dictionary = _foliage[slot + offset]
		if int(canopy.get(cell,0))==2: return true
		if canopy.has(cell):
			inside_canopy = true
	# Every log in the generated foliage volume receives the cosmetic overlay.
	# Do not randomly expose individual canopy logs.
	return inside_canopy


func _get_tree(slot: int, surface_sampler: Callable, can_grow: Callable) -> Dictionary:
	if _trees.has(slot):
		return _trees[slot]
	var blocks: Dictionary = {}
	var foliage: Dictionary = {}
	_trees[slot] = blocks
	_foliage[slot] = foliage
	var rng := RandomNumberGenerator.new()
	rng.seed = _seed + slot * 73856093 + 197933
	var tree_roll: float = rng.randf()
	if _biomes == null and tree_roll > settings.tree_chance:
		return blocks
	var x: int = slot * settings.slot_width + settings.slot_width / 2 + rng.randi_range(-2, 2)
	if _biomes != null and tree_roll > clampf(float(_biomes.definition(x)["tree_chance"]) * settings.tree_chance / .8, 0, 1): return blocks
	if not bool(can_grow.call(x)):
		return blocks
	var base_y: int = int(surface_sampler.call(x)) - 1
	if _biomes!=null and str(_biomes.definition(x).get("tree_style","oak"))=="spruce":
		_build_spruce(blocks,foliage,x,base_y,rng)
		return blocks
	if _biomes!=null and _biomes.definition(x).get("tree_style","")=="acacia":
		_build_acacia(blocks,foliage,x,base_y,rng);return blocks
	if _biomes!=null and _biomes.definition(x).get("tree_style","")=="swamp":
		_build_swamp(blocks,foliage,x,base_y,rng);return blocks
	var birch: bool = _biomes != null and rng.randf() < float(_biomes.definition(x)["birch_chance"])
	if birch:
		_build_regular(blocks, foliage, x, base_y, rng.randi_range(5, 7), rng)
		for cell in blocks:
			blocks[cell] = _birch_log if blocks[cell] == log_id else _birch_leaf
		return blocks
	if rng.randf() < settings.fancy_oak_chance:
		# Fancy configuration: base 3 + random 0..11.
		# Compact rolls use ordinary crowns in this 2D adaptation.
		var configured_height: int = rng.randi_range(settings.fancy_height.x, settings.fancy_height.y)
		if configured_height >= 7:
			_build_fancy(blocks, foliage, x, base_y, configured_height, rng)
		else:
			_build_regular(blocks, foliage, x, base_y, rng.randi_range(settings.regular_height.x, settings.regular_height.y), rng)
	else:
		# Ordinary oak configuration: straight trunk 4 + random 0..2.
		_build_regular(blocks, foliage, x, base_y, rng.randi_range(settings.regular_height.x, settings.regular_height.y), rng)
	return blocks


func _build_regular(blocks: Dictionary, foliage: Dictionary, x: int,
		base_y: int, height: int, rng: RandomNumberGenerator) -> void:
	_place_trunk(blocks, x, base_y, height)
	# Foliage attaches above the last log. Four rows translate the blob
	# placer's height-3 vertical span: broad lower rows, compact cap.
	var attachment_y: int = base_y - height
	var radii: Array[int] = [1, 1, 2, 2]
	for row in range(radii.size()):
		_leaf_row(blocks, foliage, Vector2i(x, attachment_y + row),
			radii[row], row, rng)


func _build_fancy_legacy(blocks: Dictionary, foliage: Dictionary, x: int,
		base_y: int, height: int, rng: RandomNumberGenerator) -> void:
	# The branch layout is a 2D design choice: a main stem with upper
	# foliage attachments, ascending branches, and layered leaf clusters.
	var main_height: int = maxi(5, floori(height * 0.7))
	_place_trunk(blocks, x, base_y, main_height)
	var stem_tip := Vector2i(x, base_y - main_height + 1)
	var crown_center := Vector2i(x, base_y - height + 3)
	_log_line(blocks, stem_tip, crown_center + Vector2i(0, 1))
	_fancy_cluster(blocks, foliage, crown_center, rng)

	var lowest_level: int = maxi(3, floori(height * 0.4))
	var highest_level: int = height - 4
	for level in range(highest_level, lowest_level - 1, -2):
		var fraction: float = float(level) / float(height)
		var envelope: float = sqrt(maxf(0.0,
			1.0 - pow((fraction - 0.55) / 0.55, 2.0)))
		var spread: int = clampi(roundi(envelope * height * 0.32), 2, 5)
		for direction in [-1, 1]:
			if level != highest_level and rng.randf() < 0.3:
				continue
			var node := Vector2i(
				x + direction * maxi(2, spread + rng.randi_range(-1, 0)),
				base_y - level + rng.randi_range(-1, 0)
			)
			var attachment_level: int = clampi(level - spread, 2, main_height - 1)
			var start := Vector2i(x, base_y - attachment_level + 1)
			_log_line(blocks, start, node + Vector2i(0, 1))
			_fancy_cluster(blocks, foliage, node, rng)


func _place_trunk(blocks: Dictionary, x: int, base_y: int, height: int) -> void:
	for offset in range(height):
		blocks[Vector2i(x, base_y - offset)] = log_id


func _log_line(blocks: Dictionary, a: Vector2i, b: Vector2i) -> void:
	var steps: int = maxi(absi(b.x - a.x), absi(b.y - a.y))
	var previous: Vector2i = a
	blocks[a] = log_id
	for index in range(1, steps + 1):
		var sample: Vector2 = Vector2(a).lerp(Vector2(b), float(index) / float(steps))
		var cell := Vector2i(roundi(sample.x), roundi(sample.y))
		# Keep diagonal branch steps connected in our 2D grid.
		if cell.x != previous.x and cell.y != previous.y:
			blocks[Vector2i(cell.x, previous.y)] = log_id
		blocks[cell] = log_id
		previous = cell


func _fancy_cluster(blocks: Dictionary, foliage: Dictionary,
		center: Vector2i, rng: RandomNumberGenerator) -> void:
	var radii: Array[int] = [1, 2, 2, 1]
	for row in range(radii.size()):
		_leaf_row(blocks, foliage, center + Vector2i(0, row - 2),
			radii[row], row, rng)


func _leaf_row(blocks: Dictionary, foliage: Dictionary, center: Vector2i,
		radius: int, row: int, rng: RandomNumberGenerator) -> void:
	for dx in range(-radius, radius + 1):
		# Translate 3D corner variation into occasional trims at row ends.
		# Never punch random holes through a crown's interior.
		if absi(dx) == radius and radius > 1:
			var trim_chance: float = 0.15 if row == 3 else 0.08
			if rng.randf() < trim_chance:
				continue
		var cell: Vector2i = center + Vector2i(dx, 0)
		foliage[cell] = true
		if blocks.get(cell, BlockDatabase.ID.AIR) != log_id:
			blocks[cell] = leaf_id


func retain_slots_near(minimum_x: int, maximum_x: int) -> void:
	var first: int = floori(float(minimum_x) / settings.slot_width) - 1
	var last: int = floori(float(maximum_x) / settings.slot_width) + 1
	for slot in _trees.keys():
		if slot < first or slot > last:
			_trees.erase(slot)
			_foliage.erase(slot)

func _build_fancy(blocks: Dictionary, foliage: Dictionary, x: int,
		base_y: int, height: int, rng: RandomNumberGenerator) -> void:
	if settings.fancy_revision==1:
		_build_fancy_legacy(blocks,foliage,x,base_y,height,rng)
		return
	# The supplied PNG is a 7x8-block tree at 32 pixels per block. A trunk
	# is ONE block wide. X preserves a log with a guaranteed cosmetic leaf overlay.
	var shape: Dictionary=_variants[rng.randi_range(0,_variants.size()-1)] if settings.fancy_revision>=3 else _reference_shape
	var rows: Array=shape.get("rows",[])
	if rows.is_empty(): return
	var anchor: int=int(shape["anchor_column"])
	var extra: int=clampi(height-rows.size(),0,settings.fancy_extra_trunk)
	var mirror: int=-1 if rng.randf()<settings.fancy_mirror_chance else 1
	var top: int=base_y-rows.size()+1-extra
	for row in range(rows.size()):
		for column in range(str(rows[row]).length()):
			var symbol: String=str(rows[row])[column]
			if symbol==".": continue
			var cell:=Vector2i(x+(column-anchor)*mirror,top+row)
			blocks[cell]=leaf_id if symbol=="L" else log_id
			if symbol=="L" or symbol=="X": foliage[cell]=2 if symbol=="X" else 1
	for step in range(extra): blocks[Vector2i(x,base_y-step)]=log_id


func _build_spruce(blocks: Dictionary, foliage: Dictionary, x: int, base_y: int, rng: RandomNumberGenerator) -> void:
	var height: int=rng.randi_range(7,10)
	for y in range(height): blocks[Vector2i(x,base_y-y)]=_spruce_log
	var top: int=base_y-height
	var maximum: int=rng.randi_range(2,3)
	for row in range(height-1):
		var radius: int=0 if row==0 else mini(maximum,1+row/2)
		if row>2 and row%3==0: radius=maxi(1,radius-1)
		for dx in range(-radius,radius+1):
			var cell:=Vector2i(x+dx,top+row)
			foliage[cell]=2 if blocks.get(cell,0)==_spruce_log else 1
			if blocks.get(cell,0)!=_spruce_log: blocks[cell]=_spruce_leaf

func _build_acacia(blocks: Dictionary,foliage: Dictionary,x: int,base_y: int,rng: RandomNumberGenerator) -> void:
	var height: int=rng.randi_range(5,7);var side: int=-1 if rng.randf()<.5 else 1
	for dy in range(height):blocks[Vector2i(x,base_y-dy)]=_acacia_log
	var crown:=Vector2i(x+side,base_y-height+1)
	blocks[crown]=_acacia_log;blocks[crown+Vector2i(side,0)]=_acacia_log
	for row in range(2):
		for dx in range(-3+row,4-row):
			var cell: Vector2i=crown+Vector2i(dx,-row)
			foliage[cell]=2 if blocks.get(cell,0)==_acacia_log else 1
			if blocks.get(cell,0)!=_acacia_log:blocks[cell]=_acacia_leaf
	if rng.randf()<.65:
		var branch:=Vector2i(x-side,base_y-height+3)
		blocks[branch]=_acacia_log;foliage[branch]=2
		for dx in range(-1,2):
			var cell: Vector2i=branch+Vector2i(dx,-1);foliage[cell]=2 if blocks.get(cell,0)==_acacia_log else 1
			if blocks.get(cell,0)!=_acacia_log:blocks[cell]=_acacia_leaf

func _build_swamp(blocks: Dictionary,foliage: Dictionary,x: int,base_y: int,rng: RandomNumberGenerator) -> void:
	_build_regular(blocks,foliage,x,base_y,rng.randi_range(5,7),rng)
	for side in [-2,2]:
		var bottom: int=-100000
		for cell in blocks:
			if cell.x==x+side and blocks[cell]==leaf_id:bottom=maxi(bottom,cell.y)
		if bottom<-99999 or rng.randf()>.8:continue
		for i in range(1,rng.randi_range(1,3)+1):
			var cell:=Vector2i(x+side,bottom+i)
			if cell.y>=base_y or blocks.has(cell):break
			blocks[cell]=_vine
