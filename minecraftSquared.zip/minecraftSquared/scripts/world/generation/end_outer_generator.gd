class_name EndOuterGenerator
extends RefCounted
static var RULES: Dictionary=DataFile.object_from("res://data/end_outer.json")
var seed_value: int=0
var noise:=FastNoiseLite.new()
var regions: Dictionary={}
var columns: Dictionary={}
func setup(value: int) -> void:
	seed_value=value;regions.clear();columns.clear();noise.seed=value^91743;noise.frequency=.035;noise.fractal_octaves=3
func rng_for(region: int,salt: int=0) -> RandomNumberGenerator:
	var rng:=RandomNumberGenerator.new();rng.seed=seed_value^(region*1831565813)^salt;return rng
func region_at(x: int) -> int:return floori(float(x)/int(RULES.region_width))
func plan(region: int) -> Dictionary:
	if regions.has(region):return regions[region]
	if regions.size()>=int(RULES.cache_regions):regions.erase(regions.keys()[0])
	var rng: RandomNumberGenerator=rng_for(region,12977);var width: int=RULES.region_width;var origin: int=region*width;var islands: Array[Dictionary]=[]
	if rng.randf()<float(RULES.large_chance):
		islands.append({"x":origin+rng.randi_range(92,width-92),"radius":rng.randi_range(RULES.large_radius[0],RULES.large_radius[1]),"y":255-rng.randi_range(RULES.surface_y[0],RULES.surface_y[1]),"depth":rng.randi_range(RULES.thickness[0],RULES.thickness[1]),"large":true})
	for i in range(rng.randi_range(RULES.small_count[0],RULES.small_count[1])):
		var x: int=origin+rng.randi_range(12,width-12);var radius: int=rng.randi_range(RULES.small_radius[0],RULES.small_radius[1]);var overlap: bool=false
		for island in islands:
			if absf(x-int(island.x))<radius+int(island.radius)+8:overlap=true;break
		if not overlap:islands.append({"x":x,"radius":radius,"y":255-rng.randi_range(RULES.small_y[0],RULES.small_y[1]),"depth":maxi(3,radius),"large":false})
	var result: Dictionary={"islands":islands};regions[region]=result;return result
func column(x: int) -> Dictionary:
	if columns.has(x):return columns[x]
	if columns.size()>=4096:columns.erase(columns.keys()[0])
	var result: Dictionary={"top":256,"bottom":-1,"biome":"small_end_islands","large":false}
	if absi(x)>=int(RULES.start_x):
		for region in range(region_at(x)-1,region_at(x)+2):
			for island in plan(region).islands:
				var distance: float=absf(x-int(island.x))/float(island.radius)
				if distance>=1:continue
				var edge: float=smoothstep(.55,1,distance);var top: int=int(island.y)+roundi(edge*(10 if island.large else 3)+noise.get_noise_1d(x)*2)
				var bottom: int=int(island.y)+maxi(2,roundi(float(island.depth)*sqrt(1-distance*distance)))
				if top>bottom:continue
				if top<int(result.top):result={"top":top,"bottom":bottom,"biome":("end_highlands" if distance<.5 else "end_midlands" if distance<.82 else "end_barrens") if island.large else "small_end_islands","large":island.large}
	columns[x]=result;return result
func _branch(cells: Dictionary,at: Vector2i,rng: RandomNumberGenerator,depth: int,root: Vector2i) -> void:
	var height: int=rng.randi_range(2,5) if depth==0 else rng.randi_range(1,3)
	for i in range(height):
		var cell: Vector2i=at+Vector2i.UP*i
		if root.y-cell.y>16 or cells.has(cell):return
		var neighbors: int=0
		for side in ChorusPlants.SIDES:
			if cells.has(cell+side):neighbors+=1
		if neighbors>1:
			if i>0:cells[cell+Vector2i.DOWN]=17
			return
		cells[cell]=0
	var tip: Vector2i=at+Vector2i.UP*(height-1);var branches: int=0
	if depth<3:
		for side in [-1,1]:
			if rng.randf()<(.8 if depth==0 else .45) and absi(tip.x+side*2-root.x)<7:
				var connector: Vector2i=tip+Vector2i(side,0);var next: Vector2i=tip+Vector2i(side*2,0)
				if cells.has(connector) or cells.has(next) or cells.has(next+Vector2i.DOWN) or cells.has(next+Vector2i.UP):continue
				var connector_neighbors: int=0;var next_neighbors: int=0
				for direction in ChorusPlants.SIDES:
					if cells.has(connector+direction):connector_neighbors+=1
					if cells.has(next+direction):next_neighbors+=1
				if connector_neighbors!=1 or next_neighbors!=0:continue
				cells[connector]=0;cells[next]=0;_branch(cells,next+Vector2i.UP,rng,depth+1,root);branches+=1
	if branches==0:cells[tip]=17
func plants(region: int) -> Dictionary:
	var data: Dictionary=plan(region)
	if data.has("plants"):return data.plants
	var cells: Dictionary={};var rng: RandomNumberGenerator=rng_for(region,64717);var width: int=RULES.region_width
	for x0 in range(region*width,(region+1)*width,int(RULES.chorus_spacing)):
		var x: int=x0+rng.randi_range(0,4);var c: Dictionary=column(x)
		if c.biome!="end_highlands" or rng.randf()>float(RULES.chorus_chance):continue
		_branch(cells,Vector2i(x,int(c.top)-1),rng,0,Vector2i(x,int(c.top)-1))
	data.plants=cells;data.tops={}
	for cell: Vector2i in cells:data.tops[cell.x]=mini(int(data.tops.get(cell.x,256)),cell.y)
	return cells
func plant_at(cell: Vector2i) -> int:
	var group: Dictionary={}
	for region in range(region_at(cell.x)-1,region_at(cell.x)+2):
		var cells: Dictionary=plants(region)
		if cells.has(cell):group=cells;break
	if group.is_empty():return 0
	if group[cell]==17:return BlockDatabase.id_for("chorus_flower_5")
	var mask_value: int=0
	for i in range(4):
		var next: Vector2i=cell+ChorusPlants.SIDES[i]
		if group.has(next) or i==3 and next.y==int(column(next.x).top):mask_value|=1<<i
	return ChorusPlants.stem(mask_value)
func rogue_center(region: int) -> Vector2i:
	var data: Dictionary=plan(region)
	if data.has("gateway"):return data.gateway
	data.gateway=Vector2i.ZERO
	var rng: RandomNumberGenerator=rng_for(region,12003)
	if rng.randf()>=float(RULES.gateway.rogue_chance):return Vector2i.ZERO
	for island in plan(region).islands:
		var x: int=island.x
		if absi(x)>=int(RULES.start_x) and island.large:
			data.gateway=Vector2i(x,int(column(x).top)-int(RULES.gateway.outer_height));return data.gateway
	return Vector2i.ZERO
func block_at(cell: Vector2i) -> int:
	var c: Dictionary=column(cell.x)
	if cell.y>=int(c.top) and cell.y<=int(c.bottom):return BlockDatabase.id_for("end_stone")
	var gateway: Vector2i=rogue_center(region_at(cell.x));var feature: int=EndGateways.feature(cell,gateway) if gateway!=Vector2i.ZERO else -1
	if feature>=0:return feature
	if int(c.top)>=256:return 0
	return plant_at(cell) if cell.y<int(c.top) and cell.y>=int(c.top)-18 else 0
func column_top(x: int) -> int:
	var top: int=column(x).top
	for region in range(region_at(x)-1,region_at(x)+2):
		plants(region)
		top=mini(top,int(plan(region).tops.get(x,256)))
	var gateway: Vector2i=rogue_center(region_at(x))
	if gateway!=Vector2i.ZERO and absi(gateway.x-x)<=1:top=mini(top,gateway.y-2)
	return top
static func valid() -> bool:
	var r: Dictionary=RULES
	if r.get("version")!=1 or not ContentCatalog._number(r.get("start_x"),256,8192,true) or not ContentCatalog._number(r.get("region_width"),192,512,true):return false
	for key in ["large_radius","small_radius","small_count","surface_y","thickness","small_y"]:
		if not ContentCatalog._vector(r.get(key),2,1,100,true) or r[key][0]>r[key][1]:return false
	for key in ["large_chance","chorus_chance"]:
		if not ContentCatalog._number(r.get(key),0,1):return false
	if not ContentCatalog._number(r.get("chorus_spacing"),8,64,true) or not ContentCatalog._number(r.get("cache_regions"),8,128,true) or not r.get("gateway") is Dictionary or not r.get("biomes") is Dictionary:return false
	for key in ["end_highlands","end_midlands","end_barrens","small_end_islands"]:
		if not r.biomes.get(key) is String:return false
	var g: Dictionary=r.gateway
	for key in ["maximum_pairs","main_distance","main_y","search_start","search_limit","outer_height","cooldown_seconds","new_beam_seconds","pulse_seconds"]:
		if not ContentCatalog._number(g.get(key),1,8192):return false
	for key in ["maximum_pairs","main_distance","main_y","search_start","search_limit","outer_height"]:
		if not ContentCatalog._number(g.get(key),1,8192,true):return false
	if g.main_y>200 or g.outer_height>32 or r.small_count[1]>8:return false
	return g.maximum_pairs<=20 and g.search_start>=r.start_x and g.search_start<=g.search_limit and ContentCatalog._number(g.get("rogue_chance"),0,1)
