class_name NoiseCaves
extends RefCounted

## Continuous world-coordinate density fields: no chunk seams or repeated rooms.
## A 2D adaptation of cheese, spaghetti and noodle caves, with a protected soil cap.
var config: CaveSettings
var depth: int
var cheese: FastNoiseLite
var spaghetti: FastNoiseLite
var gate: FastNoiseLite
var noodles: FastNoiseLite
var warp: FastNoiseLite
var pillars: FastNoiseLite
var _seed: int
var _entrances: Dictionary = {}

func _noise(seed_value: int, frequency: float) -> FastNoiseLite:
	var n := FastNoiseLite.new()
	n.seed = seed_value
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.fractal_type = FastNoiseLite.FRACTAL_NONE
	n.frequency = frequency
	return n

func setup(seed_value: int, world_depth: int, settings: CaveSettings) -> void:
	config = settings
	depth = world_depth
	_seed = seed_value
	cheese = _noise(seed_value + 4903, config.cavern_frequency)
	spaghetti = _noise(seed_value + 7319, config.tunnel_frequency)
	gate = _noise(seed_value + 11329, 0.009)
	noodles = _noise(seed_value + 17011, config.tunnel_frequency * 1.5)
	warp = _noise(seed_value + 22303, 0.012)
	pillars = _noise(seed_value + 31013, 0.045)
	_entrances.clear()

func is_cave(cell: Vector2i, surface: Callable) -> bool:
	var cover: int = cell.y - int(surface.call(cell.x))
	if cover < -1 or cell.y >= depth - config.bottom_margin: return false
	if _entrance(cell, surface): return true
	if cover < config.surface_cap: return false
	var x: float = cell.x + 18371.25
	var y: float = cell.y + 27431.5
	var bend: float = warp.get_noise_2d(x, y) * 15.0
	var region: float = gate.get_noise_2d(x, y)
	# Fade chambers away from the surface and bottom, keeping a substantial roof.
	var edge: float = 1.0 - minf(smoothstep(config.surface_cap, config.surface_cap + 18, cover), smoothstep(3, 12, depth - cell.y))
	var chamber_density: float = cheese.get_noise_2d(x, y * 1.6)
	var pillar_limit: float = 0.64
	if config.layered_caverns:
		# Broad deep caverns retain shelves and rock columns; tunnels intersect
		# the same field independently, so chamber entrances have no grid seams.
		chamber_density = cheese.get_noise_2d(x + bend * .35, y * config.cavern_vertical_scale)
		chamber_density -= config.cavern_shelf_strength * pillars.get_noise_2d(x * .4, y * 2.2)
		chamber_density += smoothstep(24, 90, cover) * .035
		pillar_limit = config.cavern_pillar_threshold
	if config.rooms_enabled and chamber_density > config.cavern_threshold + edge * 0.45:
		if pillars.get_noise_2d(x, y * 0.4) < pillar_limit: return true
	if region > config.tunnel_region_threshold and _tunnel(spaghetti, x + bend, y * 1.3, 1.3, config.tunnel_width, config.spaghetti_min_radius): return true
	if config.noodles_enabled and region > 0.28 and _tunnel(noodles, x - bend, y * 1.6, 1.6, config.noodle_width, 1.1): return true
	return false

func _tunnel(field: FastNoiseLite, x: float, y: float, vertical_scale: float, width: float, radius: float) -> bool:
	var signed_value: float = field.get_noise_2d(x, y)
	if absf(signed_value) < width: return true
	# Convert the local density gradient to distance. A fixed noise threshold
	# alone makes steep contour segments collapse to one-cell dotted passages.
	if absf(signed_value) > maxf(width, radius * config.tunnel_frequency * 5.0): return false
	var gradient := Vector2(field.get_noise_2d(x + 1, y) - signed_value,
		field.get_noise_2d(x, y + vertical_scale) - signed_value)
	return absf(signed_value) < radius * gradient.length()

func _entrance(cell: Vector2i, surface: Callable) -> bool:
	if config.entrance_every <= 0: return false
	var width: int = config.region_width * config.entrance_every
	var center: int = floori(float(cell.x) / width)
	# Entrances can bend across their seed-region boundary. Query every region
	# whose path could overlap this column, including when the grid is very small.
	var reach: int = ceili((62.0 + config.entrance_radius * 2.1) / width)
	for region in range(center - reach, center + reach + 1):
		if _entrance_from(region, width, cell, surface): return true
	return false

func _entrance_from(region: int, width: int, cell: Vector2i, surface: Callable) -> bool:
	if not _entrances.has(region):
		var rng := RandomNumberGenerator.new()
		rng.seed = _seed + region * 92837111 + 60493
		var margin: int = mini(16, width / 4)
		var x: int = region * width + rng.randi_range(margin, width - margin - 1)
		_entrances[region] = {"mouth": Vector2i(x, int(surface.call(x))), "length": rng.randf_range(28, 58), "slope": rng.randf_range(0.4, 0.9) * (-1 if rng.randf() < 0.5 else 1), "phase": rng.randf_range(0, TAU)}
	var entry: Dictionary = _entrances[region]
	var mouth: Vector2i = entry["mouth"]
	var dy: float = cell.y - mouth.y
	if dy < -1 or dy > float(entry["length"]): return false
	var center: float = mouth.x + dy * float(entry["slope"]) + (sin(dy * 0.12 + float(entry["phase"])) - sin(float(entry["phase"]))) * 4.0
	return absf(cell.x - center) < config.entrance_radius * (1.0 + dy * 0.018)

func retain_near(minimum_x: int, maximum_x: int) -> void:
	var width: int = config.region_width * maxi(1, config.entrance_every)
	for region in _entrances.keys():
		if region < floori(float(minimum_x) / width) - ceili((62.0 + config.entrance_radius * 2.1) / width) or region > floori(float(maximum_x) / width) + ceili((62.0 + config.entrance_radius * 2.1) / width): _entrances.erase(region)
