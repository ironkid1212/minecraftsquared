class_name NetherFortresses
extends RefCounted
var _generator: WeakRef
var generator: NetherGenerator:
	get:return _generator.get_ref() if _generator!=null else null
var plans: Dictionary={}
func setup(host: NetherGenerator) -> void:_generator=weakref(host);plans.clear()
func region_at(x: int) -> int:
	var width: int=int(generator.config.fortress_layout.region_width) if int(generator.config.get("revision",1))>=2 else int(WorldDimensions.DATA.fortress.region_width)
	return floori(float(x)/width)
func plan(region: int) -> Dictionary:
	if int(generator.config.get("revision",1))<2:return _legacy_plan(region)
	if plans.has(region):return plans[region]
	var result: Dictionary=FortressLayout.new().build(generator,region)
	plans[region]=result
	if plans.size()>64:plans.erase(plans.keys()[0])
	return result
func contains(cell: Vector2i) -> bool:
	var p: Dictionary=plan(region_at(cell.x))
	for part in p.get("pieces",[]):
		if part.bounds.has_point(cell):return true
	return false
func _legacy_plan(region: int) -> Dictionary:
	if plans.has(region):return plans[region]
	var result: Dictionary={"blocks":{},"walls":{},"containers":{},"spawners":{},"kind":"fortress","origin":Vector2i.ZERO}
	plans[region]=result
	if plans.size()>64:plans.erase(plans.keys()[0])
	if not generator.config.get("fortresses",true):return result
	var rule: Dictionary=WorldDimensions.DATA.fortress
	var rng:=RandomNumberGenerator.new();rng.seed=generator.seed+region*73428767+994911
	if rng.randf()>float(rule.chance):return result
	var x: int=region*int(rule.region_width)+rng.randi_range(64,int(rule.region_width)-64)
	var y: int=clampi(int(generator.column(x).floor)-5,58,88)
	var at:=Vector2i(x,y);result.origin=at
	var half: int=int(rule.half_width);var level: int=int(rule.level_spacing)
	# Continuous bridges and open-sided galleries preserve a navigable 2D route.
	for row in [0,-level]:
		for dx in range(-half,half+1):
			put(result,at+Vector2i(dx,row),"nether_bricks")
			for dy in range(-5,0):put(result,at+Vector2i(dx,row+dy),"air")
			if absi(dx)<half-2 and posmod(dx,7)==0:put(result,at+Vector2i(dx,row-1),"nether_brick_fence")
		for dx in range(-16,17):
			put(result,at+Vector2i(dx,row-5),"nether_bricks")
			for dy in range(-4,0):result.walls[at+Vector2i(dx,row+dy)]=BlockDatabase.id_for("nether_bricks")
	# Pillars reach down into the natural cavern rather than floating rooms.
	for dx in [-half+4,-19,19,half-4]:
		for dy in range(1,mini(26,127-y-5)):put(result,at+Vector2i(dx,dy),"nether_bricks")
	# A ladder connects both decks. Background walls provide attachment.
	for dy in range(-level-3,0):
		put(result,at+Vector2i(0,dy),"ladder");result.walls[at+Vector2i(0,dy)]=BlockDatabase.id_for("nether_bricks")
	var spawner: Vector2i=at+Vector2i(-11,-level-1);put(result,spawner,"spawner");result.spawners[spawner]="blaze"
	for dx in [12,-25]:
		var chest: Vector2i=at+Vector2i(dx,-1);put(result,chest,"chest");result.containers[chest]="nether_bridge"
	for dx in range(4,10):
		put(result,at+Vector2i(dx,0),"soul_sand");put(result,at+Vector2i(dx,-1),"nether_wart_stage"+str(rng.randi_range(0,3)))
	return result
func put(result: Dictionary,at: Vector2i,key: String) -> void:result.blocks[at]=BlockDatabase.id_for(key)
func block_at(cell: Vector2i) -> int:return int(plan(region_at(cell.x)).blocks.get(cell,-1))
func wall_at(cell: Vector2i) -> int:return int(plan(region_at(cell.x)).walls.get(cell,0))
func wall_override(cell: Vector2i) -> int:return int(plan(region_at(cell.x)).walls.get(cell,-1))
