class_name VegetationGenerator
extends RefCounted
var biomes: BiomeGenerator
var seed_value: int
var columns: Dictionary = {}

func setup(seed_number: int, sampler: BiomeGenerator) -> void:
	seed_value = seed_number
	biomes = sampler
	columns.clear()

func _roll(x: int, salt: int) -> float:
	var value: int = (x * 374761393 + seed_value + salt) & 0x7fffffff
	value = ((value ^ (value >> 13)) * 1274126177) & 0x7fffffff
	return float(value ^ (value >> 16)) / 2147483647.0

func profile(x: int, tree_at: Callable) -> Dictionary:
	if columns.has(x): return columns[x]
	var result: Dictionary = {}
	var surface: int = int(biomes.column(x)["surface"])
	var choice: float = _roll(x, 19871)
	var flower_patch: float = lerpf(.15, 2.5, smoothstep(-.2, .35, biomes.sample("flower_patches", x)))
	for entry in biomes.definition(x)["plants"]:
		choice -= float(entry["chance"]) * (flower_patch if entry.get("patch", false) else 1.0)
		if choice > 0: continue
		var key: String = str(entry["block"])
		var height: int = int(entry["height"])
		if key == "cactus":
			# Empty sides and spacing; shape is independently deterministic per column.
			if _roll(x - 1, 19871) < .03 or _roll(x + 1, 19871) < .03: break
			if int(biomes.column(x - 1)["surface"]) < surface or int(biomes.column(x + 1)["surface"]) < surface: break
			height = 1 + mini(height - 1, floori(_roll(x, 21871) * height))
		if absi(int(biomes.column(x - 1)["surface"]) - surface) > 1 or absi(int(biomes.column(x + 1)["surface"]) - surface) > 1: break
		var clear: bool = true
		for offset in range(height):
			if int(tree_at.call(Vector2i(x, surface - 1 - offset))) != 0: clear = false
		if clear: result = {"block": key, "height": height}
		break
	columns[x] = result
	return result

func block_at(cell: Vector2i, surface: int, tree_at: Callable) -> int:
	if cell.y < surface - 3 or cell.y >= surface: return 0
	var entry: Dictionary = profile(cell.x, tree_at)
	if entry.is_empty() or surface - cell.y > int(entry["height"]): return 0
	var key: String = str(entry["block"])
	if cell.y < surface - 1 and key != "cactus": key += "_upper"
	return BlockDatabase.id_for(key)

func retain_columns_near(x: int) -> void:
	for column_x in columns.keys():
		if absi(column_x - x) > 768: columns.erase(column_x)
