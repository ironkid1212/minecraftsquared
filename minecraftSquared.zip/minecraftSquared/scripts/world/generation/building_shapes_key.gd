class_name BuildingShapesKey
extends RefCounted
static func mirror(key: String) -> String:
	var entry: Dictionary=BlockDatabase.BLOCKS[BlockDatabase.id_for(key)]
	for other in BlockDatabase.BLOCKS.values():
		if other.has("building") and other.building.material==entry.building.material and other.building.kind==entry.building.kind and other.building.half==entry.building.half and other.building.facing!=entry.building.facing:return other.key
	return key
