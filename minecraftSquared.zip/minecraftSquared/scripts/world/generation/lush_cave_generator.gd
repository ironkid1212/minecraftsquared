class_name LushCaveGenerator
extends RefCounted
var _chunks: WeakRef
var chunks: ChunkWorld:
	get:return _chunks.get_ref()
var patches: FastNoiseLite
var columns: Dictionary={}
var rules: Dictionary
func setup(host: ChunkWorld) -> void:
	_chunks=weakref(host);columns.clear();rules=StrongholdGenerator.RULES.lush
	patches=host.create_noise(host.noise.seed+137861,float(rules.frequency),2)
func is_lush(cell: Vector2i) -> bool:
	if chunks.dimension!="overworld" or not chunks.config.lush_caves_enabled:return false
	if cell.y<chunks.get_surface_y(cell.x)+int(rules.minimum_depth) or chunks.world_y(cell)<int(rules.minimum_y):return false
	var humidity: float=float(chunks.biomes.column(cell.x).humidity) if chunks.biomes!=null else 0
	return patches.get_noise_2d(cell.x,cell.y*.75)+humidity*.15>float(rules.threshold)
func cave(cell: Vector2i) -> bool:return chunks.caves.is_cave(cell,chunks.get_surface_y)
func hash_at(x: int,y: int) -> int:return ((x*73428767+y*912367+chunks.noise.seed*31)&0x7fffffff)%9973
func pool(cell: Vector2i) -> bool:
	if hash_at(cell.x/9,117)%100>=int(float(rules.pool_chance)*100):return false
	# Water occupies only enclosed one-block depressions with clay beneath.
	return cave(cell) and not cave(cell+Vector2i.DOWN) and not cave(cell+Vector2i.LEFT) and not cave(cell+Vector2i.RIGHT)
func block_at(cell: Vector2i) -> int:
	if not is_lush(cell):return -1
	if cave(cell):
		if pool(cell):return BlockDatabase.id_for("water")
		if not cave(cell+Vector2i.DOWN):
			var roll: int=hash_at(cell.x,cell.y)%19
			if roll<3:return BlockDatabase.id_for("azalea" if roll==0 else "flowering_azalea" if roll==1 else "moss_carpet")
		# Stable ceiling anchors; only one column is scanned/cached at a time.
		var vines: Dictionary=vine_column(cell.x)
		if vines.has(cell.y):return int(vines[cell.y])
		if not cave(cell+Vector2i.UP):
			if hash_at(cell.x,cell.y)%37==0:return BlockDatabase.id_for("spore_blossom")
			if hash_at(cell.x,cell.y)%17==0:return BlockDatabase.id_for("hanging_roots")
		return -1
	if pool(cell+Vector2i.UP):return BlockDatabase.id_for("clay")
	if cave(cell+Vector2i.UP):return BlockDatabase.id_for("clay" if hash_at(cell.x/7,cell.y/3)%9<2 else "moss_block")
	if cave(cell+Vector2i.DOWN) and hash_at(cell.x/5,cell.y)%4!=0:return BlockDatabase.id_for("moss_block")
	return -1
func vine_column(x: int) -> Dictionary:
	if columns.has(x):return columns[x]
	var result: Dictionary={}
	for y in range(chunks.get_surface_y(x)+int(rules.minimum_depth),mini(chunks.world_depth-8,chunks.top_world_y()-int(rules.minimum_y))):
		var at:=Vector2i(x,y)
		if not is_lush(at) or not cave(at) or cave(at+Vector2i.UP):continue
		if hash_at(x,y)%100>=int(float(rules.vine_chance)*100):continue
		var length: int=2+hash_at(x,y+1)%6
		for dy in range(length):
			var p:=Vector2i(x,y+dy)
			if not cave(p) or not cave(p+Vector2i.DOWN):break
			result[p.y]=BlockDatabase.id_for("cave_vines_berries" if hash_at(x,p.y)%4==0 else "cave_vines")
	columns[x]=result
	if columns.size()>512:columns.erase(columns.keys()[0])
	return result
