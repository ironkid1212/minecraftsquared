class_name LushCaveGenerator
extends RefCounted
var _chunks: WeakRef
var chunks: ChunkWorld:
	get:return _chunks.get_ref()
var patches: FastNoiseLite
var columns: Dictionary={}
var rooms: Dictionary={}
var rules: Dictionary
func setup(host: ChunkWorld) -> void:
	_chunks=weakref(host);columns.clear();rooms.clear();rules=StrongholdGenerator.RULES.lush
	patches=host.create_noise(host.noise.seed+137861,float(rules.frequency),2)
func legacy_is_lush(cell: Vector2i) -> bool:
	if chunks.dimension!="overworld" or not chunks.config.lush_caves_enabled:return false
	if cell.y<chunks.get_surface_y(cell.x)+int(rules.minimum_depth) or chunks.world_y(cell)<int(rules.minimum_y):return false
	var humidity: float=float(chunks.biomes.column(cell.x).humidity) if chunks.biomes!=null else 0
	return patches.get_noise_2d(cell.x,cell.y*.75)+humidity*.15>float(rules.threshold)
func cave(cell: Vector2i) -> bool:return chamber_air(cell) or chunks.caves.is_cave(cell,chunks.get_surface_y)
func hash_at(x: int,y: int) -> int:return ((x*73428767+y*912367+chunks.noise.seed*31)&0x7fffffff)%9973
func pool(cell: Vector2i) -> bool:
	if hash_at(cell.x/9,117)%100>=int(float(rules.pool_chance)*100):return false
	# Water occupies only enclosed one-block depressions with clay beneath.
	return cave(cell) and not cave(cell+Vector2i.DOWN) and not cave(cell+Vector2i.LEFT) and not cave(cell+Vector2i.RIGHT)
func legacy_block_at(cell: Vector2i) -> int:
	if not legacy_is_lush(cell):return -1
	if cave(cell):
		if pool(cell):return BlockDatabase.id_for("water")
		if not cave(cell+Vector2i.DOWN):
			var roll: int=hash_at(cell.x,cell.y)%19
			if roll<3:return BlockDatabase.id_for("azalea" if roll==0 else "flowering_azalea" if roll==1 else "moss_carpet")
		# Stable ceiling anchors; only one column is scanned/cached at a time.
		var vine: int=local_vine(cell,true)
		if vine!=0:return vine
		if not cave(cell+Vector2i.UP):
			if hash_at(cell.x,cell.y)%37==0:return BlockDatabase.id_for("spore_blossom")
			if hash_at(cell.x,cell.y)%17==0:return BlockDatabase.id_for("hanging_roots")
		return -1
	if pool(cell+Vector2i.UP):return BlockDatabase.id_for("clay")
	if cave(cell+Vector2i.UP):return BlockDatabase.id_for("clay" if hash_at(cell.x/7,cell.y/3)%9<2 else "moss_block")
	if cave(cell+Vector2i.DOWN) and hash_at(cell.x/5,cell.y)%4!=0:return BlockDatabase.id_for("moss_block")
	return -1
func vine_column(x: int) -> Dictionary:
	if columns.has(x):return columns[x]
	var result: Dictionary={}
	for y in range(chunks.get_surface_y(x)+int(rules.minimum_depth),mini(chunks.world_depth-8,chunks.top_world_y()-int(rules.minimum_y))):
		var at:=Vector2i(x,y)
		if not legacy_is_lush(at) or not cave(at) or cave(at+Vector2i.UP):continue
		if hash_at(x,y)%100>=int(float(rules.vine_chance)*100):continue
		var length: int=2+hash_at(x,y+1)%6
		for dy in range(length):
			var p:=Vector2i(x,y+dy)
			if not cave(p) or not cave(p+Vector2i.DOWN):break
			result[p.y]=BlockDatabase.id_for("cave_vines_berries" if hash_at(x,p.y)%4==0 else "cave_vines")
	columns[x]=result
	if columns.size()>512:columns.erase(columns.keys()[0])
	return result

# Bounded room descriptions and local vine probes avoid whole-column scans
# during streaming. Absolute region coordinates keep chunk seams deterministic.
func room_at(cell: Vector2i) -> Dictionary:
	if chunks.config.lush_revision<2 or chunks.dimension!="overworld" or not chunks.config.lush_caves_enabled:return {}
	var region:=Vector2i(floori(cell.x/96.0),floori(cell.y/64.0))
	if rooms.has(region):return rooms[region]
	var result: Dictionary={};var rng:=RandomNumberGenerator.new();rng.seed=chunks.noise.seed^region.x*73856093^region.y*19349663^837129
	var center:=region*Vector2i(96,64)+Vector2i(48+rng.randi_range(-8,8),32+rng.randi_range(-5,5))
	if legacy_is_lush(center) and rng.randf()<float(rules.chamber_chance) and center.y+16<chunks.world_depth-8:
		result={"center":center,"rx":rng.randi_range(int(rules.chamber_width[0]),int(rules.chamber_width[1])),"ry":rng.randi_range(int(rules.chamber_height[0]),int(rules.chamber_height[1])),"pool":rng.randf()<float(rules.chamber_pool_chance),"pool_radius":rng.randi_range(6,11)}
		result.pool_radius=mini(int(result.pool_radius),floori(float(result.rx)*.45))
		result.floor=center.y+roundi(float(result.ry)*.62)
	rooms[region]=result
	if rooms.size()>256:rooms.erase(rooms.keys()[0])
	return result
func in_room(cell: Vector2i,p: Dictionary,margin: float=1.0) -> bool:
	if p.is_empty():return false
	var dx: float=float(cell.x-p.center.x)/float(p.rx);var dy: float=float(cell.y-p.center.y)/float(p.ry)
	return dx*dx+dy*dy<margin
func is_lush(cell: Vector2i) -> bool:
	if legacy_is_lush(cell):return true
	return in_room(cell,room_at(cell),1.2)
func chamber_air(cell: Vector2i) -> bool:
	var p: Dictionary=room_at(cell)
	if not in_room(cell,p):return false
	return cell.y<int(p.floor)+(2 if p.pool and absi(cell.x-p.center.x)<=int(p.pool_radius) else 0)
func local_vine(cell: Vector2i,legacy: bool=false) -> int:
	for up in range(7):
		var anchor:=cell+Vector2i(0,-up)
		if not cave(anchor+Vector2i.UP):
			if legacy and (not legacy_is_lush(anchor) or anchor.y<chunks.get_surface_y(anchor.x)+int(rules.minimum_depth) or anchor.y>=mini(chunks.world_depth-8,chunks.top_world_y()-int(rules.minimum_y))):return 0
			if hash_at(anchor.x,anchor.y)%100<int(float(rules.vine_chance)*100) and up<2+hash_at(anchor.x,anchor.y+1)%6 and cave(cell+Vector2i.DOWN):return BlockDatabase.id_for("cave_vines_berries" if hash_at(cell.x,cell.y)%4==0 else "cave_vines")
			return 0
	return 0
func block_at(cell: Vector2i) -> int:
	if chunks.config.lush_revision<2:return legacy_block_at(cell)
	var p: Dictionary=room_at(cell)
	if in_room(cell,p,1.2):
		var pool_x: bool=p.pool and absi(cell.x-p.center.x)<=int(p.pool_radius)
		if pool_x and cell.y>=int(p.floor) and cell.y<int(p.floor)+2:return BlockDatabase.id_for("water")
		if cell.y>=int(p.floor) and in_room(cell,p):
			if p.pool and absi(cell.x-p.center.x)<=int(p.pool_radius)+1 and cell.y<=int(p.floor)+3:return BlockDatabase.id_for("clay")
			if cell.y==int(p.floor):return BlockDatabase.id_for("moss_block")
			return -1
		if not in_room(cell,p):
			if in_room(cell+Vector2i.DOWN,p) or in_room(cell+Vector2i.UP,p):return BlockDatabase.id_for("moss_block")
		elif chamber_air(cell):
			if not pool_x and cell.y==int(p.floor)-1:
				var roll: int=hash_at(cell.x,cell.y)%17
				if roll<4:return BlockDatabase.id_for(["azalea","flowering_azalea","moss_carpet","short_grass"][roll])
			var vine: int=local_vine(cell)
			if vine!=0:return vine
			if not cave(cell+Vector2i.UP) and hash_at(cell.x,cell.y)%23==0:return BlockDatabase.id_for("spore_blossom")
			return 0
	if not legacy_is_lush(cell):return -1
	if cave(cell):
		if not cave(cell+Vector2i.DOWN) and hash_at(cell.x,cell.y)%19<3:return BlockDatabase.id_for("moss_carpet")
		var vine: int=local_vine(cell)
		return vine if vine!=0 else -1
	if cave(cell+Vector2i.UP) or cave(cell+Vector2i.DOWN):return BlockDatabase.id_for("moss_block")
	return -1
