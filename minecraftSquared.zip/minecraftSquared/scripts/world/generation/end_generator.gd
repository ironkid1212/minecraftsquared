class_name EndGenerator
extends RefCounted
static var RULES: Dictionary=DataFile.object_from("res://data/end.json")
var noise:=FastNoiseLite.new()
var pillars: Array[Dictionary]=[]
var exit_open: bool=false
var outer:=EndOuterGenerator.new()
var cities:=EndCityGenerator.new()
func setup(seed_value: int) -> void:
	outer.setup(seed_value);cities.setup(seed_value,outer)
	exit_open=bool(RULES.return_portal_active)
	noise.seed=seed_value+1907;noise.frequency=.045;noise.fractal_octaves=2
	pillars.clear();var rng:=RandomNumberGenerator.new();rng.seed=seed_value^736291
	var heights: Array=RULES.pillars.heights.duplicate()
	for i in range(heights.size()-1,0,-1):
		var j: int=rng.randi_range(0,i);var swap: Variant=heights[i];heights[i]=heights[j];heights[j]=swap
	for i in range(int(RULES.pillars.count)):
		pillars.append({"x":int(RULES.pillars.positions[i]),"top":255-int(heights[i]),"radius":mini((int(RULES.pillars.maximum_width)-1)/2,2+(int(heights[i])-76)/9),"cage":int(heights[i]) in [79,82]})
func surface(x: int) -> int:
	if absi(x)>int(RULES.island_radius):return int(outer.column(x).top) if absi(x)>=int(EndOuterGenerator.RULES.start_x) else 256
	var edge: float=smoothstep(float(RULES.island_radius)*.7,float(RULES.island_radius),absf(x))
	return 255-int(RULES.surface_y)+roundi(noise.get_noise_1d(x)*3+edge*12)
func column_top(x: int) -> int:
	if absi(x)>=int(EndOuterGenerator.RULES.start_x):return cities.column_top(x,outer.column_top(x))
	var top: int=surface(x)
	for p in pillars:
		if absi(x-int(p.x))<=maxi(int(p.radius),int(RULES.pillars.cage_half_width)):top=mini(top,int(p.top)-(int(RULES.pillars.cage_height) if p.cage else 0))
	if absi(x)<=3:top=mini(top,255-int(RULES.surface_y)-4)
	if absi(x-int(RULES.arrival[0]))<=2:top=mini(top,255-int(RULES.arrival[1]))
	return top
func block_at(cell: Vector2i) -> int:
	if cell.y<0 or cell.y>=256:return 0
	if absi(cell.x)>=int(EndOuterGenerator.RULES.start_x):
		var city: int=cities.block_at(cell)
		return city if city>=0 else outer.block_at(cell)
	var ground: int=255-int(RULES.surface_y)
	# Side cross-section of the bedrock exit fountain. Its central post is a background wall.
	if absi(cell.x)<=3:
		if cell.y==ground or absi(cell.x)==3 and cell.y==ground-1:return BlockDatabase.id_for("bedrock")
		if absi(cell.x)<=2 and cell.y==ground-1:return BlockDatabase.id_for("end_portal") if exit_open else 0
		if cell.y>=ground-4 and cell.y<ground:return 0
	for p in pillars:
		var dx: int=absi(cell.x-int(p.x));var top: int=p.top
		if cell.y==top and dx==0:return BlockDatabase.id_for("bedrock")
		if cell.y==top+1 and dx<=int(p.radius):return BlockDatabase.id_for("obsidian")
		if p.cage:
			if dx<=int(RULES.pillars.cage_half_width) and cell.y==top-int(RULES.pillars.cage_height):return BlockDatabase.id_for("end_cage_roof")
			if dx==int(RULES.pillars.cage_half_width) and cell.y>top-int(RULES.pillars.cage_height) and cell.y<=top:return BlockDatabase.id_for("end_cage_post")
	if absi(cell.x-int(RULES.arrival[0]))<=2 and cell.y==255-int(RULES.arrival[1]):return BlockDatabase.id_for("obsidian")
	var surface_row: int=surface(cell.x)
	if surface_row>=256 or cell.y<surface_row:return 0
	var fraction: float=1-pow(absf(cell.x)/float(RULES.island_radius),2)
	var bottom: int=surface_row+maxi(2,roundi(float(RULES.thickness)*sqrt(maxf(0,fraction))+noise.get_noise_1d(cell.x+900)*4))
	return BlockDatabase.id_for("end_stone") if cell.y<=bottom else 0
func wall_at(cell: Vector2i) -> int:
	if absi(cell.x)>84:return cities.wall_at(cell) if absi(cell.x)>=int(EndOuterGenerator.RULES.start_x) else 0
	var ground: int=255-int(RULES.surface_y)
	if cell.x==0 and cell.y>=ground-4 and cell.y<ground:return BlockDatabase.id_for("bedrock")
	for p in pillars:
		var dx: int=absi(cell.x-int(p.x));var top: int=p.top
		if dx<=int(p.radius) and cell.y>top and cell.y<=surface(cell.x)+int(RULES.pillars.foundation_depth):return BlockDatabase.id_for("obsidian")
		if p.cage and dx<=int(RULES.pillars.cage_half_width) and cell.y>=top-int(RULES.pillars.cage_height) and cell.y<=top:return BlockDatabase.id_for("iron_bars")
	return 0
func arrival(world: Node2D) -> Vector2:
	var cell:=Vector2i(int(RULES.arrival[0]),255-int(RULES.arrival[1]))
	world.player.teleport_to(world.ground.to_global(world.ground.map_to_local(cell+Vector2i.UP)));world.chunks.update_around(world.player.global_position)
	for dx in range(-2,3):
		world.set_block(cell+Vector2i(dx,0),BlockDatabase.id_for("obsidian"))
		for dy in range(1,4):world.set_block(cell+Vector2i(dx,-dy),0)
	return world.ground.to_global(world.ground.map_to_local(cell))-Vector2(0,22.05)

static func validate() -> bool:
	if not ContentCatalog._number(RULES.get("revision"),1,3,true) or RULES.get("height")!=256 or not RULES.get("return_portal_active") is bool or not EndOuterGenerator.valid() or not EndCityGenerator.valid():return false
	for key in ["island_radius","surface_y","thickness"]:
		if not ContentCatalog._number(RULES.get(key),8,256,true):return false
	if not ContentCatalog._vector(RULES.get("arrival"),2,0,255,true) or not ContentCatalog._number(RULES.get("ambient_level"),0,15,true):return false
	var spikes: Variant=RULES.get("pillars")
	if not spikes is Dictionary or spikes.get("count")!=10 or not spikes.get("heights") is Array or spikes.heights.size()!=10:return false
	if not spikes.get("positions") is Array or spikes.positions.size()!=10:return false
	for key in ["cage_half_width","cage_height","foundation_depth"]:
		if not ContentCatalog._number(spikes.get(key),1,6,true):return false
	if not ContentCatalog._number(spikes.get("maximum_width"),5,7,true) or int(spikes.maximum_width)%2==0:return false
	for position in spikes.positions:
		if not ContentCatalog._number(position,-80,80,true):return false
	for height in spikes.heights:
		if not ContentCatalog._number(height,70,120,true):return false
	return true
