class_name StructureGenerator
extends RefCounted
## Coordinate-derived plans: generation order and chunk borders cannot change a structure.
var chunks: ChunkWorld
var rules: Dictionary
var regions: Dictionary={}
func setup(host: ChunkWorld) -> void:
	chunks=host;rules=AdventureData.DATA.structures
func region_at(x: int) -> int:return floori(float(x)/int(rules.region_width))
func plan(region: int) -> Dictionary:
	if regions.has(region):return regions[region]
	var result: Dictionary={"blocks":{},"containers":{},"spawners":{},"kind":"","origin":Vector2i.ZERO}
	regions[region]=result
	if not chunks.config.structures_enabled or not rules.enabled:return result
	var rng:=RandomNumberGenerator.new();rng.seed=chunks.noise.seed+region*73428767+9872341
	if rng.randf()>float(rules.chance):return result
	var width: int=int(rules.region_width)
	var margin: int=int(rules.mineshaft_half_width)+8
	var x: int=region*width+rng.randi_range(margin,width-margin-1)
	var surface: int=chunks.get_surface_y(x)
	var y: int=mini(chunks.world_depth-int(rules.level_spacing)*(int(rules.mineshaft_levels)-1)-10,surface+rng.randi_range(int(rules.minimum_depth),int(rules.maximum_depth)))
	var room: bool=rng.randf()<float(rules.monster_room_weight)
	result["half_width"]=rng.randi_range(4,5)
	if room:
		# Find a cave along a wall: rooms open into existing tunnels, not sealed cubes.
		var found: bool=false
		for offset in range(100):
			var row: int=surface+int(rules.minimum_depth)+offset
			if row>=chunks.world_depth-12:break
			var edge: int=int(result.half_width)+1
			if chunks.caves.is_cave(Vector2i(x-edge,row-2),chunks.get_surface_y) or chunks.caves.is_cave(Vector2i(x+edge,row-2),chunks.get_surface_y):y=row;found=true;break
		if not found:return result
	result.origin=Vector2i(x,y);result.kind="monster_room" if room else "mineshaft"
	if room:_room(result,rng)
	else:_mine(result,rng)
	return result
func put(result: Dictionary,cell: Vector2i,key: String) -> void:
	if cell.y<chunks.get_surface_y(cell.x)+8 or cell.y>=chunks.world_depth-6:return
	result.blocks[cell]=0 if key=="air" else BlockDatabase.id_for(key)
func _room(result: Dictionary,rng: RandomNumberGenerator) -> void:
	var p: Vector2i=result.origin;var half: int=int(result.half_width)
	for x in range(-half,half+1):
		for y in range(-5,1):
			var edge: bool=y in [-5,0] or absi(x)==half
			var key: String="mossy_cobblestone" if y==0 and rng.randf()<.75 else "cobblestone"
			put(result,p+Vector2i(x,y),key if edge else "air")
	# Preserve cave openings through either wall. At least one is guaranteed by placement.
	for side in [-1,1]:
		for y in range(-4,-1):
			if chunks.caves.is_cave(p+Vector2i(side*(half+1),y),chunks.get_surface_y):
				put(result,p+Vector2i(side*half,y),"air");put(result,p+Vector2i(side*half,y+1),"air")
	var spawner: Vector2i=p+Vector2i(0,-1);put(result,spawner,"spawner")
	result.spawners[spawner]=["zombie","zombie","skeleton","spider"][rng.randi_range(0,3)]
	for side in [-1,1]:
		if rng.randf()<.8:
			var chest: Vector2i=p+Vector2i(side*(half-1),-1);put(result,chest,"chest");result.containers[chest]="simple_dungeon"
func _mine(result: Dictionary,rng: RandomNumberGenerator) -> void:
	var p: Vector2i=result.origin
	var half: int=int(rules.mineshaft_half_width);var spacing: int=int(rules.level_spacing)
	var levels: int=int(rules.mineshaft_levels)
	for level in range(levels):
		var row: int=p.y+level*spacing
		var left: int=p.x-half+rng.randi_range(0,8);var right: int=p.x+half-rng.randi_range(0,8)
		for x in range(left,right+1):
			put(result,Vector2i(x,row),"oak_planks")
			for y in range(row-3,row):put(result,Vector2i(x,y),"air")
			if rng.randf()<.65:put(result,Vector2i(x,row-1),"rail")
			if (x-left)%6==0:
				put(result,Vector2i(x,row-3),"oak_planks")
				for y in [row-2,row-1]:put(result,Vector2i(x,y),"oak_fence")
			elif rng.randf()<.07:put(result,Vector2i(x,row-3),"cobweb")
		# One abandoned chest cart per level. It uses normal persistent storage.
		var chest:=Vector2i(rng.randi_range(left+3,right-3),row-1)
		put(result,chest,"chest_minecart");result.containers[chest]="abandoned_mineshaft"
		if level==levels-1:
			var nest:=Vector2i(left+10,row-1);put(result,nest,"spawner");result.spawners[nest]="cave_spider"
			for dx in [-3,-2,-1,1,2,3]:put(result,nest+Vector2i(dx,-1 if dx%2==0 else 0),"cobweb")
	# Sloping side passages connect every level in the 2D plane.
	for level in range(levels-1):
		var start:=p+Vector2i(-8 if level%2==0 else 8,level*spacing)
		var direction: int=1 if level%2==0 else -1
		for step in range(spacing+1):
			var floor_cell: Vector2i=start+Vector2i(step*direction,step)
			put(result,floor_cell,"oak_stairs_left" if direction>0 else "oak_stairs")
			for up in range(1,5):put(result,floor_cell-Vector2i(0,up),"air")
	if chunks.config.structures_revision>=2:
		_repair_containers(result,half*2)
		var access_x: int=p.x+int(half*.5)
		for y in range(p.y-2,p.y+(levels-1)*spacing):
			var at:=Vector2i(access_x,y)
			if not result.containers.has(at) and not result.spawners.has(at):put(result,at,"ladder")
			at.x+=1
			if not result.containers.has(at) and not result.spawners.has(at):put(result,at,"air")

func _repair_containers(result: Dictionary,maximum: int) -> void:
	# Connecting passages used to carve through a previously planned chest cart.
	# Preserve older layouts, but relocate such loot to a clear supported cell in v2.
	for cell: Vector2i in result.containers.keys():
		if BlockDatabase.BLOCKS.get(int(result.blocks.get(cell,0)),{}).has("storage"):continue
		var destination: Vector2i=cell
		var found: bool=false
		for distance in range(1,maximum):
			for direction in [-1,1]:
				var candidate: Vector2i=cell+Vector2i(distance*direction,0)
				if result.containers.has(candidate) or result.spawners.has(candidate):continue
				var current: int=int(result.blocks.get(candidate,-1))
				if current!=0 and not BlockDatabase.has_tag(current,"rail"):continue
				if result.blocks.get(candidate+Vector2i.DOWN,-1)!=BlockDatabase.id_for("oak_planks") or result.blocks.get(candidate+Vector2i.UP,-1)!=0:continue
				destination=candidate;found=true;break
			if found:break
		var table: String=result.containers[cell]
		result.containers.erase(cell);result.containers[destination]=table
		put(result,destination,"chest_minecart")

func block_at(cell: Vector2i) -> int:
	var record: Dictionary=plan(region_at(cell.x))
	return int(record.blocks.get(cell,-1))
func retain(x: int) -> void:
	var center: int=region_at(x)
	for region in regions.keys():
		if absi(region-center)>4:regions.erase(region)
