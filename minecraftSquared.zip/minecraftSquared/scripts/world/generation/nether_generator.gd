class_name NetherGenerator
extends RefCounted

var config: Dictionary
var seed: int
var terrain: FastNoiseLite
var caves: FastNoiseLite
var ore: FastNoiseLite
var gold: FastNoiseLite
var pillars: FastNoiseLite
var _columns: Dictionary={}
var _ids: Dictionary={}
var fortresses:=NetherFortresses.new()
var _fungi: Dictionary={}
var modern: ModernNetherTerrain
func setup(seed_value: int,generation: Dictionary) -> void:
	modern=null
	seed=seed_value;config=generation.duplicate(true);_columns.clear();_ids.clear();_fungi.clear();fortresses.setup(self)
	terrain=_noise(seed+8217,float(config.cavern_frequency),3)
	caves=_noise(seed-9871,.045,2);ore=_noise(seed+4167,.17,2);gold=_noise(seed-7217,.19,2);pillars=_noise(seed+3117,.026,2)
	for key in ["netherrack","bedrock","lava","soul_sand","soul_soil","basalt","blackstone","nether_quartz_ore","nether_gold_ore","glowstone","fire","warped_nylium","warped_stem","warped_wart_block","shroomlight","warped_roots","warped_fungus","nether_sprouts","twisting_vines","twisting_vines_plant"]:_ids[key]=BlockDatabase.id_for(key)
	if int(config.get("revision",1))>=2:
		modern=ModernNetherTerrain.new();modern.setup(self)
		for key in ["crimson_nylium","crimson_stem","nether_wart_block","crimson_roots","crimson_fungus","gravel"]:_ids[key]=BlockDatabase.id_for(key)
func _noise(value: int,frequency: float,octaves: int) -> FastNoiseLite:
	var n:=FastNoiseLite.new();n.seed=value;n.frequency=frequency;n.fractal_octaves=octaves;n.noise_type=FastNoiseLite.TYPE_SIMPLEX_SMOOTH;return n
func sample(x: int,y: int) -> int:
	var value: int=(x*73428767+y*912367+seed*31)&0x7fffffff
	return ((value^(value>>13))*1274126177)&0x7fffffff
func biome_at(x: int) -> String:
	return modern.biome_at(x) if modern!=null else _legacy_biome_at(x)
func _legacy_biome_at(x: int) -> String:
	var region: int=floori(float(x)/float(config.biome_width))
	var key: String=["nether_wastes","soul_sand_valley","basalt_deltas"][posmod(region+posmod(seed,3),3)]
	# Keep the previous three-biome layout; replace selected wastes regions only.
	if config.get("warped_forests",true) and key=="nether_wastes" and sample(region,771)%3!=0:return "warped_forest"
	return key
func column(x: int) -> Dictionary:
	return modern.column(x) if modern!=null else _legacy_column(x)
func _legacy_column(x: int) -> Dictionary:
	if _columns.has(x):return _columns[x]
	var result: Dictionary={"ceiling":clampi(roundi(float(config.ceiling_base)+terrain.get_noise_1d(x)*float(config.ceiling_amplitude)),8,48),"floor":clampi(roundi(float(config.floor_base)+terrain.get_noise_1d(x+31000)*float(config.floor_amplitude)*2),56,111),"biome":biome_at(x)}
	_columns[x]=result
	if _columns.size()>8192:_columns.clear();_columns[x]=result
	return result
func block_at(cell: Vector2i) -> int:
	return modern.block_at(cell) if modern!=null else _legacy_block_at(cell)
func _legacy_block_at(cell: Vector2i) -> int:
	var height: int=int(config.height)
	if cell.y<0 or cell.y>=height:return 0
	var edge: int=mini(cell.y,height-1-cell.y)
	if edge==0 or edge<5 and sample(cell.x,cell.y)%5>=edge:return int(_ids.bedrock)
	var structure: int=fortresses.block_at(cell)
	if structure>=0:return structure
	var profile: Dictionary=column(cell.x);var floor_y: int=int(profile.floor);var roof: int=int(profile.ceiling)
	var biome: String=biome_at(cell.x+roundi(caves.get_noise_2d(cell.x,cell.y)*10))
	var pillar: bool=biome=="basalt_deltas" and pillars.get_noise_2d(cell.x,cell.y)>.35
	var open: bool=cell.y>roof and cell.y<floor_y and not pillar
	open=open or cell.y>6 and cell.y<height-6 and caves.get_noise_2d(cell.x,cell.y)>float(config.cave_threshold)
	if open:
		if biome=="warped_forest" and height-1-cell.y>int(config.lava_y):
			var vegetation: int=forest_at(cell)
			if vegetation>0:return vegetation
		if height-1-cell.y<=int(config.lava_y):return int(_ids.lava)
		if cell.y<=roof+5 and ore.get_noise_2d(cell.x+7000,roof)>.40 and cell.y-roof<=1+sample(cell.x/3,roof)%5:return int(_ids.glowstone)
		if biome=="nether_wastes" and cell.y==floor_y-1 and sample(cell.x,cell.y)%79==0:return int(_ids.fire)
		return 0
	if biome=="warped_forest" and cell.y==floor_y and height-1-cell.y>int(config.lava_y):return int(_ids.warped_nylium)
	if biome=="soul_sand_valley" and cell.y>=floor_y and cell.y<floor_y+4:return int(_ids.soul_sand if cell.y<=floor_y+1 else _ids.soul_soil)
	if biome=="basalt_deltas" and (pillar or cell.y>=floor_y and cell.y<floor_y+5):return int(_ids.basalt if sample(cell.x/4,cell.y/3)%4!=0 else _ids.blackstone)
	if edge>=6:
		if ore.get_noise_2d(cell.x,cell.y)>float(config.quartz_threshold):return int(_ids.nether_quartz_ore)
		if gold.get_noise_2d(cell.x,cell.y)>float(config.gold_threshold):return int(_ids.nether_gold_ore)
	return int(_ids.netherrack)
func wall_at(cell: Vector2i) -> int:
	return modern.wall_at(cell) if modern!=null else _legacy_wall_at(cell)
func _legacy_wall_at(cell: Vector2i) -> int:
	if cell.y<0 or cell.y>=int(config.height):return 0
	var wall: int=fortresses.wall_at(cell)
	if wall>0:return wall
	var profile: Dictionary=column(cell.x)
	if cell.y>int(profile.ceiling)+1 and cell.y<int(profile.floor):return 0
	var key: String=biome_at(cell.x)
	return int(_ids.soul_soil if key=="soul_sand_valley" else _ids.blackstone if key=="basalt_deltas" else _ids.netherrack)

func fungus(slot: int) -> Dictionary:
	return modern.fungus(slot) if modern!=null else _legacy_fungus(slot)
func _legacy_fungus(slot: int) -> Dictionary:
	if _fungi.has(slot):return _fungi[slot]
	var spacing: int=int(config.get("forest_spacing",11));var x: int=slot*spacing+2+sample(slot,611)%5
	var col: Dictionary=column(x);var y: int=int(col.floor)
	var result: Dictionary={}
	if biome_at(x)=="warped_forest" and 127-y>int(config.lava_y) and caves.get_noise_2d(x,y)<=float(config.cave_threshold) and sample(slot,912)%5!=0:
		result={"x":x,"floor":y,"height":6+sample(slot,814)%6,"radius":2+sample(slot,99)%2}
	if not result.is_empty():
		var plan: Dictionary=fortresses.plan(fortresses.region_at(x))
		if not plan.blocks.is_empty() and absi(x-int(plan.origin.x))<=int(WorldDimensions.DATA.fortress.half_width)+int(result.radius):
			var bridge_y: int=int(plan.origin.y)
			if y>=bridge_y-int(WorldDimensions.DATA.fortress.level_spacing)-5 and y-int(result.height)<=bridge_y:result={}
	_fungi[slot]=result
	if _fungi.size()>1024:_fungi.clear();_fungi[slot]=result
	return result
func forest_at(cell: Vector2i) -> int:
	return modern.forest_at(cell) if modern!=null else _legacy_forest_at(cell)
func _legacy_forest_at(cell: Vector2i) -> int:
	var spacing: int=int(config.get("forest_spacing",11));var slot: int=floori(float(cell.x)/spacing)
	for index in range(slot-1,slot+2):
		var tree: Dictionary=fungus(index)
		if tree.is_empty():continue
		var dx: int=absi(cell.x-int(tree.x));var dy: int=int(tree.floor)-cell.y
		if dx==0 and dy>=1 and dy<int(tree.height):return int(_ids.warped_stem)
		if dx<=int(tree.radius) and dy>=int(tree.height)-2 and dy<=int(tree.height):
			if dx==int(tree.radius) and dy==int(tree.height) and sample(cell.x,cell.y)%3==0:continue
			return int(_ids.shroomlight if dy==int(tree.height)-2 and dx>0 and sample(cell.x,cell.y)%9==0 else _ids.warped_wart_block)
	var floor_y: int=column(cell.x).floor
	if cell.y==floor_y-1:
		var roll: int=sample(cell.x,114)%12
		if roll<3:return int(_ids.warped_roots if roll==0 else _ids.nether_sprouts if roll==1 else _ids.warped_fungus)
		if roll==3:return int(_ids.twisting_vines_plant)
	elif cell.y<floor_y-1 and cell.y>=floor_y-4 and sample(cell.x,114)%12==3:return int(_ids.twisting_vines if cell.y==floor_y-4 else _ids.twisting_vines_plant)
	return 0
