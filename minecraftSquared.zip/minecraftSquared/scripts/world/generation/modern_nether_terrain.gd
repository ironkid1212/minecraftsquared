class_name ModernNetherTerrain
extends RefCounted

## A vertical slice of density terrain. Biome climate changes surfaces, not shape.
var _host: WeakRef
var host: NetherGenerator:
	get:return _host.get_ref() if _host!=null else null
var broad: FastNoiseLite
var detail: FastNoiseLite
var warp: FastNoiseLite
var temperature: FastNoiseLite
var humidity: FastNoiseLite
var columns: Dictionary={}
var fungi: Dictionary={}
var clusters: Dictionary={}
var pillar_plans: Dictionary={}

func setup(generator: NetherGenerator) -> void:
	_host=weakref(generator)
	broad=host._noise(host.seed+59071,float(host.config.get("density_frequency",.012)),3)
	detail=host._noise(host.seed-20591,.043,2)
	warp=host._noise(host.seed+10471,.009,2)
	var frequency: float=1.0/float(host.config.biome_width)
	temperature=host._noise(host.seed+3001,frequency,2)
	humidity=host._noise(host.seed-8173,frequency,2)

func biome_at(x: int) -> String:
	var t: float=temperature.get_noise_1d(x)*1.8
	var h: float=humidity.get_noise_1d(x)*1.8
	var best: float=INF
	var result: String="nether_wastes"
	for key in host.config.climate:
		var p: Array=host.config.climate[key]
		var distance: float=pow(t-float(p[0]),2)+pow(h-float(p[1]),2)+pow(float(p[2]),2)
		if distance<best:
			best=distance;result=key
	return result

func density(x: int,y: int) -> float:
	var bend: float=warp.get_noise_2d(x,y)*14
	var edge: float=pow(absf(y-63.5)/58.0,2)
	return broad.get_noise_2d(x+bend,y*1.65)*.95+detail.get_noise_2d(x,y)*.24+edge*1.05-float(host.config.get("cavern_opening",.20))

func column(x: int) -> Dictionary:
	if columns.has(x):return columns[x]
	var solid:=PackedByteArray();solid.resize(128)
	for y in range(128):solid[y]=1 if y<5 or y>122 or density(x,y)>0 else 0
	if int(host.config.revision)>=3:
		# Remove isolated single-cell specks and pinholes without flattening
		# shelves. Neighbor density is sampled directly, so chunk order cannot
		# affect the result. Saved revision-2 worlds keep their density field.
		var raw: PackedByteArray=solid.duplicate()
		for y in range(6,122):
			if raw[y]==raw[y-1] or raw[y]==raw[y+1]:continue
			var left: int=1 if density(x-1,y)>0 else 0
			var right: int=1 if density(x+1,y)>0 else 0
			if left==raw[y-1] and right==raw[y-1]:solid[y]=left
	var floors: Array[int]=[];var ceilings: Array[int]=[]
	for y in range(6,122):
		if solid[y]==1 and solid[y-1]==0:floors.append(y)
		if solid[y]==1 and solid[y+1]==0:ceilings.append(y)
	var floor_y: int=112;var score: int=1000
	for y in floors:
		if y<96 and solid[maxi(0,y-3)]==0 and absi(y-84)<score:floor_y=y;score=absi(y-84)
	var roof: int=5
	for y in ceilings:
		if y<floor_y:roof=y
	var result: Dictionary={"solid":solid,"floors":floors,"ceilings":ceilings,"floor":floor_y,"ceiling":roof,"biome":biome_at(x)}
	columns[x]=result
	if columns.size()>4096:columns.erase(columns.keys()[0])
	return result

func solid_at(cell: Vector2i) -> bool:
	return cell.y>=0 and cell.y<128 and column(cell.x).solid[cell.y]!=0

func block_at(cell: Vector2i) -> int:
	var y: int=cell.y
	if y<0 or y>=128:return 0
	var edge: int=mini(y,127-y)
	if edge==0 or edge<5 and host.sample(cell.x,y)%5>=edge:return host._ids.bedrock
	var structure: int=host.fortresses.block_at(cell)
	if structure>=0:return structure
	var profile: Dictionary=column(cell.x);var biome: String=profile.biome
	if not solid_at(cell):
		if not host.config.get("pillars_background",true) and basalt_pillar(cell):return host._ids.basalt
		if 127-y<=int(host.config.lava_y):return host._ids.lava
		var plant: int=forest_at(cell)
		if plant>0:return plant
		if glowstone_at(cell):return host._ids.glowstone
		if biome=="nether_wastes" and solid_at(cell+Vector2i.DOWN) and host.sample(cell.x,y)%89==0:return host._ids.fire
		return 0
	var depth: int=0
	while depth<4 and y-depth>4 and solid_at(cell-Vector2i(0,depth)):depth+=1
	if depth<4 and 127-y>int(host.config.lava_y):
		if biome=="warped_forest" and depth==1:return host._ids.warped_nylium
		if biome=="crimson_forest" and depth==1:return host._ids.crimson_nylium
		if biome=="soul_sand_valley":return host._ids.soul_sand if depth<3 else host._ids.soul_soil
		if biome=="basalt_deltas":return host._ids.basalt if host.pillars.get_noise_2d(cell.x,y)>-.12 else host._ids.blackstone
	# Sparse gravel pockets on exposed shores, not an entire repeated layer.
	if depth==1 and y>=92 and host.pillars.get_noise_2d(cell.x+710,y)>.30:return host._ids.gravel
	if edge>=6:
		if host.ore.get_noise_2d(cell.x,y)>float(host.config.quartz_threshold):return host._ids.nether_quartz_ore
		if host.gold.get_noise_2d(cell.x,y)>float(host.config.gold_threshold):return host._ids.nether_gold_ore
	return host._ids.netherrack

func glowstone_at(cell: Vector2i) -> bool:
	var slot: int=floori(float(cell.x)/11)
	for index in range(slot-1,slot+2):
		if not clusters.has(index):
			var points: Dictionary={}
			var x: int=index*11+3+host.sample(index,131)%5
			for roof in column(x).ceilings:
				if host.sample(x,roof)%5>1:continue
				var length: int=3+host.sample(x,roof+1)%3
				for dy in range(1,length+1):
					var radius: int=mini(2,mini(dy-1,length-dy))
					for dx in range(-radius,radius+1):
						var p:=Vector2i(x+dx,int(roof)+dy)
						if not solid_at(p):points[p]=true
			clusters[index]=points
			if clusters.size()>768:clusters.erase(clusters.keys()[0])
		if clusters[index].has(cell):return true
	return false

func basalt_pillar(cell: Vector2i) -> bool:
	var spacing: int=int(host.config.get("pillar_spacing",72))
	var slot: int=floori(float(cell.x)/spacing)
	var plan: Dictionary=pillar(slot)
	if plan.is_empty():return false
	if cell.y<=int(plan.roof) or cell.y>=int(plan.floor):return false
	var width: int=1 if host.sample(slot,191)%3==0 else 0
	if cell.y-int(plan.roof)<=2 or int(plan.floor)-cell.y<=2:width+=1
	return absi(cell.x-int(plan.x))<=width

func pillar(slot: int) -> Dictionary:
	if pillar_plans.has(slot):return pillar_plans[slot]
	var spacing: int=int(host.config.get("pillar_spacing",72))
	var center: int=slot*spacing+8+host.sample(slot,715)%(spacing-16)
	var result: Dictionary={}
	if biome_at(center)=="soul_sand_valley" and float(host.sample(slot,193)%10000)/10000<float(host.config.get("pillar_chance",.4)):
		var profile: Dictionary=column(center)
		for roof in profile.ceilings:
			for floor_y in profile.floors:
				if floor_y<=roof:continue
				var bottom: int=mini(int(floor_y),127-int(host.config.lava_y))
				if bottom-int(roof)>10:result={"x":center,"roof":roof,"floor":bottom}
				break
			if not result.is_empty():break
	pillar_plans[slot]=result
	if pillar_plans.size()>512:pillar_plans.erase(pillar_plans.keys()[0])
	return result

func wall_at(cell: Vector2i) -> int:
	if cell.y<0 or cell.y>=128:return 0
	var wall: int=host.fortresses.wall_override(cell)
	if wall>=0:return wall
	if host.config.get("pillars_background",true) and basalt_pillar(cell):return host._ids.basalt
	return host._ids.netherrack if solid_at(cell) else 0

func fungus(slot: int) -> Dictionary:
	if fungi.has(slot):return fungi[slot]
	var spacing: int=int(host.config.forest_spacing)
	var x: int=slot*spacing+2+host.sample(slot,611)%5
	var biome: String=biome_at(x);var result: Dictionary={}
	if biome in ["warped_forest","crimson_forest"] and host.sample(slot,912)%5!=0:
		var height: int=6+host.sample(slot,814)%6;var radius: int=2+host.sample(slot,99)%2
		for floor_y in column(x).floors:
			if floor_y>95 or floor_y-height<6:continue
			var clear: bool=true
			for dx in range(-radius,radius+1):
				for y in range(floor_y-height,floor_y):
					if solid_at(Vector2i(x+dx,y)) or host.fortresses.block_at(Vector2i(x+dx,y))>=0:clear=false;break
				if not clear:break
			if clear:result={"x":x,"floor":floor_y,"height":height,"radius":radius,"biome":biome};break
	fungi[slot]=result
	if fungi.size()>1024:fungi.erase(fungi.keys()[0])
	return result

func forest_at(cell: Vector2i) -> int:
	var biome: String=biome_at(cell.x)
	if biome not in ["warped_forest","crimson_forest"]:return 0
	var prefix: String="warped" if biome=="warped_forest" else "crimson"
	var slot: int=floori(float(cell.x)/int(host.config.forest_spacing))
	for index in range(slot-1,slot+2):
		var tree: Dictionary=fungus(index)
		if tree.is_empty():continue
		var dx: int=absi(cell.x-int(tree.x));var dy: int=int(tree.floor)-cell.y
		if dx==0 and dy>=1 and dy<int(tree.height):return host._ids[("warped" if tree.biome=="warped_forest" else "crimson")+"_stem"]
		if dx<=int(tree.radius) and dy>=int(tree.height)-2 and dy<=int(tree.height):
			if dx==int(tree.radius) and dy==int(tree.height) and host.sample(cell.x,cell.y)%3==0:continue
			return host._ids.shroomlight if dy==int(tree.height)-2 and dx>0 and host.sample(cell.x,cell.y)%9==0 else host._ids.warped_wart_block if tree.biome=="warped_forest" else host._ids.nether_wart_block
	if solid_at(cell+Vector2i.DOWN):
		var roll: int=host.sample(cell.x,114)%12
		if roll<3:return host._ids[prefix+"_roots"] if roll<2 else host._ids[prefix+"_fungus"]
	return 0
