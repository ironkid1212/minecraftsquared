class_name StrongholdGenerator
extends RefCounted
static var RULES: Dictionary=DataFile.object_from("res://data/strongholds.json")
var _chunks: WeakRef
var chunks: ChunkWorld:
	get:return _chunks.get_ref()
var positions: Array[int]=[]
var plans: Dictionary={}
static func validate() -> bool:
	if RULES.get("version")!=1 or not RULES.get("distances") is Array or RULES.distances.is_empty() or not RULES.get("brick_weights") is Dictionary:return false
	if not ContentCatalog._number(RULES.get("portal",{}).get("frame_width",5),5,9,true) or int(RULES.portal.get("frame_width",5))%2!=1:return false
	var previous: int=0
	for distance in RULES.distances:
		if not ContentCatalog._number(distance,previous+320,1000000,true):return false
		previous=int(distance)
	var total: int=0
	for key in RULES.brick_weights:
		if BlockDatabase.id_for(key)==0 or not ContentCatalog._number(RULES.brick_weights[key],0,100,true):return false
		total+=int(RULES.brick_weights[key])
	if total!=100 or not ContentCatalog._number(RULES.get("jitter"),0,128,true):return false
	if not ContentCatalog._number(RULES.get("minimum_depth"),20,128,true) or not ContentCatalog._number(RULES.get("maximum_depth"),RULES.minimum_depth,160,true):return false
	if not RULES.get("eye") is Dictionary or not RULES.get("portal") is Dictionary or not RULES.get("lush") is Dictionary:return false
	for key in ["range","near_range","flight_seconds","cooldown","maximum_active"]:
		if not ContentCatalog._number(RULES.eye.get(key),.05,128):return false
	if not ContentCatalog._number(RULES.eye.get("break_chance"),0,1) or not ContentCatalog._number(RULES.portal.get("prefill_chance"),0,1):return false
	if not ContentCatalog._vector(RULES.lush.get("chamber_width"),2,12,32,true) or not ContentCatalog._vector(RULES.lush.get("chamber_height"),2,6,16,true) or not ContentCatalog._number(RULES.lush.get("chamber_chance"),0,1) or not ContentCatalog._number(RULES.lush.get("chamber_pool_chance"),0,1):return false
	return ContentCatalog._number(RULES.lush.get("frequency"),.001,.1) and ContentCatalog._number(RULES.lush.get("threshold"),-1,1) and ContentCatalog._number(RULES.lush.get("minimum_depth"),8,128,true) and ContentCatalog._number(RULES.lush.get("minimum_y"),-64,64,true) and ContentCatalog._number(RULES.lush.get("vine_chance"),0,1) and ContentCatalog._number(RULES.lush.get("pool_chance"),0,1)
func setup(host: ChunkWorld) -> void:
	_chunks=weakref(host);plans.clear();positions.clear()
	if not validate():DataFile.fail("strongholds.json: invalid settings.");return
	var rng:=RandomNumberGenerator.new();rng.seed=host.noise.seed^914827
	for distance in RULES.distances:
		for side in [-1,1]:positions.append(side*(int(distance)+rng.randi_range(-int(RULES.jitter),int(RULES.jitter))))
	positions.sort()
func enabled() -> bool:return not positions.is_empty() and chunks.dimension=="overworld" and chunks.config.modern_generation and chunks.config.structures_enabled and chunks.config.strongholds_enabled
func region_at(x: int) -> int:
	var index: int=0
	for i in range(positions.size()):
		if absi(positions[i]-x)<absi(positions[index]-x):index=i
	return index
func plan(index: int) -> Dictionary:
	if plans.has(index):return plans[index]
	var p: Dictionary={"blocks":{},"walls":{},"containers":{},"spawners":{},"pieces":[],"kind":"stronghold","origin":Vector2i.ZERO}
	if not enabled() or index<0 or index>=positions.size():return p
	var rng:=RandomNumberGenerator.new();rng.seed=chunks.noise.seed+index*918273+73671
	var x: int=positions[index];var surface: int=chunks.get_surface_y(x)
	var y: int=clampi(surface+rng.randi_range(int(RULES.minimum_depth),int(RULES.maximum_depth)),surface+20,chunks.world_depth-40)
	p.origin=Vector2i(x,y);p.portal=Vector2i(x+66,y+10)
	plans[index]=p
	# Both galleries have continuous floors and ample body clearance.
	room(p,Vector2i(x-50,y),101,7,"crossing",rng)
	room(p,Vector2i(x-48,y+15),123,7,"corridor",rng)
	room(p,Vector2i(x-49,y-1),25,12,"library",rng)
	room(p,Vector2i(x+54,y+15),25,12,"portal_room",rng)
	for ladder_x in [x-18,x+22]:
		for row in range(y-1,y+15):
			put(p,Vector2i(ladder_x,row),"ladder");p.walls[Vector2i(ladder_x,row)]=BlockDatabase.id_for("stone_bricks")
	# The entrance is a staircase-shaped tower with a reachable ladder in a
	# side-view slice; it never puts a solid wedge across either main route.
	for row in range(y-9,y):put(p,Vector2i(x,row),"ladder")
	for dx in range(-47,-26):
		if posmod(dx,4)!=0:
			for up in [1,2,5,6]:put(p,Vector2i(x+dx,y-up),"bookshelf")
	for dx in [-46,-28]:chest(p,Vector2i(x+dx,y-3),"stronghold_library");put(p,Vector2i(x+dx,y-2),"oak_planks")
	chest(p,Vector2i(x+39,y-1),"stronghold_corridor")
	chest(p,Vector2i(x-33,y+14),"stronghold_crossing")
	# Decorative bars remain platforms so cells do not stop 2D travel.
	for dx in [-8,11]:
		for row in range(y-6,y-3):put(p,Vector2i(x+dx,row),"iron_bars")
	if chunks.config.stronghold_revision>=2:
		p.portal=Vector2i(x+66,y+12);horizontal_portal(p,rng,y)
	else:
		# Raised ring, three one-block steps, and a contained lava well.
		for dx in range(-4,5):
			var top: int=mini(3,5-absi(dx))
			for up in range(1,top+1):put(p,Vector2i(p.portal.x+dx,y+15-up),"stone_bricks")
		for cell in EndProgression.frame_cells(p.portal):put(p,cell,"end_portal_frame_filled" if rng.randf()<float(RULES.portal.prefill_chance) else "end_portal_frame")
	var spawner:=Vector2i(x+58,y+14);put(p,spawner,"spawner");p.spawners[spawner]="silverfish"
	if chunks.config.stronghold_revision==1:put(p,Vector2i(x+75,y+15),"lava");put(p,Vector2i(x+75,y+16),"stone_bricks")
	for at in [Vector2i(x-17,y-2),Vector2i(x+19,y-2),Vector2i(x+57,y+12)]:put(p,at,"torch")
	return p
func horizontal_portal(p: Dictionary,rng: RandomNumberGenerator,y: int) -> void:
	var center: Vector2i=p.portal;var half: int=int(RULES.portal.frame_width)/2
	for dx in range(-half,half+1):
		var cell:=center+Vector2i(dx,0)
		var id: int=BlockDatabase.id_for("end_portal_frame_filled" if rng.randf()<float(RULES.portal.prefill_chance) else "end_portal_frame")
		if absi(dx)==half:
			p.blocks[cell]=id
			for dy in [1,2]:put(p,cell+Vector2i(0,dy),"stone_bricks")
		else:
			p.blocks[cell]=0;p.walls[cell]=id;put(p,cell+Vector2i.DOWN,"air");put(p,cell+Vector2i(0,2),"lava")
		put(p,cell+Vector2i(0,3),"stone_bricks")
	for side in [-1,1]:
		for step in range(3):
			var dx: int=side*(half+1+step);var row: int=center.y+step
			for down in range(row+1,y+15):put(p,Vector2i(center.x+dx,down),"stone_bricks")
			put(p,Vector2i(center.x+dx,row),"stone_stairs" if side<0 else "stone_stairs_left")

func room(p: Dictionary,left: Vector2i,width: int,height: int,kind: String,rng: RandomNumberGenerator) -> void:
	p.pieces.append({"bounds":Rect2i(left-Vector2i(0,height),Vector2i(width,height+2)),"kind":kind})
	for dx in range(width):
		for dy in range(-height,2):
			var cell: Vector2i=left+Vector2i(dx,dy)
			var key: String=brick(rng) if dy in [-height,0,1] else "air"
			put(p,cell,key);p.walls[cell]=BlockDatabase.id_for("stone_bricks")
func brick(rng: RandomNumberGenerator) -> String:
	var roll: int=rng.randi_range(1,100)
	for key in RULES.brick_weights:
		roll-=int(RULES.brick_weights[key])
		if roll<=0:return key
	return "stone_bricks"
func put(p: Dictionary,at: Vector2i,key: String) -> void:p.blocks[at]=BlockDatabase.id_for(key)
func chest(p: Dictionary,at: Vector2i,table: String) -> void:put(p,at,"chest");p.containers[at]=table
func nearest(at: Vector2i) -> Dictionary:return plan(region_at(at.x))
func block_at(cell: Vector2i) -> int:
	if not enabled():return -1
	var index: int=region_at(cell.x)
	if absi(positions[index]-cell.x)>80:return -1
	return int(plan(index).blocks.get(cell,-1))
func wall_at(cell: Vector2i) -> int:
	if not enabled():return -1
	var index: int=region_at(cell.x)
	if absi(positions[index]-cell.x)>80:return -1
	return int(plan(index).walls.get(cell,-1))
