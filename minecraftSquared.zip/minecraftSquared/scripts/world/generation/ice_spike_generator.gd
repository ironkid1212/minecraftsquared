class_name IceSpikeGenerator
extends RefCounted
var chunks: ChunkWorld
var profiles: Dictionary={}
var rules: Dictionary={}
func setup(host: ChunkWorld) -> void:
	chunks=host;profiles.clear()
	rules=chunks.biomes.data.biomes.ice_spikes.ice_spikes if chunks.biomes!=null else {}
func profile(index: int) -> Dictionary:
	if chunks.dimension!="overworld" or chunks.biomes==null or chunks.config.biome_revision<8:return {}
	if profiles.has(index):return profiles[index]
	profiles[index]={}
	var rng:=RandomNumberGenerator.new();rng.seed=chunks.noise.seed^index*734287^29749
	var spacing: int=rules.spacing
	var x: int=index*spacing+rng.randi_range(4,spacing-5)
	if chunks.biomes.column(x).biome!="ice_spikes":return {}
	var heights: Array=rules.tall_heights if rng.randf()<float(rules.tall_chance) else rules.heights
	var height: int=rng.randi_range(int(heights[0]),int(heights[1]))
	profiles[index]={"x":x,"base":chunks.get_surface_y(x),"height":height,"radius":rng.randi_range(int(rules.radii[0]),int(rules.radii[1]))}
	return profiles[index]
func block_at(cell: Vector2i) -> int:
	if chunks.biomes==null:return -1
	for index in range(floori(float(cell.x)/maxi(12,int(rules.get("spacing",18))))-1,floori(float(cell.x)/maxi(12,int(rules.get("spacing",18))))+2):
		var p: Dictionary=profile(index)
		if p.is_empty():continue
		var dy: int=int(p.base)-cell.y
		if dy < -2 or dy>int(p.height):continue
		var radius: float=float(p.radius)*(1-float(maxi(0,dy))/float(p.height))
		if absi(cell.x-int(p.x))<=roundi(radius):return BlockDatabase.id_for("packed_ice")
	return -1
func column_top(x: int,base: int) -> int:
	for index in range(floori(float(x)/maxi(12,int(rules.get("spacing",18))))-1,floori(float(x)/maxi(12,int(rules.get("spacing",18))))+2):
		var p: Dictionary=profile(index)
		if not p.is_empty() and absi(x-int(p.x))<=int(p.radius):base=mini(base,int(p.base)-int(p.height))
	return base

func retain(x: int) -> void:
	for key in profiles.keys():
		if absi(key*int(rules.get("spacing",18))-x)>768:profiles.erase(key)
