class_name FortressLayout
extends RefCounted

## Piece sockets lie on walkable floors. In a side view, stair towers replace
## paths extending into the screen; supports stay behind the playable plane.
var host: NetherGenerator
var rng:=RandomNumberGenerator.new()
var result: Dictionary
var brick: int
var region_left: int
var region_right: int

func build(generator: NetherGenerator,region: int) -> Dictionary:
	host=generator;brick=BlockDatabase.id_for("nether_bricks")
	result={"blocks":{},"walls":{},"containers":{},"spawners":{},"pieces":[],"ends":[],"kind":"fortress","origin":Vector2i.ZERO}
	var rule: Dictionary=host.config.fortress_layout
	var width: int=int(rule.region_width);region_left=region*width+4;region_right=(region+1)*width-5
	rng.seed=host.seed+region*73428767+994911
	if not host.config.get("fortresses",true) or rng.randf()>float(rule.chance):return result
	var origin:=Vector2i(region*width+width/2+rng.randi_range(-24,24),rng.randi_range(58,80));result.origin=origin
	hall(origin-Vector2i(5,0),11,"crossing")
	# One irregular connected route, with changing heights and terminal branches.
	for direction in [-1,1]:
		var socket: Vector2i=origin+Vector2i(direction*6,0)
		var enclosed: bool=false
		var count: int=rng.randi_range(int(rule.minimum_pieces),int(rule.maximum_pieces))
		for index in range(count):
			var kind: String="bridge"
			if index==2:kind="lava_well";enclosed=true
			elif index==count-2:kind="wart_stairs" if direction==1 else "stairs"
			elif index==count-1:kind="spawner" if direction==-1 else "corridor"
			elif index>0 and rng.randf()<.3:kind="stairs"
			elif enclosed:kind="corridor"
			var width_piece: int=12 if kind in ["stairs","wart_stairs"] else rng.randi_range(10,17)
			var left: Vector2i=socket if direction==1 else socket-Vector2i(width_piece-1,0)
			if left.x<region_left or left.x+width_piece>region_right:break
			if kind in ["stairs","wart_stairs"]:
				var rise: int=-8 if socket.y>76 else 8 if socket.y<42 else rng.randi_range(0,1)*16-8
				var left_floor: int=socket.y if direction==1 else socket.y+rise
				stairs(Vector2i(left.x,left_floor),direction*rise,kind=="wart_stairs")
				socket+=Vector2i(direction*width_piece,rise)
			else:
				hall(left,width_piece,kind)
				socket+=Vector2i(direction*width_piece,0)
				if enclosed and kind=="corridor" and rng.randi_range(0,2)==0:chest(left+Vector2i(width_piece/2,-1))
				if kind=="spawner":
					# Full-block steps are faithful to the exterior spawner platforms.
					var center: Vector2i=left+Vector2i(width_piece/2,-3)
					for dx in range(-4,5):
						var top: int=-mini(3,5-absi(dx))
						for dy in range(top,0):put(left+Vector2i(width_piece/2+dx,dy),"nether_bricks")
					put(center+Vector2i.UP,"spawner");result.spawners[center+Vector2i.UP]="blaze"
					for dx in [-4,4]:put(left+Vector2i(width_piece/2+dx,-2),"nether_brick_fence")
		# Small broken termination rather than a repeated second deck.
		var end: Vector2i=socket-Vector2i(direction,0)
		result.ends.append({"cell":end,"direction":direction})
		var connected: bool=true
		for dx in range(1,4):
			# Consume the same random draws, but stop extending after the first
			# missing block. Otherwise a broken end can leave floating bricks.
			if rng.randf()>=.8:connected=false
			if connected and end.x+direction*dx>region_left and end.x+direction*dx<region_right:put(end+Vector2i(direction*dx,0),"nether_bricks")
	# A rear stair tower projected onto the bridge blocked its entire width.
	# The upper branch instead uses a climb-through ladder in the background.
	hall(Vector2i(origin.x-5,origin.y-14),rng.randi_range(16,25),"gallery")
	# Install after the gallery floor, leaving a genuine climb-through opening.
	for dy in range(-15,0):put(origin+Vector2i(-5,dy),"ladder");result.walls[origin+Vector2i(-5,dy)]=brick
	chest(Vector2i(origin.x+7,origin.y-15))
	reserve_clearance()
	return result

func reserve_clearance() -> void:
	# This is a side-view adaptation: natural overhangs across the playable
	# slice obscure the whole route. Reserve every piece's actual interior
	# before natural terrain, glowstone, pillars or vegetation can populate it.
	for part in result.pieces:
		# Do not grow this rectangle: that excavated a one-block moat between
		# the building and adjacent terrain. Keep solid ground at the boundary.
		var area: Rect2i=part.bounds
		for x in range(area.position.x,area.end.x):
			for y in range(area.position.y,area.end.y):
				var cell:=Vector2i(x,y)
				if x<region_left or x>region_right or y<=5 or y>=122:continue
				if not result.blocks.has(cell):result.blocks[cell]=0
				if not result.walls.has(cell):result.walls[cell]=0

func put(at: Vector2i,key: String) -> void:
	if at.y>5 and at.y<122 and at.x>=region_left and at.x<=region_right:result.blocks[at]=BlockDatabase.id_for(key)

func piece(at: Vector2i,size: Vector2i,kind: String) -> void:
	result.pieces.append({"bounds":Rect2i(at,size),"kind":kind})

func foundation(x: int,y: int) -> void:
	for down in range(y+1,123):
		if host.modern.solid_at(Vector2i(x,down)):break
		for dx in [-1,0,1]:result.walls[Vector2i(x+dx,down)]=brick

func hall(left: Vector2i,width: int,kind: String) -> void:
	var enclosed: bool=kind in ["corridor","gallery","lava_well"]
	var height: int=8 if kind=="lava_well" else 6
	piece(left-Vector2i(0,height),Vector2i(width,height+1),kind)
	result.pieces[-1].floor_left=left;result.pieces[-1].floor_right=left+Vector2i(width-1,0)
	for dx in range(width):
		var at: Vector2i=left+Vector2i(dx,0)
		put(at,"nether_bricks");put(at+Vector2i.DOWN,"nether_bricks")
		for dy in range(-height+1,0):
			# Clear enclosed rooms; bridges may have netherrack roofs above a
			# three-block passage when embedded, as in a buried fortress.
			if enclosed or dy>=-3:put(at+Vector2i(0,dy),"air")
			if enclosed:result.walls[at+Vector2i(0,dy)]=brick
		if enclosed:put(at-Vector2i(0,height),"nether_bricks")
		elif dx%7==2:put(at+Vector2i.UP,"nether_brick_fence")
		if enclosed and dx%8 in [2,3]:
			for dy in [-4,-3]:put(at+Vector2i(0,dy),"nether_brick_fence")
	for dx in [2,width-3]:foundation(left.x+dx,left.y)
	if kind=="lava_well":
		var mid: Vector2i=left+Vector2i(width/2,0)
		# The lava occupies a rear-plane-looking niche; clear sides remain usable.
		put(mid,"lava")
		put(mid+Vector2i.DOWN,"nether_bricks")

func stairs(left: Vector2i,change: int,wart: bool) -> void:
	var lowest: int=maxi(left.y,left.y+change)
	piece(Vector2i(left.x,mini(left.y,left.y+change)-6),Vector2i(12,absi(change)+7),"wart_stairs" if wart else "stairs")
	result.pieces[-1].floor_left=left;result.pieces[-1].floor_right=left+Vector2i(11,change)
	for dx in range(12):
		var step: int=clampi(dx-2,0,7)
		var floor_y: int=left.y+(step if change>0 else -step)
		# The final landing meets the next socket exactly.
		if dx>=10:floor_y=left.y+change
		for dy in range(floor_y-5,floor_y):put(Vector2i(left.x+dx,dy),"air");result.walls[Vector2i(left.x+dx,dy)]=brick
		put(Vector2i(left.x+dx,floor_y),"nether_brick_stairs_left" if change>0 else "nether_brick_stairs")
		# Stair sprites expose part of their own cell, so it needs a wall too.
		result.walls[Vector2i(left.x+dx,floor_y)]=brick
		for y in range(floor_y+1,lowest+2):put(Vector2i(left.x+dx,y),"nether_bricks")
		put(Vector2i(left.x+dx,floor_y-6),"nether_bricks")
		if wart and dx in [0,1,10,11]:put(Vector2i(left.x+dx,floor_y),"soul_sand");put(Vector2i(left.x+dx,floor_y-1),"nether_wart_stage"+str(rng.randi_range(0,3)))
	foundation(left.x+3,lowest+1);foundation(left.x+9,lowest+1)

func chest(at: Vector2i) -> void:
	put(at,"chest");result.containers[at]="nether_bridge"
