class_name GeologyGenerator
extends RefCounted

var data: Dictionary = DataFile.object_from("res://data/overworld_generation.json")
var _seed: int
var _config: TerrainSettings
var _noise: Dictionary = {}
var _regions: Dictionary = {}
var _ids: Dictionary = {}
var _ore_sources: Dictionary = {}
var _vein_sources: Dictionary = {}

func setup(seed_value: int, config: TerrainSettings) -> void:
	_seed = seed_value
	_config = config
	_regions.clear()
	_ore_sources.clear()
	_vein_sources.clear()
	_noise.clear()
	_ids.clear()
	for id in BlockDatabase.BLOCKS: _ids[str(BlockDatabase.BLOCKS[id]["key"])] = id
	if not validate_data(): return
	for deposit in data.get("deposits", []):
		_noise[str(deposit["block"])] = _make_noise(int(deposit["salt"]), float(deposit["frequency"]))
	_noise["soil"] = _make_noise(8191, 0.11)
	_noise["soil_depth"] = _make_noise(9191, 0.035)

func validate_data() -> bool:
	var valid: bool = data.get("deepslate") is Dictionary and data.get("deposits") is Array and data.get("ores") is Array and data.get("legacy_ores", []) is Array and data.get("large_veins", []) is Array
	if valid:
		var rule: Dictionary = data["deepslate"]
		valid = ContentCatalog._number(rule.get("start_y"), -1024, 1024) and ContentCatalog._number(rule.get("end_y"), -1024, 1024) and float(rule.get("start_y", 0)) > float(rule.get("end_y", 0)) and ContentCatalog._number(rule.get("at_zero_bias", 2), 0.01, 16) and ContentCatalog._number(data.get("bedrock_layers"), 1, 16)
	if valid:
		for deposit in data["deposits"]:
			if not deposit is Dictionary or not _ids.has(str(deposit.get("block", ""))) or not ContentCatalog._number(deposit.get("frequency"), 0.0001, 1) or not ContentCatalog._number(deposit.get("threshold"), -1, 1) or not ContentCatalog._number(deposit.get("salt"), -2147483648, 2147483647) or not _valid_band(deposit): valid = false
		for ore in data["ores"] + data.get("legacy_ores", []):
			if not ore is Dictionary:
				valid = false
				continue
			var key: String = str(ore.get("ore", ""))
			var size: Variant = ore.get("size")
			if not _ids.has(key + "_ore") or not _ids.has("deepslate_" + key + "_ore") or not _valid_band(ore) or not ContentCatalog._number(ore.get("peak_y"), float(ore.get("min_y", 0)), float(ore.get("max_y", 0))) or not ContentCatalog._number(ore.get("attempts"), 0, 256) or not ContentCatalog._number(ore.get("exposed_keep"), 0, 1) or not ContentCatalog._number(ore.get("priority"), 0, 1000): valid = false
			if not size is Array or size.size() != 2:
				valid = false
			elif not ContentCatalog._number(size[0], 1, 64) or not ContentCatalog._number(size[1], float(size[0]), 64): valid = false
	if valid:
		for ore in data["ores"]:
			if not ContentCatalog._number(ore.get("chance", 1.0), 0, 1): valid = false
			if ore.get("distribution", "triangle") not in ["triangle", "uniform"] or not ContentCatalog._number(ore.get("salt"), -2147483648, 2147483647, true): valid = false
		for vein in data.get("large_veins", []):
			if not vein is Dictionary:
				valid = false
				continue
			if not _ids.has(str(vein.get("ore", "")) + "_ore") or not _ids.has(str(vein.get("filler", ""))) or not _valid_band(vein) or not ContentCatalog._number(vein.get("chance"), 0, 1) or not ContentCatalog._number(vein.get("radius"), 1, 3) or not ContentCatalog._number(vein.get("ore_fraction"), 0, 1) or not ContentCatalog._number(vein.get("salt"), -2147483648, 2147483647, true): valid = false
			var length: Variant = vein.get("length")
			if not length is Array or length.size() != 2: valid = false
			elif not ContentCatalog._number(length[0], 4, 48, true) or not ContentCatalog._number(length[1], float(length[0]), 48, true): valid = false
	if not valid: DataFile.fail("overworld_generation.json: invalid material key, height band, ore vein or noise settings.")
	return valid

func _valid_band(rule: Dictionary) -> bool:
	return ContentCatalog._number(rule.get("min_y"), -1024, 1024) and ContentCatalog._number(rule.get("max_y"), float(rule.get("min_y", 0)), 1024)

func _make_noise(salt: int, frequency: float) -> FastNoiseLite:
	var result := FastNoiseLite.new()
	result.seed = _seed + salt
	result.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	result.frequency = frequency
	result.fractal_octaves = 2
	return result

func y_level(cell: Vector2i) -> int:
	return _config.top_y - cell.y

func _unit(cell: Vector2i, salt: int) -> float:
	var value: int = (int(cell.x) * 374761393 + int(cell.y) * 668265263 + _seed + salt) & 0x7fffffff
	value = ((value ^ (value >> 13)) * 1274126177) & 0x7fffffff
	return float(value ^ (value >> 16)) / 2147483647.0

func is_bedrock(cell: Vector2i) -> bool:
	var above_floor: int = y_level(cell) - _config.bottom_y
	var layers: int = int(data.get("bedrock_layers", 5))
	return above_floor == 0 or (above_floor > 0 and above_floor < layers and _unit(cell, 1771) < float(layers - above_floor) / layers)

func is_deepslate(cell: Vector2i) -> bool:
	var rule: Dictionary = data["deepslate"]
	var fraction: float = clampf(float(int(rule["start_y"]) - y_level(cell)) / maxf(1, int(rule["start_y"]) - int(rule["end_y"])), 0, 1)
	return _unit(cell, 8177) < 1.0 - pow(1.0 - fraction, float(rule.get("at_zero_bias", 2)))

func host(cell: Vector2i, surface_y: int) -> int:
	if not _noise.has("soil"): return _ids.get("stone", 3)
	if is_bedrock(cell): return _ids["bedrock"]
	var cover: int = cell.y - surface_y
	var soil_depth: float = _config.dirt_depth + _noise["soil_depth"].get_noise_1d(cell.x) * 4.0
	# The noisy interface and independent pockets avoid parallel dirt/stone bands.
	if cover >= 1 and cover < maxf(1.0, soil_depth + _noise["soil"].get_noise_2d(cell.x, cell.y) * 4.5): return _ids["dirt"]
	var y: int = y_level(cell)
	for deposit in data["deposits"]:
		if y < int(deposit["min_y"]) or y > int(deposit["max_y"]): continue
		if _noise[str(deposit["block"])].get_noise_2d(cell.x, cell.y) > float(deposit["threshold"]): return _ids[str(deposit["block"])]
	return _ids["deepslate"] if is_deepslate(cell) else _ids["stone"]

func material(cell: Vector2i, surface_y: int, exposed: Callable, mountain_biome: bool = false) -> int:
	var rock: int = host(cell, surface_y)
	if not _noise.has("soil"): return rock
	var key: String = str(BlockDatabase.BLOCKS[rock]["key"])
	if key not in ["stone", "deepslate", "granite", "diorite", "andesite", "tuff"]: return rock
	var region := Vector2i(floori(cell.x / 32.0), floori(cell.y / 32.0))
	if _config.generation_revision >= 2:
		return _modern_material(cell, region, rock, exposed, mountain_biome)
	var candidate: Dictionary = {}
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var mask: Dictionary = _legacy_region(region + Vector2i(dx, dy))
			if not mask.has(cell): continue
			var rule: Dictionary = mask[cell]
			if candidate.is_empty() or int(rule["priority"]) < int(candidate["priority"]): candidate = rule
	if candidate.is_empty(): return rock
	var y: int = y_level(cell)
	if y < int(candidate["min_y"]) or y > int(candidate["max_y"]): return rock
	if candidate.get("mountains_only", false) and not mountain_biome and _config.top_y - surface_y < 100: return rock
	if float(candidate["exposed_keep"]) < 1.0 and _unit(cell, 7719) > float(candidate["exposed_keep"]) and bool(exposed.call(cell)): return rock
	var ore: String = str(candidate["ore"])
	var prefix: String = "deepslate_" if is_deepslate(cell) else ""
	return _ids[prefix + ore + "_ore"]

func _weight(rule: Dictionary, y: int) -> float:
	var low: int = int(rule["min_y"])
	var high: int = int(rule["max_y"])
	var peak: int = int(rule["peak_y"])
	if y < low or y > high: return 0.0
	if y <= peak: return clampf(float(y - low + 1) / maxi(1, peak - low + 1), 0, 1)
	return clampf(float(high - y + 1) / maxi(1, high - peak + 1), 0, 1)

func _legacy_region(region: Vector2i) -> Dictionary:
	if _regions.has(region): return _regions[region]
	var rng := RandomNumberGenerator.new()
	rng.seed = _seed + region.x * 92837111 + region.y * 689287499 + 31819
	var result: Dictionary = {}
	for rule in data.get("legacy_ores", data["ores"]):
		for attempt in range(int(rule["attempts"])):
			var point: Vector2i = region * 32 + Vector2i(rng.randi_range(0, 31), rng.randi_range(0, 31))
			if rng.randf() > _weight(rule, y_level(point)): continue
			var size: int = rng.randi_range(int(rule["size"][0]), int(rule["size"][1]))
			for index in range(size):
				if not result.has(point) or int(rule["priority"]) < int(result[point]["priority"]): result[point] = rule
				point += [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN][rng.randi_range(0, 3)]
	if _regions.size() >= 256: _regions.erase(_regions.keys()[0])
	_regions[region] = result
	return result

func _modern_weight(rule: Dictionary, y: int) -> float:
	if y < int(rule["min_y"]) or y > int(rule["max_y"]): return 0.0
	return 1.0 if rule.get("distribution", "triangle") == "uniform" else _weight(rule, y)

func _modern_material(cell: Vector2i, region: Vector2i, rock: int, exposed: Callable, mountain: bool) -> int:
	var tile: Dictionary = _tile(region)
	var entry: Dictionary = tile.get(cell, {})
	if entry.is_empty(): return rock
	var y: int = y_level(cell)
	var deep: bool = is_deepslate(cell)
	for rule in entry.get("ores", []):
		if y < int(rule["min_y"]) or y > int(rule["max_y"]): continue
		if rule.get("mountains_only", false) and not mountain: continue
		var keep: float = float(rule["exposed_keep"])
		if keep < 1 and _unit(cell, int(rule["salt"])) >= keep and bool(exposed.call(cell)): continue
		return _ids[("deepslate_" if deep else "") + str(rule["ore"]) + "_ore"]
	if entry.has("vein"):
		var vein: Dictionary = entry["vein"]
		if y >= int(vein["min_y"]) and y <= int(vein["max_y"]):
			if _unit(cell, int(vein["salt"]) + 31) < float(vein["ore_fraction"]):
				return _ids[("deepslate_" if deep else "") + str(vein["ore"]) + "_ore"]
			return _ids[str(vein["filler"])]
	return rock

func _tile(region: Vector2i) -> Dictionary:
	# Compile neighboring source features once per tile, not nine lookups per cell.
	if _regions.has(region): return _regions[region]
	var result: Dictionary = {}
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var neighbor: Vector2i = region + Vector2i(dx, dy)
			var sources: Dictionary = _ore_source(neighbor)
			for point in sources:
				if Vector2i(floori(point.x / 32.0), floori(point.y / 32.0)) != region: continue
				if not result.has(point): result[point] = {}
				var ores: Array = result[point].get("ores", [])
				ores.append_array(sources[point])
				ores.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a["priority"]) < int(b["priority"]))
				result[point]["ores"] = ores
			var veins: Dictionary = _vein_source(neighbor)
			for point in veins:
				if Vector2i(floori(point.x / 32.0), floori(point.y / 32.0)) != region: continue
				if not result.has(point): result[point] = {}
				result[point]["vein"] = veins[point]
	_cache(_regions, region, result)
	return result

func _cache(cache: Dictionary, key: Vector2i, value: Dictionary) -> void:
	if cache.size() >= 256: cache.erase(cache.keys()[0])
	cache[key] = value

func _ore_source(region: Vector2i) -> Dictionary:
	if _ore_sources.has(region): return _ore_sources[region]
	var result: Dictionary = {}
	for rule in data["ores"]:
		# Every distribution has an independent seed, so adding an ore does not
		# shift the RNG sequence of all the other ores.
		var rng := RandomNumberGenerator.new()
		rng.seed = _seed + region.x * 92837111 + region.y * 689287499 + int(rule["salt"])
		for attempt in range(int(rule["attempts"])):
			var start: Vector2i = region * 32 + Vector2i(rng.randi_range(0, 31), rng.randi_range(0, 31))
			if rng.randf() >= _modern_weight(rule, y_level(start)) * float(rule.get("chance", 1.0)): continue
			var count: int = rng.randi_range(int(rule["size"][0]), int(rule["size"][1]))
			var visited: Dictionary = {start: true}
			var frontier: Array[Vector2i] = []
			var point: Vector2i = start
			for i in range(count):
				if not result.has(point): result[point] = []
				if not result[point].has(rule): result[point].append(rule)
				for offset in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
					var next: Vector2i = point + offset
					if visited.has(next) or absi(next.x - start.x) > 15 or absi(next.y - start.y) > 15: continue
					visited[next] = true
					frontier.append(next)
				var chosen: int = rng.randi_range(0, frontier.size() - 1)
				point = frontier[chosen]
				frontier.remove_at(chosen)
	_cache(_ore_sources, region, result)
	return result

func _vein_source(region: Vector2i) -> Dictionary:
	if _vein_sources.has(region): return _vein_sources[region]
	var result: Dictionary = {}
	for rule in data.get("large_veins", []):
		var rng := RandomNumberGenerator.new()
		rng.seed = _seed + region.x * 92837111 + region.y * 689287499 + int(rule["salt"])
		if rng.randf() >= float(rule["chance"]): continue
		var point: Vector2 = Vector2(region * 32) + Vector2(rng.randf_range(0, 31), rng.randf_range(0, 31))
		if y_level(Vector2i(point)) < int(rule["min_y"]) or y_level(Vector2i(point)) > int(rule["max_y"]): continue
		var angle: float = rng.randf_range(0, TAU)
		var radius: float = float(rule["radius"])
		var length: int = rng.randi_range(int(rule["length"][0]), int(rule["length"][1]))
		for step in range(length):
			for x in range(floori(point.x - radius), ceili(point.x + radius) + 1):
				for y in range(floori(point.y - radius), ceili(point.y + radius) + 1):
					var cell := Vector2i(x, y)
					if Vector2(cell).distance_squared_to(point) <= radius * radius: result[cell] = rule
			angle += rng.randf_range(-.35, .35)
			point += Vector2.from_angle(angle) * .55
	_cache(_vein_sources, region, result)
	return result
