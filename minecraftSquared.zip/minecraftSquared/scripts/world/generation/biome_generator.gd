class_name BiomeGenerator
extends RefCounted

## A 2D adaptation of Minecraft's climate -> terrain spline -> biome pipeline.
## The noise coordinates are shared; changing a biome never jumps surface height.
var data: Dictionary
var config: TerrainSettings
var noise: Dictionary = {}
var columns: Dictionary = {}
var _climate_columns: Dictionary = {}
var _region_plans: Dictionary = {}
var _definitions: Dictionary = {}
var _resolved_regions: Dictionary = {}
var _seed: int
const REGIONS_PER_PLAN: int = 12

func setup(seed_value: int, terrain: TerrainSettings) -> bool:
	_seed = seed_value
	_climate_columns.clear()
	_region_plans.clear()
	_definitions.clear()
	_resolved_regions.clear()
	config = terrain

	data = DataFile.object_from(config.biomes_path)
	columns.clear()
	noise.clear()
	if not data.get("noises") is Dictionary or not data.get("biomes") is Dictionary or not data.get("terrain") is Dictionary:
		DataFile.fail("biomes.json requires noises, terrain and biomes objects.")
		return false
	for key in ["continentalness", "erosion", "weirdness", "temperature", "humidity", "detail", "flower_patches"]:
		var rule: Dictionary = data["noises"].get(key, {})
		if not ContentCatalog._number(rule.get("frequency"), .00001, 1) or not ContentCatalog._number(rule.get("salt"), -2147483648, 2147483647) or not ContentCatalog._number(rule.get("strength"), .01, 10):
			DataFile.fail("biomes.json: invalid noise " + key)
			return false
		var offset: Variant = rule.get("offset")
		if not offset is Array or offset.size() != 2 or not ContentCatalog._number(offset[0], -1000000, 1000000) or not ContentCatalog._number(offset[1], -1000000, 1000000):
			DataFile.fail("biomes.json: noise offset requires two finite coordinates.")
			return false
		var sample := FastNoiseLite.new()
		sample.seed = seed_value + int(rule["salt"])
		sample.noise_type = FastNoiseLite.TYPE_PERLIN
		sample.frequency = float(rule["frequency"])
		sample.fractal_octaves = 2
		noise[key] = sample
	for key in ["continental_curve", "erosion_curve", "peak_curve"]:
		var points: Variant = data.get(key)
		if not points is Array or points.size() < 2:
			DataFile.fail("biomes.json: " + key + " requires ordered [x,y] points.")
			return false
		var previous: float = -INF
		for point in points:
			if not point is Array or point.size() != 2 or not ContentCatalog._number(point[0], -2, 2) or not ContentCatalog._number(point[1], -512, 512) or float(point[0]) <= previous:
				DataFile.fail("biomes.json: invalid spline " + key)
				return false
			previous = float(point[0])
	for key in data["biomes"]:
		if not data["biomes"].get(key) is Dictionary:
			DataFile.fail("biomes.json: missing biome " + key)
			return false
		var biome: Dictionary = data["biomes"][key]
		if not ContentCatalog._number(biome.get("minimum_revision",1),1,4,true) or biome.get("tree_style","oak") not in ["oak","spruce","acacia","swamp"]:
			DataFile.fail("biomes.json: invalid revision/tree style for "+str(key))
			return false
		if biome.has("color_climate"):
			var climate: Variant=biome["color_climate"]
			for tint in ["grass","foliage","grass_alternate"]:
				if climate is Dictionary and climate.has(tint) and (not climate[tint] is String or not Color.html_is_valid(str(climate[tint]))):
					DataFile.fail("biomes.json: invalid climate tint for "+str(key));return false
			if climate is Dictionary and not climate.get("snow",false) is bool:DataFile.fail("biomes.json: snow must be boolean.");return false
			if not climate is Dictionary or not ContentCatalog._number(climate.get("temperature"),-2,2) or not ContentCatalog._number(climate.get("downfall"),0,1) or not climate.get("precipitation") is bool or not climate.get("water") is String or not Color.html_is_valid(str(climate.get("water",""))):
				DataFile.fail("biomes.json: invalid color climate for "+str(key))
				return false
		if biome.get("surface_profile", "grassland") not in ["grassland", "desert", "rocky", "badlands"]:
			DataFile.fail("biomes.json: unknown surface profile for " + str(key))
			return false
		if biome.get("surface_profile")=="badlands":
			if not biome.get("strata") is Array or biome.strata.is_empty() or biome.strata.size()>32:DataFile.fail("biomes.json: invalid badlands strata.");return false
			for block in biome.strata:
				if not block is String or BlockDatabase.id_for(block)==0:return false
		if config.generation_revision >= 2:
			var placement: Variant = biome.get("placement")
			if not placement is Dictionary or not placement.get("ranges") is Dictionary:
				DataFile.fail("biomes.json: placement ranges required for " + str(key))
				return false
			if not placement.get("weights", {}) is Dictionary or not ContentCatalog._number(placement.get("offset", 0), -10, 10) or not ContentCatalog._number(placement.get("minimum_relief", 12), 0, 128):
				DataFile.fail("biomes.json: invalid placement weights/offset/relief")
				return false
			for field in placement.get("weights", {}):
				if not placement["ranges"].has(field) or not ContentCatalog._number(placement["weights"][field], .001, 100):
					DataFile.fail("biomes.json: invalid placement weight")
					return false
			for field in placement["ranges"]:
				var bounds: Variant = placement["ranges"][field]
				if field not in ["temperature", "humidity", "mountain_rise", "continentalness", "erosion", "peaks_valleys"] or not bounds is Array or bounds.size() != 2 or not ContentCatalog._number(bounds[0], -1000, 1000) or not ContentCatalog._number(bounds[1], float(bounds[0]), 1000):
					DataFile.fail("biomes.json: invalid placement interval")
					return false
		BlockDatabase.id_for(str(biome.get("surface", "")))
		if not ContentCatalog._number(biome.get("tree_chance"), 0, 1) or not ContentCatalog._number(biome.get("birch_chance"), 0, 1) or not biome.get("plants") is Array:
			DataFile.fail("biomes.json: invalid vegetation for " + key)
			return false
		for plant in biome["plants"]:
			if not plant is Dictionary or not ContentCatalog._number(plant.get("chance"), 0, 1) or not ContentCatalog._number(plant.get("height"), 1, 3, true):
				DataFile.fail("biomes.json: invalid plant distribution")
				return false
			BlockDatabase.id_for(str(plant.get("block", "")))
	for field in ["mountain_relief", "detail_amplitude", "calcite_period", "calcite_width"]:
		if not ContentCatalog._number(data["terrain"].get(field), 0.01, 128):
			DataFile.fail("biomes.json: invalid terrain control " + field)
			return false
	for field in ["continental_start", "continental_full"]:
		if not ContentCatalog._number(data["terrain"].get(field), -1, 1):
			DataFile.fail("biomes.json: invalid climate control " + field)
			return false
	if float(data["terrain"]["continental_full"]) <= float(data["terrain"]["continental_start"]):
		DataFile.fail("biomes.json: continental_full must exceed continental_start.")
		return false
	if not data.get("selection") is Array or not data["biomes"].has(str(data.get("default_biome", ""))):
		DataFile.fail("biomes.json: selection rules and a valid default_biome are required.")
		return false
	for rule in data["selection"]:
		if not rule is Dictionary or not data["biomes"].has(str(rule.get("biome", ""))) or not rule.get("ranges") is Dictionary:
			DataFile.fail("biomes.json: invalid biome selection rule.")
			return false
		for field in rule["ranges"]:
			var bounds: Variant = rule["ranges"][field]
			if field not in ["continentalness", "erosion", "peaks_valleys", "temperature", "humidity", "mountain_rise"] or not bounds is Array or bounds.size() != 2 or not ContentCatalog._number(bounds[0], -1000, 1000) or not ContentCatalog._number(bounds[1], float(bounds[0]), 1000):
				DataFile.fail("biomes.json: invalid climate interval in selection.")
				return false
	return DataFile.errors.is_empty()

func sample(key: String, x: float) -> float:
	if key in ["temperature", "humidity"]: x /= maxf(config.biome_size, 0.1)
	elif key in ["continentalness", "erosion", "weirdness"]: x /= maxf(config.terrain_region_size, 0.25)
	var rule: Dictionary = data["noises"][key]
	var offset: Array = rule.get("offset", [18371.5, 27431.25])
	# A non-grid slice avoids identical zero-valued climate at every seed's origin.
	return clampf(noise[key].get_noise_2d(x + float(offset[0]), float(offset[1])) * float(rule["strength"]), -1, 1)

func curve(points: Array, x: float) -> float:
	# Zero-tangent cubic segments create broad flats and shoulders, not sine hills.
	if x <= float(points[0][0]): return float(points[0][1])
	for i in range(1, points.size()):
		if x <= float(points[i][0]):
			return lerpf(float(points[i - 1][1]), float(points[i][1]), smoothstep(float(points[i - 1][0]), float(points[i][0]), x))
	return float(points.back()[1])

func climate_column(x: int) -> Dictionary:
	if _climate_columns.has(x): return _climate_columns[x]
	var c: float = sample("continentalness", x)
	var e: float = sample("erosion", x)
	var w: float = sample("weirdness", x)
	var t: float = sample("temperature", x)
	var h: float = sample("humidity", x)
	# This is the ridges_folded transform used by Minecraft's density functions.
	var pv: float = -(absf(absf(w) - 2.0 / 3.0) - 1.0 / 3.0) * 3.0
	var rules: Dictionary = data["terrain"]
	var inland: float = smoothstep(float(rules["continental_start"]), float(rules["continental_full"]), c)
	var mountain: float = inland * curve(data["erosion_curve"], e) * curve(data["peak_curve"], pv)
	# Temperature and humidity choose biomes; they do not change terrain height.
	var rise: float = mountain * float(rules["mountain_relief"])
	var height: float = config.top_y - config.surface_level + curve(data["continental_curve"], c)
	height += sample("detail", x) * float(rules["detail_amplitude"]) * lerpf(.3, 1, inland)
	height += rise
	var climate: Dictionary = {"continentalness": c, "erosion": e, "peaks_valleys": pv, "temperature": t, "humidity": h, "mountain_rise": rise}
	var key: String = str(data["default_biome"])
	for rule in data["selection"]:
		var matches: bool = true
		for field in rule["ranges"]:
			var bounds: Array = rule["ranges"][field]
			if float(climate[field]) < float(bounds[0]) or float(climate[field]) > float(bounds[1]):
				matches = false
				break
		if matches:
			key = str(rule["biome"])
			break
	var result: Dictionary = {"biome": key, "surface": clampi(roundi(config.top_y - height), 6, config.top_y - config.bottom_y - 23), "continentalness": c, "erosion": e, "peaks_valleys": pv, "temperature": t, "humidity": h, "mountain_rise": rise}
	_climate_columns[x] = result
	return result

func _roll(value: int, salt: int) -> float:
	var n: int = (value * 374761393 + _seed + salt) & 0x7fffffff
	n = ((n ^ (n >> 13)) * 1274126177) & 0x7fffffff
	return float(n ^ (n >> 16)) / 2147483647.0

func _region_width() -> int:
	return maxi(config.minimum_biome_width, roundi(config.biome_region_width * config.biome_size))

func _boundary(index: int) -> int:
	var width: int = _region_width()
	var jitter: int = mini(floori(width * .15), (width - config.minimum_biome_width) / 2)
	return index * width + roundi((_roll(index, 9719) * 2.0 - 1.0) * jitter)

func _region_plan(group: int) -> Array:
	if _region_plans.has(group): return _region_plans[group]
	var result: Array = []
	var recent: Array[String] = []
	var counts: Dictionary = {}
	for index in range(group * REGIONS_PER_PLAN, (group + 1) * REGIONS_PER_PLAN):
		var left: int = _boundary(index)
		var right: int = _boundary(index + 1)
		var climate: Dictionary = climate_column((left + right) / 2).duplicate()
		# A mountain region must actually contain mountain relief.
		for fraction in [.15, .35, .65, .85]:
			climate["mountain_rise"] = maxf(float(climate["mountain_rise"]), float(climate_column(roundi(lerpf(left, right, fraction)))["mountain_rise"]))
		var best: String = str(data["default_biome"])
		var best_cost: float = INF
		var number: int = 0
		for key in data["biomes"]:
			if int(data["biomes"][key].get("minimum_revision",1))>config.biome_revision: continue
			number += 1
			var mountain: bool = bool(data["biomes"][key].get("mountain", false))
			var cost: float = .8 if key == data["default_biome"] else .2
			if mountain:
				var minimum_rise: float = 6.0
				for rule in data["selection"]:
					if rule["biome"] == key and rule["ranges"].has("mountain_rise"): minimum_rise = float(rule["ranges"]["mountain_rise"][0])
				if float(climate["mountain_rise"]) < minimum_rise: continue
				cost = .65 - minf(1.0, float(climate["mountain_rise"]) / maxf(1.0,float(data["terrain"]["mountain_relief"])))
			else:
				for rule in data["selection"]:
					if rule["biome"] != key: continue
					for field in rule["ranges"]:
						var bounds: Array = rule["ranges"][field]
						var value: float = float(climate[field])
						cost += maxf(float(bounds[0]) - value, maxf(value - float(bounds[1]), 0)) * 3.0
			# Strong cooldown prevents local A-B-A flickering. A small usage cost
			# spreads the available types rather than repeatedly picking humidity's favorite.
			if not recent.is_empty() and key == recent.back(): cost += 20
			if recent.size() > 1 and key == recent[recent.size() - 2]: cost += 6
			cost += int(counts.get(key, 0)) * .12 + _roll(index, 19793 + number * 101) * .7
			if cost < best_cost:
				best_cost = cost
				best = key
		result.append({"left": left, "right": right, "biome": best})
		recent.append(best)
		counts[best] = int(counts.get(best, 0)) + 1
	_region_plans[group] = result
	return result

func _raw_region(index: int) -> Dictionary:
	if config.generation_revision >= 2: return _climate_region(index)
	var group: int = floori(float(index) / REGIONS_PER_PLAN)
	return _region_plan(group)[posmod(index, REGIONS_PER_PLAN)]

func _climate_region(index: int) -> Dictionary:
	# Regional samples preserve climate relationships without a forced biome cycle.
	var cache_key: String = "climate_" + str(index)
	if _region_plans.has(cache_key): return _region_plans[cache_key]
	var left: int = _boundary(index)
	var right: int = _boundary(index + 1)
	var climate: Dictionary = {}
	for fraction in [.25, .5, .75]:
		var sample_column: Dictionary = climate_column(roundi(lerpf(left, right, fraction)))
		for field in ["temperature", "humidity", "mountain_rise", "continentalness", "erosion", "peaks_valleys"]:
			climate[field] = float(climate.get(field, 0)) + float(sample_column[field]) / 3.0
	var best: String = str(data["default_biome"])
	var best_cost: float = INF
	for key in data["biomes"]:
		if int(data["biomes"][key].get("minimum_revision",1))>config.biome_revision: continue
		var placement: Dictionary = data["biomes"][key].get("placement", {})
		if placement.is_empty(): continue
		if bool(data["biomes"][key].get("mountain", false)) and float(climate["mountain_rise"]) < float(placement.get("minimum_relief", 12)): continue
		var cost: float = 0.0
		for field in placement.get("ranges", {}):
			var bounds: Array = placement["ranges"][field]
			var distance: float = maxf(float(bounds[0]) - float(climate[field]), maxf(float(climate[field]) - float(bounds[1]), 0))
			cost += distance * distance * float(placement.get("weights", {}).get(field, 1.0))
		cost += float(placement.get("offset", 0))
		if cost < best_cost:
			best_cost = cost
			best = str(key)
	var result: Dictionary = {"left": left, "right": right, "biome": best}
	_region_plans[cache_key] = result
	return result

func seam_x(index: int, world_row: int) -> float:
	# One shared curve per boundary, not independently selected column materials.
	# World Y makes both sides evaluate the exact same seam on sloping terrain.
	var boundary: int = _boundary(index)
	var surface: int = int(climate_column(boundary)["surface"])
	var depth: float = maxf(0, world_row - surface)
	var amplitude: float = minf(config.biome_transition_width * .5, config.minimum_biome_width * .20)
	var phase: float = _roll(index, 45119) * TAU
	var phase2: float = _roll(index, 65123) * TAU
	var offset: float = (sin(depth * .42 + phase) - sin(phase)) * .65
	offset += (sin(depth * .17 + phase2) - sin(phase2)) * .35
	return boundary + offset * amplitude * .45

func _region(index: int) -> Dictionary:
	if _resolved_regions.has(index): return _resolved_regions[index]
	var result: Dictionary = _raw_region(index).duplicate()
	var left: String = str(_raw_region(index - 1)["biome"])
	var right: String = str(_raw_region(index + 1)["biome"])
	# Resolve short returns across independent plan seams from immutable raw
	# neighbors. This is deterministic even when chunks load in reverse order.
	if left == right: result["biome"] = left
	_resolved_regions[index] = result
	return result

func column(x: int) -> Dictionary:
	if columns.has(x): return columns[x]
	var result: Dictionary = climate_column(x).duplicate()
	if config.coherent_biomes:
		var index: int = floori(float(x) / _region_width())
		if x < _boundary(index): index -= 1
		elif x >= _boundary(index + 1): index += 1
		var region: Dictionary = _region(index)
		var key: String = region["biome"]
		result["biome"] = key
		result["blend_from"] = key
		result["blend_to"] = key
		result["blend"] = 0.0
		var half: float = minf(config.biome_transition_width * .5, (int(region["right"]) - int(region["left"])) * .25)
		if half > 0:
			if x < int(region["left"]) + half:
				result["blend_from"] = _region(index - 1)["biome"]
				result["blend"] = smoothstep(int(region["left"]) - half, int(region["left"]) + half, x)
			elif x > int(region["right"]) - half:
				result["blend_to"] = _region(index + 1)["biome"]
				result["blend"] = smoothstep(int(region["right"]) - half, int(region["right"]) + half, x)
	columns[x] = result
	return result

func material_biome(x: int, cover: int = 0) -> String:
	if config.coherent_biomes and config.generation_revision >= 2:
		if cover <= 0: return str(column(x)["biome"])
		var index: int = floori(float(x) / _region_width())
		var row: int = int(climate_column(x)["surface"]) + cover
		if x < seam_x(index, row): index -= 1
		elif x >= seam_x(index + 1, row): index += 1
		return str(_region(index)["biome"])
	var info: Dictionary = column(x)
	if not info.has("blend_from"): return str(info["biome"])
	# Revision 1 compatibility only: retain existing saved worlds exactly.
	# New worlds return above and use a single shared boundary curve.
	var salt: int = 45119 + floori(maxi(0, cover) / 2.0) * 668265263
	return str(info["blend_to"] if _roll(floori(x / 3.0), salt) < float(info["blend"]) else info["blend_from"])

func definition(x: int) -> Dictionary:
	if _definitions.has(x): return _definitions[x]
	var info: Dictionary = column(x)
	if not config.coherent_biomes: return data["biomes"][info["biome"]]
	var result: Dictionary = data["biomes"][material_biome(x)].duplicate()
	var from: Dictionary = data["biomes"][info["blend_from"]]
	var to: Dictionary = data["biomes"][info["blend_to"]]
	result["tree_chance"] = lerpf(float(from["tree_chance"]), float(to["tree_chance"]), float(info["blend"])) if result.get("surface_profile", "grassland") == "grassland" else 0.0
	result["birch_chance"] = lerpf(float(from["birch_chance"]), float(to["birch_chance"]), float(info["blend"]))
	_definitions[x] = result
	return result

func material(cell: Vector2i, surface: int, base_id: int) -> int:
	# Biome surface rules have no work to do in the deep underground.
	if cell.y - surface >= 24: return base_id
	var key: String = material_biome(cell.x, cell.y - surface) if config.coherent_biomes else str(column(cell.x)["biome"])
	if config.coherent_biomes and cell.y - surface <= config.minimum_dirt_depth:
		var surface_key: String = material_biome(cell.x)
		# Keep dirt under grass, but allow soil wedges beneath desert sand.
		if config.generation_revision < 2:
			key = surface_key
		elif cell.y > surface and data["biomes"][surface_key].get("surface_profile") == "grassland":
			return BlockDatabase.id_for(config.soil_block)
	var profile: String = str(data["biomes"][key].get("surface_profile", "grassland"))
	var cover: int = cell.y - surface
	if profile == "grassland" and cover >= 1 and cover <= config.minimum_dirt_depth:
		return BlockDatabase.id_for(config.soil_block)
	if profile=="badlands":
		var biome: Dictionary=data.biomes[key]
		if cover<2:return BlockDatabase.id_for("red_sand")
		if cover<4:return BlockDatabase.id_for("red_sandstone")
		var band: int=posmod(floori((config.top_y-cell.y+sample("detail",cell.x)*2)/2),biome.strata.size())
		return BlockDatabase.id_for(str(biome.strata[band]))
	if profile == "desert":
		var biome: Dictionary = data["biomes"][key]
		var sand_depth: int = int(biome["sand_depth"]) + roundi(sample("detail", cell.x) * 2)
		if cover < sand_depth: return BlockDatabase.id_for("sand")
		if cover < sand_depth + int(biome["sandstone_depth"]): return BlockDatabase.id_for("sandstone")
	elif profile == "rocky" and cover < 24:
		var y: int = config.top_y - cell.y
		var band: float = fposmod(y + cell.x * .17 + sample("detail", cell.x) * 7, float(data["terrain"]["calcite_period"]))
		if band < float(data["terrain"]["calcite_width"]): return BlockDatabase.id_for("calcite")
		if str(BlockDatabase.BLOCKS.get(base_id, {}).get("key", "")) in ["dirt", "grass", "sand"]: return BlockDatabase.id_for("stone")
		return base_id
	if cover == 0: return BlockDatabase.id_for(str(data["biomes"][key]["surface"]))
	return base_id

func retain_columns_near(x: int) -> void:
	for column_x in _definitions.keys():
		if absi(column_x - x) > 768: _definitions.erase(column_x)
	var center: int = floori(float(x) / _region_width())
	for index in _resolved_regions.keys():
		if absi(index - center) > REGIONS_PER_PLAN * 3: _resolved_regions.erase(index)
	for column_x in _climate_columns.keys():
		if absi(column_x - x) > 768: _climate_columns.erase(column_x)
	var group: int = floori(float(x) / (_region_width() * REGIONS_PER_PLAN))
	for cached in _region_plans.keys():
		if cached is String:
			if absi(int(cached.trim_prefix("climate_")) - center) > REGIONS_PER_PLAN * 3: _region_plans.erase(cached)
		elif absi(cached - group) > 2: _region_plans.erase(cached)
	for column_x in columns.keys():
		if absi(column_x - x) > 768: columns.erase(column_x)


