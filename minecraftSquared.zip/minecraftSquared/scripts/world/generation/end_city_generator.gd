class_name EndCityGenerator
extends RefCounted
static var RULES: Dictionary=DataFile.object_from("res://data/end_cities.json")
static var PIECES: Dictionary=DataFile.object_from("res://data/end_city_pieces.json").get("pieces",{})
var seed_value: int
var outer: EndOuterGenerator
var plans: Dictionary={}
func setup(value: int,generator: EndOuterGenerator) -> void:seed_value=value;outer=generator;plans.clear()
func region_at(x: int) -> int:return floori(float(x)/int(RULES.region_width))
func _put(p: Dictionary,cell: Vector2i,key: String) -> void:p.blocks[cell]=BlockDatabase.id_for(key)
func _stamp(p: Dictionary,name: String,left: int,bottom: int,mirror: bool=false) -> Dictionary:
	var piece: Dictionary=PIECES[name];var width: int=piece.size[0];var bounds:=Rect2i(left,bottom-int(piece.size[1])+1,width,int(piece.size[1]))
	for a in piece.blocks:
		var key: String=a[2]
		if mirror:
			var e: Dictionary=BlockDatabase.BLOCKS.get(BlockDatabase.id_for(key),{})
			if e.has("building") and e.building.kind=="stairs":key=BuildingShapesKey.mirror(key)
		_put(p,Vector2i(left+(width-1-int(a[0]) if mirror else int(a[0])),bottom+int(a[1])),key)
	for a in piece.walls:p.walls[Vector2i(left+(width-1-int(a[0]) if mirror else int(a[0])),bottom+int(a[1]))]=BlockDatabase.id_for(str(a[2]))
	# A 3D middle slice omits side faces and contains staircase voids intended
	# for adjoining pieces. Build a closed 2D cutaway shell around that room.
	if not name.begins_with("bridge") and name!="ship" and not name.ends_with("roof"):
		var margin: int=3 if name=="fat_tower_top" else 2 if name=="tower_top" else 1
		var wall_left: int=left+margin;var wall_right: int=left+width-margin-1
		var material: String="purpur_pillar" if name.begins_with("tower") else "end_stone_bricks"
		for xx in range(wall_left,wall_right+1):
			for yy in range(bounds.position.y,bottom+1):
				var at:=Vector2i(xx,yy)
				_put(p,at,"purpur_block" if yy==bottom else material if xx==wall_left or xx==wall_right else "air")
				if xx>wall_left and xx<wall_right and yy<bottom:p.walls[at]=BlockDatabase.id_for(material)
		if name in ["fat_tower_top","tower_top"]:
			var roof_y: int=bounds.position.y+(1 if name=="fat_tower_top" else 0)
			for xx in range(left,left+width):
				_put(p,Vector2i(xx,roof_y),"purpur_block" if xx>left and xx<left+width-1 else "purpur_stairs")
			if name=="fat_tower_top":
				for xx in range(left,left+width):
					_put(p,Vector2i(xx,bounds.position.y),"air");p.walls.erase(Vector2i(xx,bounds.position.y))
	if name.ends_with("roof"):
		# Native roofs have an empty upper slice; fill it in the 2D section so
		# the narrower tower above cannot float one cell over the roof.
		for xx in range(left+1,left+width-1):_put(p,Vector2i(xx,bounds.position.y),"purpur_block")
	p.pieces.append({"name":name,"bounds":bounds});p.bounds=p.bounds.merge(bounds) if p.bounds.has_area() else bounds
	return {"bounds":bounds,"center":left+width/2,"bottom":bottom}
func _access(p: Dictionary,x: int,top: int,bottom: int) -> void:
	# The 3D spiral staircase becomes a narrow climbable access shaft in 2D.
	for y in range(top,bottom+1):
		_put(p,Vector2i(x,y),"ladder");p.walls[Vector2i(x,y)]=BlockDatabase.id_for("purpur_pillar")
		_put(p,Vector2i(x+1,y),"air")
func _bridge(p: Dictionary,from_x: int,to_x: int,end_floor: int,steep: bool=false) -> void:
	# Native bridges have a full deck and inverted stair brackets. Their gentle
	# and steep sections descend away from the parent tower by four blocks.
	var direction: int=signi(to_x-from_x);var length: int=absi(to_x-from_x)+1
	var slope_width: int=4 if steep else 8
	var cursor: int=from_x;var remaining: int=length;var floor_y: int=end_floor-4
	var first: bool=true
	while remaining>0:
		var sloped: bool=first and remaining>=slope_width
		var name: String=("bridge_steep_stairs" if steep else "bridge_gentle_stairs") if sloped else "bridge_piece"
		var width: int=slope_width if sloped else mini(4,remaining)
		var left: int=cursor if direction>0 else cursor-width+1
		var bottom: int=floor_y+5 if sloped else floor_y+1
		# Short final sections crop the native flat piece instead of overlapping rooms.
		var piece: Dictionary=PIECES[name]
		for layer in ["blocks","walls"]:
			for a in piece[layer]:
				if int(a[0])>=width:continue
				var local_x: int=int(a[0]) if direction>0 else width-1-int(a[0])
				var at:=Vector2i(left+local_x,bottom+int(a[1]));var key: String=str(a[2])
				if direction<0 and key.begins_with("purpur_stairs"):key=BuildingShapesKey.mirror(key)
				if layer=="blocks":_put(p,at,key)
				elif key!="air":p.walls[at]=BlockDatabase.id_for(key)
		var bounds:=Rect2i(left,bottom-int(piece.size[1])+1,width,int(piece.size[1]))
		p.pieces.append({"name":name,"bounds":bounds});p.bounds=p.bounds.merge(bounds)
		# Carve only the walking route, retaining each native underside support.
		for i in range(width):
			var row: int=floor_y+(mini(4,floori(float(i)/2)) if sloped and not steep else mini(4,i) if sloped else 0)
			var xx: int=cursor+direction*i
			for dy in range(1,4):_put(p,Vector2i(xx,row-dy),"air")
		if sloped:floor_y+=4
		cursor+=direction*width;remaining-=width;first=false
	# Two-block doorways connect at wall faces; room interiors remain intact.
	for endpoint in [Vector2i(from_x-direction,end_floor-4),Vector2i(to_x+direction,end_floor)]:
		_put(p,endpoint,"purpur_block")
		for dy in range(1,4):_put(p,endpoint-Vector2i(0,dy),"air")
func _chest(p: Dictionary,at: Vector2i) -> void:
	_put(p,at,"chest");_put(p,at+Vector2i.DOWN,"purpur_block");_put(p,at+Vector2i.UP,"air");p.containers[at]="end_city"
func _guardian(p: Dictionary,at: Vector2i) -> void:
	if p.guardians.size()>=int(RULES.guardian_cap):return
	_put(p,at,"air");_put(p,at+Vector2i.DOWN,"purpur_block");p.guardians[at]=true
	_put(p,at+Vector2i.UP,"air")
func plan(region: int) -> Dictionary:
	if plans.has(region):return plans[region]
	if plans.size()>=int(RULES.cache_regions):plans.erase(plans.keys()[0])
	var p: Dictionary={"blocks":{},"walls":{},"containers":{},"spawners":{},"guardians":{},"potions":[],"pieces":[],"bounds":Rect2i(),"ship":false,"origin":Vector2i.ZERO}
	plans[region]=p;var rng:=RandomNumberGenerator.new();rng.seed=seed_value^(region*734317)^192319
	if rng.randf()>float(RULES.chance):return p
	var start: int=region*int(RULES.region_width);var anchor:=Vector2i.ZERO
	for index in range(outer.region_at(start+128),outer.region_at(start+int(RULES.region_width)-128)+1):
		for island in outer.plan(index).islands:
			var x: int=island.x
			if not island.large or absi(x)<int(EndOuterGenerator.RULES.start_x)+80 or x<start+128 or x>start+int(RULES.region_width)-128:continue
			if outer.rogue_center(index)!=Vector2i.ZERO:continue
			anchor=Vector2i(x,int(outer.column(x).top));break
		if anchor!=Vector2i.ZERO:break
	if anchor==Vector2i.ZERO:return p
	p.origin=anchor;var x: int=anchor.x;var floor_y: int=anchor.y
	_stamp(p,"base_floor",x-5,floor_y)
	_stamp(p,"second_floor_1",x-6,floor_y-3)
	_stamp(p,"third_floor_2",x-7,floor_y-10)
	_stamp(p,"third_roof",x-8,floor_y-17)
	var tower_bottom: int=floor_y-19;_stamp(p,"tower_base",x-3,tower_bottom)
	var levels: int=rng.randi_range(2,4)
	for i in range(levels):_stamp(p,"tower_piece",x-3,tower_bottom-6-i*4)
	var tower_top: int=tower_bottom-6-levels*4;_stamp(p,"tower_top",x-4,tower_top)
	_access(p,x-1,tower_top-2,floor_y-1)
	for side in [-1,1]:
		if side==-1 and rng.randf()<.25:continue
		var branch_x: int=x+side*rng.randi_range(24,34);var branch_floor: int=floor_y-rng.randi_range(10,14)
		_stamp(p,"fat_tower_base",branch_x-6,branch_floor)
		_stamp(p,"fat_tower_middle",branch_x-6,branch_floor-3)
		_stamp(p,"fat_tower_top",branch_x-8,branch_floor-10)
		_bridge(p,x+side*3,branch_x-side*6,branch_floor,rng.randf()<.35)
		_access(p,branch_x-1,branch_floor-13,branch_floor-1)
		_chest(p,Vector2i(branch_x+3,branch_floor-11));_chest(p,Vector2i(branch_x-4,branch_floor-11))
		_guardian(p,Vector2i(branch_x+4,branch_floor-4));_guardian(p,Vector2i(branch_x-4,branch_floor-4))
	for dx in [-3,3]:_guardian(p,anchor+Vector2i(dx,-1))
	_guardian(p,Vector2i(x+2,tower_top-1));_chest(p,Vector2i(x+4,floor_y-12))
	if rng.randf()<float(RULES.ship_chance):
		p.ship=true;var left: int=x+48;var bottom: int=tower_top+9
		_stamp(p,"ship",left,bottom)
		_bridge(p,x+3,left-5,bottom-5)
		_access(p,left+23,bottom-8,bottom-4)
		_chest(p,Vector2i(left+6,bottom-4));_chest(p,Vector2i(left+9,bottom-4))
		_put(p,Vector2i(left+7,bottom-6),"elytra_display");p.walls[Vector2i(left+7,bottom-6)]=BlockDatabase.id_for("purpur_block")
		_guardian(p,Vector2i(left+12,bottom-4));_guardian(p,Vector2i(left+25,bottom-7))
		var stand:=Vector2i(left+24,bottom-7);_put(p,stand,"brewing_stand");_put(p,stand+Vector2i.DOWN,"purpur_block");p.potions.append(stand)
		_put(p,Vector2i(left,bottom-8),"dragon_head_right");_put(p,Vector2i(left+1,bottom-8),"purpur_block")
	_access(p,x-1,tower_top-2,floor_y-1)
	# Embed the base in the island and keep its entrance at the terrain surface.
	for xx in range(x-5,x+5):
		for y in range(floor_y,int(outer.column(xx).top)+2):_put(p,Vector2i(xx,y),"purpur_pillar")
	for side in [-1,1]:
		for y in range(floor_y-2,floor_y):_put(p,Vector2i(x+(-4 if side<0 else 3),y),"air")
	return p
func block_at(cell: Vector2i) -> int:return int(plan(region_at(cell.x)).blocks.get(cell,-1))
func wall_at(cell: Vector2i) -> int:return int(plan(region_at(cell.x)).walls.get(cell,0))
func column_top(x: int,top: int) -> int:
	var p: Dictionary=plan(region_at(x))
	if p.bounds.has_area() and x>=p.bounds.position.x and x<p.bounds.end.x:return mini(top,p.bounds.position.y)
	return top
static func valid() -> bool:
	if RULES.get("version")!=1 or not ContentCatalog._number(RULES.get("region_width"),384,2048,true) or not ContentCatalog._number(RULES.get("chance"),0,1) or not ContentCatalog._number(RULES.get("ship_chance"),0,1):return false
	for piece in PIECES.values():
		for a in piece.blocks:
			if a[2]!="air" and BlockDatabase.id_for(a[2])==0:DataFile.fail("Unknown End city template material: "+str(a[2]));return false
	return true


