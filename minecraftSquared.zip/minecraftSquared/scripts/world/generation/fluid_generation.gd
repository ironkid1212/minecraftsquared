class_name FluidGeneration
extends RefCounted

var settings: FluidSettings
var seed_value: int
var _profiles: Dictionary = {}
var _pools: Dictionary = {}
var water_id: int
var lava_id: int

func setup(seed_number: int, config: FluidSettings) -> void:
	seed_value = seed_number
	settings = config
	water_id = BlockDatabase.id_for("water")
	lava_id = BlockDatabase.id_for("lava")

func _rng(a: int, b: int = 0) -> RandomNumberGenerator:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value ^ (a * 73856093) ^ (b * 19349663) ^ 83492791
	return rng

func profile(x: int, base_surface: Callable) -> Dictionary:
	if not settings.generation_enabled: return {}
	var region: int = floori(float(x) / settings.surface_region_width)
	if not _profiles.has(region):
		var rng: RandomNumberGenerator = _rng(region)
		var choice: float = rng.randf()
		var entry: Dictionary = {}
		if choice < settings.lake_chance + settings.channel_chance:
			var channel: bool = choice >= settings.lake_chance
			var radius: int = settings.channel_radius if channel else settings.lake_radius
			var margin: int = radius+settings.shore_width+settings.shore_blend_width+2 if settings.shore_revision>=2 else radius+8
			var center: int = region * settings.surface_region_width + rng.randi_range(margin,settings.surface_region_width-margin)
			# A fixed, low waterline bounded by both banks, independent of chunk order.
			var line: int = maxi(int(base_surface.call(center-radius-1)),int(base_surface.call(center+radius+1)))+1
			line = maxi(line,int(base_surface.call(center)))
			var high: int = mini(int(base_surface.call(center-radius-1)),int(base_surface.call(center+radius+1)))
			if line-high > settings.maximum_bank_relief:
				_profiles[region]={}
				return {}
			entry = {"center":center,"radius":radius,"line":line,"depth":settings.channel_depth if channel else settings.lake_depth}
			if settings.shore_revision>=2: entry.merge({"left_bank":rng.randi_range(0,1),"right_bank":rng.randi_range(0,1)})
		_profiles[region] = entry
	return _profiles[region]

func surface_y(x: int, base: int, base_surface: Callable) -> int:
	var entry: Dictionary = profile(x,base_surface)
	if entry.is_empty(): return base
	var distance: float = absf(float(x-int(entry["center"]))) / int(entry["radius"])
	if distance >= 1:
		if settings.shore_revision<2: return base
		var steps: int=absi(x-int(entry["center"]))-int(entry["radius"])
		var rise: int=int(entry.get("left_bank" if x<int(entry["center"]) else "right_bank",0))
		# The water-facing sand is at the water source's row. Remaining beach
		# columns can rise by ONE block, then a broad graded strip joins terrain.
		if steps<settings.shore_width: return int(entry["line"])-(rise if steps>0 else 0)
		if steps<settings.shore_width+settings.shore_blend_width:
			var blend: float=float(steps-settings.shore_width+1)/settings.shore_blend_width
			return roundi(lerpf(float(int(entry["line"])-rise),base,blend))
		return base
	return maxi(base,int(entry["line"])+maxi(1,roundi(sqrt(1.0-distance*distance)*int(entry["depth"]))))

func surface_water(cell: Vector2i, surface: int, base_surface: Callable) -> bool:
	if not settings.generation_enabled or cell.y >= surface: return false
	var entry: Dictionary = profile(cell.x,base_surface)
	return not entry.is_empty() and absi(cell.x-int(entry["center"])) < int(entry["radius"]) and cell.y >= int(entry["line"])

## Small sealed aquifer chambers, cut through the host rock rather than floating
## sheets of water in arbitrary caves. Existing caves can connect to a chamber.
func underground(cell: Vector2i, base_surface: Callable, world_depth: int) -> int:
	if not settings.generation_enabled: return -1
	var region := Vector2i(floori(cell.x/128.0),floori(cell.y/64.0))
	if not _pools.has(region):
		var rng: RandomNumberGenerator = _rng(region.x,region.y+1001)
		var entry: Dictionary = {}
		if rng.randf() < settings.underground_pool_chance:
			var center := region*Vector2i(128,64)+Vector2i(rng.randi_range(18,110),rng.randi_range(12,52))
			if center.y > int(base_surface.call(center.x))+18 and center.y < world_depth-18:
				entry = {"center":center,"radius":rng.randi_range(6,11),"height":rng.randi_range(4,6)}
		_pools[region]=entry
	var pool: Dictionary = _pools[region]
	if pool.is_empty(): return -1
	var offset: Vector2i = cell-Vector2i(pool["center"])
	if pow(float(offset.x)/int(pool["radius"]),2)+pow(float(offset.y)/int(pool["height"]),2) >= 1: return -1
	return water_id if offset.y >= 1 else 0

func retain_near(x: int) -> void:
	for region in _profiles.keys():
		if absi(region-floori(float(x)/settings.surface_region_width)) > 8: _profiles.erase(region)
	for region in _pools.keys():
		if absi(region.x-floori(x/128.0)) > 8: _pools.erase(region)

func is_shore(x: int, base_surface: Callable) -> bool:
	if settings.shore_revision < 2: return false
	var entry: Dictionary=profile(x,base_surface)
	if entry.is_empty(): return false
	var distance: int=absi(x-int(entry["center"]))-int(entry["radius"])
	return distance>=0 and distance<settings.shore_width

func cane_height(x: int, base_surface: Callable) -> int:
	if settings.shore_revision < 2: return 0
	var entry: Dictionary=profile(x,base_surface)
	if entry.is_empty() or absi(x-int(entry["center"]))!=int(entry["radius"]): return 0
	var rng: RandomNumberGenerator=_rng(x,8017)
	if rng.randf()>=settings.sugar_cane_chance: return 0
	return rng.randi_range(1,3)
