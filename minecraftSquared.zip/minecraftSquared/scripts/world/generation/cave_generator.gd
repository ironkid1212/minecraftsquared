class_name CaveGenerator
extends RefCounted

var settings: CaveSettings = CaveSettings.new()
var _noise_caves := NoiseCaves.new()
var _seed: int
var _modern: bool = false
var _depth: int
var _regions: Dictionary = {}

var _mask: Dictionary = {}
var _heights: Dictionary = {}
var _surface_sampler: Callable
var _rng := RandomNumberGenerator.new()
var _left: float
var _right: float


func setup(world_seed: int, world_depth: int, config: CaveSettings = null, modern: bool = false) -> void:
	settings = config if config != null else CaveSettings.new()
	_modern = modern
	_seed = world_seed
	_depth = world_depth
	_regions.clear()
	_noise_caves.setup(world_seed, world_depth, settings)


func is_cave(cell: Vector2i, surface_sampler: Callable) -> bool:
	if not settings.enabled or cell.y < 0 or cell.y >= _depth - settings.bottom_margin:
		return false
	if settings.noise_caves: return _noise_caves.is_cave(cell, surface_sampler)
	if settings.systems_per_region <= 0 or settings.system_probability <= 0: return false
	var region: int = floori(float(cell.x) / settings.region_width)
	for offset in range(-1, 2):
		var mask: Dictionary = _get_region(region + offset, surface_sampler)
		if mask.has(cell):
			return true
	return false


func _get_region(region: int, surface_sampler: Callable) -> Dictionary:
	if _regions.has(region):
		return _regions[region]
	_mask = {}
	_heights = {}
	_surface_sampler = surface_sampler
	_rng.seed = _seed + region * 92837111 + 60493
	_left = float(region * settings.region_width + 8)
	_right = float((region + 1) * settings.region_width - 8)

	for system_index in range(settings.systems_per_region):
		# Preserve the existing random sequence at probability 1.0.
		if settings.system_probability < 1.0 and _rng.randf() >= settings.system_probability:
			continue
		_build_system(region)
	_smooth_mask()

	var result: Dictionary = _mask
	_regions[region] = result
	# Release the temporary callable, avoiding a persistent ownership cycle.
	_surface_sampler = Callable()
	_mask = {}
	_heights = {}
	return result


func _build_system(region: int) -> void:
	var x: float = (_left + _right) * 0.5 + _rng.randf_range(-12.0, 12.0)
	var shallow_y: float = clampf(
		float(_surface(floori(x)) + settings.shallow_depth), 18.0, (float(_depth - settings.bottom_margin - 16) if _modern else float(_depth) * 0.55)
	)
	var shallow_start := Vector2(x, shallow_y)
	var direction: float = -1.0 if _rng.randf() < 0.5 else 1.0
	var path: Array[Vector2] = _walk(
		shallow_start, Vector2(direction, 0.15), maxi(1, settings.shallow_length), settings.shallow_radius
	)

	# Branches start on the existing path, keeping them connected.
	for branch_index in range(settings.branch_count):
		var fraction: float = float(branch_index + 1) * 1.05 / float(settings.branch_count + 1)
		var index: int = clampi(floori(path.size() * fraction), 0, path.size() - 1)
		var start: Vector2 = path[index]
		var branch_direction := Vector2(-direction * 0.6, 0.8)
		if fraction > 0.5:
			branch_direction = Vector2(direction * 0.8, -0.5)
		_walk(start, branch_direction, maxi(1, settings.branch_length), settings.branch_radius)

	if settings.deep_enabled:
		var deep_start := Vector2(
			x + _rng.randf_range(-18.0, 18.0), float(_depth) * settings.deep_depth_ratio
		)
		if _modern:
			deep_start.y = lerpf(shallow_y + 16.0, float(_depth - settings.bottom_margin - 12), settings.deep_depth_ratio)
		var deep_path: Array[Vector2] = _walk(
			deep_start, Vector2(-direction, 0.2), maxi(1, settings.deep_length), settings.deep_radius
		)
		_connect(path[floori(path.size() * 0.5)], deep_path[0], settings.connection_radius, false)
		if settings.rooms_enabled:
			_room(path[floori(path.size() * 0.55)], settings.shallow_room_size.max(Vector2.ONE))
			_room(deep_path[floori(deep_path.size() * 0.5)], settings.deep_room_size.max(Vector2.ONE))
	elif settings.rooms_enabled:
		_room(path[floori(path.size() * 0.55)], settings.shallow_room_size.max(Vector2.ONE))

	# Optionally connect a surface entrance at the configured regional interval.
	if settings.entrance_every > 0 and posmod(region, settings.entrance_every) == 0:
		var mouth_x: float = clampf(x - 16.0, _left + 5.0, _right - 5.0)
		var mouth := Vector2(mouth_x, float(_surface(floori(mouth_x))))
		_connect(mouth, path[0], settings.entrance_radius, true)


func _surface(x: int) -> int:
	if not _heights.has(x):
		_heights[x] = int(_surface_sampler.call(x))
	return _heights[x]


func _walk(start: Vector2, velocity: Vector2, steps: int, base_radius: float) -> Array[Vector2]:
	var points: Array[Vector2] = []
	var position: Vector2 = start
	var heading: Vector2 = velocity.normalized()
	var radius: float = base_radius
	var target_radius: float = base_radius
	for index in range(steps):
		position.x = clampf(position.x, _left, _right)
		var roof: float = float(_surface(floori(position.x))) + radius + settings.roof_clearance
		position.y = clampf(position.y, roof, float(_depth) - radius - settings.bottom_margin - 2.0)
		points.append(position)
		_stamp(position, Vector2(radius * 1.15, radius), false)

		if position.x <= _left + 1.0:
			heading.x = absf(heading.x)
		elif position.x >= _right - 1.0:
			heading.x = -absf(heading.x)
		if position.y <= roof + 1.0:
			heading.y = absf(heading.y)
		elif position.y >= float(_depth) - radius - settings.bottom_margin - 3.0:
			heading.y = -absf(heading.y)

		# Smooth heading and width changes avoid salt-and-pepper holes.
		heading = heading.rotated(_rng.randf_range(-settings.turn_jitter, settings.turn_jitter)).normalized()
		if index % 12 == 0:
			target_radius = base_radius * _rng.randf_range(settings.radius_variation.x, settings.radius_variation.y)
		radius = lerpf(radius, target_radius, settings.radius_smoothing)
		radius = maxf(radius, settings.minimum_radius)
		position += heading * settings.step_length
	return points


func _connect(a: Vector2, b: Vector2, radius: float, surface_entrance: bool) -> void:
	var count: int = maxi(ceili(a.distance_to(b)), 1)
	var perpendicular: Vector2 = (b - a).normalized().orthogonal()
	var phase: float = _rng.randf_range(0.0, TAU)
	for index in range(count + 1):
		var t: float = float(index) / float(count)
		var bend: float = sin(t * PI) * sin(t * TAU + phase) * 3.0
		var position: Vector2 = a.lerp(b, t) + perpendicular * bend
		_stamp(position, Vector2(radius, radius), surface_entrance)


func _room(center: Vector2, radii: Vector2) -> void:
	_stamp(center, radii, false)
	for index in range(3):
		var offset := Vector2(_rng.randf_range(-3.5, 3.5), _rng.randf_range(-1.5, 1.5))
		_stamp(center + offset, radii * _rng.randf_range(0.65, 0.9), false)


func _stamp(center: Vector2, radii: Vector2, surface_entrance: bool) -> void:
	radii = radii.max(Vector2.ONE)
	for x in range(maxi(floori(center.x - radii.x), floori(_left) - 8), mini(ceili(center.x + radii.x) + 1, ceili(_right) + 9)):
		var surface_y: int = _surface(x)
		var minimum_y: int = surface_y - 1 if surface_entrance else surface_y + settings.minimum_cover
		for y in range(floori(center.y - radii.y), ceili(center.y + radii.y) + 1):
			if y < maxi(minimum_y, 0) or y >= _depth - settings.bottom_margin:
				continue
			var relative: Vector2 = (Vector2(x, y) + Vector2(0.5, 0.5) - center) / radii
			if relative.length_squared() <= 1.0:
				_mask[Vector2i(x, y)] = true


func _smooth_mask() -> void:
	# Remove thin stone splinters where brushes nearly meet.
	# Apply each pass simultaneously so dictionary order cannot affect terrain.
	for pass_index in range(settings.smoothing_passes):
		var candidates: Dictionary = {}
		for air_cell in _mask.keys():
			for dx in range(-1, 2):
				for dy in range(-1, 2):
					var neighbor: Vector2i = air_cell + Vector2i(dx, dy)
					if not _mask.has(neighbor):
						candidates[neighbor] = true
		var additions: Array[Vector2i] = []
		for cell in candidates.keys():
			if cell.y < _surface(cell.x) + settings.minimum_cover or cell.y >= _depth - settings.bottom_margin:
				continue
			var air_neighbors: int = 0
			for dx in range(-1, 2):
				for dy in range(-1, 2):
					if _mask.has(cell + Vector2i(dx, dy)):
						air_neighbors += 1
			if air_neighbors >= settings.smoothing_neighbors:
				additions.append(cell)
		for cell in additions:
			_mask[cell] = true


func retain_regions_near(minimum_x: int, maximum_x: int) -> void:
	_noise_caves.retain_near(minimum_x, maximum_x)
	# Unloaded masks can be regenerated exactly from their regional seed.
	var first: int = floori(float(minimum_x) / settings.region_width) - 1
	var last: int = floori(float(maximum_x) / settings.region_width) + 1
	for region in _regions.keys():
		if region < first or region > last:
			_regions.erase(region)
