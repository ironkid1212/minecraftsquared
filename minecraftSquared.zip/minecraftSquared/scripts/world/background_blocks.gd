class_name BackgroundBlocks
extends RefCounted
var world: Node2D
func setup(game: Node2D) -> void:world=game
func held() -> bool:return Input.is_action_pressed("background_layer")
func allowed(id: int) -> bool:return bool(BlockDatabase.BLOCKS.get(id,{}).get("background",false))
func visible_target(cell: Vector2i) -> bool:
	return world.chunks.is_cell_loaded(cell) and world.cell_is_reachable(cell) and (world.get_block(cell)==BlockDatabase.id_for("end_portal") or not BlockDatabase.BLOCKS.get(world.get_block(cell),{}).get("occludes_background",false))
func resolve(cell: Vector2i,id: int) -> int:
	var shape: Dictionary=BlockDatabase.BLOCKS.get(id,{}).get("building",{})
	if shape.is_empty():return id
	var relative: Vector2=world.ground.to_local(world.pointer_global_position())-world.ground.map_to_local(cell)
	var half: String="top" if relative.y<0 else "bottom"
	var existing: Dictionary=BlockDatabase.BLOCKS.get(world.chunks.get_wall_block(cell),{}).get("building",{})
	if shape.kind=="slab" and existing.get("item")==shape.item and existing.get("half")!=half and existing.get("half")!="double":half="double"
	var facing: String="left" if shape.kind=="stairs" and world.player.facing<0 else "right"
	return int(world.building.variants.get(world.building._key(shape.item,half,facing),0))
func can_place(cell: Vector2i) -> bool:
	var id: int=world.get_interaction_item()
	if world.player.spectator or world.player.survival_dead or not allowed(id) or not visible_target(cell):return false
	var old: int=world.chunks.get_wall_block(cell);var placed: int=resolve(cell,id)
	if placed==0 or old==placed:return false
	var merging: bool=BlockDatabase.BLOCKS[placed].get("building",{}).get("half")=="double"
	if old!=0 and (world.chunks.wall_edits.has(cell) or old in [BlockDatabase.id_for("end_portal_frame"),BlockDatabase.id_for("end_portal_frame_filled")]) and not merging:return false
	if old!=0:return true
	for offset in [Vector2i.ZERO,Vector2i.UP,Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT]:
		if world.get_block(cell+offset)!=0 or world.chunks.get_wall_block(cell+offset)!=0:return true
	return false
func place(cell: Vector2i) -> bool:
	if world.inventory.counts[world.use_slot()]<=0 or not can_place(cell):return false
	var id: int=resolve(cell,world.get_interaction_item());world.chunks.set_wall_block(cell,id)
	if world.chunks.get_wall_block(cell)!=id:return false
	if world.effects!=null:world.effects.block_event(cell,id,"place")
	world.inventory.consume_for_placement(world.use_slot());world.player.swing_hand("place",world.ground.to_global(world.ground.map_to_local(cell)));return true
func update_mining(cell: Vector2i,delta: float) -> void:
	var id: int=world.chunks.get_wall_block(cell)
	if world.player.spectator or world.player.survival_dead or not visible_target(cell) or id==0 or not world.player.creative and not BlockDatabase.BLOCKS[id].diggable:
		world.reset_mining();return
	if world.player.creative:break_cell(cell);world.reset_mining();return
	var tool: int=world.hotbar.get_selected_block()
	if not world.mining_background or cell!=world.mining_cell or id!=world.mining_block_id or world.mining_tool_slot!=world.hotbar.selected_slot or world.mining_tool_id!=tool:
		world.reset_mining();world.mining_background=true;world.mining_cell=cell;world.mining_block_id=id;world.mining_tool_slot=world.hotbar.selected_slot;world.mining_tool_id=tool
	if world.effects!=null:world.effects.block_event(cell,id,"hit")
	world.player.begin_mining(world.ground.to_global(world.ground.map_to_local(cell)))
	var duration: float=ToolDatabase.mining_time(id,tool,world.player.is_on_floor(),world.fluids!=null and world.fluids.submerged(world.player.eye_position())=="water",world.inventory.tags[world.hotbar.selected_slot])
	if world.mining_duration>0 and duration!=world.mining_duration:world.mining_elapsed*=duration/world.mining_duration
	world.mining_duration=duration
	world.mining_elapsed+=delta
	if world.mining_elapsed>=world.mining_duration:break_cell(cell);world.reset_mining()
func break_cell(cell: Vector2i) -> void:
	if not visible_target(cell):return
	var id: int=world.chunks.get_wall_block(cell)
	if id==0 or not world.player.creative and not BlockDatabase.BLOCKS[id].diggable:return
	if world.effects!=null:world.effects.block_event(cell,id,"break")
	world.chunks.set_wall_block(cell,0)
	if world.player.creative:return
	var tool: int=world.hotbar.get_selected_block()
	if ToolDatabase.can_harvest(id,tool):
		var enchanted: Dictionary=EnchantmentDatabase.mining_drops(id,tool,world.inventory.tags[world.hotbar.selected_slot])
		var reward: Array=BlockDatabase.BLOCKS[id].get("experience",[0,0])
		if not enchanted.silk:world.experience.spawn(randi_range(int(reward[0]),int(reward[1])),world.ground.to_global(world.ground.map_to_local(cell)))
		for drop in enchanted.drops:world.dropped_items.spawn_item(drop.id,drop.count,world.ground.to_global(world.ground.map_to_local(cell)))
	if ToolDatabase.TOOLS.has(tool) and float(BlockDatabase.BLOCKS[id].hardness)>0:world.inventory.damage_tool(world.hotbar.selected_slot,int(ToolDatabase.TOOLS[tool].wear_per_block))
	world.food.add_exhaustion(float(world.food.rules.mine))
func draw_target() -> void:
	var cell: Vector2i=world.get_mouse_cell()
	if not visible_target(cell) or world.chunks.get_wall_block(cell)==0 and not can_place(cell):return
	world.target_overlay.draw_set_transform_matrix(world.target_overlay.global_transform.affine_inverse()*world.ground.global_transform)
	var bounds:=Rect2(world.ground.map_to_local(cell)-Vector2(8,8),Vector2(16,16))
	if world.mining_held and world.mining_background and world.mining_cell==cell and world.mining_block_id!=0:world.draw_mining_cracks(bounds)
	world.draw_target_border(bounds,Color(.25,.55,.8))
