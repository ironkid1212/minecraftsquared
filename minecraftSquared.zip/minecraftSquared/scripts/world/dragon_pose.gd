class_name DragonPose
extends RefCounted
static var MODEL: Dictionary=DataFile.object_from("res://data/dragon_model.json")
static func box(a: Array) -> Rect2:return Rect2(a[0],a[1],a[2],a[3])
static func part(commands: Array,hits: Array,key: String,t: Transform2D,shade: float=1,hit_name: String="",scale_value: float=1) -> void:
	var rule: Dictionary=MODEL[key];var bounds: Rect2=box(rule.bounds);bounds=Rect2(bounds.position*scale_value,bounds.size*scale_value)
	commands.append({"source":box(rule.source),"bounds":bounds,"transform":t,"shade":shade,"texture":"skin","flip":true})
	if not hit_name.is_empty():hits.append({"name":hit_name,"bounds":t*bounds})
static func membrane(commands: Array,source: Array,points: PackedVector2Array,t: Transform2D,shade: float) -> void:
	commands.append({"source":box(source),"points":points,"transform":t,"shade":shade,"texture":"skin"})
static func wing(commands: Array,hits: Array,t: Transform2D,phase: float,near: bool,perched: bool) -> void:
	var shade: float=1 if near else .6
	var root:=Vector2(6 if near else 3,-7)
	var lift: float=(.18 if perched else .25)+(.12 if perched else .7)*cos(phase)
	var elbow: Vector2=root+Vector2(-9 if near else -15,-56*sin(lift))
	var tip: Vector2=elbow+Vector2(-21,-56*sin(lift-.35))
	var back:=Vector2(-56,0)
	membrane(commands,MODEL.wing_inner,PackedVector2Array([root,elbow,elbow+back,root+back]),t,shade)
	membrane(commands,MODEL.wing_tip,PackedVector2Array([elbow,tip,tip+back,elbow+back]),t,shade)
	for spec in [[root,elbow,"wing_bone",8],[elbow,tip,"wing_tip_bone",4]]:
		var a: Vector2=spec[0];var d: Vector2=Vector2(spec[1])-a
		commands.append({"source":box(MODEL[spec[2]]),"bounds":Rect2(0,-float(spec[3])*.5,maxf(1,d.length()),float(spec[3])),"transform":t*Transform2D(d.angle(),a),"shade":shade,"texture":"skin","flip":false})
		if near:hits.append({"name":"wing","bounds":t*Rect2(a.min(Vector2(spec[1]))-Vector2(3,3),d.abs()+Vector2(6,6))})
static func legs(commands: Array,hits: Array,t: Transform2D,phase: float,near: bool,perched: bool) -> void:
	for front in [false,true]:
		var shade: float=1 if near else .6
		var sway: float=sin(phase)*.08 if not perched else 0
		var upper: float=(.4 if front else -.3)+sway
		var lower: float=(-1.1 if front else 1.1) if not perched else (-.65 if front else .65)
		var at:=Vector2(7 if front else -36,9)+(Vector2(0,0) if near else Vector2(-2,-2))
		var joint: Transform2D=t*Transform2D(upper,at)
		part(commands,hits,"front_leg" if front else "hind_leg",joint,shade)
		joint*=Transform2D(lower,Vector2(0,20 if front else 28))
		part(commands,hits,"front_shin" if front else "hind_shin",joint,shade)
		joint*=Transform2D(-(upper+lower),Vector2(0,23 if front else 30))
		part(commands,hits,"front_foot" if front else "hind_foot",joint,shade)
static func build(at: Vector2,facing: int,pitch: float,wing_phase: float,perched: bool,jaw: float,head_pitch: float=0) -> Dictionary:
	var commands: Array=[];var hits: Array=[]
	var t:=Transform2D(pitch*facing,Vector2(facing,1),0,at)
	wing(commands,hits,t,wing_phase+.12,false,perched);legs(commands,hits,t,wing_phase,false,perched)
	var tail:=Vector2(-48,0)
	for i in range(int(MODEL.tail_segments)):
		var angle: float=sin(wing_phase*.65-i*.35)*(.08+i*.008)+(.05 if perched else 0)
		var direction:=Vector2(-cos(angle),sin(angle));tail+=direction*4.8
		var segment: Transform2D=t*Transform2D(-angle,tail)
		var shrink: float=lerpf(1,.55,float(i)/float(MODEL.tail_segments))
		part(commands,hits,"neck",segment,1,"tail",shrink);part(commands,hits,"neck_spine",segment,1,"",shrink);tail+=direction*4.8
	part(commands,hits,"body",t,1,"body")
	for x in [-30,-10,10]:part(commands,hits,"body_spine",t*Transform2D(0,Vector2(x,0)))
	legs(commands,hits,t,wing_phase,true,perched);wing(commands,hits,t,wing_phase,true,perched)
	var neck:=Vector2(16,-4);var angle: float=0
	for i in range(int(MODEL.neck_segments)):
		angle=(.3 if perched else 0)+sin(wing_phase*.5+i*.5)*.07+head_pitch*.35
		var direction:=Vector2(cos(angle),sin(angle));neck+=direction*4.8
		var segment: Transform2D=t*Transform2D(angle,neck)
		part(commands,hits,"neck",segment,1,"neck");part(commands,hits,"neck_spine",segment);neck+=direction*4.8
	var head: Transform2D=t*Transform2D(angle+head_pitch,neck+Vector2(5,0))
	part(commands,hits,"head",head,1,"head");part(commands,hits,"snout",head,1,"head");part(commands,hits,"horn",head);part(commands,hits,"nostril",head)
	part(commands,hits,"jaw",head*Transform2D(jaw,Vector2(8,4)),1,"head")
	part(commands,hits,"eye",head)
	commands[commands.size()-1].texture="eyes"
	var bounds:=Rect2(at,Vector2.ZERO)
	for command in commands:
		if command.has("bounds"):bounds=bounds.merge(Transform2D(command.transform)*Rect2(command.bounds))
		else:
			for point: Vector2 in command.points:bounds=bounds.expand(Transform2D(command.transform)*point)
	return {"commands":commands,"hits":hits,"bounds":bounds,"head":head*Vector2(8,0),"mouth":head*Vector2(23,5)}
