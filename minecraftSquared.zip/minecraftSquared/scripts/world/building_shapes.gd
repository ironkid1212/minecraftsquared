class_name BuildingShapes
extends RefCounted

## Placed orientations are catalog records, so ordinary block edits save them.
var world: Node2D
var variants: Dictionary = {}

func setup(game: Node2D) -> bool:
	world=game
	for id in BlockDatabase.BLOCKS:
		var entry: Dictionary=BlockDatabase.BLOCKS[id]
		var shape: Dictionary=entry.get("building",{})
		if shape.is_empty(): continue
		var item: int=BlockDatabase.id_for(str(shape["item"]))
		if item==0 or BlockDatabase.id_for(str(shape["material"]))==0 or not entry.has("collision_boxes"):
			DataFile.fail("Building shape needs a material, item and collision boxes: "+str(entry["key"]))
			return false
		var key: String=_key(str(shape["item"]),str(shape["half"]),str(shape["facing"]))
		if variants.has(key):
			DataFile.fail("Duplicate building shape: "+key)
			return false
		variants[key]=int(id)
	return true

func _key(item: String, half: String, facing: String) -> String: return item+":"+half+":"+facing

func resolve(cell: Vector2i, selected: int, pointer: Vector2) -> int:
	var shape: Dictionary=BlockDatabase.BLOCKS.get(selected,{}).get("building",{})
	if shape.is_empty(): return selected
	var relative: Vector2=world.ground.to_local(pointer)-world.ground.map_to_local(cell)
	var half: String="top" if relative.y<0 else "bottom"
	var existing: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(cell),{}).get("building",{})
	if not existing.is_empty():
		if shape["kind"]!="slab" or existing["item"]!=shape["item"] or existing["half"]=="double" or existing["half"]==half: return 0
		return int(variants.get(_key(str(shape["item"]),"double","right"),0))
	var facing: String="left" if shape["kind"]=="stairs" and world.player.facing<0 else "right"
	return int(variants.get(_key(str(shape["item"]),half,facing),0))

func overlaps_player(cell: Vector2i, id: int) -> bool:
	var entry: Dictionary=BlockDatabase.BLOCKS[id]
	var boxes: Array=FenceConnections.collision_boxes(world.chunks,cell,entry) if entry.has("fence") else entry.get("collision_boxes",[])
	if boxes.is_empty(): boxes=[[0,16-float(entry.get("collision_height",16)),16,float(entry.get("collision_height",16))]]
	var origin: Vector2=world.ground.map_to_local(cell)-Vector2(8,8)
	var player_bounds: Rect2=world.player_collision.global_transform*world.player_collision.shape.get_rect()
	for box in boxes:
		var local_bounds:=Rect2(origin+Vector2(float(box[0]),float(box[1])),Vector2(float(box[2]),float(box[3])))
		if (world.ground.global_transform*local_bounds).intersects(player_bounds): return true
	return false
