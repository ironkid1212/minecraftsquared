class_name StructureSystem
extends Node2D
var world: Node2D
var spawners: Dictionary={}
var initialized: Dictionary={}
var rules: Dictionary
var scan_time: float=0
var rng:=RandomNumberGenerator.new()
var loaded: Array[Vector2i]=[]
func setup(game: Node2D) -> void:
	world=game;rules=AdventureData.DATA.spawners;rng.seed=world.world_seed+978871
	world.chunks.cell_changed.connect(_changed);z_index=3
func _changed(cell: Vector2i,old_id: int,new_id: int) -> void:
	if old_id==BlockDatabase.id_for("spawner"):spawners.erase(cell)
	if new_id==BlockDatabase.id_for("spawner"):register(cell,"zombie")
func register(cell: Vector2i,kind: String) -> void:
	if not spawners.has(cell):spawners[cell]={"kind":kind,"delay":rng.randf_range(10,39.95)}
	if world.chunks.is_cell_loaded(cell) and cell not in loaded:loaded.append(cell)
func generators() -> Array:
	return [world.chunks.nether.fortresses] if world.is_nether() else [world.chunks.strongholds,world.chunks.structures]
func discover() -> void:
	for generator in generators():
		var center: int=generator.region_at(world.mobs.cell(world.player.global_position).x)
		for region in range(center-1,center+2):
			if generator is StrongholdGenerator and (region<0 or region>=generator.positions.size() or absi(generator.positions[region]-world.mobs.cell(world.player.global_position).x)>world.chunks.load_radius.x*32+100):continue
			var plan: Dictionary=generator.plan(region)
			for cell: Vector2i in plan.containers:
				if initialized.has(cell) or not world.chunks.is_cell_loaded(cell) or not world.storage.is_storage(world.get_block(cell)):continue
				if world.storage.states.has(cell):initialized[cell]=true
				else:world.storage.state_at(cell)
			for cell: Vector2i in plan.spawners:
				if world.chunks.is_cell_loaded(cell) and world.get_block(cell)==BlockDatabase.id_for("spawner"):register(cell,plan.spawners[cell])
	loaded.clear()
	for cell: Vector2i in spawners:
		if world.chunks.is_cell_loaded(cell):loaded.append(cell)
func populate_container(cell: Vector2i,items: BlockInventory) -> void:
	if initialized.has(cell):return
	var plan: Dictionary={}
	for generator in generators():
		var candidate: Dictionary=generator.plan(generator.region_at(cell.x))
		if candidate.containers.has(cell):plan=candidate;break
	if plan.is_empty():return
	if not plan.containers.has(cell):return
	initialized[cell]=true
	var loot_seed: int=world.world_seed+cell.x*73471+cell.y*9217
	var loot_rng:=RandomNumberGenerator.new();loot_rng.seed=loot_seed
	var slots: Array=[]
	for i in range(27):slots.append(i)
	for stack in StructureLoot.generate(plan.containers[cell],loot_seed):
		if slots.is_empty():break
		var index: int=loot_rng.randi_range(0,slots.size()-1);items.set_stack(slots.pop_at(index),stack)
func _physics_process(dt: float) -> void:
	scan_time-=dt
	if scan_time<=0:scan_time=.25;discover()
	if world.player.spectator or world.player.survival_dead:return
	for cell: Vector2i in loaded:
		if not spawners.has(cell):continue
		if not world.chunks.is_cell_loaded(cell):continue
		if world.get_block(cell)!=BlockDatabase.id_for("spawner"):spawners.erase(cell);continue
		var center: Vector2=world.ground.to_global(world.ground.map_to_local(cell))
		if center.distance_to(world.player.global_position)>float(rules.activation_range)*16:continue
		var state: Dictionary=spawners[cell];state.delay=maxf(0,state.delay-dt)
		if state.delay>0:continue
		var count: int=0
		for mob: MobActor in world.mobs.active.values():
			if not mob.dead and mob.definition.key==state.kind and absf(mob.center().x-center.x)<=4.5*16 and absf(mob.center().y-center.y)<=4.5*16:count+=1
		if count>=int(rules.nearby_cap):reset_delay(state);continue
		var spawned: bool=false
		for attempt in range(int(rules.spawn_count)):
			if count>=int(rules.nearby_cap) or world.mobs.active.size()>=int(MobCatalog.rules.maximum_active):break
			var at: Vector2i=cell+Vector2i(rng.randi_range(-int(rules.spawn_range),int(rules.spawn_range)),rng.randi_range(-1,1))
			if not world.chunks.is_cell_loaded(at) or not world.mobs.can_fit(state.kind,world.mobs.feet(at)):continue
			if not world.lighting.has_light_sample(at):continue
			var light: Vector2i=world.lighting.sample_levels(at)
			if maxi(light.x,light.y)>(11 if state.kind in ["blaze","silverfish"] else int(rules.maximum_light)):continue
			if world.mobs.spawn(state.kind,world.mobs.feet(at))!=null:spawned=true;count+=1
		if spawned:reset_delay(state)
	queue_redraw()
func reset_delay(state: Dictionary) -> void:state.delay=rng.randi_range(int(rules.delay_ticks[0]),int(rules.delay_ticks[1]))*.05
func _draw() -> void:
	if world==null:return
	var view: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	for cell: Vector2i in loaded:
		if not spawners.has(cell):continue
		var p: Vector2=world.ground.to_global(world.ground.map_to_local(cell))
		if not world.chunks.is_cell_loaded(cell) or not view.has_point(p):continue
		# Small supplied mob head inside the cage; no extra actors or collision.
		var def: Dictionary=MobCatalog.definitions[spawners[cell].kind]
		if def.rig in ["silverfish","endermite","bat"]:
			draw_texture_rect_region(world.mobs.renderer.textures[def.texture],Rect2(p-Vector2(3,2),Vector2(6,4)),Rect2(0,2,2,2),world.lighting.render_tint(cell));continue
		if def.rig in ["blaze","enderman","magma_cube"]:
			draw_texture_rect_region(world.mobs.renderer.textures[def.texture],Rect2(p-Vector2(3,3),Vector2(6,6)),Rect2(8,8,8,8),world.lighting.render_tint(cell));continue
		var uv: Array=def.front_head
		var rect:=Rect2(uv[0],uv[1],uv[2],uv[3])
		draw_texture_rect_region(preload("res://assets/mobs/front_heads.png"),Rect2(p-Vector2(3,3),Vector2(6,6)),rect,world.lighting.render_tint(cell))
func snapshot() -> Dictionary:
	var records: Array=[];var cells: Array=[]
	for cell: Vector2i in spawners:records.append({"cell":[cell.x,cell.y],"kind":spawners[cell].kind,"delay":spawners[cell].delay})
	for cell: Vector2i in initialized:cells.append([cell.x,cell.y])
	return {"spawners":records,"initialized":cells}
func restore(record: Dictionary) -> void:
	spawners.clear();initialized.clear();loaded.clear()
	for p in record.get("initialized",[]):initialized[Vector2i(p[0],p[1])]=true
	for entry in record.get("spawners",[]):spawners[Vector2i(entry.cell[0],entry.cell[1])]={"kind":entry.kind,"delay":float(entry.delay)}
