class_name FarmingSystem
extends Node

var world: Node2D
var settings: FarmingSettings
var rules: Dictionary
var stages: Dictionary = {}
var seeds: Dictionary = {}
var farmland: int
var soil: int
var _rng := RandomNumberGenerator.new()

func setup(game: Node2D, config: FarmingSettings) -> bool:
	world=game
	settings=config
	_rng.seed=world.world_seed ^ 0xFA42
	rules=DataFile.object_from(settings.rules_path)
	if not rules.get("crops") is Array or not ContentCatalog._number(rules.get("water_radius"),1,8,true) or not ContentCatalog._number(rules.get("growth_light"),0,15,true) or not ContentCatalog._number(settings.growth_multiplier,.1,20):
		DataFile.fail("farming.json: invalid crops, water radius or growth settings.")
		return false
	farmland=BlockDatabase.id_for(str(rules.get("farmland","")))
	soil=BlockDatabase.id_for(str(rules.get("soil","")))
	var bone: Variant=rules.get("bone_meal",{})
	var vine: Variant=rules.get("cave_vines",{})
	if not bone is Dictionary or not ContentCatalog._vector(bone.get("crop_growth"),2,1,7,true) or bone.crop_growth[1]<bone.crop_growth[0] or not ContentCatalog._number(bone.get("beetroot_chance"),0,1) or not ContentCatalog._number(bone.get("moss_radius"),1,5,true):return false
	if not vine is Dictionary or not ContentCatalog._number(vine.get("growth_chance"),0,1) or not ContentCatalog._number(vine.get("berry_chance"),0,1) or not ContentCatalog._number(vine.get("maximum_length"),1,64,true):return false
	for crop in rules["crops"]:
		if not crop is Dictionary or not crop.get("stages") is Array or crop["stages"].size()<2 or not ContentCatalog._number(crop.get("growth_chance_factor"),.01,1):
			DataFile.fail("farming.json: each crop needs stages and growth chance.")
			return false
		var seed_id: int=BlockDatabase.id_for(str(crop.get("seed","")))
		if crop.has("fruit"):
			if BlockDatabase.id_for(str(crop.fruit))==0 or not crop.get("fruit_substrates") is Array:return false
			for substrate in crop.fruit_substrates:
				if BlockDatabase.id_for(str(substrate))==0:return false
		var ids: Array[int]=[]
		for key in crop["stages"]: ids.append(BlockDatabase.id_for(str(key)))
		if seeds.has(seed_id):
			DataFile.fail("farming.json: duplicate seed.")
			return false
		seeds[seed_id]=ids[0]
		for i in range(ids.size()):
			if stages.has(ids[i]):
				DataFile.fail("farming.json: duplicate crop stage.")
				return false
			stages[ids[i]]={"next":ids[mini(i+1,ids.size()-1)],"mature":i==ids.size()-1,"chance":float(crop["growth_chance_factor"]),"substrate":BlockDatabase.id_for(str(crop.get("substrate","farmland"))),"light":int(crop.get("growth_light",rules.growth_light)),"nether":bool(crop.get("nether_crop",false)),"key":str(crop.key),"fruit":str(crop.get("fruit","")),"fruit_substrates":crop.get("fruit_substrates",[])}
	world.chunks.cell_changed.connect(_changed)
	return DataFile.errors.is_empty()

func _changed(cell: Vector2i, _old: int, new_id: int) -> void:
	if new_id!=farmland: world.chunks.farm_moisture.erase(cell)

func moisture(cell: Vector2i) -> int: return int(world.chunks.farm_moisture.get(cell,0))

func set_moisture(cell: Vector2i, value: int) -> void:
	value=clampi(value,0,7)
	if moisture(cell)==value: return
	if value==0: world.chunks.farm_moisture.erase(cell)
	else: world.chunks.farm_moisture[cell]=value
	world.chunks.mark_visual_dirty(cell)

func watered(cell: Vector2i) -> bool:
	if world.weather!=null and world.weather.raining_at(cell): return true
	for dx in range(-int(rules["water_radius"]),int(rules["water_radius"])+1):
		for dy in [-1,0]:
			if world.fluids.kind_at(cell+Vector2i(dx,dy))=="water": return true
	return false

func use_item(cell: Vector2i) -> bool:
	if not settings.enabled or world.player.spectator or world.player.survival_dead: return false
	var seed_id: int=world.get_interaction_item()
	if seed_id==BlockDatabase.id_for("bone_meal"):return bone_meal(cell)
	if not seeds.has(seed_id): return false
	var plant_id: int=int(seeds[seed_id]);var substrate: int=int(stages[plant_id].substrate)
	var target: Vector2i=cell+Vector2i.UP if world.get_block(cell)==substrate else cell
	if not world.cell_is_reachable(target) or not world.chunks.is_cell_loaded(target) or world.get_block(target)!=0 or world.get_block(target+Vector2i.DOWN)!=substrate: return false
	if world.lighting.sample_survival_light_level(target)<int(stages[plant_id].light): return false
	world.set_block(target,int(seeds[seed_id]))
	if not world.player.creative:world.inventory.remove_from_slot(world.use_slot(),1)
	world.player.swing_hand("place",world.ground.to_global(world.ground.map_to_local(target)))
	return true

func tick(cell: Vector2i, id: int, random_tick: bool) -> void:
	if not settings.enabled: return
	if id==farmland:
		var above: int=world.get_block(cell+Vector2i.UP)
		if BlockDatabase.BLOCKS.get(above,{}).get("collision","")=="solid":
			world.set_block(cell,soil)
			return
		if not random_tick: return
		if watered(cell): set_moisture(cell,7)
		elif moisture(cell)>0: set_moisture(cell,moisture(cell)-1)
		elif not stages.has(above): world.set_block(cell,soil)
	elif stages.has(id):
		var below: Vector2i=cell+Vector2i.DOWN
		if not world.chunks.is_cell_loaded(below): return
		if world.get_block(below)!=int(stages[id].substrate):
			world.world_updates._remove_with_drops(cell,id)
			return
		if not random_tick or stages[id]["mature"] and str(stages[id].fruit).is_empty() or world.lighting.sample_survival_light_level(cell)<int(stages[id].light): return
		if stages[id].nether:
			if _rng.randf()<float(stages[id].chance)*settings.growth_multiplier:world.set_block(cell,int(stages[id].next))
			return
		var speed: float=1.0+(3.0 if moisture(below)>0 else 1.0)
		for dx in [-1,1]:
			var neighbor: Vector2i=below+Vector2i(dx,0)
			if world.get_block(neighbor)==farmland: speed+=(3.0 if moisture(neighbor)>0 else 1.0)*.25
		var chance: float=1.0/(floorf(25.0/speed)+1.0)*float(stages[id]["chance"])*settings.growth_multiplier
		if _rng.randf()<chance:
			if stages[id].mature:grow_fruit(cell,id)
			else:world.set_block(cell,int(stages[id]["next"]))

func grow_fruit(cell: Vector2i,id: int) -> bool:
	var fruit: int=BlockDatabase.id_for(str(stages[id].fruit))
	if fruit==0:return false
	for direction in [Vector2i.LEFT,Vector2i.RIGHT]:
		if world.get_block(cell+direction)==fruit:return false
	var directions: Array=[Vector2i.LEFT,Vector2i.RIGHT]
	if _rng.randf()<.5:directions.reverse()
	for direction: Vector2i in directions:
		var at: Vector2i=cell+direction;var below: Vector2i=at+Vector2i.DOWN
		if not world.chunks.is_cell_loaded(at) or not world.chunks.is_cell_loaded(below) or world.get_block(at)!=0:continue
		if str(BlockDatabase.BLOCKS.get(world.get_block(below),{}).get("key","")) not in stages[id].fruit_substrates:continue
		world.set_block(at,fruit);return true
	return false

func bone_meal(cell: Vector2i) -> bool:
	if not world.cell_is_reachable(cell) or not world.chunks.is_cell_loaded(cell):return false
	var id: int=world.get_block(cell);var used: bool=false
	if stages.has(id) and not stages[id].nether:
		if stages[id].mature and str(stages[id].fruit).is_empty():return false
		used=true
		if stages[id].key!="beetroots" or _rng.randf()<float(rules.bone_meal.beetroot_chance):
			var amount: int=_rng.randi_range(int(rules.bone_meal.crop_growth[0]),int(rules.bone_meal.crop_growth[1]))
			for i in range(amount):
				if stages[id].mature:break
				id=int(stages[id].next)
			world.set_block(cell,id)
			if stages[id].mature and not str(stages[id].fruit).is_empty():grow_fruit(cell,id)
	elif BlockDatabase.has_tag(id,"cave_vine"):
		if id==BlockDatabase.id_for("cave_vines_berries"):return false
		world.set_block(cell,BlockDatabase.id_for("cave_vines_berries"));used=true
	elif id in [BlockDatabase.id_for("grass"),BlockDatabase.id_for("moss_block")]:
		var radius: int=int(rules.bone_meal.moss_radius)
		for dx in range(-radius,radius+1):
			for dy in range(-1,2):
				var at:=cell+Vector2i(dx,dy)
				if not world.chunks.is_cell_loaded(at+Vector2i.UP) or not world.chunks.is_cell_loaded(at) or world.get_block(at+Vector2i.UP)!=0 or _rng.randf()<.4:continue
				var ground: int=world.get_block(at)
				if id==BlockDatabase.id_for("moss_block") and ground in [soil,BlockDatabase.id_for("stone"),BlockDatabase.id_for("deepslate"),BlockDatabase.id_for("rooted_dirt")]:world.set_block(at,id);ground=id
				if ground==id and world.get_block(at+Vector2i.UP)==0:
					var key: String="moss_carpet" if id==BlockDatabase.id_for("moss_block") else "short_grass"
					var plant: int=BlockDatabase.id_for(key)
					if plant>0:world.set_block(at+Vector2i.UP,plant)
		used=true
	if not used:return false
	world.inventory.consume_for_placement(world.use_slot());world.player.swing_hand("place",world.ground.to_global(world.ground.map_to_local(cell)));return true

func tick_vine(cell: Vector2i,id: int,random_tick: bool) -> void:
	if not settings.enabled or not random_tick or not BlockDatabase.has_tag(id,"cave_vine"):return
	var below: Vector2i=cell+Vector2i.DOWN
	if not world.chunks.is_cell_loaded(below) or world.get_block(below)!=0 or _rng.randf()>=float(rules.cave_vines.growth_chance):return
	var length: int=1;var above: Vector2i=cell+Vector2i.UP
	while length<int(rules.cave_vines.maximum_length) and world.chunks.is_cell_loaded(above) and BlockDatabase.has_tag(world.get_block(above),"cave_vine"):
		length+=1;above+=Vector2i.UP
	if length>=int(rules.cave_vines.maximum_length) or not world.chunks.is_cell_loaded(above):return
	world.set_block(below,BlockDatabase.id_for("cave_vines_berries" if _rng.randf()<float(rules.cave_vines.berry_chance) else "cave_vines"))

func snapshot() -> Array:
	var records: Array=[]
	for cell in world.chunks.farm_moisture:
		if world.get_block(cell)==farmland: records.append([cell.x,cell.y,moisture(cell)])
	return records

func restore(records: Array) -> void:
	for cell in world.chunks.farm_moisture: world.chunks.mark_visual_dirty(cell)
	world.chunks.farm_moisture.clear()
	for record in records:
		var cell:=Vector2i(int(record[0]),int(record[1]))
		if world.get_block(cell)==farmland: set_moisture(cell,int(record[2]))
