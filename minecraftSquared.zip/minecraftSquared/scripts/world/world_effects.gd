class_name WorldEffects
extends Node2D
var config: EffectsSettings
static var CATALOG: Dictionary=DataFile.object_from("res://data/effects_sounds.json").get("events",{})
static var MATERIALS: Array=DataFile.object_from("res://data/effects_sounds.json").get("materials",[])
var rng:=RandomNumberGenerator.new()
var world: Node2D
var voices: Array[AudioStreamPlayer2D]=[]
var priorities: PackedInt32Array=[]
var streams: Dictionary={}
var textures: Dictionary={}
var families: Dictionary={}
var effect_colors: Dictionary={"levitation":Color(.8,.8,.7)}
var cooldowns: Dictionary={}
var positions: PackedVector2Array=[]
var velocities: PackedVector2Array=[]
var lifetimes: PackedFloat32Array=[]
var durations: PackedFloat32Array=[]
var sizes: PackedFloat32Array=[]
var gravity: PackedFloat32Array=[]
var animation: PackedInt32Array=[]
var tints: PackedColorArray=[]
var regions: Array[Rect2]=[]
var images: Array[Texture2D]=[]
var active: Array[int]=[]
var free: Array[int]=[]
var emitters: Array[Vector2i]=[]
var scan_cursor: int=0
var emitter_cursor: int=0
var ambient_clock: float=0
var mob_clock: float=1
var time: float=0
var next_mining: float=0
var step_distance: float=0
var previous_position:=Vector2.ZERO
var previous_fluid: String=""
var was_grounded: bool=false
var last_dimension: String=""
var view:=Rect2()
var emitted: int=0
var rejected: int=0
var samples: int=0
var sounds_played: int=0
var setup_milliseconds: float=0
func setup(game: Node2D) -> void:
	var started: int=Time.get_ticks_usec()
	world=game;rng.randomize();config=world.effects_settings;z_index=22;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	for event in CATALOG.values():
		for variant in event:
			if not streams.has(variant.path):streams[variant.path]=load(variant.path)
	for name in ["flame","soul_fire_flame","smoke","bubble","splash_0","critical_hit","glint","effect_0","spark","end_rod","enchanted_hit"]:
		var path: String="res://assets/particles/"+name+".png"
		if ResourceLoader.exists(path):textures[name]=load(path)
	for i in range(config.sound_voices):
		var voice:=AudioStreamPlayer2D.new();voice.max_distance=config.hearing_distance;voice.panning_strength=.4;voice.max_polyphony=1;add_child(voice);voices.append(voice);priorities.append(0)
	var listener:=AudioListener2D.new();world.player.add_child(listener);listener.make_current();get_viewport().audio_listener_enable_2d=true
	positions.resize(config.particle_limit);velocities.resize(config.particle_limit);lifetimes.resize(config.particle_limit);durations.resize(config.particle_limit);sizes.resize(config.particle_limit);gravity.resize(config.particle_limit);animation.resize(config.particle_limit);tints.resize(config.particle_limit);regions.resize(config.particle_limit);images.resize(config.particle_limit)
	for potion in BrewingData.DATA.potions.values():
		if not str(potion.effect).is_empty():effect_colors[potion.effect]=Color(potion.color[0],potion.color[1],potion.color[2])
	clear();setup_milliseconds=float(Time.get_ticks_usec()-started)/1000
func clear() -> void:
	active.clear();free.clear();emitters.clear();cooldowns.clear();scan_cursor=0;emitter_cursor=0;step_distance=0
	for i in range(images.size()):free.append(i);images[i]=null
	for voice in voices:voice.stop()
	view=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	previous_position=world.player.global_position;previous_fluid="";was_grounded=false;last_dimension=world.chunks.dimension;queue_redraw()
func audible(at: Vector2) -> bool:return world.player.global_position.distance_squared_to(at)<=config.hearing_distance*config.hearing_distance
func sound(event: String,at: Vector2,category: String="blocks",volume: float=1,pitch: float=1,priority: int=1,interval: float=.08) -> bool:
	if not CATALOG.has(event) or not audible(at) or config.master_volume<=0:return false
	var gain: float=float(config.get(category+"_volume"))*config.master_volume*volume
	if gain<=0:return false
	var bucket: String=event+":"+str(Vector2i(at/64))
	if time<float(cooldowns.get(bucket,-1)):return false
	var slot: int=-1;var lowest: int=priority
	for i in range(voices.size()):
		if not voices[i].playing:slot=i;break
		if priorities[i]<lowest:lowest=priorities[i];slot=i
	if slot<0:return false
	if cooldowns.size()>=256:cooldowns.erase(cooldowns.keys()[0])
	cooldowns[bucket]=time+interval
	var choices: Array=CATALOG[event];var variant: Dictionary=choices[rng.randi()%choices.size()];var voice: AudioStreamPlayer2D=voices[slot]
	voice.stop();voice.stream=streams[variant.path];voice.global_position=at;voice.volume_db=linear_to_db(maxf(.0001,gain*float(variant.volume)));voice.pitch_scale=clampf(pitch*float(variant.pitch)*rng.randf_range(.96,1.04),.3,2.5);priorities[slot]=priority;voice.play();sounds_played+=1;return true
func family(id: int) -> String:
	if families.has(id):return families[id]
	var key: String=str(BlockDatabase.BLOCKS.get(id,{}).get("key","stone"));var result: String="stone"
	for group in MATERIALS:
		if group[0] in key:result=group[1];break
	families[id]=result;return result
func block_sound(id: int,action: String,at: Vector2) -> void:
	var event: String="block."+family(id)+"."+action
	if not CATALOG.has(event):event="block.stone."+action
	sound(event,at,"blocks",.22 if action=="hit" else .3 if action=="step" else .7,1,0 if action=="step" else 1,.22 if action=="hit" else .12)
func cell_position(cell: Vector2i) -> Vector2:return world.ground.to_global(world.ground.map_to_local(cell))
func emit_particle(name: String,at: Vector2,velocity: Vector2=Vector2.ZERO,life: float=.5,size: float=3,tint: Color=Color.WHITE,acceleration: float=0,source: Texture2D=null,region: Rect2=Rect2()) -> bool:
	if free.is_empty() or config.particle_density<=0 or not view.grow(24).has_point(at):rejected+=1;return false
	if rng.randf()>config.particle_density:return false
	var texture: Texture2D=source if source!=null else textures.get(name)
	if texture==null:return false
	if source==null and name in ["smoke","bubble","splash_0","critical_hit","glint","enchanted_hit"]:tint*=world.lighting.render_tint(world.mobs.cell(at))
	var i: int=free.pop_back();active.append(i);positions[i]=at;velocities[i]=velocity;lifetimes[i]=life;durations[i]=life;sizes[i]=size;tints[i]=tint;gravity[i]=acceleration;images[i]=texture;animation[i]=8 if name in ["smoke","spark","end_rod"] else 1;regions[i]=region if region.has_area() else Rect2(Vector2.ZERO,Vector2(texture.get_width(),texture.get_height()/animation[i]));emitted+=1;return true
func debris(id: int,at: Vector2,count: int=12) -> void:
	if id==0 or not view.grow(16).has_point(at):return
	var entry: Dictionary=BlockDatabase.BLOCKS.get(id,{})
	if entry.is_empty():return
	var source: TileSetAtlasSource=AtlasDatabase.source(entry.get("atlas_type","blocks"),world.atlas_source)
	if source==null:return
	var coords: Vector2i=entry.get("atlas",Vector2i.ZERO);var origin: Vector2=source.margins+coords*(source.texture_region_size+source.separation)
	var tint: Color=world.lighting.render_tint(world.mobs.cell(at))*entry.get("tint",Color.WHITE)
	var biome_tint: String=str(entry.get("biome_tint",""))
	if not biome_tint.is_empty():tint*=world.chunks.colors.color_at(world.mobs.cell(at).x,biome_tint)
	for n in range(count):emit_particle("",at+Vector2(rng.randf_range(-6,6),rng.randf_range(-6,6)),Vector2(rng.randf_range(-35,35),rng.randf_range(-65,-10)),rng.randf_range(.25,.65),rng.randf_range(1.5,3),tint,140,source.texture,Rect2(origin+Vector2(rng.randi_range(0,13),rng.randi_range(0,13)),Vector2(2,2)))
func block_event(cell: Vector2i,id: int,action: String) -> void:
	if action=="hit":
		if time<next_mining:return
		next_mining=time+.16
	var at: Vector2=cell_position(cell);block_sound(id,action,at)
	if action in ["break","hit"]:debris(id,at,14 if action=="break" else 2)
func puff(name: String,at: Vector2,count: int=5,color: Color=Color.WHITE) -> void:
	for n in range(count):emit_particle(name,at+Vector2(rng.randf_range(-6,6),rng.randf_range(-6,6)),Vector2(rng.randf_range(-12,12),rng.randf_range(-24,-6)),rng.randf_range(.3,.7),rng.randf_range(2,5),color)
func mob_event(mob: MobActor,event: String) -> void:
	var kind: String=mob.definition.key
	if kind=="cave_spider":kind="spider"
	if kind=="mooshroom":kind="cow"
	sound("entity."+kind+"."+event,mob.center(),"entities",.7,1.4 if AnimalBreeding.baby(mob) else 1,2 if event!="ambient" else 0,.2 if event!="ambient" else 2)
	if event=="death":puff("smoke",mob.center(),8)
func _physics_process(dt: float) -> void:
	time+=dt;view=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	if world.chunks.dimension!=last_dimension or previous_position.distance_squared_to(world.player.global_position)>256*256:clear()
	var dirty: bool=not active.is_empty()
	for n in range(active.size()-1,-1,-1):
		var i: int=active[n];lifetimes[i]-=dt
		if lifetimes[i]<=0 or not view.grow(48).has_point(positions[i]):
			active[n]=active[-1];active.pop_back();free.append(i);images[i]=null;continue
		velocities[i].y+=gravity[i]*dt;positions[i]+=velocities[i]*dt
	_movement(dt);ambient_clock-=dt;mob_clock-=dt
	if ambient_clock<=0:ambient_clock=.2;_ambient()
	if mob_clock<=0:
		mob_clock=rng.randf_range(1.5,3);var candidates: Array=world.mobs.active.values()
		if not candidates.is_empty():
			var mob: MobActor=candidates[rng.randi()%candidates.size()]
			if not mob.dead and rng.randf()<.6:mob_event(mob,"ambient")
	if dirty or not active.is_empty():queue_redraw()
func _movement(_dt: float) -> void:
	var p: CharacterBody2D=world.player;var at: Vector2=p.global_position;var moved: float=at.distance_to(previous_position);previous_position=at
	if p.spectator or p.survival_dead or moved>32:was_grounded=false;previous_fluid="";return
	var fluid: String=world.fluids.submerged(at+Vector2(0,8))
	if fluid!=previous_fluid and fluid=="water":
		sound("entity.player.splash",at,"player",.5,1,1,.35);puff("splash_0",at,7,Color(.4,.65,1))
	if p.climbing.active and moved>.02:sound("block.ladder.step",at,"player",.3,1,0,.35)
	previous_fluid=fluid
	if fluid=="water" and moved>.05:
		sound("entity.player.swim",at,"player",.2,1,0,.5)
		if rng.randf()<.15:emit_particle("bubble",at,Vector2(0,-14),.6,2)
	var grounded: bool=p.is_on_floor();var foot: Vector2i=world.mobs.cell(at+Vector2(0,15));var id: int=world.get_block(foot)
	if grounded and not p.crouching and moved>.02 and absf(p.velocity.x)>1:
		step_distance+=moved
		if step_distance>=9 and id!=0:
			step_distance=fmod(step_distance,9);block_sound(id,"step",at)
			if p.sprinting:debris(id,at+Vector2(0,12),2)
	if grounded and not was_grounded and moved>1 and id!=0:block_sound(id,"step",at)
	was_grounded=grounded
func _ambient() -> void:
	if config.particle_density<=0 and config.ambient_volume<=0:return
	var top_left: Vector2i=world.mobs.cell(view.position);var bottom_right: Vector2i=world.mobs.cell(view.end);var width: int=maxi(1,bottom_right.x-top_left.x+1);var height: int=maxi(1,bottom_right.y-top_left.y+1)
	for i in range(config.ambient_scan_budget):
		var index: int=posmod(scan_cursor,width*height);scan_cursor+=1;samples+=1
		var cell:=top_left+Vector2i(index%width,index/width)
		if not world.chunks.is_cell_loaded(cell):continue
		var key: String=str(BlockDatabase.BLOCKS.get(world.get_block(cell),{}).get("key",""))
		if _emitter(key) and (key!="water" or world.fluids.level(cell)>0) and not emitters.has(cell) and emitters.size()<96:emitters.append(cell)
	for i in range(mini(config.ambient_emit_budget,emitters.size())):
		if emitters.is_empty():break
		emitter_cursor=posmod(emitter_cursor,emitters.size());var cell: Vector2i=emitters[emitter_cursor]
		var at: Vector2=cell_position(cell);var key: String=str(BlockDatabase.BLOCKS.get(world.get_block(cell),{}).get("key",""))
		if not view.has_point(at) or not _emitter(key):emitters.remove_at(emitter_cursor);continue
		emitter_cursor+=1
		if "torch" in key or "fire" in key:
			if "torch" not in key:sound("block.fire.ambient",at,"ambient",.35,1,0,2)
			var tip: Vector2=at+Vector2(0,-5);emit_particle("soul_fire_flame" if "soul" in key else "flame",tip,Vector2(0,-2),.3,3);emit_particle("smoke",tip,Vector2(rng.randf_range(-2,2),-6),.8,3,Color(.5,.5,.5,.7))
		elif "lava" in key:
			if rng.randf()<.1:puff("smoke",at,1);sound("block.lava.pop",at,"ambient",.25,1,0,2)
		elif "portal" in key:emit_particle("effect_0",at+Vector2(rng.randf_range(-7,7),rng.randf_range(-7,7)),Vector2(rng.randf_range(-7,7),-5),.8,2,Color(.75,.2,1));sound("block.portal.ambient",at,"ambient",.25,1,0,4)
		elif "end_rod" in key:emit_particle("end_rod",at+Vector2(rng.randf_range(-4,4),rng.randf_range(-4,4)),Vector2(0,-2),1,1.5,Color(1,1,.85))
		elif key=="furnace_lit":
			emit_particle("smoke",at+Vector2(0,-7),Vector2(0,-6),.7,3,Color(.5,.5,.5,.7));sound("block.furnace.fire_crackle",at,"ambient",.2,1,0,3)
		elif "water" in key:sound("block.water.ambient",at,"ambient",.2,1,0,3)
	if not world.survival.effects.remaining.is_empty():
		var color:=Color(0,0,0,0);var total: int=0
		for effect in world.survival.effects.remaining:
			var weight: int=1+int(world.survival.effects.amplifiers.get(effect,0));color+=Color(effect_colors.get(effect,Color.WHITE))*weight;total+=weight
		color/=maxi(1,total);color.a=.7
		emit_particle("effect_0",world.player.global_position+Vector2(rng.randf_range(-5,5),rng.randf_range(-13,12)),Vector2(0,-7),.8,2,color)
	var cell: Vector2i=world.mobs.cell(world.player.global_position)
	if world.weather.strength>.1 and world.weather.precipitation_at(cell.x)=="rain" and cell.y<=world.weather.roof(cell.x):
		sound("weather.rain",world.player.global_position,"ambient",world.weather.strength*.3,1,0,3)
		var roof_y: int=world.weather.roof(cell.x)
		if roof_y>=top_left.y and roof_y<=bottom_right.y:emit_particle("splash_0",cell_position(Vector2i(cell.x,roof_y))+Vector2(0,-8),Vector2(0,-6),.2,3,Color(.5,.7,1,.7))
func _emitter(key: String) -> bool:return "torch" in key or "fire" in key or key in ["nether_portal","end_portal","end_gateway"] or "lava" in key or "end_rod" in key or key in ["water","water_flowing","furnace_lit"]
func _draw() -> void:
	for i in active:
		if not view.has_point(positions[i]):continue
		var tint: Color=tints[i];tint.a*=minf(1,lifetimes[i]/maxf(.01,durations[i]) * 3)
		var region: Rect2=regions[i]
		if animation[i]>1:region.position.y=region.size.y*clampi(int((1-lifetimes[i]/durations[i])*animation[i]),0,animation[i]-1)
		draw_texture_rect_region(images[i],Rect2(positions[i].floor()-Vector2.ONE*sizes[i]*.5,Vector2.ONE*sizes[i]),region,tint)

func arrival(event: String="block.portal.travel") -> void:
	clear();sound(event,world.player.global_position,"player",.65,1,3,.5)
	puff("effect_0",world.player.global_position,8,Color(.7,.2,1))
