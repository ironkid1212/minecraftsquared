class_name BedSystem
extends RefCounted

var world: Node2D
var definitions: Dictionary
var parts: Dictionary = {}
var _removing: bool = false

func setup(game: Node2D, path: String) -> bool:
	world = game
	definitions = DataFile.object_from(path)
	for item in definitions:
		var rule: Variant = definitions[item]
		if not rule is Dictionary or not rule.get("spawn_offsets") is Array:
			DataFile.fail("beds.json: bed rules need variants and spawn offsets.")
			return false
		for direction in [1, -1]:
			var pair: Variant = rule.get("right" if direction == 1 else "left")
			if not pair is Array or pair.size() != 2:
				DataFile.fail("beds.json: each orientation needs [foot, head].")
				return false
			var foot: int = BlockDatabase.id_for(str(pair[0]))
			var head: int = BlockDatabase.id_for(str(pair[1]))
			for id in [foot, head]:
				if id == 0 or BlockDatabase.BLOCKS[id]["interaction"] != "bed" or not BlockDatabase.BLOCKS[id]["platform"] or parts.has(id):
					DataFile.fail("beds.json: invalid/duplicate bed part.")
					return false
				parts[id] = {"item": BlockDatabase.id_for(str(item)), "foot": foot, "head": head, "direction": direction, "is_head": id == head, "offsets": rule["spawn_offsets"]}
		for offset in rule["spawn_offsets"]:
			if not ContentCatalog._vector(offset, 2, -8, 8, true):
				DataFile.fail("beds.json: invalid spawn offset.")
				return false
	world.chunks.cell_changed.connect(_changed)
	return DataFile.errors.is_empty()

func is_item(id: int) -> bool:
	return definitions.has(str(BlockDatabase.BLOCKS.get(id, {}).get("key", "")))

func resolve(cell: Vector2i) -> Dictionary:
	var id: int = world.get_block(cell)
	if not parts.has(id): return {}
	var result: Dictionary = parts[id].duplicate()
	result["anchor"] = cell - Vector2i(int(result["direction"]), 0) if result["is_head"] else cell
	return result

func intact(anchor: Vector2i) -> bool:
	var rule: Dictionary = resolve(anchor)
	if rule.is_empty() or rule["is_head"]: return false
	var head: Vector2i = anchor + Vector2i(int(rule["direction"]), 0)
	return world.chunks.is_cell_loaded(anchor) and world.chunks.is_cell_loaded(head) and world.get_block(head) == rule["head"]

func can_place(cell: Vector2i, id: int, direction: int) -> bool:
	var key: String = str(BlockDatabase.BLOCKS[id]["key"])
	if not definitions.has(key): return false
	for point in [cell, cell + Vector2i(direction, 0)]:
		if not world.chunks.is_cell_loaded(point) or world.get_block(point) != 0: return false
		var floor: Vector2i = point + Vector2i.DOWN
		if not world.chunks.is_cell_loaded(floor): return false
		if not BlockDatabase.BLOCKS.get(world.get_block(floor), {}).get("solid", false) and not world.chunks.has_platform_top(floor): return false
		if world.world_updates.falling.overlaps_cell(point): return false
		var block_bounds: Rect2 = world.ground.global_transform * Rect2(world.ground.map_to_local(point) - Vector2(8,8), Vector2(16,16))
		if block_bounds.intersects(world.player_collision.global_transform * world.player_collision.shape.get_rect()): return false
	return true

func place(cell: Vector2i, id: int, direction: int) -> bool:
	if not can_place(cell, id, direction): return false
	var pair: Array = definitions[BlockDatabase.BLOCKS[id]["key"]]["right" if direction == 1 else "left"]
	world.set_block(cell, BlockDatabase.id_for(str(pair[0])))
	world.set_block(cell + Vector2i(direction, 0), BlockDatabase.id_for(str(pair[1])))
	return true

func can_break(cell: Vector2i) -> bool:
	var rule: Dictionary = resolve(cell)
	if rule.is_empty(): return true
	return world.chunks.is_cell_loaded(rule["anchor"]) and world.chunks.is_cell_loaded(rule["anchor"] + Vector2i(int(rule["direction"]), 0))

func _changed(cell: Vector2i, old_id: int, new_id: int) -> void:
	if _removing or not parts.has(old_id) or new_id == old_id: return
	var rule: Dictionary = parts[old_id]
	var other: Vector2i = cell + Vector2i(-int(rule["direction"]) if rule["is_head"] else int(rule["direction"]), 0)
	var expected: int = int(rule["foot"] if rule["is_head"] else rule["head"])
	if world.chunks.is_cell_loaded(other) and world.get_block(other) == expected:
		_removing = true
		world.set_block(other, 0)
		_removing = false

func use(cell: Vector2i) -> bool:
	var rule: Dictionary = resolve(cell)
	if rule.is_empty() or not world.cell_is_reachable(cell): return false
	if world.chunks.dimension!="overworld":
		world.set_block(cell,0)
		world.mobs.explosions.explode(world.ground.to_global(world.ground.map_to_local(cell)),float(WorldDimensions.DATA.environment.bed_explosion_power),"You were blown up by a bed")
		return true
	var query := PhysicsRayQueryParameters2D.create(world.player.global_position - Vector2(0,8), world.ground.to_global(world.ground.map_to_local(cell)), 1)
	query.exclude = [world.player.get_rid()]
	if not world.ground.get_world_2d().direct_space_state.intersect_ray(query).is_empty(): return false
	if not intact(rule["anchor"]) or spawn_at(rule["anchor"]) == null:
		world.show_mode_notice("This bed is obstructed")
		return true
	world.survival.bed_anchor = rule["anchor"]
	world.survival.has_bed = true
	world.show_mode_notice("Respawn point set")
	world.player.swing_hand("place", world.ground.to_global(world.ground.map_to_local(cell)))
	return true

func safe_on(floor: Vector2i) -> Variant:
	if not world.chunks.is_cell_loaded(floor): return null
	var block: Dictionary = BlockDatabase.BLOCKS.get(world.get_block(floor), {})
	if not block.get("solid", false) and not world.chunks.has_platform_top(floor): return null
	var height: int = int(block.get("platform_height", 16)) if block.get("platform", false) else 16
	var position: Vector2 = world.ground.to_global(world.ground.map_to_local(floor) + Vector2(0, 8 - height - 14.05))
	var bounds: Rect2 = world.ground.global_transform.affine_inverse() * Rect2(position - Vector2(4,14), Vector2(8,28))
	var first: Vector2i = world.ground.local_to_map(bounds.position + Vector2.ONE * .1)
	var last: Vector2i = world.ground.local_to_map(bounds.end - Vector2.ONE * .1)
	for y in range(first.y, last.y + 1):
		for x in range(first.x, last.x + 1):
			var cell := Vector2i(x,y)
			if not world.chunks.is_cell_loaded(cell) or BlockDatabase.BLOCKS.get(world.get_block(cell), {}).get("solid", false) or BlockDatabase.has_tag(world.get_block(cell),"fluid"): return null
	return position

func spawn_at(anchor: Vector2i) -> Variant:
	if not intact(anchor): return null
	var rule: Dictionary = resolve(anchor)
	for offset in rule["offsets"]:
		var result: Variant = safe_on(anchor + Vector2i(int(offset[0]) * int(rule["direction"]), int(offset[1])))
		if result != null: return result
	return null
