class_name DayNightCycle
extends Node

const TICKS_PER_DAY: int = 24000
var world: Node2D
var settings: DayNightSettings
var total_ticks: float = 1000
var running: bool = true
var sky: DayNightSky

func setup(game: Node2D, config: DayNightSettings) -> void:
	world = game
	settings = config
	total_ticks = settings.initial_time
	running = settings.enabled
	process_priority = -10
	sky = DayNightSky.new()
	sky.name = "DayNightSky"
	world.lighting._sky.hide()
	world.lighting._sky.get_parent().add_child(sky)
	sky.setup(self,world.world_seed)
	apply()

func _process(delta: float) -> void:
	if running:
		total_ticks = minf(1000000000000,total_ticks+delta*TICKS_PER_DAY/settings.cycle_seconds)
		apply()

func time_of_day() -> float: return fposmod(total_ticks,TICKS_PER_DAY)
func day_number() -> int: return floori(total_ticks/TICKS_PER_DAY)
func moon_phase() -> int: return posmod(day_number(),8)

func daylight() -> float:
	var time: float = time_of_day()
	if time >= 23000: return smoothstep(23000,24000,time)
	if time >= 12000: return 1.0-smoothstep(12000,13000,time)
	return 1.0

func star_visibility() -> float:
	# A steady celestial pattern: global dawn/dusk fade, no per-star blinking.
	return pow(1.0-daylight(),2.0)*settings.star_brightness*(1.0-world.weather.strength if world.weather!=null else 1.0)

func apply() -> void:
	if world.chunks.dimension!="overworld":
		world.lighting.set_daylight(0,1)
		if sky!=null:sky.refresh()
		return
	var strength: float = daylight()
	var weather_factor: float=world.weather.daylight_factor() if world.weather!=null else 1.0
	world.lighting.set_daylight(lerpf(settings.night_sky_light,1,strength)*weather_factor,lerpf(settings.night_ambient_factor,1,strength)*weather_factor,settings.lighting_steps)
	if sky != null: sky.refresh()

func set_daytime(value: int) -> void:
	total_ticks = minf(1000000000000,day_number()*float(TICKS_PER_DAY)+posmod(value,TICKS_PER_DAY))
	apply()

func snapshot() -> Dictionary: return {"ticks":total_ticks,"running":running}

func restore(data: Dictionary) -> void:
	total_ticks = float(data.get("ticks",settings.initial_time))
	running = bool(data.get("running",settings.enabled))
	apply()

func clock_text() -> String:
	var minutes: int = floori(fposmod(time_of_day()/TICKS_PER_DAY*1440+360,1440))
	return "%02d:%02d" % [minutes/60,minutes%60]
