class_name WorldDoors
extends RefCounted
var world: Node2D
var _busy: bool=false
func setup(game: Node2D) -> void:
	world=game;world.chunks.cell_changed.connect(changed)
func is_item(id: int) -> bool:
	var entry: Dictionary=BlockDatabase.BLOCKS.get(id,{})
	return entry.has("door") and id==BlockDatabase.id_for(entry.door.item)
func supported(cell: Vector2i) -> bool:
	var below: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(cell+Vector2i.DOWN),{})
	return below.get("solid",false) and not below.has("fence") and not below.has("gate") and not below.has("door") and int(below.get("collision_height",16))>=16 and below.get("building",{}).get("half","top") in ["top","double"]
func can_place(cell: Vector2i,id: int) -> bool:
	if not is_item(id) or not world.cell_is_reachable(cell) or not supported(cell):return false
	var placed: int=state_id(BlockDatabase.BLOCKS[id].door.item,false,false,world.player.facing)
	for at in [cell,cell+Vector2i.UP]:
		if not world.chunks.is_cell_loaded(at) or world.get_block(at)!=0 or world.building.overlaps_player(at,placed):return false
	return true
func place(cell: Vector2i,id: int) -> bool:
	if not can_place(cell,id):return false
	var item: String=BlockDatabase.BLOCKS[id].door.item;var hinge: int=world.player.facing
	world.set_block(cell,state_id(item,false,false,hinge));world.set_block(cell+Vector2i.UP,state_id(item,true,false,hinge));return true
func lower(cell: Vector2i) -> Vector2i:
	return cell+Vector2i.DOWN if BlockDatabase.BLOCKS.get(world.get_block(cell),{}).get("door",{}).get("upper",false) else cell
func use(cell: Vector2i) -> bool:
	var entry: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(cell),{})
	if not entry.has("door") or not world.cell_is_reachable(cell):return false
	var base: Vector2i=lower(cell)
	if not world.chunks.is_cell_loaded(base) or not world.chunks.is_cell_loaded(base+Vector2i.UP):return true
	var key: String=entry.door.item;var closing: bool=entry.door.open
	var hinge: int=int(entry.door.get("hinge",1))
	var lower_id: int=state_id(key,false,not closing,hinge)
	if closing:
		for at in [base,base+Vector2i.UP]:
			if world.building.overlaps_player(at,lower_id):return true
		for mob: MobActor in world.mobs.active.values():
			if not mob.dead:
				for at in [base,base+Vector2i.UP]:
					if HingedBlocks.overlaps_mob(world.chunks,at,BlockDatabase.BLOCKS[lower_id],mob.bounds(mob.global_position)):return true
	if world.effects!=null:world.effects.sound("block."+("iron_door" if "iron" in key else "wooden_door")+(".close" if closing else ".open"),world.effects.cell_position(base),"blocks",.7,1,1,.15)
	_busy=true;world.set_block(base,lower_id);world.set_block(base+Vector2i.UP,state_id(key,true,not closing,hinge));_busy=false
	world.player.swing_hand("place",world.ground.to_global(world.ground.map_to_local(cell)));return true
func changed(cell: Vector2i,old: int,new: int) -> void:
	if _busy:return
	var was: Dictionary=BlockDatabase.BLOCKS.get(old,{}).get("door",{});var now: Dictionary=BlockDatabase.BLOCKS.get(new,{}).get("door",{})
	if not was.is_empty() and now.get("item","")!=was.item:
		var peer: Vector2i=cell+(Vector2i.DOWN if was.upper else Vector2i.UP)
		if BlockDatabase.BLOCKS.get(world.get_block(peer),{}).get("door",{}).get("item","")==was.item:
			_busy=true;erase_half(peer);_busy=false
	if not was.is_empty() and now.get("item","")==was.item and (now.open!=was.open or now.get("hinge",1)!=was.get("hinge",1)):
		var peer: Vector2i=cell+(Vector2i.DOWN if now.upper else Vector2i.UP)
		if BlockDatabase.BLOCKS.get(world.get_block(peer),{}).get("door",{}).get("item","")==now.item:
			_busy=true;write_half(peer,state_id(now.item,not now.upper,now.open,int(now.get("hinge",1))));_busy=false
	var above:=cell+Vector2i.UP;var door: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(above),{}).get("door",{})
	if not door.is_empty() and not door.upper and not supported(above):
		_busy=true;erase_half(above);erase_half(above+Vector2i.UP);_busy=false
		world.dropped_items.spawn_item(BlockDatabase.id_for(door.item),1,world.ground.to_global(world.ground.map_to_local(above)))

func erase_half(cell: Vector2i) -> void:write_half(cell,0)
func write_half(cell: Vector2i,id: int) -> void:
	if world.chunks.is_cell_loaded(cell):world.set_block(cell,id)
	else:
		world.chunks.edits[cell]=id
		world.chunks._block_cache.erase(world.chunks.cell_to_chunk(cell))

func state_id(item: String,upper: bool,opened: bool,hinge: int) -> int:
	return BlockDatabase.id_for(item+("_right" if hinge<0 else "")+("_open" if opened else "")+("_upper" if upper else ""))
