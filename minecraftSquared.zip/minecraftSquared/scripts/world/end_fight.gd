class_name EndFight
extends Node2D
static var RULES: Dictionary=DataFile.object_from("res://data/dragon_fight.json")
const PHASES: Array[String]=["holding","strafe","charge_warning","charge","landing","scan","roar","breath","takeoff","dying","defeated","respawning"]
var world: Node2D
var initialized: bool=false
var health: float=200
var defeated: bool=false
var previously_killed: bool=false
var egg_awarded: bool=false
var phase: String="holding"
var phase_time: float=0
var position_world:=Vector2.ZERO
var previous_position:=Vector2.ZERO
var velocity:=Vector2.ZERO
var facing: int=1
var pitch: float=0
var wing_phase: float=0
var head_pitch: float=0
var orbit: float=0
var target_point:=Vector2.ZERO
var phase_limit: float=12
var perch_damage: float=0
var breath_cycles: int=0
var healing: int=-1
var heal_clock: float=0
var hit_time: float=0
var hit_damage: float=0
var flash: float=0
var contact_time: float=0
var cloud_clock: float=0
var crystals: Array[bool]=[]
var placed: Array[Dictionary]=[]
var next_crystal: int=1
var projectiles: Array[Dictionary]=[]
var clouds: Array[Dictionary]=[]
var pose: Dictionary={}
var rng:=RandomNumberGenerator.new()
var death_time: float=0
var xp_paid: int=0
var restored_pillars: int=0
var regen_queue: Array[Vector2i]=[]
var renderer: EndDragonRenderer
var bar: DragonBossBar
var _destroy_clock: float=0
var _swing_clock: float=0
var _portal_open: bool=false
func setup(game: Node2D) -> void:
	world=game;rng.seed=world.world_seed^72741
	if not EndFightState.valid_rules():DataFile.fail("dragon_fight.json: invalid fight settings.")
	renderer=EndDragonRenderer.new();world.add_child(renderer);renderer.setup(self)
	bar=DragonBossBar.new();(world.ui_layer if world.ui_layer!=null else world.get_node("UI")).add_child(bar);bar.fight=self
	world.chunks.changed.connect(func():
		if world.is_end() and initialized:_sync_portal())
func floor_row() -> int:return 255-int(EndGenerator.RULES.surface_y)
func floor_point() -> Vector2:return world.ground.to_global(world.ground.map_to_local(Vector2i(0,floor_row()))-Vector2(0,8))
func placed_point(cell: Vector2i) -> Vector2:return world.ground.to_global(world.ground.map_to_local(cell)-Vector2(0,24))
func perched() -> bool:return phase in ["scan","roar","breath"]
func present() -> bool:return world!=null and world.is_end() and initialized and phase not in ["defeated","respawning"]
func clear() -> void:
	initialized=false;health=float(RULES.health);defeated=false;previously_killed=false;egg_awarded=false;phase="holding";phase_time=0;death_time=0;xp_paid=0;crystals.clear();placed.clear();projectiles.clear();clouds.clear();pose.clear();regen_queue.clear();healing=-1;_portal_open=false;restored_pillars=0;next_crystal=1
	position_world=Vector2.ZERO;previous_position=Vector2.ZERO;velocity=Vector2.ZERO;target_point=Vector2.ZERO
	facing=1;pitch=0;head_pitch=0;wing_phase=0;orbit=0;phase_limit=12;perch_damage=0;breath_cycles=0
	heal_clock=0;hit_time=0;hit_damage=0;flash=0;contact_time=0;cloud_clock=0;_destroy_clock=0;_swing_clock=0
func ensure() -> void:
	if initialized or not world.is_end():return
	rng.seed=world.world_seed^72741
	initialized=true;health=float(RULES.health);crystals.assign([true,true,true,true,true,true,true,true,true,true])
	position_world=floor_point()+Vector2(-40*16,-float(RULES.cruise_height)*16);previous_position=position_world;orbit=PI
	_set_phase("holding");_set_exit(false);update_pose()
func _set_phase(value: String) -> void:
	phase=value;phase_time=0
	if value=="holding":phase_limit=rng.randf_range(float(RULES.holding_seconds[0]),float(RULES.holding_seconds[1]))
	if value=="landing":perch_damage=0
	if value=="roar":renderer.sound("growl",position_world)
	if value=="charge_warning":target_point=world.player.global_position;renderer.sound("growl",position_world)
	if value=="breath":
		breath_cycles+=1;renderer.sound("shoot",position_world)
	if value=="dying":death_time=0;xp_paid=0;healing=-1;clouds.clear();projectiles.clear();renderer.sound("death",position_world)
func _write(cell: Vector2i,id: int,wall: bool=false) -> void:
	if world.chunks.is_cell_loaded(cell):
		if wall:world.chunks.set_wall_block(cell,id)
		else:world.set_block(cell,id)
	else:
		if wall:world.chunks.wall_edits[cell]=id
		else:world.chunks.edits[cell]=id
		world.chunks._block_cache.erase(world.chunks.cell_to_chunk(cell))
func _set_exit(opened: bool) -> void:
	_portal_open=opened;world.chunks.end.exit_open=opened
	for x in range(-2,3):_write(Vector2i(x,floor_row()-1),BlockDatabase.id_for("end_portal") if opened else 0)
func _sync_portal() -> void:
	world.chunks.end.exit_open=_portal_open
func crystal_point(index: int) -> Vector2:
	var p: Dictionary=world.chunks.end.pillars[index]
	return placed_point(Vector2i(int(p.x),int(p.top)))
func crystal_bounds(point: Vector2) -> Rect2:return Rect2(point-Vector2(16,34),Vector2(32,50))
func crystal_records() -> Array[Dictionary]:
	var result: Array[Dictionary]=[]
	if world.is_end() and initialized:
		for i in range(crystals.size()):
			if crystals[i]:result.append({"kind":"crystal","key":i,"position":crystal_point(i),"base":true})
	for c in placed:result.append({"kind":"placed","key":int(c.id),"position":placed_point(c.cell),"base":false})
	return result
func update_pose() -> void:
	if not present():pose.clear();return
	var jaw: float=.4 if phase in ["roar","breath"] else .08+.06*sin(wing_phase)
	pose=DragonPose.build(position_world,facing,pitch,wing_phase,perched(),jaw,head_pitch)
func _physics_process(dt: float) -> void:
	_swing_clock=maxf(0,_swing_clock-dt);flash=maxf(0,flash-dt);hit_time=maxf(0,hit_time-dt);contact_time=maxf(0,contact_time-dt)
	if not world.is_end():return
	ensure();previous_position=position_world
	if absf(world.player.global_position.x)>160*16:return
	phase_time+=dt;wing_phase+=dt*(1.5 if perched() else 5);cloud_clock+=dt
	_update_clouds(dt);_update_projectiles(dt)
	if phase=="respawning":_respawn(dt);return
	if phase=="defeated":return
	if phase=="dying":_death(dt);update_pose();return
	var alive: bool=not world.player.creative and not world.player.spectator and not world.player.survival_dead
	var goal: Vector2=position_world;var speed: float=float(RULES.flight_speed)
	var center: Vector2=floor_point()
	if phase=="holding":
		orbit+=dt*.17
		goal=center+Vector2(sin(orbit)*float(RULES.orbit_radius)*16,-(float(RULES.cruise_height)+sin(orbit*2)*float(RULES.cruise_variation))*16)
		if alive and phase_time>=phase_limit:
			if rng.randi_range(0,_alive_crystals()+2)==0 or _alive_crystals()==0:_set_phase("landing");facing=1 if world.player.global_position.x>=0 else -1;breath_cycles=0
			else:_set_phase("strafe")
	elif phase=="strafe":
		facing=1 if world.player.global_position.x>=position_world.x else -1
		goal=world.player.global_position+Vector2(-facing*12*16,-8*16)
		if not alive:_set_phase("holding")
		elif phase_time>=float(RULES.strafe_seconds):
			shoot();_set_phase("charge_warning" if rng.randf()<.3 else "holding")
	elif phase=="charge_warning":
		goal=position_world
		if phase_time>=float(RULES.charge_warning_seconds):_set_phase("charge")
	elif phase=="charge":
		goal=target_point;speed=float(RULES.charge_speed)
		if phase_time>=float(RULES.charge_seconds) or position_world.distance_to(goal)<16:_set_phase("takeoff")
	elif phase=="landing":
		goal=center+Vector2(0,-64)
		if position_world.distance_to(goal)<3:position_world=goal;velocity=Vector2.ZERO;_set_phase("scan")
	elif perched():
		goal=center+Vector2(0,-64);position_world=goal;velocity=Vector2.ZERO
		head_pitch=clampf((world.player.eye_position().y-(position_world.y+16))/160,-.12,.4)
		if phase=="scan" and phase_time>=float(RULES.scan_seconds):_set_phase("roar" if alive else "takeoff")
		elif phase=="roar" and phase_time>=float(RULES.roar_seconds):_set_phase("breath")
		elif phase=="breath":
			if phase_time-dt<.5 and phase_time>=.5:add_cloud(pose.get("mouth",position_world)+Vector2(facing*20,20),float(RULES.perched_cloud_radius))
			if phase_time>=float(RULES.breath_seconds):_set_phase("takeoff" if breath_cycles>=int(RULES.maximum_breath_cycles) else "scan")
	elif phase=="takeoff":
		goal=center+Vector2(facing*25*16,-float(RULES.cruise_height)*16)
		if phase_time>=float(RULES.takeoff_seconds):_set_phase("holding")
	if not perched():
		var offset: Vector2=goal-position_world
		var desired: Vector2=offset.normalized()*minf(speed,offset.length()*2)
		velocity=velocity.move_toward(desired,dt*160);position_world+=velocity*dt
		if absf(velocity.x)>12 and phase not in ["landing","takeoff","strafe"]:facing=1 if velocity.x>0 else -1
		pitch=lerpf(pitch,clampf(velocity.y/maxf(40,absf(velocity.x)),-.35,.35),minf(1,dt*3))
		head_pitch=move_toward(head_pitch,0,dt)
	else:pitch=move_toward(pitch,0,dt)
	update_pose();_healing(dt)
	if alive:_contact()
	_destroy_clock+=dt
	if _destroy_clock>=.1:_destroy_clock=0;_destroy_blocks()
func _alive_crystals() -> int:
	var count: int=0
	for alive in crystals:
		if alive:count+=1
	return count
func _healing(dt: float) -> void:
	var nearest: int=-1;var distance: float=float(RULES.heal_radius)*16
	for i in range(crystals.size()):
		if not crystals[i]:continue
		var d: float=position_world.distance_to(crystal_point(i))
		if d<distance:nearest=i;distance=d
	healing=nearest;heal_clock+=dt
	if heal_clock>=float(RULES.heal_interval):
		heal_clock=fmod(heal_clock,float(RULES.heal_interval))
		if healing>=0:health=minf(float(RULES.health),health+float(RULES.heal_amount))
func hurt(amount: float,part: String,kind: String="melee") -> bool:
	if not present() or phase=="dying" or amount<=0 or perched() and kind=="projectile":return false
	var damage: float=amount if part=="head" else amount/float(RULES.body_damage_divisor)+minf(amount,float(RULES.body_damage_bonus))
	if hit_time>0:
		if damage<=hit_damage:return false
		damage-=hit_damage
	else:hit_time=.5
	hit_damage=amount if part=="head" else amount/float(RULES.body_damage_divisor)+minf(amount,float(RULES.body_damage_bonus))
	health=maxf(0,health-damage);flash=.35
	if perched():
		perch_damage+=damage
		if perch_damage>=float(RULES.perch_damage_limit):_set_phase("takeoff")
	if health<=0:_set_phase("dying")
	return true
func _contact() -> void:
	if contact_time>0 or pose.is_empty():return
	var bounds: Rect2=world.player_collision.global_transform*world.player_collision.shape.get_rect()
	for hit in pose.hits:
		if hit.name not in ["head","wing","body"] or not Rect2(hit.bounds).intersects(bounds):continue
		var amount: float=float(RULES.head_damage if hit.name=="head" else RULES.wing_damage)
		if not world.shields.block(amount,Rect2(hit.bounds).get_center(),"melee") and world.survival.take_damage(amount,"You were struck by the Ender Dragon"):
			world.player.receive_knockback(Rect2(hit.bounds).get_center(),float(RULES.contact_knockback));world.player.velocity.y=-128
		contact_time=float(RULES.contact_interval);return
func _destroy_blocks() -> void:
	if not world.mobs.mob_griefing or pose.is_empty():return
	var budget: int=RULES.destroy_budget
	for hit in pose.hits:
		if hit.name not in ["head","body","neck"]:continue
		var bounds: Rect2=hit.bounds;var first: Vector2i=world.mobs.cell(bounds.position);var last: Vector2i=world.mobs.cell(bounds.end)
		for y in range(first.y,last.y+1):
			for x in range(first.x,last.x+1):
				var cell:=Vector2i(x,y)
				if not world.chunks.is_cell_loaded(cell):continue
				var entry: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(cell),{})
				if entry.is_empty() or entry.key=="air" or entry.key in RULES.dragon_immune or not entry.get("diggable",false) or "fluid" in entry.tags:continue
				world.set_block(cell,0);budget-=1
				if budget<=0:return
func ray_hit(from: Vector2,to: Vector2,reach: float=INF) -> Dictionary:
	var nearest: float=minf(reach,from.distance_to(to));var result: Dictionary={}
	for c in crystal_records():
		var box: Rect2=crystal_bounds(c.position);var d: float=PlayerCombat.ray_entry(from,to,box,nearest)
		if is_finite(d) and d<=nearest:nearest=d;result={"kind":c.kind,"key":c.key,"distance":d,"bounds":box}
	if present() and not pose.is_empty() and phase!="dying":
		for hit in pose.hits:
			var d: float=PlayerCombat.ray_entry(from,to,hit.bounds,nearest)
			if is_finite(d) and d<nearest:nearest=d;result={"kind":"dragon","part":hit.name,"distance":d,"bounds":hit.bounds}
	return result
func pointer_target() -> Dictionary:
	if world.player.spectator or world.player.survival_dead:return {}
	var point: Vector2=world.pointer_global_position();var focus: bool=false
	for c in crystal_records():
		if crystal_bounds(c.position).has_point(point):focus=true;break
	if not focus and present() and not pose.is_empty():
		for hit in pose.hits:
			if Rect2(hit.bounds).has_point(point):focus=true;break
	if not focus:return {}
	var eye: Vector2=world.player.eye_position();var hit: Dictionary=ray_hit(eye,point,float(MobCatalog.rules.attack_reach)*16)
	if hit.is_empty():return {}
	var at: Vector2=eye+(point-eye).normalized()*float(hit.distance)
	return hit if world.cell_is_visible(world.mobs.cell(at)) and world.mobs.visible(eye,at) else {}
func attack_pointer() -> bool:
	var hit: Dictionary=pointer_target()
	if hit.is_empty():return false
	var target: Vector2=Rect2(hit.bounds).get_center();var strike: Dictionary=world.combat.prepare_strike(target)
	var successful: bool=hit_target(hit,float(strike.damage),"melee",true)
	if successful:world.combat.finish_strike(strike,target)
	return true
func hit_target(hit: Dictionary,damage: float,kind: String,player_owned: bool=true) -> bool:
	if hit.kind=="dragon":return hurt(damage,hit.part,kind) if player_owned else false
	return destroy_crystal(hit.kind,int(hit.key))
func destroy_crystal(kind: String,key: int) -> bool:
	var point:=Vector2.ZERO
	if kind=="crystal":
		if key<0 or key>=crystals.size() or not crystals[key]:return false
		crystals[key]=false;point=crystal_point(key)
		if healing==key:hit_time=0;hurt(float(RULES.linked_crystal_damage),"head","crystal");healing=-1
	else:
		var found: bool=false
		for i in range(placed.size()-1,-1,-1):
			if int(placed[i].id)==key:point=placed_point(placed[i].cell);placed.remove_at(i);found=true;break
		if not found:return false
		if phase=="respawning":regen_queue.clear();_set_phase("defeated");_set_exit(true)
	world.mobs.explosions.explode(point,float(RULES.crystal_power),"You were blown up by an End Crystal")
	if present() and phase not in ["dying","landing","takeoff"] and not perched() and not world.player.survival_dead:_set_phase("strafe")
	return true
func on_explosion(origin: Vector2,power: float) -> void:
	for c in crystal_records():
		if origin.distance_to(c.position)<=power*32 and world.mobs.explosions.exposure(origin,Rect2(Vector2(c.position)-Vector2(8,8),Vector2(16,16)))>0:destroy_crystal(c.kind,int(c.key))
	if not present() or phase=="dying" or pose.is_empty():return
	var best: float=0;var part: String="body"
	for hit in pose.hits:
		var damage: float=world.mobs.explosions.blast_damage(origin.distance_to(Rect2(hit.bounds).get_center()),world.mobs.explosions.exposure(origin,hit.bounds),power)
		var reduced: float=damage if hit.name=="head" else damage/4+minf(damage,1)
		if reduced>best:best=reduced;part=hit.name
	if best>0:hit_time=0;hurt(best if part=="head" else maxf(0,(best-1)*4),part,"explosion")
func shoot() -> void:
	if projectiles.size()>=int(RULES.projectile_limit) or pose.is_empty():return
	var origin: Vector2=pose.mouth;var direction: Vector2=(world.player.global_position-origin).normalized()
	projectiles.append({"position":origin,"velocity":direction*float(RULES.fireball_speed),"life":8.0});renderer.sound("shoot",origin)
func add_cloud(point: Vector2,radius: float) -> void:
	if clouds.size()>=int(RULES.cloud_limit):clouds.pop_front()
	var cell: Vector2i=world.mobs.cell(point)
	for depth in range(12):
		if world.chunks.is_cell_loaded(cell+Vector2i(0,depth)) and world.mobs.support(cell+Vector2i(0,depth)):
			point.y=world.ground.to_global(world.ground.map_to_local(cell+Vector2i(0,depth))-Vector2(0,8)).y;break
	clouds.append({"position":point,"radius":radius*16,"age":0.0,"life":float(RULES.cloud_seconds)})
func _update_projectiles(dt: float) -> void:
	for i in range(projectiles.size()-1,-1,-1):
		var ball: Dictionary=projectiles[i];var from: Vector2=ball.position;var to: Vector2=from+Vector2(ball.velocity)*dt;ball.life-=dt
		if ball.life<=0:projectiles.remove_at(i);continue
		if not world.chunks.is_cell_loaded(world.mobs.cell(from)):ball.position=to;continue
		var query:=PhysicsRayQueryParameters2D.create(from,to,3);query.exclude=[world.player.get_rid()]
		var hit: Dictionary=get_world_2d().direct_space_state.intersect_ray(query)
		var player_box: Rect2=world.player_collision.global_transform*world.player_collision.shape.get_rect()
		var intersects_player: bool=not world.player.spectator and not world.player.creative and not world.player.survival_dead and is_finite(PlayerCombat.ray_entry(from,to,player_box,from.distance_to(to)))
		if not hit.is_empty() or intersects_player:add_cloud(hit.position if not hit.is_empty() else to,float(RULES.cloud_radius));projectiles.remove_at(i)
		else:ball.position=to
func _update_clouds(dt: float) -> void:
	for i in range(clouds.size()-1,-1,-1):
		clouds[i].age+=dt
		if clouds[i].age>=clouds[i].life or clouds[i].radius<8:clouds.remove_at(i)
	if cloud_clock<float(RULES.cloud_interval):return
	cloud_clock=0
	for cloud in clouds:
		if cloud.age<float(RULES.cloud_warmup):continue
		var box:=Rect2(Vector2(cloud.position)-Vector2(float(cloud.radius),16),Vector2(float(cloud.radius)*2,16))
		var player_box: Rect2=world.player_collision.global_transform*world.player_collision.shape.get_rect()
		if box.intersects(player_box):world.survival.take_damage(float(RULES.cloud_damage),"Dragon breath magic",true)
		for mob: MobActor in world.mobs.active.values():
			if not mob.dead and box.intersects(mob.bounds(mob.global_position)):mob.hurt(float(RULES.cloud_damage),cloud.position,"magic")
func _death(dt: float) -> void:
	death_time+=dt;position_world=position_world.move_toward(floor_point()+Vector2(0,-144),dt*64)
	var total: int=int(RULES.repeat_xp if previously_killed else RULES.first_xp)
	var pulses: int=clampi(floori((death_time-7.5)/.25),0,10);var due: int=floori(total*.08)*pulses
	if death_time>=float(RULES.death_seconds):due=total
	if due>xp_paid:world.experience.spawn(due-xp_paid,floor_point()-Vector2(0,48));xp_paid=due
	if death_time<float(RULES.death_seconds):return
	defeated=true;previously_killed=true;_set_phase("defeated");_set_exit(true)
	world.gateways.award_victory()
	if not egg_awarded:
		egg_awarded=true;_write(Vector2i(0,floor_row()-5),BlockDatabase.id_for("dragon_egg"))
	world.show_mode_notice("The Ender Dragon has been defeated!")
func ritual_slots() -> Array[Vector2i]:
	var result: Array[Vector2i]=[]
	for x in RULES.respawn_slots:result.append(Vector2i(int(x),floor_row()-(1 if absi(int(x))==3 else 0)))
	return result
func try_respawn() -> bool:
	if not world.is_end() or not defeated or phase=="respawning":return false
	for slot in ritual_slots():
		var found: bool=false
		for c in placed:
			if Vector2i(c.cell)==slot:found=true;break
		if not found:return false
	restored_pillars=0;regen_queue.clear();_set_phase("respawning");_set_exit(false);return true
func _respawn(dt: float) -> void:
	var desired: int=clampi(floori((phase_time-float(RULES.respawn_prepare_seconds))/float(RULES.respawn_pillar_seconds))+1,0,10)
	if regen_queue.is_empty() and restored_pillars<desired:
		var p: Dictionary=world.chunks.end.pillars[restored_pillars]
		for x in range(int(p.x)-int(p.radius)-1,int(p.x)+int(p.radius)+2):
			for y in range(int(p.top)-4,world.chunks.end.surface(x)+4):regen_queue.append(Vector2i(x,y))
	if not regen_queue.is_empty():
		for i in range(mini(16,regen_queue.size())):
			var cell: Vector2i=regen_queue.pop_back();_write(cell,world.chunks.end.block_at(cell));_write(cell,world.chunks.end.wall_at(cell),true)
		if regen_queue.is_empty():crystals[restored_pillars]=true;restored_pillars+=1
	var duration: float=float(RULES.respawn_prepare_seconds)+10*float(RULES.respawn_pillar_seconds)+float(RULES.respawn_finish_seconds)
	if phase_time<duration or restored_pillars<10 or not regen_queue.is_empty():return
	var slots: Array[Vector2i]=ritual_slots()
	for i in range(placed.size()-1,-1,-1):
		if Vector2i(placed[i].cell) in slots:placed.remove_at(i)
	defeated=false;health=float(RULES.health);death_time=0;xp_paid=0;position_world=floor_point()+Vector2(0,-16*float(RULES.cruise_height));previous_position=position_world;_set_phase("holding");update_pose()
func use_item(cell: Vector2i) -> bool:
	var item: int=world.get_interaction_item()
	if item==BlockDatabase.id_for("glass_bottle"):
		var point: Vector2=world.pointer_global_position()
		for cloud in clouds:
			if Rect2(Vector2(cloud.position)-Vector2(cloud.radius,24),Vector2(cloud.radius*2,32)).has_point(point) and world.player.eye_position().distance_to(point)<=world.interaction_reach:
				if not world.player.creative:world.inventory.remove_from_slot(world.use_slot(),1)
				var remainder: int=world.inventory.add_item(BlockDatabase.id_for("dragon_breath"),1)
				if remainder>0:world.dropped_items.spawn_item(BlockDatabase.id_for("dragon_breath"),remainder,world.player.global_position)
				cloud.radius=maxf(0,float(cloud.radius)-8);world.player.swing_hand("place",point);return true
		return false
	if item!=BlockDatabase.id_for("end_crystal"):return false
	if _swing_clock>0:return true
	var base: Vector2i=cell if world.get_block(cell) in [BlockDatabase.id_for("bedrock"),BlockDatabase.id_for("obsidian")] else cell+Vector2i.DOWN
	if placed.size()>=int(RULES.crystal_limit) or not world.cell_is_reachable(base) or world.get_block(base) not in [BlockDatabase.id_for("bedrock"),BlockDatabase.id_for("obsidian")]:return false
	var point: Vector2=placed_point(base);var bounds: Rect2=crystal_bounds(point)
	for c in crystal_records():
		if bounds.intersects(crystal_bounds(c.position)):return false
	var player_box: Rect2=world.player_collision.global_transform*world.player_collision.shape.get_rect()
	if player_box.intersects(bounds):return false
	for offset in [Vector2i.UP,Vector2i.UP*2]:
		var entry: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(base+offset),{})
		if entry.get("solid",false):return false
	for mob: MobActor in world.mobs.active.values():
		if not mob.dead and mob.bounds(mob.global_position).intersects(bounds):return false
	placed.append({"id":next_crystal,"cell":base});next_crystal+=1;_swing_clock=.25
	world.inventory.consume_for_placement(world.use_slot());world.player.swing_hand("place",point);try_respawn();return true

func snapshot() -> Dictionary:return EndFightState.snapshot(self)
func restore(record: Dictionary) -> void:EndFightState.restore(self,record)
