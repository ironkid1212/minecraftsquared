class_name BrewingSystem
extends Node
var world: Node2D
var states: Dictionary={}
func setup(game: Node2D) -> void:
	world=game
	if not BrewingData.validate():DataFile.fail("brewing.json: invalid recipes/potions.");set_process(false);return
	world.chunks.cell_changed.connect(_changed)
func state_at(cell: Vector2i) -> BrewingState:
	if not states.has(cell):states[cell]=BrewingState.new()
	return states[cell]
func is_stand(id: int) -> bool:return BlockDatabase.BLOCKS.get(id,{}).get("interaction")=="brewing"
func _changed(cell: Vector2i,old: int,value: int) -> void:
	if is_stand(value):state_at(cell)
	elif is_stand(old) and states.has(cell):
		if world.furnace_screen.is_open and world.furnace_screen.cell==cell:world.furnace_screen.set_open(false)
		var state: BrewingState=states[cell]
		for i in range(5):
			if state.counts[i]>0:world.dropped_items.spawn_item(state.ids[i],state.counts[i],world.ground.to_global(world.ground.map_to_local(cell)),Vector2.ZERO,state.durability[i],state.tags[i])
		states.erase(cell)
func can_brew(state: BrewingState) -> bool:
	if state.counts[3]<=0:return false
	for i in range(3):
		if state.counts[i]==1 and BrewingData.result(state.ids[i],state.ids[3])!=0:return true
	return false
func tick(state: BrewingState,delta: float) -> void:
	var remaining: float=delta
	for event in range(128):
		if remaining<=.000001:return
		if state.fuel<=0 and state.counts[4]>0 and state.ids[4]==BlockDatabase.id_for(str(BrewingData.DATA.fuel)):
			state.fuel=int(BrewingData.DATA.fuel_uses);state.remove_from_slot(4,1)
		if state.remaining>0:
			if state.ingredient!=state.ids[3] or not can_brew(state):state.remaining=0;state.ingredient=0;return
		else:
			if state.fuel<=0 or not can_brew(state):return
			state.fuel-=1;state.remaining=float(BrewingData.DATA.seconds);state.ingredient=state.ids[3]
		var step: float=minf(remaining,state.remaining);remaining-=step;state.remaining-=step
		if state.remaining<=.000001:
			for i in range(3):
				var output: int=BrewingData.result(state.ids[i],state.ids[3]) if state.counts[i]==1 else 0
				if output>0:state.set_stack(i,{"id":output,"count":1,"tags":state.tags[i]})
			state.remove_from_slot(3,1);state.remaining=0;state.ingredient=0;state.changed.emit()
func _process(delta: float) -> void:
	for cell in states:
		if world.chunks.is_cell_loaded(cell):tick(states[cell],delta)
func use(cell: Vector2i) -> bool:
	if not is_stand(world.get_block(cell)) or not world.cell_is_reachable(cell):return false
	world.inventory_screen.set_open(false);world.storage_screen.set_open(false);world.upgrade_screen.set_open(false)
	world.furnace_screen.open_brewing(cell,self);return true
func snapshot() -> Array:
	var records: Array=[]
	for cell in states:
		var state: BrewingState=states[cell];var slots: Array=[]
		for i in range(5):slots.append({"item":str(BlockDatabase.BLOCKS[state.ids[i]].key) if state.ids[i]!=0 else "air","count":state.counts[i],"durability":state.durability[i],"tags":state.tags[i].duplicate(true)})
		records.append({"cell":[cell.x,cell.y],"slots":slots,"fuel":state.fuel,"remaining":state.remaining,"ingredient":str(BlockDatabase.BLOCKS[state.ingredient].key) if state.ingredient>0 else "air"})
	return records
func restore(records: Array) -> void:
	states.clear()
	for record in records:
		var at:=Vector2i(record.cell[0],record.cell[1])
		if not is_stand(world.get_block(at)):continue
		var state: BrewingState=state_at(at);state.fuel=int(record.fuel);state.remaining=float(record.remaining);state.ingredient=BlockDatabase.id_for(record.ingredient)
		for i in range(5):
			var stack: Dictionary=record.slots[i];state.set_stack(i,{"id":BlockDatabase.id_for(stack.item),"count":int(stack.count),"durability":int(stack.get("durability",0)),"tags":stack.get("tags",{})})
static func valid(records: Variant,store: RefCounted) -> bool:
	if not records is Array or records.size()>100000:return false
	var seen: Dictionary={}
	for record in records:
		if not record is Dictionary or not ContentCatalog._vector(record.get("cell"),2,-10000000,10000000,true) or not record.get("slots") is Array or record.slots.size()!=5 or not ContentCatalog._number(record.get("fuel"),0,float(BrewingData.DATA.fuel_uses),true) or not ContentCatalog._number(record.get("remaining"),0,float(BrewingData.DATA.seconds)) or not record.get("ingredient") is String:return false
		var cell:=Vector2i(record.cell[0],record.cell[1])
		if seen.has(cell):return false
		seen[cell]=true
		var found: bool=record.ingredient=="air"
		for item in BlockDatabase.BLOCKS.values():
			if item.key==record.ingredient:found=true;break
		if not found:return false
		for i in range(5):
			if not store._valid_stack(record.slots[i]):return false
			if i<3 and int(record.slots[i].count)>1:return false
	return true
