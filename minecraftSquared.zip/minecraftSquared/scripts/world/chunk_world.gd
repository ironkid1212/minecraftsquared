class_name ChunkWorld
extends RefCounted

signal fluid_changed(cell: Vector2i)
signal changed
signal cell_changed(cell: Vector2i, old_id: int, new_id: int)

const CHUNK_SIZE: int = 32
const MIN_WORLD_Y: int = -24
var dimension: String="overworld"
var nether_generation: Dictionary={}
var nether:=NetherGenerator.new()
var min_world_y: int = MIN_WORLD_Y
var structures:=StructureGenerator.new()
var strongholds:=StrongholdGenerator.new()
var lush:=LushCaveGenerator.new()
var geology := GeologyGenerator.new()
var colors := BiomeColors.new()
var biomes: BiomeGenerator
var vegetation: VegetationGenerator
var fluid_generation := FluidGeneration.new()

var config: TerrainSettings = TerrainSettings.new()
var tree_config: TreeSettings = TreeSettings.new()
var update_config: WorldUpdateSettings = WorldUpdateSettings.new()
var surface_id: int = BlockDatabase.ID.GRASS
var soil_id: int = BlockDatabase.ID.DIRT
var rock_id: int = BlockDatabase.ID.STONE
var load_radius := Vector2i(2, 1)
var ground: TileMapLayer
var source_id: int
var noise: FastNoiseLite
var world_depth: int
var surface_level: int
var hill_height: int
var dirt_depth: int
var loaded_chunks: Dictionary = {}
var visual_versions: Dictionary = {}
var _visual_serial: int = 0
var edits: Dictionary = {}
var waterlogged: Dictionary = {}
var farm_moisture: Dictionary = {}
var storage_pairs: Dictionary={}
## Support direction for each placed torch: down/left/right or zero for background.
var torch_mounts: Dictionary = {}
# Cached IDs avoid regenerating noise during lighting and neighbor queries.
var _block_cache: Dictionary = {}
var _surface_cache: Dictionary = {}
var _pending: Array[Vector2i] = []
var _building_chunk := Vector2i.ZERO
var _building_data := PackedInt32Array()
var _building_column: int = 0
var _drawing_chunk := Vector2i.ZERO
var _drawing_column: int = 0
var _drawing_active: bool = false
var last_center := Vector2i.ZERO
var has_center: bool = false

var gravel_noise: FastNoiseLite
var gravel_id: int = 0
var region_noise: FastNoiseLite
var plains_noise: FastNoiseLite
var mountain_noise: FastNoiseLite
var caves := CaveGenerator.new()
var trees := TreeGenerator.new()
var log_leaf_overlay: TileMapLayer
var background_walls: TileMapLayer
var platforms: TileMapLayer


func setup(layer: TileMapLayer, atlas_id: int, terrain_noise: FastNoiseLite,
		depth: int, surface: int, hills: int, dirt: int, settings: GameSettings = null) -> void:
	if settings != null:
		config = settings.terrain
		tree_config = settings.tree
		update_config = settings.world_updates
	load_radius = config.load_radius.max(Vector2i.ONE)
	surface_id = BlockDatabase.id_for(config.surface_block)
	soil_id = BlockDatabase.id_for(config.soil_block)
	rock_id = BlockDatabase.id_for(config.rock_block)
	gravel_noise = create_noise(terrain_noise.seed + 7171, config.gravel_frequency, 2) if not config.modern_generation and config.gravel_enabled else null
	gravel_id = BlockDatabase.id_for(config.gravel_block) if config.gravel_enabled else 0
	ground = layer
	source_id = atlas_id
	noise = terrain_noise
	# This cave layout needs room for shallow and deep systems.
	world_depth = config.top_y - config.bottom_y + 1 if config.modern_generation else maxi(depth, 96)
	min_world_y = 0 if config.modern_generation else MIN_WORLD_Y
	if dimension=="nether":
		world_depth=128;min_world_y=0;nether.setup(noise.seed,nether_generation)
	farm_moisture.clear();storage_pairs.clear()
	geology.setup(noise.seed, config)
	fluid_generation.setup(noise.seed, settings.fluid if settings != null else FluidSettings.new())
	biomes = null
	vegetation = null
	if dimension=="overworld" and config.modern_generation and config.biome_generation:
		biomes = BiomeGenerator.new()
		if not biomes.setup(noise.seed, config): return
		vegetation = VegetationGenerator.new()
		vegetation.setup(noise.seed, biomes)
	surface_level = surface
	hill_height = hills
	dirt_depth = dirt
	region_noise = null
	plains_noise = null
	mountain_noise = null
	if biomes == null:
		region_noise = create_noise(noise.seed + 101, config.region_frequency, 2)
		plains_noise = create_noise(noise.seed + 202, config.plains_frequency, 2)
		mountain_noise = create_noise(noise.seed + 303, config.mountain_frequency, 3)
	caves.setup(noise.seed, world_depth, settings.cave if settings != null else null, config.modern_generation)
	trees.setup(noise.seed, tree_config, biomes)
	structures.setup(self);strongholds.setup(self);lush.setup(self)
	ground.clear()
	torch_mounts.clear()
	_setup_platforms()
	# A visual-only layer above the block tiles, using the same coordinates.
	log_leaf_overlay = ground.get_node_or_null("LogLeafOverlay") as TileMapLayer
	if log_leaf_overlay == null:
		log_leaf_overlay = TileMapLayer.new()
		log_leaf_overlay.name = "LogLeafOverlay"
		ground.add_child(log_leaf_overlay)
	log_leaf_overlay.tile_set = ground.tile_set
	log_leaf_overlay.collision_enabled = false
	log_leaf_overlay.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	log_leaf_overlay.clear()
	background_walls = ground.get_node_or_null("BackgroundWalls") as TileMapLayer
	if background_walls == null:
		background_walls = TileMapLayer.new()
		background_walls.name = "BackgroundWalls"
		ground.add_child(background_walls)
	background_walls.tile_set = ground.tile_set
	background_walls.collision_enabled = false
	background_walls.z_index = -1
	background_walls.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	background_walls.modulate = settings.lighting.wall_tint if settings != null else LightingSettings.new().wall_tint
	background_walls.clear()
	_block_cache.clear()
	_surface_cache.clear()
	_pending.clear()
	_building_data.clear()
	_building_column = 0
	loaded_chunks.clear()
	visual_versions.clear()
	_drawing_active = false
	edits.clear()
	waterlogged.clear()
	has_center = false


func create_noise(noise_seed: int, frequency: float, octaves: int) -> FastNoiseLite:
	var result := FastNoiseLite.new()
	result.seed = noise_seed
	result.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	result.frequency = frequency
	result.fractal_type = FastNoiseLite.FRACTAL_FBM
	result.fractal_octaves = octaves
	return result


func cell_to_chunk(cell: Vector2i) -> Vector2i:
	return Vector2i(floori(float(cell.x) / CHUNK_SIZE), floori(float(cell.y) / CHUNK_SIZE))


func is_cell_loaded(cell: Vector2i) -> bool:
	return cell.y >= min_world_y and cell.y < world_depth and loaded_chunks.has(cell_to_chunk(cell))


func get_surface_y(x: int) -> int:
	if dimension=="nether":return int(nether.column(x).floor)
	var base: int = get_base_surface_y(x)
	return fluid_generation.surface_y(x,base,get_base_surface_y) if fluid_generation.settings != null else base

func get_base_surface_y(x: int) -> int:
	if dimension=="nether":return int(nether.column(x).floor)
	if _surface_cache.has(x):
		return _surface_cache[x]
	if biomes != null:
		var row: int = int(biomes.column(x)["surface"])
		_surface_cache[x] = row
		return row
	var sample_x: float = float(x)
	var region: float = region_noise.get_noise_1d(sample_x)
	var plains_y: float = surface_level + plains_noise.get_noise_1d(sample_x) * hill_height * 0.35
	var hills_y: float = surface_level + noise.get_noise_1d(sample_x) * hill_height * 1.8
	var mountains_y: float = (surface_level
		- absf(mountain_noise.get_noise_1d(sample_x)) * hill_height * 2.0
		+ noise.get_noise_1d(sample_x) * hill_height * 0.45)
	var height: float = lerpf(plains_y, hills_y, smoothstep(-0.3, 0.1, region))
	height = lerpf(height, mountains_y, smoothstep(0.15, 0.55, region))
	if config.modern_generation:
		# Average a broad profile rather than amplifying high-frequency ridges.
		# Sampling absolute X keeps the same slopes across chunk boundaries.
		var total: float = 0.0
		var weight_sum: float = 0.0
		for offset in range(-config.surface_smoothing_radius, config.surface_smoothing_radius + 1):
			var weight: float = config.surface_smoothing_radius + 1 - absi(offset)
			total += _modern_height(sample_x + offset) * weight
			weight_sum += weight
		height = total / weight_sum
	var result: int = clampi(roundi(height), 6, world_depth - 24)
	_surface_cache[x] = result
	return result

func _modern_height(x: float) -> float:
	var region: float = region_noise.get_noise_1d(x)
	var mountain_weight: float = smoothstep(config.mountain_start, config.mountain_full, region)
	var broad_shape: float = 0.8 + mountain_noise.get_noise_1d(x) * 0.2
	var rise: float = mountain_weight * broad_shape * config.mountain_height
	return surface_level + plains_noise.get_noise_1d(x) * hill_height - rise


func get_natural_block(cell: Vector2i, surface_y: int) -> int:
	if dimension=="nether":return nether.block_at(cell)
	if cell.y < min_world_y or cell.y >= world_depth:
		return BlockDatabase.ID.AIR
	if config.modern_generation and geology.is_bedrock(cell): return BlockDatabase.id_for("bedrock")
	if strongholds.enabled():
		var stronghold: int=strongholds.block_at(cell)
		if stronghold>=0:return stronghold
	if cell.y>=surface_y+8 and config.structures_enabled:
		var structure_block: int=structures.block_at(cell)
		if structure_block>=0:return structure_block
	if fluid_generation.surface_water(cell,surface_y,get_base_surface_y):
		if biomes!=null and biomes.data["biomes"][biomes.column(cell.x)["biome"]].get("color_climate",{}).get("snow",false) and not fluid_generation.surface_water(cell+Vector2i.UP,surface_y,get_base_surface_y):return BlockDatabase.id_for("ice")
		return fluid_generation.water_id
	if cell.y < surface_y:
		var cane: int=fluid_generation.cane_height(cell.x,get_base_surface_y)
		if cane>0 and cell.y>=surface_y-cane: return BlockDatabase.id_for("sugar_cane")
		var tree: int = _tree_block(cell)
		if tree != 0: return tree
		if fluid_generation.is_shore(cell.x,get_base_surface_y): return 0
		if vegetation != null and cell.y >= surface_y - 3 and not caves.is_cave(Vector2i(cell.x, surface_y), get_surface_y):
			return 0 if fluid_generation.surface_water(Vector2i(cell.x,surface_y-1),surface_y,get_base_surface_y) else vegetation.block_at(cell, surface_y, _tree_block)
		return 0
	if fluid_generation.is_shore(cell.x,get_base_surface_y) and cell.y < surface_y+fluid_generation.settings.shore_depth: return BlockDatabase.id_for("sand")
	var aquifer: int = fluid_generation.underground(cell,get_base_surface_y,world_depth)
	if aquifer >= 0: return aquifer
	if config.lush_caves_enabled:
		var lush_block: int=lush.block_at(cell)
		if lush_block>=0:return lush_block
	# Check caves before grass/dirt so dedicated entrances can cut the surface.
	if caves.is_cave(cell, get_surface_y):
		if fluid_generation.settings.generation_enabled and config.modern_generation and world_y(cell) <= fluid_generation.settings.lava_level: return fluid_generation.lava_id
		return BlockDatabase.ID.AIR
	if cell.y < surface_y+fluid_generation.settings.lakebed_depth and fluid_generation.surface_water(Vector2i(cell.x,surface_y-1),surface_y,get_base_surface_y):
		var patch: bool = sin(cell.x*.17+noise.seed*.001)>0.65
		return BlockDatabase.id_for(fluid_generation.settings.lakebed_patch if patch else fluid_generation.settings.lakebed_block)
	if cell.y == surface_y and biomes == null:
		return surface_id
	if config.modern_generation:
		var mountain: bool = biomes != null and bool(biomes.definition(cell.x).get("mountain", false))
		var material: int = geology.material(cell, surface_y, _exposed_to_air, mountain)
		return biomes.material(cell, surface_y, material) if biomes != null else material
	if cell.y <= surface_y + dirt_depth:
		return soil_id
	if gravel_id != 0 and cell.y >= surface_y + maxi(dirt_depth + 1, config.gravel_min_depth) and gravel_noise.get_noise_2d(cell.x, cell.y) > config.gravel_threshold:
		return gravel_id
	return rock_id

func _tree_block(cell: Vector2i) -> int:
	return trees.get_block(cell, get_surface_y, _can_grow_tree)

func natural_column_top(x: int) -> int:
	if dimension=="nether":return 0
	var surface: int = get_surface_y(x)
	var top: int = trees.column_top(x, surface, get_surface_y, _can_grow_tree)
	top=mini(top,surface-fluid_generation.cane_height(x,get_base_surface_y))
	var water: Dictionary = fluid_generation.profile(x,get_base_surface_y)
	if not water.is_empty() and fluid_generation.surface_water(Vector2i(x,surface-1),surface,get_base_surface_y):
		top = mini(top,int(water["line"]))
	if vegetation != null and not caves.is_cave(Vector2i(x, surface), get_surface_y):
		var entry: Dictionary = vegetation.profile(x, _tree_block)
		if not entry.is_empty(): top = mini(top, surface - int(entry["height"]))
	return top

func biome_name(x: int) -> String:
	if dimension=="nether":return str(WorldDimensions.DATA.biomes[nether.biome_at(x)].name)
	if biomes == null: return "Legacy terrain"
	return str(biomes.data["biomes"][biomes.column(x)["biome"]]["name"])

func find_spawn_surface(start_x: int) -> Vector2i:
	for offset in range(96):
		var x: int = start_x + offset
		var surface: int = get_surface_y(x)
		var id: int = get_natural_block(Vector2i(x, surface), surface)
		if biomes == null:
			if id == surface_id: return Vector2i(x, surface)
		elif bool(BlockDatabase.BLOCKS.get(id, {}).get("solid", false)):
			var clear: bool = true
			for above in [1, 2]:
				var head_id: int = get_natural_block(Vector2i(x, surface - above), surface)
				if BlockDatabase.BLOCKS.get(head_id, {}).get("solid", false) or BlockDatabase.has_tag(head_id,"fluid"): clear = false
			if clear: return Vector2i(x, surface)
	return Vector2i(start_x, get_surface_y(start_x))


func world_y(cell: Vector2i) -> int:
	return top_world_y()-cell.y

func top_world_y() -> int:
	return 127 if dimension=="nether" else config.top_y if config.modern_generation else 0

## Feet/entity coordinates and block labels share the active dimension origin.
func world_coordinates(local_pixels: Vector2) -> Vector2:
	return Vector2(local_pixels.x/16.0,top_world_y()+1.0-local_pixels.y/16.0)

func local_from_coordinates(coordinates: Vector2) -> Vector2:
	return Vector2(coordinates.x*16.0,(top_world_y()+1.0-coordinates.y)*16.0)

func cell_from_coordinates(coordinates: Vector2i) -> Vector2i:
	return Vector2i(coordinates.x,top_world_y()-coordinates.y)

func _exposed_to_air(cell: Vector2i) -> bool:
	for offset in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
		var neighbor: Vector2i = cell + offset
		if config.structures_enabled and structures.block_at(neighbor)==0:return true
		if neighbor.y < get_surface_y(neighbor.x) or caves.is_cave(neighbor, get_surface_y): return true
	return false

func _can_grow_tree(x: int) -> bool:
	var surface_y: int = get_surface_y(x)
	if fluid_generation.surface_water(Vector2i(x,surface_y-1),surface_y,get_base_surface_y): return false
	if fluid_generation.is_shore(x,get_base_surface_y): return false
	# Don't grow over cave entrances or on the edge of steep steps.
	if caves.is_cave(Vector2i(x, surface_y), get_surface_y):
		return false
	return (absi(get_surface_y(x - 1) - surface_y) <= 1
		and absi(get_surface_y(x + 1) - surface_y) <= 1)


func get_block(cell: Vector2i) -> int:
	if cell.y < min_world_y or cell.y >= world_depth:
		return BlockDatabase.ID.AIR
	var chunk: Vector2i = cell_to_chunk(cell)
	if _block_cache.has(chunk):
		var local_cell: Vector2i = cell - chunk * CHUNK_SIZE
		return _block_cache[chunk][local_cell.y * CHUNK_SIZE + local_cell.x]
	if edits.has(cell):
		return edits[cell]
	return get_natural_block(cell, get_surface_y(cell.x))


func set_block(cell: Vector2i, block_id: int) -> void:
	if not is_cell_loaded(cell):
		return
	if block_id != BlockDatabase.ID.AIR and not BlockDatabase.BLOCKS.has(block_id):
		push_error("Unknown block ID: %s" % block_id)
		return
	var old_id: int = get_block(cell)
	var was_logged: bool = waterlogged.has(cell)
	var can_log: bool = bool(BlockDatabase.BLOCKS.get(block_id,{}).get("waterloggable",false))
	if block_id == 0 and was_logged: block_id = BlockDatabase.id_for("water")
	var log_after: bool = can_log and (was_logged or BlockDatabase.has_tag(old_id,"water"))
	if log_after: waterlogged[cell] = true
	else: waterlogged.erase(cell)
	if old_id == block_id:
		return
	var natural_id: int = get_natural_block(cell, get_surface_y(cell.x))
	if block_id == natural_id:
		edits.erase(cell)
	else:
		edits[cell] = block_id
	var chunk: Vector2i = cell_to_chunk(cell)
	var data: PackedInt32Array = _block_cache[chunk]
	var local_cell: Vector2i = cell - chunk * CHUNK_SIZE
	data[local_cell.y * CHUNK_SIZE + local_cell.x] = block_id
	_block_cache[chunk] = data
	torch_mounts.erase(cell)
	draw_block(cell, block_id)
	# Rails and their barrier change immediately on either side, including seams.
	for offset in [Vector2i.LEFT,Vector2i.RIGHT]:
		var neighbor: Vector2i=cell+offset
		if _available_for_drawing(neighbor) and BlockDatabase.BLOCKS.get(get_block(neighbor),{}).has("fence"):draw_block(neighbor,get_block(neighbor))
	# Covering or uncovering the cell also changes the platform directly below.
	_refresh_platform(cell + Vector2i.DOWN)
	# Nearby canopy edits may expose or cover a log.
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			_refresh_log_overlay(cell + Vector2i(dx, dy))
			mark_visual_dirty(cell + Vector2i(dx, dy))
	cell_changed.emit(cell, old_id, block_id)
	if was_logged != log_after: fluid_changed.emit(cell)

func mark_visual_dirty(cell: Vector2i) -> void:
	var chunk: Vector2i = cell_to_chunk(cell)
	if not loaded_chunks.has(chunk): return
	_visual_serial += 1
	visual_versions[chunk] = _visual_serial


func get_wall_block(cell: Vector2i) -> int:
	if dimension=="nether":return nether.wall_at(cell)
	var stronghold: int=strongholds.wall_at(cell)
	if stronghold>=0:return stronghold
	if cell.y < 0 or cell.y >= world_depth:
		return BlockDatabase.ID.AIR
	var surface_y: int = get_surface_y(cell.x)
	if cell.y < surface_y + 2:
		return BlockDatabase.ID.AIR
	if config.modern_generation:
		var host_id: int = geology.host(cell, surface_y)
		return biomes.material(cell, surface_y, host_id) if biomes != null else host_id
	if cell.y <= surface_y + dirt_depth + 4:
		return soil_id
	return rock_id


func has_background_wall(cell: Vector2i) -> bool:
	return get_wall_block(cell) != BlockDatabase.ID.AIR


func _draw_background_wall(cell: Vector2i) -> void:
	var foreground: int = get_block(cell)
	if foreground != BlockDatabase.ID.AIR and BlockDatabase.BLOCKS[foreground].get("occludes_background", false):
		background_walls.erase_cell(cell)
		return
	var wall_id: int = get_wall_block(cell)
	if wall_id == BlockDatabase.ID.AIR:
		background_walls.erase_cell(cell)
		return
	var coordinates: Vector2i = BlockDatabase.BLOCKS[wall_id]["atlas"]
	background_walls.set_cell(cell, source_id, coordinates, BlockDatabase.BLOCKS[wall_id]["alternative_tile"])


func draw_block(cell: Vector2i, block_id: int) -> void:
	_refresh_platform(cell)
	_draw_background_wall(cell)
	log_leaf_overlay.erase_cell(cell)
	if block_id == BlockDatabase.ID.AIR or BlockDatabase.has_tag(block_id,"fluid"):
		ground.erase_cell(cell)
		return
	var coordinates: Vector2i = BlockDatabase.BLOCKS[block_id]["atlas"]
	var entry: Dictionary=BlockDatabase.BLOCKS[block_id]
	if entry.has("fence"):
		var variant: Dictionary=entry.fence_variants[FenceConnections.mask(self,cell,entry)]
		ground.set_cell(cell,source_id,variant.coords,variant.alternative)
	else:ground.set_cell(cell, source_id, coordinates, entry["alternative_tile"])
	_refresh_log_overlay(cell)


func should_overlay_log(cell: Vector2i) -> bool:
	if not trees.is_log(get_block(cell)):
		return false
	if not trees.has_leaf_overlay(cell, get_surface_y, _can_grow_tree):
		return false
	# Only show foliage while real neighboring leaves still exist.
	var leaf_neighbors: int = 0
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			if trees.is_leaf(get_block(cell + Vector2i(dx, dy))):
				leaf_neighbors += 1
	return leaf_neighbors >= 1


func _refresh_log_overlay(cell: Vector2i) -> void:
	if _available_for_drawing(cell) and should_overlay_log(cell):
		var leaf: int = trees.leaf_for_log(get_block(cell))
		var coordinates: Vector2i = BlockDatabase.BLOCKS[leaf]["atlas"]
		log_leaf_overlay.set_cell(cell, source_id, coordinates, BlockDatabase.BLOCKS[leaf]["alternative_tile"])
	else:
		log_leaf_overlay.erase_cell(cell)


func update_around(global_position: Vector2, incremental: bool = false) -> void:
	var player_cell: Vector2i = ground.local_to_map(ground.to_local(global_position))
	player_cell.y = clampi(player_cell.y, min_world_y, world_depth - 1)
	var center: Vector2i = cell_to_chunk(player_cell)
	# Crossing a border during a jump must not repeatedly unload/reload both sides.
	if incremental and has_center and Rect2i(last_center * CHUNK_SIZE - Vector2i(8, 8), Vector2i(48, 48)).has_point(player_cell):
		center = last_center
	var did_change: bool = false
	if not has_center or center != last_center:
		last_center = center
		has_center = true
		_building_data.clear()
		_building_column = 0
		var wanted: Dictionary = {}
		_pending.clear()
		for dx in range(-load_radius.x, load_radius.x + 1):
			for dy in range(-load_radius.y, load_radius.y + 1):
				var chunk: Vector2i = center + Vector2i(dx, dy)
				var first_y: int = chunk.y * CHUNK_SIZE
				if first_y >= world_depth or first_y + CHUNK_SIZE <= min_world_y:
					continue
				wanted[chunk] = true
				if not loaded_chunks.has(chunk):
					_pending.append(chunk)
		_pending.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
			return (a - center).length_squared() < (b - center).length_squared())
		if _drawing_active:
			if wanted.has(_drawing_chunk):
				_pending.erase(_drawing_chunk)
				_pending.push_front(_drawing_chunk)
			else: unload_chunk(_drawing_chunk)
		for chunk in loaded_chunks.keys():
			if not wanted.has(chunk):
				unload_chunk(chunk)
				did_change = true
		# Bound caches while keeping recently visited chunks for quick backtracking.
		for chunk in _block_cache.keys():
			if not loaded_chunks.has(chunk) and (absi(chunk.x - center.x) > load_radius.x + 3
				or absi(chunk.y - center.y) > load_radius.y + 2):
				_block_cache.erase(chunk)
		for x in _surface_cache.keys():
			if absi(x - player_cell.x) > 512:
				_surface_cache.erase(x)
		structures.retain(player_cell.x)
		fluid_generation.retain_near(player_cell.x)
		if biomes != null: biomes.retain_columns_near(player_cell.x)
		if vegetation != null: vegetation.retain_columns_near(player_cell.x)
		caves.retain_regions_near((center.x - load_radius.x) * CHUNK_SIZE,
			(center.x + load_radius.x + 1) * CHUNK_SIZE - 1)
		trees.retain_slots_near((center.x - load_radius.x) * CHUNK_SIZE,
			(center.x + load_radius.x + 1) * CHUNK_SIZE - 1)
	# During play, spread chunk generation over frames instead of one large burst.
	var start: int = Time.get_ticks_usec()
	while not _pending.is_empty():
		if incremental and not _prepare_pending_chunk(_pending[0], start):
			break
		if incremental:
			if not _draw_pending_chunk(_pending[0], start): break
			_pending.pop_front()
		else: load_chunk(_pending.pop_front())
		did_change = true
		if incremental and Time.get_ticks_usec() - start >= maxi(500, roundi(config.stream_budget_ms * 1000.0)):
			break
	if did_change:
		changed.emit()


func _prepare_pending_chunk(chunk: Vector2i, start: int) -> bool:
	if _block_cache.has(chunk):
		return true
	if _building_data.is_empty() or _building_chunk != chunk:
		_building_chunk = chunk
		_building_column = 0
		_building_data.resize(CHUNK_SIZE * CHUNK_SIZE)
	var origin: Vector2i = chunk * CHUNK_SIZE
	while _building_column < CHUNK_SIZE:
		var surface_y: int = get_surface_y(origin.x + _building_column)
		for local_y in range(CHUNK_SIZE):
			var cell: Vector2i = origin + Vector2i(_building_column, local_y)
			_building_data[local_y * CHUNK_SIZE + _building_column] = edits[cell] if edits.has(cell) else get_natural_block(cell, surface_y)
		_building_column += 1
		if _building_column < CHUNK_SIZE and Time.get_ticks_usec() - start >= maxi(500, roundi(config.stream_budget_ms * 1000.0)):
			return false
	_block_cache[chunk] = _building_data
	_building_data = PackedInt32Array()
	_building_column = 0
	return true

func _draw_pending_chunk(chunk: Vector2i, start: int) -> bool:
	if not _drawing_active:
		_drawing_chunk = chunk
		_drawing_column = 0
		_drawing_active = true
	var blocks: PackedInt32Array = _block_cache[chunk]
	var origin: Vector2i = chunk * CHUNK_SIZE
	while _drawing_column < CHUNK_SIZE:
		for y in range(CHUNK_SIZE):
			var cell: Vector2i = origin + Vector2i(_drawing_column, y)
			if cell.y >= min_world_y and cell.y < world_depth:
				draw_block(cell, blocks[y * CHUNK_SIZE + _drawing_column])
		_drawing_column += 1
		if _drawing_column < CHUNK_SIZE and Time.get_ticks_usec() - start >= maxi(500, roundi(config.stream_budget_ms * 1000.0)): return false
	loaded_chunks[chunk] = true
	_drawing_active = false
	mark_visual_dirty(origin)
	return true

func _available_for_drawing(cell: Vector2i) -> bool:
	return is_cell_loaded(cell) or (_drawing_active and cell.y >= min_world_y and cell.y < world_depth and cell_to_chunk(cell) == _drawing_chunk)


func load_chunk(chunk: Vector2i) -> void:
	if loaded_chunks.has(chunk):
		return
	var origin: Vector2i = chunk * CHUNK_SIZE
	if not _block_cache.has(chunk):
		var data := PackedInt32Array()
		data.resize(CHUNK_SIZE * CHUNK_SIZE)
		for local_x in range(CHUNK_SIZE):
			var surface_y: int = get_surface_y(origin.x + local_x)
			for local_y in range(CHUNK_SIZE):
				var cell: Vector2i = origin + Vector2i(local_x, local_y)
				data[local_y * CHUNK_SIZE + local_x] = edits[cell] if edits.has(cell) else get_natural_block(cell, surface_y)
		_block_cache[chunk] = data
	loaded_chunks[chunk] = true
	if _drawing_active and _drawing_chunk == chunk: _drawing_active = false
	var blocks: PackedInt32Array = _block_cache[chunk]
	for local_y in range(CHUNK_SIZE):
		for local_x in range(CHUNK_SIZE):
			var cell: Vector2i = origin + Vector2i(local_x, local_y)
			if cell.y >= min_world_y and cell.y < world_depth:
				draw_block(cell, blocks[local_y * CHUNK_SIZE + local_x])
	mark_visual_dirty(origin)


func unload_chunk(chunk: Vector2i) -> void:
	var origin: Vector2i = chunk * CHUNK_SIZE
	for local_x in range(CHUNK_SIZE):
		for local_y in range(CHUNK_SIZE):
			var cell: Vector2i = origin + Vector2i(local_x, local_y)
			ground.erase_cell(cell)
			log_leaf_overlay.erase_cell(cell)
			background_walls.erase_cell(cell)
			platforms.erase_cell(cell)
	loaded_chunks.erase(chunk)
	visual_versions.erase(chunk)
	if _drawing_active and _drawing_chunk == chunk: _drawing_active = false


func _setup_platforms() -> void:
	# Collision-only TileMap: one batched layer, not one node per plant/workstation/log.
	platforms = ground.get_node_or_null("Platforms") as TileMapLayer
	if platforms == null:
		platforms = TileMapLayer.new()
		platforms.name = "Platforms"
		ground.add_child(platforms)
	platforms.visible = false
	platforms.collision_enabled = true
	var tiles := TileSet.new()
	tiles.tile_size = ground.tile_set.tile_size
	tiles.add_physics_layer()
	tiles.set_physics_layer_collision_layer(0, 2)
	tiles.set_physics_layer_collision_mask(0, 0)
	var source := TileSetAtlasSource.new()
	source.texture = (ground.tile_set.get_source(source_id) as TileSetAtlasSource).texture
	source.texture_region_size = tiles.tile_size
	tiles.add_source(source, 0)
	var half: Vector2 = Vector2(tiles.tile_size) / 2.0
	for height in range(1, 17):
		var coords := Vector2i(height - 1, 0)
		source.create_tile(coords)
		var data: TileData = source.get_tile_data(coords, 0)
		var top: float = half.y - height
		data.set_collision_polygons_count(0, 1)
		data.set_collision_polygon_points(0, 0, PackedVector2Array([
			Vector2(-half.x, top), Vector2(half.x, top),
			Vector2(half.x, top + 2), Vector2(-half.x, top + 2)
		]))
		data.set_collision_polygon_one_way(0, 0, true)
		data.set_collision_polygon_one_way_margin(0, 0, 1.0)
	platforms.tile_set = tiles
	platforms.clear()


func has_platform_top(cell: Vector2i) -> bool:
	if not _available_for_drawing(cell):
		return false
	var id: int = get_block(cell)
	return (bool(BlockDatabase.BLOCKS.get(id, {}).get("platform", false))
		and (get_block(cell + Vector2i.UP) == BlockDatabase.ID.AIR or BlockDatabase.has_tag(get_block(cell+Vector2i.UP),"nether_portal") or BlockDatabase.has_tag(get_block(cell+Vector2i.UP),"fire")))


func _refresh_platform(cell: Vector2i) -> void:
	if platforms == null:
		return
	if has_platform_top(cell):
		var height: int = int(BlockDatabase.BLOCKS[get_block(cell)].get("platform_height",16))
		platforms.set_cell(cell, 0, Vector2i(height - 1, 0))
	else:
		platforms.erase_cell(cell)

func set_waterlogged(cell: Vector2i, enabled: bool) -> bool:
	if not is_cell_loaded(cell) or not BlockDatabase.BLOCKS.get(get_block(cell),{}).get("waterloggable",false): return false
	if waterlogged.has(cell)==enabled: return false
	if enabled: waterlogged[cell]=true
	else: waterlogged.erase(cell)
	mark_visual_dirty(cell)
	fluid_changed.emit(cell)
	return true

func light_absorption(cell: Vector2i) -> int:
	return maxi(int(BlockDatabase.BLOCKS.get(get_block(cell),{}).get("light_absorption",0)),1 if waterlogged.has(cell) else 0)

func biome_at_cell(cell: Vector2i) -> String:
	if dimension=="nether":return nether.biome_at(cell.x)
	if lush.is_lush(cell):return "lush_caves"
	return str(biomes.column(cell.x).biome) if biomes!=null else "legacy"
