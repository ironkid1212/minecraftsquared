class_name EndDragonRenderer
extends Node2D
const SKIN: Texture2D=preload("res://assets/environment/end/dragon.png")
const EYES: Texture2D=preload("res://assets/environment/end/dragon_eyes.png")
const DYING: Texture2D=preload("res://assets/environment/end/dragon_exploding.png")
const CRYSTAL: Texture2D=preload("res://assets/environment/end/end_crystal.png")
const BEAM: Texture2D=preload("res://assets/environment/end/end_crystal_beam.png")
const FIREBALL: Texture2D=preload("res://assets/environment/end/dragon_fireball.png")
const BREATH: Texture2D=preload("res://assets/environment/end/dragon_breath_particle.png")
var fight: EndFight
var age: float=0
var flap_clock: float=0
var voices: Array[AudioStreamPlayer2D]=[]
var streams: Dictionary={}
func setup(host: EndFight) -> void:
	fight=host;z_index=17;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	for key in ["flap","growl","death"]:streams[key]=load("res://assets/environment/end/sounds/"+key+".ogg")
	streams["shoot"]=load("res://assets/audio/mob/ghast/fireball4.ogg")
	for i in range(4):
		var voice:=AudioStreamPlayer2D.new();voice.max_distance=2200;voice.volume_db=-12;add_child(voice);voices.append(voice)
func sound(key: String,at: Vector2) -> void:
	var config: EffectsSettings=fight.world.effects_settings
	if not streams.has(key) or config.master_volume<=0 or config.entities_volume<=0:return
	var volume: float=-12+linear_to_db(config.master_volume*config.entities_volume)
	for voice in voices:
		if not voice.playing:voice.global_position=at;voice.volume_db=volume;voice.stream=streams[key];voice.play();return
func _process(dt: float) -> void:
	age+=dt;flap_clock+=dt
	if fight.present() and not fight.perched() and flap_clock>1.25:flap_clock=0;sound("flap",fight.position_world)
	if fight.world.is_end() or not fight.placed.is_empty():queue_redraw()
func quad(texture: Texture2D,points: PackedVector2Array,uv: PackedVector2Array,tint: Color) -> void:
	var normalized:=PackedVector2Array()
	for p in uv:normalized.append(p/Vector2(texture.get_size()))
	draw_polygon(points,PackedColorArray([tint]),normalized,texture)
func rect_piece(texture: Texture2D,source: Rect2,bounds: Rect2,tint: Color,flip: bool=false) -> void:
	var p: Vector2=bounds.position;var e: Vector2=bounds.end;var u: Vector2=source.position;var v: Vector2=source.end
	quad(texture,PackedVector2Array([p,Vector2(e.x,p.y),e,Vector2(p.x,e.y)]),PackedVector2Array([Vector2(v.x,u.y),u,Vector2(u.x,v.y),v]) if flip else PackedVector2Array([u,Vector2(v.x,u.y),v,Vector2(u.x,v.y)]),tint)
func _beam(from: Vector2,to: Vector2,view: Rect2) -> void:
	if not view.intersects(Rect2(from.min(to),from.distance_to(to)*Vector2.ONE).grow(8)):return
	var d: Vector2=to-from
	draw_set_transform(from,d.angle());draw_texture_rect_region(BEAM,Rect2(0,-2,d.length(),4),Rect2(0,0,BEAM.get_width(),BEAM.get_height()),Color(.9,.8,1,.85));draw_set_transform_matrix(Transform2D.IDENTITY)
func crystal_base(at: Vector2) -> void:
	# One side face, flush with the cap: no visible top or depth projection.
	draw_texture_rect_region(CRYSTAL,Rect2(at.floor()+Vector2(-12,8),Vector2(24,8)),Rect2(0,56,24,8))
func crystal_center(at: Vector2,key: int) -> Vector2:
	return (at+Vector2(0,-18-sin(age*3+float(key))*2)).floor()
func crystal(at: Vector2,key: int,base: bool) -> void:
	if base:crystal_base(at)
	var center: Vector2=crystal_center(at,key)
	# Flat sprite layers. Only the outer face is tilted within the screen plane.
	draw_set_transform(center,PI/4)
	draw_texture_rect_region(CRYSTAL,Rect2(-8,-8,16,16),Rect2(16,16,16,16))
	draw_set_transform(center)
	draw_texture_rect_region(CRYSTAL,Rect2(-6,-6,12,12),Rect2(16,16,16,16),Color(.8,.9,1))
	var glow: float=.9+.1*sin(age*2+float(key))
	draw_texture_rect_region(CRYSTAL,Rect2(-4,-4,8,8),Rect2(80,16,16,16),Color(1,glow,1))
	draw_set_transform_matrix(Transform2D.IDENTITY)
func _draw() -> void:
	if fight==null:return
	var view: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	if fight.world.is_end() and fight.healing>=0 and not fight.pose.is_empty():_beam(crystal_center(fight.crystal_point(fight.healing),fight.healing),fight.pose.head,view)
	if fight.world.is_end() and fight.phase=="respawning":
		var target: Vector2=fight.floor_point()-Vector2(0,128*16)
		if fight.phase_time>float(EndFight.RULES.respawn_prepare_seconds) and fight.restored_pillars<10:target=fight.crystal_point(fight.restored_pillars)
		for c in fight.placed:_beam(crystal_center(fight.placed_point(c.cell),int(c.id)),target,view)
	for c in fight.crystal_records():
		var at: Vector2=c.position
		if not view.grow(28).has_point(at) or not fight.world.chunks.is_cell_loaded(fight.world.mobs.cell(at)):continue
		crystal(at,int(c.key),bool(c.base))
	if fight.present() and not fight.pose.is_empty() and view.intersects(Rect2(fight.pose.bounds).grow(16)):
		var fraction: float=Engine.get_physics_interpolation_fraction();var offset: Vector2=fight.previous_position.lerp(fight.position_world,fraction)-fight.position_world
		var shift:=Transform2D(0,offset)
		var light: Color=fight.world.lighting.render_tint(fight.world.mobs.cell(fight.position_world))
		light=Color(.65,.65,.72) if light.r<.5 else light
		if fight.flash>0:light*=Color(1,.35,.35)
		for command in fight.pose.commands:
			var texture: Texture2D=EYES if command.texture=="eyes" else SKIN
			var tint: Color=Color.WHITE if command.texture=="eyes" else light*float(command.shade)
			draw_set_transform_matrix(shift*Transform2D(command.transform))
			if command.has("points"):
				var u: Vector2=Rect2(command.source).position;var v: Vector2=Rect2(command.source).end
				quad(texture,command.points,PackedVector2Array([u,Vector2(v.x,u.y),v,Vector2(u.x,v.y)]),tint)
			else:rect_piece(texture,command.source,command.bounds,tint,command.get("flip",false))
			if fight.phase=="dying" and command.texture!="eyes" and fmod(fight.death_time,.2)<.1 and command.has("bounds"):rect_piece(DYING,command.source,command.bounds,Color(1,1,1,clampf(fight.death_time/10,0,.8)),command.get("flip",false))
		draw_set_transform_matrix(Transform2D.IDENTITY)
		if fight.phase=="dying":
			for i in range(16):
				var angle: float=i*TAU/16+fight.death_time*.1;var extent: float=30+fight.death_time*12+sin(i*31.7)*20;var origin: Vector2=fight.position_world
				draw_colored_polygon(PackedVector2Array([origin,origin+Vector2.from_angle(angle-.035)*extent,origin+Vector2.from_angle(angle+.035)*extent]),Color(.7,.4,1,clampf(fight.death_time/10,0,.7)))
	draw_set_transform_matrix(Transform2D.IDENTITY)
	for ball in fight.projectiles:
		if view.grow(12).has_point(ball.position):draw_texture_rect(FIREBALL,Rect2(Vector2(ball.position)-Vector2(6,6),Vector2(12,12)),false)
	for cloud in fight.clouds:
		var at: Vector2=cloud.position;var radius: float=cloud.radius
		if not view.intersects(Rect2(at-Vector2(radius,24),Vector2(radius*2,32))):continue
		for i in range(mini(72,ceili(radius)*2)):
			var x: float=sin(i*127.1)*radius;var y: float=-absf(sin(i*43.8+age*1.5))*13
			var opacity: float=minf(1,float(cloud.age)*2)*minf(1,float(cloud.life)-float(cloud.age))*.65
			draw_texture_rect(BREATH,Rect2((at+Vector2(x,y)).floor()-Vector2(2,2),Vector2(5,5)),false,Color(.85,.25,1,opacity))
