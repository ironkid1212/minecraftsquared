class_name BiomeColors
extends RefCounted

## Vanilla temperature/downfall colormap lookup, averaged across horizontal
## biome neighbors for this 2D world. Birch keeps its fixed vanilla foliage tint.
var chunks: ChunkWorld
var settings: Dictionary = {}
var _maps: Dictionary = {}
var _cache: Dictionary = {}

func setup(world: ChunkWorld) -> void:
	chunks=world
	settings=DataFile.object_from(chunks.config.biomes_path).get("colors",{})
	if not settings.get("enabled",true): return
	if not ContentCatalog._number(settings.get("blend_radius",3),0,16,true):
		DataFile.fail("biomes.json colors: blend_radius must be 0–16.")
		return
	for kind in ["grass","foliage"]:
		var texture: Texture2D=load(str(settings.get(kind+"_colormap","")))
		if texture==null:
			DataFile.fail("Missing biome colormap: "+kind)
			continue
		var image: Image=texture.get_image()
		if image.get_size()!=Vector2i(256,256): DataFile.fail("Biome colormaps must be 256x256.")
		_maps[kind]=image

func sample(kind: String, temperature: float, downfall: float) -> Color:
	if not _maps.has(kind): return Color.WHITE
	var t: float=clampf(temperature,0,1)
	var h: float=clampf(downfall,0,1)*t
	return _maps[kind].get_pixel(int((1.0-t)*255),int((1.0-h)*255))

func color_at(x: int, kind: String) -> Color:
	if not settings.get("enabled",true) or kind.is_empty(): return Color.WHITE
	if kind=="spruce": return Color(str(settings.get("spruce_color","619961")))
	if kind=="birch": return Color(str(settings.get("birch_color","80a755")))
	var cache_key:=Vector2i(x,0 if kind=="grass" else 1 if kind=="foliage" else 2)
	if _cache.has(cache_key): return _cache[cache_key]
	var radius: int=int(settings.get("blend_radius",3))
	var color:=Color(0,0,0,0)
	for dx in range(-radius,radius+1):
		var key: String=str(chunks.biomes.column(x+dx)["biome"]) if chunks.biomes!=null else "plains"
		var definition: Dictionary=chunks.biomes.data["biomes"][key] if chunks.biomes!=null else {}
		var climate: Dictionary=definition.get("color_climate",{"temperature":.8,"downfall":.4,"water":"3f76e4"})
		var override: String=str(climate.get(kind,""))
		if kind=="grass" and climate.has("grass_alternate") and chunks.biomes!=null and chunks.biomes.sample("detail",x+dx)<-.1:override=str(climate["grass_alternate"])
		color+=Color(str(climate.get("water","3f76e4"))) if kind=="water" else Color(override) if not override.is_empty() else sample(kind,float(climate.get("temperature",.8)),float(climate.get("downfall",.4)))
	color/=float(radius*2+1)
	_cache[cache_key]=color
	return color

func retain(minimum_x: int, maximum_x: int) -> void:
	for key in _cache.keys():
		if key.x<minimum_x-32 or key.x>maximum_x+32: _cache.erase(key)
