class_name HeldLightField
extends RefCounted

## Visual-only, bounded light propagation. Permanent light and spawn rules stay separate.
static func build(lighting: WorldLighting,sources: Dictionary) -> Dictionary:
	var result: Dictionary={};var queue: Array[int]=[]
	var rect: Rect2i=lighting._rect;var width: int=rect.size.x
	if width<=0:return result
	for cell: Vector2i in sources:
		if not rect.has_point(cell):continue
		var at: Vector2i=cell-rect.position;var index: int=at.y*width+at.x
		if lighting._opaque[index]!=0:continue
		result[index]=maxi(int(result.get(index,0)),int(sources[cell]));queue.append(index)
	var cursor: int=0;var offsets: Array[int]=[-1,1,-width,width]
	while cursor<queue.size():
		var index: int=queue[cursor];cursor+=1
		var candidate: int=int(result[index])-1
		if candidate<=0:continue
		for offset in offsets:
			if offset==-1 and index%width==0 or offset==1 and index%width==width-1:continue
			var next: int=index+offset
			if next<0 or next>=width*rect.size.y:continue
			var cell: Vector2i=rect.position+Vector2i(next%width,next/width)
			if not lighting.chunks.is_cell_loaded(cell):continue
			var power: int=candidate-maxi(0,int(lighting._absorption[next])-1) if lighting._opaque[next]==0 else candidate
			if power<=int(result.get(next,0)):continue
			result[next]=power
			if lighting._opaque[next]==0:queue.append(next)
	# Shade the visible interiors of rock without transmitting through it into air.
	queue.clear();var depth: Dictionary={}
	for index: int in result:
		if lighting._opaque[index]!=0:queue.append(index);depth[index]=0
	cursor=0
	while cursor<queue.size():
		var index: int=queue[cursor];cursor+=1
		if int(depth[index])>=lighting.settings.solid_shade_depth:continue
		var candidate: int=int(result[index])-lighting.settings.solid_shade_loss
		if candidate<=0:continue
		for offset in offsets:
			if offset==-1 and index%width==0 or offset==1 and index%width==width-1:continue
			var next: int=index+offset
			if next<0 or next>=width*rect.size.y or lighting._opaque[next]==0 or int(result.get(next,0))>=candidate:continue
			result[next]=candidate;depth[next]=int(depth[index])+1;queue.append(next)
	return result
