class_name PixelGame
extends Control

@export var presentation: PixelPresentationSettings = preload("res://data/settings/pixel_presentation.tres")
@export var world_scene: PackedScene = preload("res://scenes/world.tscn")

var world: Node2D
var world_viewport: SubViewport
var display: TextureRect
var display_rect := Rect2()
var pixel_scale: int = 1
var camera: Camera2D
var _screen_mouse := Vector2.ZERO
var _has_pointer: bool = false
var _background: ColorRect

func _ready() -> void:
	# Screen-space UI must never receive another fractional root stretch.
	get_window().content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	process_priority = -100
	_background = ColorRect.new()
	_background.color = presentation.gutter_color
	_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_background)
	world_viewport = SubViewport.new()
	world_viewport.name = "WorldViewport"
	world_viewport.disable_3d = true
	world_viewport.world_2d = World2D.new()
	world_viewport.handle_input_locally = true
	world_viewport.gui_disable_input = false
	world_viewport.snap_2d_transforms_to_pixel = false
	world_viewport.snap_2d_vertices_to_pixel = false
	world_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(world_viewport)
	display = TextureRect.new()
	display.name = "WorldDisplay"
	display.texture = world_viewport.get_texture()
	display.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	display.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	display.stretch_mode = TextureRect.STRETCH_SCALE
	display.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(display)
	_resize()
	world = world_scene.instantiate()
	# Move UI before it enters the tree, so all its layout/input bindings use
	# the root viewport. World simulation and physics stay in the subviewport.
	var ui: CanvasLayer = world.get_node("UI")
	world.remove_child(ui)
	_clear_scene_owners(ui)
	ui.layer = 10
	add_child(ui)
	world.ui_layer = ui
	camera = world.get_node("Player/Camera2D")
	camera.zoom = Vector2.ONE
	camera.position_smoothing_enabled = false
	camera.top_level = true
	camera.position = (world.transform*world.get_node("Player").position).round()
	world_viewport.add_child(world)
	_update_camera()
	get_viewport().size_changed.connect(_resize)
	get_viewport().mouse_exited.connect(_pointer_exited)

func _clear_scene_owners(node: Node) -> void:
	node.owner = null
	for child in node.get_children():
		_clear_scene_owners(child)

func _resize() -> void:
	var window_size := Vector2i(get_viewport_rect().size)
	pixel_scale = presentation.scale_for(window_size)
	# Even dimensions give the camera an integer center; no half-pixel canvas shift.
	var logical := Vector2i(maxi(2,window_size.x/pixel_scale),maxi(2,window_size.y/pixel_scale))
	logical = Vector2i(maxi(2,logical.x/2*2),maxi(2,logical.y/2*2))
	world_viewport.size = logical
	display_rect = Rect2(((Vector2(window_size)-Vector2(logical*pixel_scale))/2).floor(),Vector2(logical*pixel_scale))
	display.position = display_rect.position
	display.size = display_rect.size
	_background.size = Vector2(window_size)
	_update_camera()
	_update_pointer()

func screen_to_world_viewport(point: Vector2) -> Vector2:
	return (point-display_rect.position)/pixel_scale

func world_viewport_to_screen(point: Vector2) -> Vector2:
	return display_rect.position+point*pixel_scale

func _update_camera() -> void:
	if is_instance_valid(camera) and is_instance_valid(world) and world.is_node_ready():
		world.player.update_render_camera()

func _update_pointer() -> void:
	if not is_instance_valid(world) or not world.is_node_ready():
		return
	var over_ui: bool = world.hotbar.visible and world.hotbar.get_global_rect().has_point(_screen_mouse)
	world.set_viewport_pointer(screen_to_world_viewport(_screen_mouse),_has_pointer and display_rect.has_point(_screen_mouse),over_ui)

func _pointer_exited() -> void:
	_has_pointer = false
	_update_pointer()

func _process(_delta: float) -> void:
	_update_camera()
	_update_pointer()

func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion or event is InputEventMouseButton:
		_screen_mouse = event.position
		_has_pointer = true
		_update_pointer()

func _unhandled_input(event: InputEvent) -> void:
	if not is_instance_valid(world) or not world.is_node_ready():
		return
	if world.chat != null and world.chat.is_open: return
	var forwarded: InputEvent = event.duplicate()
	if event is InputEventMouseMotion or event is InputEventMouseButton:
		if not display_rect.has_point(event.position) or world.pointer_over_ui:
			return
		forwarded.position = screen_to_world_viewport(event.position)
		forwarded.global_position = forwarded.position
		if event is InputEventMouseMotion:
			forwarded.relative = event.relative/pixel_scale
			forwarded.velocity = event.velocity/pixel_scale
	world_viewport.push_input(forwarded,true)
	get_viewport().set_input_as_handled()


