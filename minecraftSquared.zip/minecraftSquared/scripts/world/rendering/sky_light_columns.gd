class_name SkyLightColumns
extends RefCounted

## Direct sunlight depends on a column's blocks, not on camera position.
## Keep the exact result until that column's absorption changes.
var chunks: ChunkWorld
var _columns: Dictionary = {}
var _edit_tops: Dictionary = {}

func _init(world: ChunkWorld) -> void:
	chunks = world
	clear()

func clear() -> void:
	_columns.clear()
	_edit_tops.clear()
	for cell in chunks.edits:
		_edit_tops[cell.x] = mini(int(_edit_tops.get(cell.x, chunks.world_depth)), cell.y)

func invalidate(cell: Vector2i) -> void:
	_columns.erase(cell.x)
	# Keeping an old, higher top after removal is harmless: it only traces more air.
	_edit_tops[cell.x] = mini(int(_edit_tops.get(cell.x, chunks.world_depth)), cell.y)

func retain(minimum_x: int, maximum_x: int) -> void:
	for x in _columns.keys():
		if x < minimum_x - 32 or x > maximum_x + 32: _columns.erase(x)

func column(x: int) -> PackedByteArray:
	if _columns.has(x): return _columns[x]
	var result := PackedByteArray()
	result.resize(chunks.world_depth - chunks.min_world_y)
	result.fill(WorldLighting.LEVELS)
	var top: int = chunks.natural_column_top(x)
	top = maxi(chunks.min_world_y, mini(top, int(_edit_tops.get(x, top))))
	var beam: int = WorldLighting.LEVELS
	for y in range(top, chunks.world_depth):
		var id: int = chunks.get_block(Vector2i(x, y))
		var absorption: int = chunks.light_absorption(Vector2i(x,y))
		if absorption < 16: beam = maxi(0, beam - absorption)
		result[y - chunks.min_world_y] = beam
		if absorption >= 16 or beam <= 0:
			# The first opaque face receives light; the blocks below receive none.
			for below in range(y + 1 - chunks.min_world_y, result.size()): result[below] = 0
			break
	_columns[x] = result
	return result
