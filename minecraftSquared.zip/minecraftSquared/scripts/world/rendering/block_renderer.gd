class_name BlockRenderer
extends Node2D

# A few chunk meshes, with one constant color per tile. No lighting shader,
# per-block nodes, or TileMap physics rebuilds when brightness changes.
var chunks: ChunkWorld
var _source: TileSetAtlasSource
var _meshes: Dictionary = {}
var _states: Dictionary = {}
var _regions: Dictionary = {}
var _tints: Dictionary = {}
var mesh_updates: int = 0

func invalidate() -> void:
	_states.clear()


func setup(world: ChunkWorld) -> void:
	chunks = world
	chunks.colors.setup(chunks)
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	# The player camera aligns the shared canvas translation. Snapping each
	# CanvasItem again would round the player and terrain independently.
	get_viewport().snap_2d_transforms_to_pixel = false
	get_viewport().snap_2d_vertices_to_pixel = false
	if chunks.ground.tile_set.has_source(chunks.source_id):
		_source = chunks.ground.tile_set.get_source(chunks.source_id) as TileSetAtlasSource
	if _source == null:
		return
	# Keep the TileMap as the collision/data layer. Only replace its drawing.
	chunks.ground.self_modulate.a = 0.0
	chunks.background_walls.visible = false
	chunks.log_leaf_overlay.visible = false


func refresh(bounds: Rect2i, lighting: WorldLighting) -> void:
	if _source == null:
		return
	chunks.colors.retain(bounds.position.x,bounds.end.x)
	var wanted: Dictionary = {}
	for chunk in chunks.loaded_chunks:
		var part: Rect2i = bounds.intersection(Rect2i(chunk * ChunkWorld.CHUNK_SIZE,
			Vector2i.ONE * ChunkWorld.CHUNK_SIZE))
		if not part.has_area():
			continue
		wanted[chunk] = true
		var state := PackedInt64Array([part.position.x, part.position.y, part.size.x, part.size.y,
			roundi(chunks.update_config.wall_torch_angle * 1000), roundi(chunks.update_config.wall_torch_inset * 1000),
			int(chunks.visual_versions.get(chunk, 0))])
		var layers: Array[TileMapLayer] = [chunks.background_walls, chunks.ground, chunks.log_leaf_overlay]
		for y in range(part.position.y, part.end.y):
			for x in range(part.position.x, part.end.x):
				var cell := Vector2i(x, y)
				state.append(lighting.render_tint(cell).to_rgba32())
		if _states.has(chunk) and _states[chunk] == state:
			continue
		_states[chunk] = state
		_rebuild_chunk(chunk, part, layers, lighting)
	for chunk in _meshes.keys():
		if not wanted.has(chunk):
			_meshes[chunk].visible = false
			_meshes[chunk].queue_free()
			_meshes.erase(chunk)
			_states.erase(chunk)


func _rebuild_chunk(chunk: Vector2i, part: Rect2i, layers: Array[TileMapLayer], lighting: WorldLighting) -> void:
	var vertices := PackedVector2Array()
	var uvs := PackedVector2Array()
	var colors := PackedColorArray()
	var indices := PackedInt32Array()
	var size := Vector2(chunks.ground.tile_set.tile_size)
	for layer in layers:
		for y in range(part.position.y, part.end.y):
			for x in range(part.position.x, part.end.x):
				var cell := Vector2i(x, y)
				if layer == chunks.ground and (chunks.waterlogged.has(cell) or BlockDatabase.has_tag(chunks.get_block(cell),"nether_portal") or BlockDatabase.has_tag(chunks.get_block(cell),"fire")): continue
				var coords: Vector2i = layer.get_cell_atlas_coords(cell)
				if coords.x < 0:
					continue
				var base_coords: Vector2i=coords
				if layer==chunks.ground and chunks.storage_pairs.has(cell):
					var storage: Dictionary=BlockDatabase.BLOCKS.get(chunks.get_block(cell),{}).get("storage",{})
					var side: String="left_tile" if cell.x<chunks.storage_pairs[cell].x else "right_tile"
					if storage.has(side):
						var tile: Array=storage[side];coords=Vector2i(int(tile[0]),int(tile[1]))
				if layer==chunks.ground:
					var states: Array=BlockDatabase.BLOCKS.get(chunks.get_block(cell),{}).get("moisture_tiles",[])
					if not states.is_empty():
						var tile: Array=states[clampi(int(chunks.farm_moisture.get(cell,0)),0,7)]
						coords=Vector2i(int(tile[0]),int(tile[1]))
				if not _regions.has(coords):
					var pixel_origin: Vector2i = _source.margins + coords * (_source.texture_region_size + _source.separation)
					# Map all 16 source pixels to all 16 world pixels. Insetting
					# this span squeezes the texture and creates uneven pixel widths.
					# Nearest filtering and shared pixel-snapped transforms keep
					# neighboring blocks aligned without changing their UV span.
					_regions[coords] = Rect2(Vector2(pixel_origin) / _source.texture.get_size(),
						Vector2(_source.texture_region_size) / _source.texture.get_size())
				var alternative: int = layer.get_cell_alternative_tile(cell)
				var tint_key := Vector3i(base_coords.x,base_coords.y,alternative)
				if not _tints.has(tint_key):
					_tints[tint_key] = _source.get_tile_data(base_coords, alternative).modulate
				var uv: Rect2 = _regions[coords]
				var entry: Dictionary=BlockDatabase.BLOCKS.get(chunks.get_block(cell),{})
				if layer==chunks.log_leaf_overlay:
					entry=BlockDatabase.BLOCKS.get(chunks.trees.leaf_for_log(chunks.get_block(cell)),{})
				var mode: String=str(entry.get("biome_tint",""))
				var block_color: Color=chunks.colors.color_at(cell.x,mode) if not mode.is_empty() and layer!=chunks.background_walls else _tints[tint_key]
				var tint: Color = lighting.render_tint(cell) * block_color * layer.modulate
				var p: Vector2 = chunks.ground.map_to_local(cell) - size * 0.5
				if layer==chunks.ground:
					var offset: Array=entry.get("render_offset",[0,0])
					p+=Vector2(float(offset[0]),float(offset[1]))
				var first: int = vertices.size()
				if layer == chunks.ground and TorchMounting.is_attached(chunks.get_block(cell)):
					var config: WorldUpdateSettings = chunks.update_config
					vertices.append_array(TorchMounting.vertices(chunks, cell, chunks.torch_mounts.get(cell, TorchMounting.INVALID), size, config))
				else:
					vertices.append_array(PackedVector2Array([p, p + Vector2(size.x, 0), p + size, p + Vector2(0, size.y)]))
				uvs.append_array(PackedVector2Array([uv.position, uv.position + Vector2(uv.size.x, 0), uv.end, uv.position + Vector2(0, uv.size.y)]))
				colors.append_array(PackedColorArray([tint, tint, tint, tint]))
				indices.append_array(PackedInt32Array([first, first + 1, first + 2, first, first + 2, first + 3]))
				# Grass side tint affects the vegetation overlay, never the brown soil.
				if layer==chunks.ground and entry.has("biome_overlay"):
					var tile: Array=entry["biome_overlay"]
					var origin: Vector2=Vector2(_source.margins+Vector2i(int(tile[0]),int(tile[1]))*(_source.texture_region_size+_source.separation))/_source.texture.get_size()
					var span: Vector2=Vector2(_source.texture_region_size)/_source.texture.get_size()
					var grass: Color=lighting.render_tint(cell)*chunks.colors.color_at(cell.x,"grass")*layer.modulate
					first=vertices.size()
					vertices.append_array(PackedVector2Array([p,p+Vector2(size.x,0),p+size,p+Vector2(0,size.y)]))
					uvs.append_array(PackedVector2Array([origin,origin+Vector2(span.x,0),origin+span,origin+Vector2(0,span.y)]))
					colors.append_array(PackedColorArray([grass,grass,grass,grass]))
					indices.append_array(PackedInt32Array([first,first+1,first+2,first,first+2,first+3]))
	var instance: MeshInstance2D
	if _meshes.has(chunk):
		instance = _meshes[chunk]
	else:
		instance = MeshInstance2D.new()
		instance.name = "ShadedChunk_%s_%s" % [chunk.x, chunk.y]
		instance.texture = _source.texture
		add_child(instance)
		_meshes[chunk] = instance
	if vertices.is_empty():
		instance.mesh = null
		return
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	instance.mesh = mesh
	mesh_updates += 1
