class_name FluidRenderer
extends Node2D

var system: FluidSystem
var dirty: bool = true
var drawn_cells: int = 0
var cached_cells: Array[Vector2i] = []
var _textures: Dictionary = {}
var _frames: Dictionary = {}
var _bounds := Rect2i()
var _timer: float = 0
var _clock: float = 0
var _flames: Node2D
var _was_burning: bool = false
const FIRE: Texture2D = preload("res://assets/fluids/fire_0.png")

func setup(fluids: FluidSystem) -> void:
	system=fluids
	_flames=Node2D.new()
	_flames.z_index=21
	_flames.z_as_relative=false
	add_child(_flames)
	_flames.draw.connect(_draw_flames)
	var fire_animation: Dictionary=DataFile.object_from("res://assets/fluids/fire_0.png.mcmeta").get("animation",{})
	_frames["fire"]={"time":float(fire_animation.get("frametime",1))/20.0}
	z_index=6
	texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	for kind in ["water","lava"]:
		for mode in ["still","flow"]:
			var key: String=kind+mode
			var path: String=system.rules[kind][mode]
			var texture: Texture2D=load(path)
			_textures[key]=texture
			var metadata: Dictionary=DataFile.object_from(path+".mcmeta").get("animation",{})
			var frame_list: Array=metadata.get("frames",[])
			if frame_list.is_empty():
				for i in range(texture.get_height()/texture.get_width()): frame_list.append(i)
			_frames[key]={"time":float(metadata.get("frametime",1))/20.0,"frames":frame_list}

func _visible_bounds() -> Rect2i:
	var view: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	var start:=Vector2i(floori(view.position.x/16),floori(view.position.y/16))
	var end:=Vector2i(ceili(view.end.x/16),ceili(view.end.y/16))
	return Rect2i(start,end-start).grow(1)

func _process(delta: float) -> void:
	_clock+=delta
	if system.burning>0 or _was_burning: _flames.queue_redraw()
	_was_burning=system.burning>0
	_timer+=delta
	var bounds: Rect2i=_visible_bounds()
	if bounds!=_bounds: dirty=true
	if dirty:
		_bounds=bounds
		cached_cells.clear()
		# No offscreen fluid geometry, and no scan of unloaded terrain.
		for chunk in system.chunks.loaded_chunks:
			var part: Rect2i=bounds.intersection(Rect2i(chunk*32,Vector2i(32,32)))
			for y in range(part.position.y,part.end.y):
				for x in range(part.position.x,part.end.x):
					var cell:=Vector2i(x,y)
					if not system.kind_at(cell).is_empty(): cached_cells.append(cell)
		dirty=false
		queue_redraw()
	if _timer>=.05 and not cached_cells.is_empty():
		_timer=fmod(_timer,.05)
		queue_redraw()

func _height(cell: Vector2i, kind: String) -> float:
	if system.kind_at(cell)!=kind: return 0
	return system.height_at(cell)

func _draw() -> void:
	drawn_cells=0
	if system==null: return
	for kind in ["water","lava"]:
		var values: Array=system.rules[kind]["tint"]
		var base:=Color(values[0],values[1],values[2],values[3])
		for cell in cached_cells:
			if not system.chunks.is_cell_loaded(cell) or system.kind_at(cell)!=kind: continue
			var flowing: bool=system.level(cell)!=0
			var key: String=kind+("flow" if flowing else "still")
			var texture: Texture2D=_textures[key]
			var animation: Dictionary=_frames[key]
			var index: int=floori(_clock/float(animation["time"]))%animation["frames"].size()
			var frame: int=int(animation["frames"][index])
			var height: float=system.height_at(cell)
			var left: float=height
			var right: float=height
			if height<16:
				var neighbor: float=_height(cell+Vector2i.LEFT,kind)
				if neighbor>0 and neighbor<16: left=(height+neighbor)*.5
				neighbor=_height(cell+Vector2i.RIGHT,kind)
				if neighbor>0 and neighbor<16: right=(height+neighbor)*.5
			var p: Vector2=system.world.ground.map_to_local(cell)-Vector2(8,8)
			left=roundf(left)
			right=roundf(right)
			var points:=PackedVector2Array([p+Vector2(0,16-left),p+Vector2(16,16-right),p+Vector2(16,16),p+Vector2(0,16)])
			var frame_size: float=texture.get_width()
			var start: float=frame*frame_size/texture.get_height()
			var span: float=frame_size/texture.get_height()
			var u0: float=.25 if flowing else 0.0
			var u1: float=.75 if flowing else 1.0
			var bottom: float=start+span*(.75 if flowing else 1.0)
			var sample_span: float=span*(.5 if flowing else 1.0)
			var uvs:=PackedVector2Array([Vector2(u0,bottom-sample_span*left/16.0),Vector2(u1,bottom-sample_span*right/16.0),Vector2(u1,bottom),Vector2(u0,bottom)])
			var water_color: Color=system.chunks.colors.color_at(cell.x,"water")*Color(1,1,1,base.a) if kind=="water" else base
			var tint: Color=system.world.lighting.render_tint(cell)*water_color
			draw_polygon(points,PackedColorArray([tint]),uvs,texture)
			if system.chunks.waterlogged.has(cell):
				# The normal mesh skips this leaf: draw water behind its cutout once.
				var definition: Dictionary=BlockDatabase.BLOCKS[system.chunks.get_block(cell)]
				var source: TileSetAtlasSource=system.world.atlas_source
				# Use the committed tile state, including connected fence variants.
				var coords: Vector2i=system.world.ground.get_cell_atlas_coords(cell)
				var pixel: Vector2i=source.margins+coords*(source.texture_region_size+source.separation)
				draw_texture_rect_region(source.texture,Rect2(p,Vector2(16,16)),Rect2(Vector2(pixel),Vector2(16,16)),system.chunks.colors.color_at(cell.x,str(definition.get("biome_tint","")))*system.world.lighting.render_tint(cell))
			drawn_cells+=1

func _draw_flames() -> void:
	if system.burning<=0 or system.world.player.spectator or system.world.player.survival_dead: return
	var frame: int=floori(_clock/float(_frames["fire"]["time"]))%(FIRE.get_height()/FIRE.get_width())
	var point: Vector2=to_local(system.world.player.render_anchor()).round()
	_flames.draw_texture_rect_region(FIRE,Rect2(point-Vector2(8,17),Vector2(16,32)),Rect2(0,frame*16,16,16))
