class_name WorldLighting
extends Node2D

const LEVELS: int = 15


var settings: LightingSettings = LightingSettings.new()
var chunks: ChunkWorld
var player: Node2D
var _renderer: BlockRenderer
var _visual_dirty: bool = true
var _player_tint := Color.WHITE
var _sky: ColorRect
var _dirty: bool = true
var _rect := Rect2i()
var _opaque := PackedByteArray()
var _absorption := PackedByteArray()
var _sun := PackedByteArray()
var _fire := PackedByteArray()
var _levels := PackedByteArray()
var _colors := PackedColorArray()
var _sky_columns: SkyLightColumns
var _last_visual_bounds := Rect2i()
var _fullbright: bool = false
var daylight_factor: float = 1.0
var ambient_factor: float = 1.0
var simulation_rebuilds: int = 0
var color_updates: int = 0
var _shaded_sun := PackedByteArray()
var _shaded_fire := PackedByteArray()
var _ambient := PackedByteArray()
var _dynamic: Dictionary={}
var _dynamic_tints: Dictionary={}
var _dynamic_signature: Array=[]
var _dynamic_timer: float=0
var dynamic_rebuilds: int=0



func setup(world: ChunkWorld, character: Node2D, config: LightingSettings = null) -> void:
	settings = config if config != null else LightingSettings.new()
	chunks = world
	_sky_columns = SkyLightColumns.new(chunks)
	player = character
	chunks.changed.connect(_mark_dirty)
	chunks.cell_changed.connect(_on_cell_changed)
	chunks.fluid_changed.connect(_on_fluid_changed)
	var sky_layer := CanvasLayer.new()
	sky_layer.name = "SkyBackground"
	sky_layer.layer = -100
	add_child(sky_layer)
	_sky = ColorRect.new()
	_sky.color = settings.sky_color
	_sky.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sky_layer.add_child(_sky)
	_resize_sky()
	get_viewport().size_changed.connect(_resize_sky)

	_renderer = BlockRenderer.new()
	_renderer.name = "BlockRenderer"
	chunks.ground.add_child(_renderer)
	_renderer.setup(chunks)
	_player_tint = player.self_modulate
	_rebuild()


func _resize_sky() -> void:
	_sky.size = get_viewport_rect().size


func _mark_dirty() -> void:
	# Chunk residency does not change natural blocks or their light absorption.
	# Only newly exposed coverage needs a fresh light field.
	if _field_rect() != _rect: _dirty = true
	_visual_dirty = true


func _on_cell_changed(cell: Vector2i, old_id: int, new_id: int) -> void:
	if _last_visual_bounds.grow(1).has_point(cell): _visual_dirty = true
	var old_def: Dictionary = BlockDatabase.BLOCKS.get(old_id, {})
	var new_def: Dictionary = BlockDatabase.BLOCKS.get(new_id, {})
	if old_def.get("light_absorption", 0) != new_def.get("light_absorption", 0):
		_sky_columns.invalidate(cell)
	# An edited roof above the visible field can change an entire daylight shaft.
	if cell.x < _rect.position.x or cell.x >= _rect.end.x or cell.y >= _rect.end.y:
		return
	if (old_def.get("light_absorption", 0) != new_def.get("light_absorption", 0)
		or old_def.get("light_level", 0) != new_def.get("light_level", 0)):
		_dirty = true

func invalidate() -> void:
	# Bulk save restoration writes edits in unloaded chunks without cell signals.
	_sky_columns.clear()
	_renderer.invalidate()
	_dirty = true
	_visual_dirty = true


func _field_rect() -> Rect2i:
	var first: bool = true
	var minimum := Vector2i.ZERO
	var maximum := Vector2i.ZERO
	for chunk in chunks.loaded_chunks:
		if first:
			minimum = chunk
			maximum = chunk
			first = false
		else:
			minimum = minimum.min(chunk)
			maximum = maximum.max(chunk)
	var origin: Vector2i = minimum * ChunkWorld.CHUNK_SIZE
	var end: Vector2i = (maximum + Vector2i.ONE) * ChunkWorld.CHUNK_SIZE
	origin.y = maxi(origin.y, chunks.min_world_y)
	end.y = mini(end.y, chunks.world_depth)
	var bounds := Rect2i(origin, end - origin)
	# Keep a full light radius around the camera so offscreen torches can contribute.
	if get_viewport().get_camera_2d() != null:
		get_viewport().get_camera_2d().force_update_scroll()
		var visible: Rect2 = chunks.ground.get_global_transform_with_canvas().affine_inverse() * get_viewport_rect()
		var tile_size := Vector2(chunks.ground.tile_set.tile_size)
		var required_start := Vector2i(floori(visible.position.x / tile_size.x) - 16, floori(visible.position.y / tile_size.y) - 16)
		var required_end := Vector2i(ceili(visible.end.x / tile_size.x) + 16, ceili(visible.end.y / tile_size.y) + 16)
		var required: Rect2i = bounds.intersection(Rect2i(required_start, required_end - required_start))
		# A guard band avoids rebuilding the light simulation at every camera step.
		# Drawing still uses the much tighter visible rectangle below.
		if _rect.has_area() and _rect.encloses(required) and bounds.encloses(_rect): return _rect
		var start_cell := Vector2i(floori(visible.position.x / tile_size.x / 8.0) * 8 - 24,
			floori(visible.position.y / tile_size.y / 8.0) * 8 - 24)
		var end_cell := Vector2i(ceili(visible.end.x / tile_size.x / 8.0) * 8 + 24,
			ceili(visible.end.y / tile_size.y / 8.0) * 8 + 24)
		bounds = bounds.intersection(Rect2i(start_cell, end_cell - start_cell))
	return bounds


func _process(_delta: float) -> void:
	if chunks == null:
		return
	var fullbright: bool = bool(player.get("spectator"))
	if fullbright != _fullbright:
		_fullbright = fullbright
		_renderer.invalidate()
		_visual_dirty = true
	if _dirty or _field_rect() != _rect:
		_rebuild()
	else:
		_update_dynamic(_delta)
		if _visual_dirty or _visual_bounds() != _last_visual_bounds:_refresh_visuals()
	var cell: Vector2i = chunks.ground.local_to_map(chunks.ground.to_local(player.global_position))
	player.self_modulate = _player_tint * render_tint(cell)


func _refresh_visuals() -> void:
	_visual_dirty = false
	if _renderer == null:
		return
	_last_visual_bounds = _visual_bounds()
	_renderer.refresh(_last_visual_bounds, self)

func _visual_bounds() -> Rect2i:
	var bounds: Rect2i = _rect
	if get_viewport().get_camera_2d() != null:
		var visible: Rect2 = chunks.ground.get_global_transform_with_canvas().affine_inverse() * get_viewport_rect()
		var size := Vector2(chunks.ground.tile_set.tile_size)
		var start := Vector2i(floori(visible.position.x / size.x / 8.0) * 8 - 2,
			floori(visible.position.y / size.y / 8.0) * 8 - 2)
		var end := Vector2i(ceili(visible.end.x / size.x / 8.0) * 8 + 2,
			ceili(visible.end.y / size.y / 8.0) * 8 + 2)
		bounds = bounds.intersection(Rect2i(start, end - start))
	return bounds


func has_light_sample(cell: Vector2i) -> bool:
	return _rect.has_point(cell) and not _levels.is_empty()


func sample_light_level(cell: Vector2i) -> int:
	if not _rect.has_point(cell) or _levels.is_empty():
		return 0
	var local_cell: Vector2i = cell - _rect.position
	return _levels[local_cell.y * _rect.size.x + local_cell.x]


func render_tint(cell: Vector2i) -> Color:
	if bool(player.get("spectator")):return Color.WHITE
	if _rect.has_point(cell):
		var at: Vector2i=cell-_rect.position
		var index: int=at.y*_rect.size.x+at.x
		if _dynamic_tints.has(index):return _dynamic_tints[index]
	return sample_tint(cell)

func invalidate_dynamic() -> void:
	_dynamic_signature.clear();_dynamic_timer=0

func apply_dynamic_preferences() -> void:
	invalidate_dynamic()
	# Options run while the world is paused; keep the lighting preview responsive.
	_process(0)

func _update_dynamic(delta: float=0,force: bool=false) -> void:
	var options: Node=get_node_or_null("/root/GameOptions")
	var preferences: Dictionary=options.values if options!=null else {}
	var enabled: bool=bool(preferences.get("dynamic_lighting",true)) and not player.get("spectator") and not player.get("survival_dead")
	var intensity: float=float(preferences.get("dynamic_light_brightness",80))/80.0
	var sources: Dictionary={}
	if enabled:
		var main: PlayerPresentation=player.presentation
		for hand: PlayerPresentation in [main,main.offhand]:
			if hand==null:continue
			var power: int=roundi(float(BlockDatabase.BLOCKS.get(hand.held_id,{}).get("light_level",0))*intensity)
			if power<=0:continue
			var point: Vector2=player.global_position+Vector2(player.facing*5,-5)
			var cell: Vector2i=chunks.ground.local_to_map(chunks.ground.to_local(point))
			if _rect.has_point(cell):
				var at: Vector2i=cell-_rect.position
				if _opaque[at.y*_rect.size.x+at.x]!=0:cell=chunks.ground.local_to_map(chunks.ground.to_local(player.global_position))
			sources[cell]=maxi(power,int(sources.get(cell,0)))
	var signature: Array=[_rect,sources]
	if not force and signature==_dynamic_signature:return
	_dynamic_timer-=delta
	if not force and not sources.is_empty() and not _dynamic_signature.is_empty() and _dynamic_timer>0:return
	_dynamic_timer=[.05,.1,.2][clampi(int(preferences.get("dynamic_light_updates",2))-1,0,2)]
	_dynamic_signature=signature.duplicate(true)
	_dynamic=HeldLightField.build(self,sources) if not sources.is_empty() else {}
	dynamic_rebuilds+=1
	_recolor_dynamic()
	_visual_dirty=true

func _recolor_dynamic() -> void:
	_dynamic_tints.clear()
	for index: int in _dynamic:
		if index>=0 and index<_shaded_fire.size():_dynamic_tints[index]=_tint_for(index,maxf(_shaded_fire[index],_dynamic[index]))

func _tint_for(index: int,torch_level: float) -> Color:
	var ambient: float=maxf(roundi(settings.underground_ambient*LEVELS),(float(WorldDimensions.DATA.environment.ambient_level) if chunks.dimension=="nether" else _ambient[index]*ambient_factor))
	var daylight: float=maxf(_shaded_sun[index]*daylight_factor,ambient)
	var brightness: float=maxf(settings.minimum_brightness,pow(maxf(daylight,torch_level)/LEVELS,settings.brightness_curve))
	var tint:=Color(brightness,brightness,brightness,1)
	if torch_level>daylight:
		var warm: float=(torch_level-daylight)/maxf(1,torch_level)
		tint*=Color(lerpf(1,settings.torch_tint.r,warm),lerpf(1,settings.torch_tint.g,warm),lerpf(1,settings.torch_tint.b,warm),1)
	return tint


func sample_tint(cell: Vector2i) -> Color:
	if not _rect.has_point(cell) or _colors.is_empty():
		return Color(settings.minimum_brightness, settings.minimum_brightness, settings.minimum_brightness, 1.0)
	var local_cell: Vector2i = cell - _rect.position
	return _colors[local_cell.y * _rect.size.x + local_cell.x]


func _rebuild() -> void:
	simulation_rebuilds += 1
	_dirty = false
	if chunks.loaded_chunks.is_empty():
		_rect = Rect2i()
		_refresh_visuals()
		return
	_rect = _field_rect()
	if not _rect.has_area():
		_refresh_visuals()
		return
	var origin: Vector2i = _rect.position
	var end: Vector2i = _rect.end
	var count: int = _rect.size.x * _rect.size.y
	_absorption.resize(count)
	_absorption.fill(0)
	_opaque.resize(count)
	_opaque.fill(0)
	_sun.resize(count)
	_sun.fill(0)
	_fire.resize(count)
	_fire.fill(0)
	var sun_queue := PackedInt32Array()
	var fire_queue := PackedInt32Array()
	for local_y in range(_rect.size.y):
		for local_x in range(_rect.size.x):
			var cell: Vector2i = origin + Vector2i(local_x, local_y)
			var index: int = local_y * _rect.size.x + local_x
			var id: int = chunks.get_block(cell)
			if id == BlockDatabase.ID.AIR:
				continue
			var definition: Dictionary = BlockDatabase.BLOCKS[id]
			_absorption[index] = chunks.light_absorption(cell)
			_opaque[index] = 1 if _absorption[index] >= 16 else 0
			var emission: int = int(definition.get("light_level", 0))
			if emission > 0:
				_fire[index] = clampi(emission, 0, LEVELS)
				fire_queue.append(index)

	# Trace from real sky, not from the top of a deep loaded chunk.
	# Mined shafts can admit daylight; intact terrain above still blocks it.
	for local_x in range(_rect.size.x):
		var x: int = origin.x + local_x
		var column: PackedByteArray = _sky_columns.column(x)
		for y in range(origin.y, end.y):
			var index: int = (y - origin.y) * _rect.size.x + local_x
			_sun[index] = column[y - chunks.min_world_y]
			if _absorption[index] < 16 and _sun[index] > 0: sun_queue.append(index)
	_sky_columns.retain(origin.x, end.x)
	_sun = _spread(_sun, sun_queue)
	_fire = _spread(_fire, fire_queue)
	_shaded_sun = _shade_solids(_sun)
	_shaded_fire = _shade_solids(_fire)
	_ambient.resize(count)
	for local_x in range(_rect.size.x):
		var surface_y: int = chunks.get_surface_y(origin.x+local_x)
		for local_y in range(_rect.size.y):
			var index: int = local_y*_rect.size.x+local_x
			var depth: float = maxf(0,origin.y+local_y-surface_y)
			_ambient[index] = roundi(lerpf(settings.surface_ambient,settings.underground_ambient,smoothstep(0,settings.surface_fade_depth,depth))*LEVELS)
	_update_dynamic(0,true)
	_recolor()

func set_daylight(sky_factor: float, surface_factor: float, steps: int = 128) -> void:
	var sky_value: float = roundf(clampf(sky_factor,0,1)*steps)/steps
	var surface_value: float = roundf(clampf(surface_factor,0,1)*steps)/steps
	if is_equal_approx(daylight_factor,sky_value) and is_equal_approx(ambient_factor,surface_value): return
	daylight_factor = sky_value
	ambient_factor = surface_value
	if not _dirty and _shaded_sun.size() == _rect.size.x*_rect.size.y: _recolor()

func _recolor() -> void:
	# Reuse propagation/solid-shading fields. Time never rescans roofs or physics.
	var count: int = _shaded_sun.size()
	if count == 0: return
	color_updates += 1
	_levels.resize(count)
	_colors.resize(count)
	var floor_ambient: float = roundi(settings.underground_ambient*LEVELS)
	for index in range(count):
		var ambient: float = maxf(floor_ambient,(float(WorldDimensions.DATA.environment.ambient_level) if chunks.dimension=="nether" else _ambient[index]*ambient_factor))
		var daylight: float = maxf(_shaded_sun[index]*daylight_factor,ambient)
		var torch_level: float = _shaded_fire[index]
		var level: float = maxf(daylight,torch_level)
		_levels[index] = roundi(level)
		var brightness: float = maxf(settings.minimum_brightness,pow(level/LEVELS,settings.brightness_curve))
		var tint := Color(brightness,brightness,brightness,1)
		if torch_level > daylight:
			var warm: float = (torch_level-daylight)/maxf(1,torch_level)
			tint *= Color(lerpf(1,settings.torch_tint.r,warm),lerpf(1,settings.torch_tint.g,warm),lerpf(1,settings.torch_tint.b,warm),1)
		_colors[index] = tint
	_recolor_dynamic()
	_refresh_visuals()

func sample_survival_light_level(cell: Vector2i) -> int:
	# Plants should not die merely because the sun set; retain structural skylight.
	if not has_light_sample(cell): return -1
	var at: Vector2i = cell-_rect.position
	var index: int = at.y*_rect.size.x+at.x
	return maxi(_sun[index],_fire[index])


func _shade_solids(actual_light: PackedByteArray) -> PackedByteArray:
	# A side view exposes the inside of the rock. Fade its drawing beneath lit
	# faces without allowing that cosmetic light to illuminate air beyond walls.
	var result: PackedByteArray = actual_light.duplicate()
	if settings.solid_shade_depth <= 0:
		return result
	var count: int = result.size()
	var depth := PackedByteArray()
	depth.resize(count)
	depth.fill(255)
	var queue := PackedInt32Array()
	for index in range(count):
		if _opaque[index] != 0 and actual_light[index] > 0:
			depth[index] = 0
			queue.append(index)
	var width: int = _rect.size.x
	var offsets := PackedInt32Array([-1, 1, -width, width])
	var cursor: int = 0
	while cursor < queue.size():
		var index: int = queue[cursor]
		cursor += 1
		if depth[index] >= settings.solid_shade_depth:
			continue
		var candidate: int = int(result[index]) - settings.solid_shade_loss
		if candidate <= 0:
			continue
		var x: int = index % width
		for offset in offsets:
			if (offset == -1 and x == 0) or (offset == 1 and x == width - 1):
				continue
			var next: int = index + offset
			if next < 0 or next >= count or _opaque[next] == 0 or result[next] >= candidate:
				continue
			result[next] = candidate
			depth[next] = depth[index] + 1
			queue.append(next)
	return result


func _spread(field: PackedByteArray, queue: PackedInt32Array) -> PackedByteArray:
	var cursor: int = 0
	var width: int = _rect.size.x
	var count: int = field.size()
	var offsets := PackedInt32Array([-1, 1, -width, width])
	while cursor < queue.size():
		var index: int = queue[cursor]
		cursor += 1
		var candidate: int = int(field[index]) - 1
		if candidate <= 0:
			continue
		var x: int = index % width
		for offset in offsets:
			if offset == -1 and x == 0:
				continue
			if offset == 1 and x == width - 1:
				continue
			var next: int = index + offset
			if next < 0 or next >= count:
				continue
			var attenuated: int = candidate - maxi(0,int(_absorption[next])-1) if _absorption[next] < 16 else candidate
			if attenuated <= 0 or field[next] >= attenuated:
				continue
			field[next] = attenuated
			# Illuminate a solid face, but don't transmit through it.
			if _opaque[next] == 0:
				queue.append(next)
	return field


func sample_levels(cell: Vector2i) -> Vector2i:
	# Expose the separate sunlight and emitted-light fields for inspection.
	if not _rect.has_point(cell):
		return Vector2i.ZERO
	var local_cell: Vector2i = cell - _rect.position
	var index: int = local_cell.y * _rect.size.x + local_cell.x
	return Vector2i(roundi(_sun[index]*daylight_factor), _fire[index])

func _on_fluid_changed(cell: Vector2i) -> void:
	_sky_columns.invalidate(cell)
	if cell.x>=_rect.position.x and cell.x<_rect.end.x and cell.y<_rect.end.y: _dirty=true
	_visual_dirty=true
