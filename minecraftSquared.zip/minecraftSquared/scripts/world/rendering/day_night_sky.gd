class_name DayNightSky
extends Node2D

const SUN: Texture2D = preload("res://assets/environment/sun.png")
const CLOUDS: Texture2D = preload("res://assets/environment/clouds.png")
const MOONS: Array[Texture2D] = [
	preload("res://assets/environment/full_moon.png"),
	preload("res://assets/environment/waning_gibbous.png"),
	preload("res://assets/environment/third_quarter.png"),
	preload("res://assets/environment/waning_crescent.png"),
	preload("res://assets/environment/new_moon.png"),
	preload("res://assets/environment/waxing_crescent.png"),
	preload("res://assets/environment/first_quarter.png"),
	preload("res://assets/environment/waxing_gibbous.png")
]
var clock: DayNightCycle
var stars: Array[Dictionary] = []
var _celestial: Node2D
var _clouds: Node2D
var _fog_color:=Color.BLACK
var _fog_ready: bool=false
var _fog_x: float=0
var _fog_samples: Dictionary={}
var _fog_signature: String=""

func setup(cycle: DayNightCycle, seed_value: int) -> void:
	clock = cycle
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value ^ 32452843
	for i in range(clock.settings.star_count):
		# Fixed square stars, with a spread of brightness and sizes like the sky mesh.
		stars.append({"position":Vector2(rng.randf(),rng.randf()*.86),"size":2 if rng.randf()<.13 else 1,"brightness":rng.randf_range(.35,1.0)})
	_celestial = Node2D.new()
	var additive := CanvasItemMaterial.new()
	additive.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	_celestial.material = additive
	add_child(_celestial)
	_celestial.draw.connect(_draw_celestial)
	_clouds = Node2D.new()
	add_child(_clouds)
	_clouds.draw.connect(_draw_clouds)
	get_viewport().size_changed.connect(refresh)
	refresh()

func _process(delta: float) -> void:
	if clock==null:return
	if not clock.world.is_nether():_fog_ready=false;return
	advance_fog(delta)

func fog_target(x: float) -> Color:
	var generator: NetherGenerator=clock.world.chunks.nether
	var signature: String=str(generator.seed)+":"+str(generator.config.revision)+":"+str(generator.config.biome_width)
	if signature!=_fog_signature:_fog_signature=signature;_fog_samples.clear()
	var first: int=floori(x)
	return fog_sample(first).lerp(fog_sample(first+1),x-first)

func fog_sample(x: int) -> Color:
	if _fog_samples.has(x):return _fog_samples[x]
	var radius: int=int(WorldDimensions.DATA.environment.get("fog_blend_radius",24))
	var sigma: float=maxf(radius/2.5,1)
	var color:=Color(0,0,0,0);var total: float=0
	for dx in range(-radius,radius+1,2):
		var weight: float=exp(-.5*pow(float(dx)/sigma,2))
		var biome: String=clock.world.chunks.nether.biome_at(x+dx)
		var rgb: Array=WorldDimensions.DATA.biomes[biome].fog
		color+=Color(rgb[0],rgb[1],rgb[2])*weight;total+=weight
	color/=total;_fog_samples[x]=color
	if _fog_samples.size()>192:_fog_samples.erase(_fog_samples.keys()[0])
	return color

func advance_fog(delta: float) -> void:
	var x: float=clock.world.ground.to_local(clock.world.player.global_position).x/16.0
	var target: Color=fog_target(x)
	var seconds: float=float(WorldDimensions.DATA.environment.get("fog_transition_seconds",.35))
	if not _fog_ready or absf(x-_fog_x)>64:_fog_color=target
	else:_fog_color=_fog_color.lerp(target,1-exp(-delta/maxf(.01,seconds)))
	_fog_ready=true;_fog_x=x;queue_redraw()

func refresh() -> void:
	queue_redraw()
	if _celestial != null: _celestial.queue_redraw()
	if _clouds != null: _clouds.queue_redraw()

const END_SKY: Texture2D=preload("res://assets/environment/end/end_sky.png")
func _draw() -> void:
	if clock == null: return
	var view: Vector2 = get_viewport_rect().size
	if clock.world.is_end():
		for x in range(ceili(view.x/128)):
			for y in range(ceili(view.y/128)):draw_texture_rect(END_SKY,Rect2(x*128,y*128,128,128),false,Color(.16,.13,.19))
		return
	if clock.world.is_nether():
		if not _fog_ready:advance_fog(0)
		draw_rect(Rect2(Vector2.ZERO,view),_fog_color);return
	var day: float = clock.daylight()
	var config: DayNightSettings = clock.settings
	var top: Color = config.night_zenith.lerp(config.day_zenith,day)
	var horizon: Color = config.night_horizon.lerp(config.day_horizon,day)
	var twilight: float = 1.0-absf(2.0*day-1.0)
	horizon = horizon.lerp(config.twilight_color,twilight*.8)
	var weather: WeatherSystem=clock.world.weather
	if weather!=null:
		top=top.lerp(Color(.25,.29,.33),weather.strength*.7)
		horizon=horizon.lerp(Color(.4,.44,.47),weather.strength*.7)
		if weather.flash>0:
			top=top.lerp(Color(.8,.82,.95),weather.flash*3)
			horizon=horizon.lerp(Color(.8,.82,.95),weather.flash*3)
	# Bands stay pixel aligned; no per-frame gradient texture allocations.
	for i in range(32):
		var y: float = floorf(view.y*i/32.0)
		var end: float = ceilf(view.y*(i+1)/32.0)
		draw_rect(Rect2(0,y,view.x,end-y),top.lerp(horizon,pow((i+.5)/32.0,1.6)))
	var alpha: float = clock.star_visibility()
	if alpha <= .001: return
	for star in stars:
		var at: Vector2 = Vector2(star["position"])*view
		at.x = fposmod(at.x-clock.time_of_day()/24000.0*view.x*1.5,view.x)
		at.y += sin(clock.time_of_day()/24000.0*TAU)*view.y*.035
		at = at.floor()
		var brightness: float = float(star["brightness"])
		draw_rect(Rect2(at,Vector2.ONE*int(star["size"])),Color(brightness,brightness,brightness,alpha))

func disc_position(progress: float, size_value: float) -> Vector2:
	var view: Vector2 = get_viewport_rect().size
	# East is +X: rise at the right edge, set at the left, in a Terraria-style arc.
	return Vector2(lerpf(view.x+size_value*.5,-size_value*.5,progress),view.y*(clock.settings.horizon_height-sin(progress*PI)*clock.settings.arc_height)).floor()

func _draw_celestial() -> void:
	if clock!=null and clock.world.chunks.dimension!="overworld":return
	if clock == null: return
	var time: float = clock.time_of_day()
	var sun: bool = time < 12000
	var progress: float = time/12000.0 if sun else (time-12000.0)/12000.0
	var size_value: float = clock.settings.sun_size if sun else clock.settings.moon_size
	var at: Vector2 = disc_position(progress,size_value)
	var texture: Texture2D = SUN if sun else MOONS[clock.moon_phase()]
	# Source files use black backgrounds, exactly as vanilla's additive sky pass.
	_celestial.draw_texture_rect(texture,Rect2(at-Vector2.ONE*size_value*.5,Vector2.ONE*size_value),false,Color(1,1,1,1.0-clock.world.weather.strength*.9 if clock.world.weather!=null else 1.0))

func _draw_clouds() -> void:
	if clock!=null and clock.world.chunks.dimension!="overworld":return
	if clock == null or not clock.settings.clouds_enabled: return
	var view: Vector2 = get_viewport_rect().size
	var day: float = clock.daylight()
	var color := Color(.35,.42,.55,.12).lerp(Color(1,1,1,.70),day)
	if clock.world.weather!=null: color=color.lerp(Color(.35,.38,.42,.9),clock.world.weather.strength)
	# Individual original cloud-map patches, projected as distant 2D silhouettes.
	# Do not squash an entire strip of the map into horizontal scanlines.
	var regions: Array[Rect2] = [Rect2(13,21,53,36),Rect2(175,30,47,32),Rect2(146,103,43,16),Rect2(193,205,38,16)]
	var offset: float = fposmod(clock.total_ticks/20.0*clock.settings.cloud_speed,768)
	for i in range(-1,ceili((view.x+768)/192)+1):
		var index: int = posmod(i,4)
		var source: Rect2 = regions[index]
		var at := Vector2(i*192-offset,view.y*(.16+index*.065)).floor()
		var size_value := Vector2(source.size.x*2,maxf(6,source.size.y*.5)).floor()
		if at.x+size_value.x<0 or at.x>view.x: continue
		_clouds.draw_texture_rect_region(CLOUDS,Rect2(at+Vector2(0,2),size_value),source,color*Color(.72,.78,.86,1))
		_clouds.draw_texture_rect_region(CLOUDS,Rect2(at,size_value),source,color)
