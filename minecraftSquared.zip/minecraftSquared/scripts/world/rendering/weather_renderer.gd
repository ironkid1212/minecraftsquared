class_name WeatherRenderer
extends Node2D

var weather: WeatherSystem
var rain: Texture2D
const SNOW: Texture2D=preload("res://assets/environment/snow.png")
var _clock: float = 0
var _timer: float = 0
var drawn_columns: int = 0

func setup(system: WeatherSystem) -> void:
	weather=system
	rain=load(weather.settings.rain_texture)
	z_index=30
	texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	texture_repeat=CanvasItem.TEXTURE_REPEAT_ENABLED

func _process(delta: float) -> void:
	_clock+=delta
	_timer+=delta
	if _timer>=.05:
		_timer=fmod(_timer,.05)
		queue_redraw()

func _draw() -> void:
	drawn_columns=0
	if weather==null or rain==null or weather.strength<=.001: return
	var view: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	for x in range(floori(view.position.x/16),ceili(view.end.x/16)):
		var kind: String=weather.precipitation_at(x)
		if kind=="none":continue
		var bottom: float=minf(view.end.y,float(weather.roof(x))*16)
		var top: float=view.position.y
		if bottom<=top: continue
		var snow: bool=kind=="snow"
		var alpha: float=weather.strength*(.65 if snow else .22+float(posmod(x*97,13))*.016)
		var offset: float=fposmod(-_clock*(24 if snow else 180)+posmod(x*73,64),64)
		var drift: float=roundf(sin(_clock*.7+x)*2) if snow else 0
		draw_texture_rect_region(SNOW if snow else rain,Rect2(x*16+drift,top,16,bottom-top),Rect2(posmod(x*17,48),offset,16,bottom-top),Color(1,1,1,alpha) if snow else Color(.8,.85,1,alpha),false,false)
		drawn_columns+=1
