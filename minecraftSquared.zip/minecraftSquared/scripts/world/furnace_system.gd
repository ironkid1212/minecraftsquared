class_name FurnaceSystem
extends Node
var world: Node2D
var states: Dictionary={}
var data: Dictionary=DataFile.object_from("res://data/smelting.json")
var _recipes: Dictionary={}
var _fuels: Dictionary={}
var _elapsed: float=0
const EPS: float=.000001
func setup(game: Node2D) -> void:
	world=game
	if not validate():set_process(false);return
	world.chunks.cell_changed.connect(_changed)
func validate() -> bool:
	_recipes.clear();_fuels.clear()
	if data.get("version")!=2 or not data.get("recipes") is Dictionary or not data.get("fuels") is Dictionary or not ContentCatalog._number(data.get("cook_seconds"),.05,12000) or not ContentCatalog._number(data.get("cooldown_multiplier"),0,20):DataFile.fail("smelting.json: invalid schema/timing.");return false
	for key in data.recipes:
		var rule: Variant=data.recipes[key];var input: int=BlockDatabase.id_for(key)
		if input==0 or not rule is Dictionary or not ContentCatalog._known(rule,["result","seconds","experience","count"],"smelting.json "+str(key)):DataFile.fail("smelting.json: invalid recipe "+str(key));return false
		var output: int=BlockDatabase.id_for(str(rule.get("result","")))
		if output==0 or not ContentCatalog._number(rule.get("seconds"),.05,12000) or not ContentCatalog._number(rule.get("experience"),0,1000) or not ContentCatalog._number(rule.get("count",1),1,BlockDatabase.BLOCKS[output].max_stack,true):DataFile.fail("smelting.json: invalid result/timing/XP for "+str(key));return false
		_recipes[input]={"id":output,"seconds":float(rule.seconds),"experience":float(rule.experience),"count":int(rule.get("count",1))}
	for key in data.fuels:
		var fuel: Variant=data.fuels[key];var id: int=BlockDatabase.id_for(key)
		if id==0 or not fuel is Dictionary or not ContentCatalog._known(fuel,["seconds","remainder"],"smelting.json fuel "+str(key)) or not ContentCatalog._number(fuel.get("seconds"),.05,100000):DataFile.fail("smelting.json: invalid fuel "+str(key));return false
		var remainder: String=str(fuel.get("remainder",""))
		if not remainder.is_empty() and (BlockDatabase.id_for(remainder)==0 or int(BlockDatabase.BLOCKS[id].max_stack)!=1):DataFile.fail("smelting.json: remainder fuels must be unstackable and name a real item.");return false
		_fuels[id]={"seconds":float(fuel.seconds),"remainder":BlockDatabase.id_for(remainder)}
	return true
func key_for(id: int) -> String:return str(BlockDatabase.BLOCKS.get(id,{}).get("key",""))
func is_furnace(id: int) -> bool:return BlockDatabase.BLOCKS.get(id,{}).get("interaction")=="furnace"
func state_at(cell: Vector2i) -> FurnaceState:
	if not states.has(cell):states[cell]=FurnaceState.new()
	return states[cell]
func _changed(cell: Vector2i,old_id: int,new_id: int) -> void:
	if is_furnace(new_id):state_at(cell)
	elif is_furnace(old_id) and states.has(cell):
		var state: FurnaceState=states[cell]
		for index in range(3):
			if state.counts[index]>0:world.dropped_items.spawn_item(state.ids[index],state.counts[index],world.ground.to_global(world.ground.map_to_local(cell)),Vector2.ZERO,state.durability[index],state.tags[index])
		pay_experience(state,world.ground.to_global(world.ground.map_to_local(cell)));states.erase(cell)
		if world.furnace_screen.is_open and world.furnace_screen.cell==cell:world.furnace_screen.set_open(false)
func recipe_for(id: int) -> Dictionary:return _recipes.get(id,{})
func result_for(id: int) -> int:return int(_recipes.get(id,{}).get("id",0))
func cook_seconds(id: int) -> float:return float(_recipes.get(id,{}).get("seconds",data.cook_seconds))
func fuel_seconds(id: int) -> float:return float(_fuels.get(id,{}).get("seconds",0))
func has_room(state: FurnaceState,recipe: Dictionary) -> bool:
	if recipe.is_empty() or state.counts[0]<=0:return false
	if state.counts[2]==0:return true
	return state.ids[2]==int(recipe.id) and state.tags[2].is_empty() and state.durability[2]==ToolDatabase.initial_durability(int(recipe.id)) and state.counts[2]+int(recipe.count)<=int(BlockDatabase.BLOCKS[int(recipe.id)].max_stack)
func status(state: FurnaceState) -> String:
	if state.counts[0]<=0:return "empty"
	var recipe: Dictionary=recipe_for(state.ids[0])
	if recipe.is_empty():return "recipe"
	if not has_room(state,recipe):return "output"
	if state.burn>0:return "cooking"
	return "cooling" if state.cook>0 else "fuel"
func _process(delta: float) -> void:
	_elapsed+=delta
	if _elapsed<.05:return
	var elapsed: float=floorf((_elapsed+EPS)/.05)*.05;_elapsed=maxf(0,_elapsed-elapsed)
	for cell in states.keys():
		if not world.chunks.is_cell_loaded(cell):continue
		var state: FurnaceState=states[cell];tick(state,elapsed)
		var target: int=BlockDatabase.id_for("furnace_lit" if state.burn>0 else "furnace")
		if world.get_block(cell)!=target:world.set_block(cell,target)
func _ignite(state: FurnaceState) -> bool:
	if state.counts[1]<=0 or fuel_seconds(state.ids[1])<=0:return false
	var rule: Dictionary=_fuels[state.ids[1]]
	state.burn=float(rule.seconds);state.burn_total=state.burn;state.counts[1]-=1
	if state.counts[1]==0:
		state.clear_slot(1)
		if int(rule.remainder)!=0:state.ids[1]=int(rule.remainder);state.counts[1]=1
	return true
func sync_recipe(state: FurnaceState) -> void:
	var key: String=key_for(state.ids[0]) if state.counts[0]>0 else ""
	var uses: int=state.durability[0] if state.counts[0]>0 else 0
	var metadata: Dictionary=state.tags[0] if state.counts[0]>0 else {}
	if key!=state.recipe_key or uses!=state.recipe_durability or not NBT.same(metadata,state.recipe_tags):
		state.recipe_key=key;state.recipe_durability=uses;state.recipe_tags=metadata.duplicate(true);state.cook=0
func tick(state: FurnaceState,delta: float) -> void:
	if not is_finite(delta) or delta<=0:return
	var remaining: float=delta
	# Jump between fuel/completion boundaries, rather than iterating every game tick.
	# This preserves fractional fuels and works identically for slow/fast frames.
	while remaining>EPS:
		sync_recipe(state)
		var recipe: Dictionary=recipe_for(state.ids[0]) if state.counts[0]>0 else {}
		if not has_room(state,recipe):state.cook=0;state.burn=maxf(0,state.burn-remaining);return
		if state.burn<=EPS:
			state.burn=0
			if not _ignite(state):state.cook=maxf(0,state.cook-remaining*float(data.cooldown_multiplier));return
		var seconds: float=float(recipe.seconds)
		var step: float=minf(remaining,minf(state.burn,maxf(0,seconds-state.cook)))
		state.burn=maxf(0,state.burn-step);state.cook+=step;remaining-=step
		if state.cook+EPS>=seconds:
			state.cook=0
			if state.counts[2]==0:state.clear_slot(2);state.ids[2]=int(recipe.id);state.durability[2]=ToolDatabase.initial_durability(int(recipe.id))
			state.counts[2]+=int(recipe.count);state.experience+=float(recipe.experience)
			state.counts[0]-=1
			if state.counts[0]==0:state.clear_slot(0)
		if state.burn<EPS:state.burn=0

func snapshot() -> Array:
	var result: Array = []
	for cell in states:
		var state: FurnaceState = states[cell]
		var slots: Array = []
		for index in range(3): slots.append({"item": str(BlockDatabase.BLOCKS.get(state.ids[index], {}).get("key", "air")), "count": state.counts[index], "durability": state.durability[index],"tags":state.tags[index]})
		result.append({"cell": [cell.x, cell.y], "slots": slots, "burn": state.burn, "burn_total": state.burn_total, "cook": state.cook, "recipe_key": state.recipe_key,"recipe_durability":state.recipe_durability,"recipe_tags":state.recipe_tags.duplicate(true),"experience":state.experience})
	return result

func restore(records: Array) -> void:
	states.clear()
	for record in records:
		var cell := Vector2i(int(record["cell"][0]), int(record["cell"][1]))
		if not is_furnace(world.get_block(cell)): continue
		var state: FurnaceState = state_at(cell)
		for index in range(3):
			state.ids[index] = BlockDatabase.id_for(str(record["slots"][index]["item"]))
			state.counts[index] = int(record["slots"][index]["count"])
			state.durability[index]=int(record["slots"][index].get("durability",0))
			state.tags[index]=record["slots"][index].get("tags",{}).duplicate(true)
		state.burn = float(record["burn"])
		state.burn_total = maxf(state.burn,float(record["burn_total"]))
		state.cook = clampf(float(record["cook"]),0,cook_seconds(state.ids[0]))
		state.experience=float(record.get("experience",0))
		state.recipe_key = str(record.get("recipe_key",key_for(state.ids[0]) if state.counts[0]>0 else ""))
		state.recipe_durability=int(record.get("recipe_durability",state.durability[0]))
		state.recipe_tags=record.get("recipe_tags",state.tags[0]).duplicate(true)

func pay_experience(state: FurnaceState,point: Vector2) -> void:
	var amount: int=floori(state.experience)
	if randf()<state.experience-amount:amount+=1
	if world.experience!=null:world.experience.spawn(amount,point)
	state.experience=0
