class_name SkullBlocks
extends RefCounted
static func supported(world: Node2D,cell: Vector2i,mount: String) -> bool:
	var direction: Vector2i=Vector2i.DOWN if mount=="floor" else Vector2i.LEFT if mount=="left" else Vector2i.RIGHT
	var support: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(cell+direction),{})
	if support.has("skull") or support.has("door") or support.has("gate") or support.has("fence"):return false
	if not support.get("solid",false) and not (mount=="floor" and support.get("platform",false) and int(support.get("platform_height",16))==16):return false
	for box in support.get("collision_boxes",[[0,0,16,16]]):
		if mount=="floor" and float(box[1])==0 and float(box[0])<=4 and float(box[0])+float(box[2])>=12:return true
		if mount=="left" and float(box[0])+float(box[2])==16 and float(box[1])<=4 and float(box[1])+float(box[3])>=12:return true
		if mount=="right" and float(box[0])==0 and float(box[1])<=4 and float(box[1])+float(box[3])>=12:return true
	return false
static func resolve(world: Node2D,cell: Vector2i,id: int) -> int:
	if not BlockDatabase.BLOCKS.get(id,{}).has("skull"):return id
	for mount in ["floor","left","right"]:
		if supported(world,cell,mount):return BlockDatabase.id_for(("dragon_head" if BlockDatabase.has_tag(id,"dragon_head") or BlockDatabase.BLOCKS[id].key.begins_with("dragon_head") else "wither_skeleton_skull")+("" if mount=="floor" else "_"+mount))
	return 0
static func changed(world: Node2D,cell: Vector2i) -> void:
	for at in [cell,cell+Vector2i.UP,cell+Vector2i.LEFT,cell+Vector2i.RIGHT]:
		if not world.chunks.is_cell_loaded(at):continue
		var entry: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(at),{})
		if entry.has("skull") and not supported(world,at,entry.skull.mount):
			world.set_block(at,0)
			world.dropped_items.spawn_item(BlockDatabase.id_for("dragon_head" if entry.key.begins_with("dragon_head") else "wither_skeleton_skull"),1,world.ground.to_global(world.ground.map_to_local(at)))
