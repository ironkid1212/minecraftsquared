class_name WeatherSystem
extends Node

var world: Node2D
var settings: WeatherSettings
var state: String = "clear"
var remaining: float = 600
var cycling: bool = true
var strength: float = 0
var storm_strength: float = 0
var flash: float = 0
var renderer: WeatherRenderer
var _rng := RandomNumberGenerator.new()
var _lightning: float = 20
var _roofs: Dictionary = {}
var _edit_tops: Dictionary = {}

func setup(game: Node2D, config: WeatherSettings) -> void:
	world=game
	settings=config
	_rng.seed=world.world_seed ^ 0x7EA7
	cycling=settings.cycling
	remaining=_rng.randf_range(settings.clear_duration.x,settings.clear_duration.y)
	clear_roofs()
	world.chunks.cell_changed.connect(_changed)
	renderer=WeatherRenderer.new()
	renderer.name="Rain"
	world.ground.add_child(renderer)
	renderer.setup(self)

func _changed(cell: Vector2i, _old: int, _new: int) -> void:
	_roofs.erase(cell.x)
	_edit_tops[cell.x]=mini(int(_edit_tops.get(cell.x,cell.y)),cell.y)

func clear_roofs() -> void:
	_roofs.clear()
	_edit_tops.clear()
	for cell in world.chunks.edits: _edit_tops[cell.x]=mini(int(_edit_tops.get(cell.x,cell.y)),cell.y)

func roof(x: int) -> int:
	if _roofs.has(x): return int(_roofs[x])
	var chunks: ChunkWorld=world.chunks
	var top: int=maxi(chunks.min_world_y,mini(chunks.natural_column_top(x),int(_edit_tops.get(x,chunks.world_depth))))
	for y in range(top,chunks.world_depth):
		var id: int=chunks.get_block(Vector2i(x,y))
		var entry: Dictionary=BlockDatabase.BLOCKS.get(id,{})
		if id!=0 and (entry.get("collision","none")!="none" or entry.get("biome_tint","") in ["foliage","birch","spruce"] or world.fluids.kinds.has(id)):
			_roofs[x]=y
			return y
	_roofs[x]=chunks.world_depth
	return chunks.world_depth

func wet_biome(x: int) -> bool:
	return precipitation_at(x)!="none"

func precipitation_at(x: int) -> String:
	if world.chunks.dimension!="overworld":return "none"
	if state=="snow":return "snow"
	if world.chunks.biomes==null: return "rain"
	var key: String=str(world.chunks.biomes.column(x)["biome"])
	var biome: Dictionary=world.chunks.biomes.data["biomes"][key]
	var climate: Dictionary=biome.get("color_climate",{})
	if not bool(climate.get("precipitation",key!="desert")):return "none"
	return "snow" if bool(climate.get("snow",false)) else "rain"

func raining_at(cell: Vector2i) -> bool:
	return settings.enabled and state!="clear" and precipitation_at(cell.x)=="rain" and cell.y<=roof(cell.x)

func daylight_factor() -> float:
	if not settings.enabled: return 1.0
	return lerpf(1.0,lerpf(settings.rain_daylight,settings.thunder_daylight,storm_strength),strength)

func set_weather(mode: String, seconds: float = -1) -> void:
	if mode not in ["clear","rain","snow","thunder"]: return
	state=mode
	var range_value: Vector2=settings.clear_duration if mode=="clear" else settings.rain_duration
	remaining=seconds if seconds>0 else _rng.randf_range(range_value.x,range_value.y)
	_lightning=_rng.randf_range(settings.lightning_interval.x,settings.lightning_interval.y)
	if mode!="thunder": flash=0
	world.clock.apply()

func _process(delta: float) -> void:
	if world.chunks.dimension!="overworld":
		strength=0;storm_strength=0;flash=0;renderer.queue_redraw();return
	if not settings.enabled: return
	if cycling:
		remaining-=delta
		if remaining<=0: set_weather(("thunder" if _rng.randf()<settings.thunder_chance else "rain") if state=="clear" else "clear")
	var previous: float=strength
	var previous_flash: float=flash
	var previous_storm: float=storm_strength
	strength=move_toward(strength,0.0 if state=="clear" else 1.0,delta/maxf(.1,settings.fade_seconds))
	if state!="clear" or strength==0:
		storm_strength=move_toward(storm_strength,1.0 if state=="thunder" else 0.0,delta/maxf(.1,settings.fade_seconds))
	if state=="thunder":
		_lightning-=delta
		if _lightning<=0:
			if world.effects!=null:world.effects.sound("entity.lightning_bolt.thunder",world.player.global_position+Vector2(_rng.randf_range(-160,160),-80),"ambient",.7,1,3,2)
			flash=.22
			_lightning=_rng.randf_range(settings.lightning_interval.x,settings.lightning_interval.y)
	flash=maxf(0,flash-delta)
	if strength!=previous or flash!=previous_flash or storm_strength!=previous_storm: world.clock.apply()
	# Keep roof caches bounded while traversing an endless world.
	if _roofs.size()>512:
		var x: int=floori(world.player.global_position.x/16)
		for column in _roofs.keys():
			if absi(int(column)-x)>160: _roofs.erase(column)
	if world.fluids.burning>0:
		var cell: Vector2i=world.ground.local_to_map(world.ground.to_local(world.player.global_position))
		if raining_at(cell): world.fluids.burning=0

func snapshot() -> Dictionary:
	return {"state":state,"remaining":remaining,"cycling":cycling,"strength":strength,"storm_strength":storm_strength,"rng":str(_rng.state)}

func restore(data: Dictionary) -> void:
	state=str(data.get("state","clear"))
	remaining=float(data.get("remaining",remaining))
	cycling=bool(data.get("cycling",settings.cycling))
	strength=float(data.get("strength",0))
	storm_strength=float(data.get("storm_strength",1.0 if state=="thunder" else 0.0))
	if data.has("rng"): _rng.state=int(data["rng"])
	clear_roofs()
	world.clock.apply()
