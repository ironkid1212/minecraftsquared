class_name HingedBlocks
extends Node2D
var world: Node2D
var transitions: Dictionary={}
var visible_cells: Array[Vector2i]=[]
var _bounds:=Rect2i()
var _dirty: bool=true
const SWING_SECONDS: float=.18
func setup(game: Node2D) -> void:
	world=game;z_index=1;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	world.chunks.cell_changed.connect(changed);world.chunks.changed.connect(func():_dirty=true)
static func gate_boxes(entry: Dictionary) -> Array:
	return [] if entry.gate.open else [[6,-8,4,24]]
static func configure_gate(source: TileSetAtlasSource,entry: Dictionary) -> void:
	if not entry.has("gate"):return
	var data: TileData=source.get_tile_data(entry.atlas,entry.alternative_tile)
	data.set_collision_polygons_count(0,0 if entry.gate.open else 1)
	if not entry.gate.open:data.set_collision_polygon_points(0,0,PackedVector2Array([Vector2(-2,-16),Vector2(2,-16),Vector2(2,8),Vector2(-2,8)]))
static func overlaps_mob(chunks: ChunkWorld,cell: Vector2i,entry: Dictionary,bounds: Rect2) -> bool:
	var boxes: Array=gate_boxes(entry) if entry.has("gate") else entry.get("collision_boxes",[[0,0,16,16]])
	for box in boxes:
		var rect:=Rect2(chunks.ground.map_to_local(cell)-Vector2(8,8)+Vector2(box[0],box[1]),Vector2(box[2],box[3]))
		if (chunks.ground.global_transform*rect).intersects(bounds):return true
	return false
func changed(cell: Vector2i,old: int,new: int) -> void:
	_dirty=true
	var before: Dictionary=BlockDatabase.BLOCKS.get(old,{})
	var after: Dictionary=BlockDatabase.BLOCKS.get(new,{})
	var kind: String="door" if after.has("door") else "gate" if after.has("gate") else ""
	if kind.is_empty() or not before.has(kind):transitions.erase(cell);return
	var a: Dictionary=before[kind];var b: Dictionary=after[kind]
	if kind=="door" and (b.upper or a.item!=b.item):return
	if kind=="gate" and a.closed!=b.closed:return
	if a.open==b.open:return
	var from: float=float(transitions[cell].value) if transitions.has(cell) else (1.0 if a.open else 0.0)
	transitions[cell]={"value":from,"from":from,"to":1.0 if b.open else 0.0,"age":0.0,"swing":int(b.get("swing",1) if b.open else a.get("swing",1))}
func _process(delta: float) -> void:
	var rect: Rect2=world.ground.get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	var bounds:=Rect2i(Vector2i(floori(rect.position.x/16)-1,floori(rect.position.y/16)-2),Vector2i(ceili(rect.size.x/16)+4,ceili(rect.size.y/16)+5))
	if _dirty or bounds!=_bounds:
		_dirty=false;_bounds=bounds;visible_cells.clear();queue_redraw()
		for chunk: Vector2i in world.chunks.loaded_chunks:
			var part: Rect2i=bounds.intersection(Rect2i(chunk*ChunkWorld.CHUNK_SIZE,Vector2i.ONE*ChunkWorld.CHUNK_SIZE))
			if not part.has_area():continue
			var blocks: PackedInt32Array=world.chunks._block_cache[chunk]
			for y in range(part.position.y,part.end.y):
				for x in range(part.position.x,part.end.x):
					var id: int=blocks[(y-chunk.y*32)*32+x-chunk.x*32];var entry: Dictionary=BlockDatabase.BLOCKS.get(id,{})
					if entry.has("gate") or entry.has("door") and not entry.door.upper:visible_cells.append(Vector2i(x,y))
	for cell in transitions.keys():
		var state: Dictionary=transitions[cell];state.age+=delta
		state.value=lerpf(state.from,state.to,smoothstep(0,SWING_SECONDS,float(state.age)))
		if state.age>=SWING_SECONDS:transitions.erase(cell)
	if not visible_cells.is_empty() or not transitions.is_empty():queue_redraw()
static func face_width(value: float,width: float) -> float:return roundf(sin(clampf(value,0,1)*PI*.5)*width)
func _piece(entry: Dictionary,source: Rect2,target: Rect2,tint: Color) -> void:
	if target.size.x<=0:return
	var atlas: TileSetAtlasSource=world.atlas_source
	var origin: Vector2=Vector2(atlas.margins+entry.atlas*(atlas.texture_region_size+atlas.separation))
	draw_texture_rect_region(atlas.texture,target,Rect2(origin+source.position,source.size),tint*entry.tint)
func _draw() -> void:
	if world==null:return
	for cell in visible_cells:
		if not world.chunks.is_cell_loaded(cell):continue
		var entry: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(cell),{})
		if not entry.has("door") and not entry.has("gate"):continue
		var data: Dictionary=entry.get("door",entry.get("gate",{}));var value: float=1 if data.open else 0
		if transitions.has(cell):value=float(transitions[cell].value)
		var origin: Vector2=to_local(world.ground.to_global(world.ground.map_to_local(cell)))-Vector2(8,8)
		if entry.has("door"):
			var sign_value: int=int(data.get("hinge",1));var pivot: float=origin.x+(0 if sign_value>0 else 16)
			var width: float=face_width(value,16);var edge: float=roundf(cos(value*PI*.5)*3)
			for upper in [false,true]:
				var at: Vector2i=cell+(Vector2i.UP if upper else Vector2i.ZERO)
				if not world.chunks.is_cell_loaded(at):continue
				var full: Dictionary=BlockDatabase.BLOCKS[world.doors.state_id(data.item,upper,true,sign_value)]
				var side: Dictionary=BlockDatabase.BLOCKS[world.doors.state_id(data.item,upper,false,sign_value)]
				var tint: Color=world.lighting.render_tint(at);var y: float=origin.y-(16 if upper else 0)
				_piece(full,Rect2(0,0,16,16),Rect2(pivot if sign_value>0 else pivot-width,y,width,16),tint)
				_piece(side,Rect2(0 if sign_value>0 else 13,0,3,16),Rect2(pivot if sign_value>0 else pivot-edge,y,edge,16),tint)
		else:
			var swing: int=int(transitions[cell].swing) if transitions.has(cell) else int(data.get("swing",1))
			var key: String=data.opened_left if swing<0 else data.opened
			var full: Dictionary=BlockDatabase.BLOCKS[BlockDatabase.id_for(key)]
			var closed: Dictionary=BlockDatabase.BLOCKS[BlockDatabase.id_for(data.closed)]
			var width: float=face_width(value,8);var tint: Color=world.lighting.render_tint(cell);var pivot: float=origin.x+8
			_piece(full,Rect2(0 if swing<0 else 8,0,8,16),Rect2(pivot-width if swing<0 else pivot,origin.y,width,16),tint)
			_piece(closed,Rect2(6,0,4,16),Rect2(origin.x+6,origin.y,4,16),tint)

func reset() -> void:
	transitions.clear();visible_cells.clear();_dirty=true;_bounds=Rect2i();queue_redraw()
