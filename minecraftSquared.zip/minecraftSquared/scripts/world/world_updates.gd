class_name WorldUpdates
extends Node

## Bounded, loaded-region simulation. All mutations go through ChunkWorld so
## collisions, lighting, overlays and the normal save edit list stay in sync.
const NEIGHBORS := [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]
var world: Node2D
var chunks: ChunkWorld
var settings: WorldUpdateSettings
var rules: Dictionary = {}
var persistent_leaves: Dictionary = {}
var plant_ages: Dictionary = {}
var falling: FallingBlocks
var _scheduled: Dictionary = {}
var _decay: Dictionary = {}
var _dark_since: Dictionary = {}
var _scan_jobs: Dictionary = {}
var _known_chunks: Dictionary = {}
var _active_chunks: Array[Vector2i] = []
var _clock: float = 0.0
var _random_timer: float = 0.0
var _random_remaining: int = 0
var _random_cursor: int = 0
var _support_radius: int = 1
var _last_sim_center := Vector2i(2147483647, 2147483647)
var _rng := RandomNumberGenerator.new()
var last_updates: int = 0
var last_scanned: int = 0

func setup(game: Node2D, config: WorldUpdateSettings) -> bool:
	world = game
	chunks = world.chunks
	settings = config
	_rng.seed = int(world.world_seed) ^ 0x57A1
	if not _compile_rules():
		set_process(false)
		return false
	falling = FallingBlocks.new()
	falling.name = "FallingBlocks"
	world.ground.add_child(falling)
	falling.setup(world, self)
	chunks.cell_changed.connect(_on_cell_changed)
	chunks.fluid_changed.connect(_on_waterlogged_changed)
	chunks.changed.connect(_sync_chunks)
	_sync_chunks()
	return true

func _compile_rules() -> bool:
	var source: Variant = BlockDatabase.UPDATE_RULES.get("blocks")
	if not source is Dictionary:
		DataFile.fail("content.json updates: a blocks object is required.")
		return false
	var keys: Dictionary = {}
	for id in BlockDatabase.BLOCKS: keys[str(BlockDatabase.BLOCKS[id]["key"])] = id
	for key in source:
		var rule: Variant = source[key]
		if not keys.has(key) or not rule is Dictionary or rule.get("behavior") not in ["grass", "soil", "falling", "log", "leaves", "attached", "plant", "sugar_cane", "farmland", "crop", "vine", "climbable"]:
			DataFile.fail("content.json updates: unknown block or behavior: " + str(key))
			return false
		if not ContentCatalog._known(rule, ["behavior", "soil", "grows_into", "spread_chance", "growth_light", "death_light", "fall_through", "logs", "leaves", "support_distance", "self_drop_tool_tags", "background_support", "substrates", "upper", "lower", "clear_sides", "max_height", "growth_ticks", "support_offset"], "content.json updates / " + str(key)): return false
		if rule.has("support_offset"):
			if not ContentCatalog._vector(rule.support_offset,2,-1,1,true) or absf(rule.support_offset[0])+absf(rule.support_offset[1])!=1:return _invalid_rule(str(key))
		if rule.has("background_support") and not rule["background_support"] is bool: return _invalid_rule(str(key))
		if rule.has("clear_sides") and not rule["clear_sides"] is bool: return _invalid_rule(str(key))
		for field in ["soil", "grows_into", "upper", "lower"]:
			if rule.has(field) and not keys.has(rule[field]):
				DataFile.fail("content.json updates: unknown block reference: " + str(rule[field]))
				return false
		for field in ["logs", "leaves", "fall_through", "substrates"]:
			if not rule.get(field, []) is Array: return _invalid_rule(str(key))
			for name in rule.get(field, []):
				if name != "air" and not keys.has(name): return _invalid_rule(str(key))
		for field in ["growth_light", "death_light"]:
			if rule.has(field) and not ContentCatalog._number(rule[field], 0, 15, true): return _invalid_rule(str(key))
		if rule.has("spread_chance") and not ContentCatalog._number(rule["spread_chance"], 0, 1): return _invalid_rule(str(key))
		if not ContentCatalog._number(rule.get("support_distance", 6), 1, 12, true): return _invalid_rule(str(key))
		if rule.get("behavior") == "leaves" and (rule.get("logs", []).is_empty() or rule.get("leaves", []).is_empty()): return _invalid_rule(str(key))
		if not rule.get("self_drop_tool_tags", []) is Array: return _invalid_rule(str(key))
		for tag in rule.get("self_drop_tool_tags", []):
			if not tag is String: return _invalid_rule(str(key))
		if rule.get("behavior")=="sugar_cane" and (not ContentCatalog._number(rule.get("max_height"),1,8,true) or not ContentCatalog._number(rule.get("growth_ticks"),1,256,true)): return _invalid_rule(str(key))
		rules[int(keys[key])] = rule.duplicate(true)
		_support_radius = maxi(_support_radius, int(rule.get("support_distance", 1)))
	return true

func _invalid_rule(key: String) -> bool:
	DataFile.fail("content.json updates: invalid rule for " + key)
	return false

func rule_for(id: int) -> Dictionary:
	return rules.get(id, {})

func _active(cell: Vector2i) -> bool:
	if not chunks.is_cell_loaded(cell): return false
	var center: Vector2i = _simulation_center()
	var chunk: Vector2i = chunks.cell_to_chunk(cell)
	return absi(chunk.x - center.x) <= settings.simulation_radius.x and absi(chunk.y - center.y) <= settings.simulation_radius.y

func _simulation_center() -> Vector2i:
	var cell: Vector2i = chunks.ground.local_to_map(chunks.ground.to_local(world.player.global_position))
	cell.y = clampi(cell.y, chunks.min_world_y, chunks.world_depth - 1)
	return chunks.cell_to_chunk(cell)

func _sync_chunks() -> void:
	_last_sim_center = _simulation_center()
	_active_chunks.clear()
	for chunk in chunks.loaded_chunks:
		if not _active(chunk * ChunkWorld.CHUNK_SIZE + Vector2i(16, 16)): continue
		_active_chunks.append(chunk)
		if not _known_chunks.has(chunk):
			_scan_jobs[chunk] = 0
			_known_chunks[chunk] = true
	for chunk in _known_chunks.keys():
		if chunk not in _active_chunks:
			_known_chunks.erase(chunk)
			_scan_jobs.erase(chunk)
	for cell in _decay.keys():
		if not _active(cell): _decay.erase(cell)
	for cell in _dark_since.keys():
		if not _active(cell): _dark_since.erase(cell)

func schedule(cell: Vector2i, delay: float = 0.0) -> void:
	if not _active(cell): return
	var at: float = _clock + maxf(0.0, delay)
	if not _scheduled.has(cell) or at < float(_scheduled[cell]): _scheduled[cell] = at

func _on_cell_changed(cell: Vector2i, old_id: int, new_id: int) -> void:
	persistent_leaves.erase(cell)
	plant_ages.erase(cell)
	_decay.erase(cell)
	_dark_since.erase(cell)
	for target in [cell, cell + Vector2i.UP, cell + Vector2i.DOWN, cell + Vector2i.LEFT, cell + Vector2i.RIGHT, cell + Vector2i(-1,-1), cell + Vector2i(1,-1)]:
		var rule: Dictionary = rule_for(chunks.get_block(target))
		if not rule.is_empty(): schedule(target, settings.fall_interval if rule.get("behavior") == "falling" else 0.0)
	if rule_for(old_id).get("behavior") in ["log", "leaves"] or rule_for(new_id).get("behavior") in ["log", "leaves"]:
		for dx in range(-_support_radius, _support_radius + 1):
			for dy in range(-_support_radius, _support_radius + 1):
				if absi(dx) + absi(dy) > _support_radius: continue
				var target: Vector2i = cell + Vector2i(dx, dy)
				if chunks.is_cell_loaded(target) and rule_for(chunks.get_block(target)).get("behavior") == "leaves": schedule(target)

func note_player_placement(cell: Vector2i, id: int, pointer: Variant = null) -> void:
	var upper: String = str(rule_for(id).get("upper", ""))
	if not upper.is_empty(): chunks.set_block(cell + Vector2i.UP, BlockDatabase.id_for(upper))
	if rule_for(id).get("behavior") == "attached":
		chunks.torch_mounts[cell] = TorchMounting.choose(chunks, cell, bool(rule_for(id).get("background_support", false)), pointer)
		chunks.mark_visual_dirty(cell)
	if rule_for(id).get("behavior") == "leaves":
		persistent_leaves[cell] = true
		_decay.erase(cell)

func _process(delta: float) -> void:
	if settings == null or not settings.enabled: return
	if _simulation_center() != _last_sim_center: _sync_chunks()
	_clock += delta
	_random_timer += delta
	if _random_timer >= settings.random_tick_interval:
		_random_timer = fmod(_random_timer, settings.random_tick_interval)
		_random_remaining = maxi(_random_remaining, _active_chunks.size() * settings.random_samples_per_chunk)
	var start: int = Time.get_ticks_usec()
	var budget: int = maxi(100, roundi(settings.budget_ms * 1000.0))
	last_updates = 0
	last_scanned = 0
	for cell in _scheduled.keys():
		if last_updates >= settings.max_updates_per_frame or Time.get_ticks_usec() - start >= budget: break
		if not _active(cell):
			_scheduled.erase(cell)
			continue
		if float(_scheduled[cell]) > _clock: continue
		_scheduled.erase(cell)
		update_cell(cell)
		last_updates += 1
	# New chunks are inspected once in small slices, never rescanned each frame.
	for chunk in _scan_jobs.keys():
		if Time.get_ticks_usec() - start >= budget or last_scanned >= settings.scan_cells_per_frame: break
		var offset: int = int(_scan_jobs[chunk])
		while offset < 1024 and last_scanned < settings.scan_cells_per_frame and Time.get_ticks_usec() - start < budget:
			var cell: Vector2i = chunk * 32 + Vector2i(offset % 32, offset / 32)
			var rule: Dictionary = rule_for(chunks.get_block(cell))
			if rule.get("behavior") in ["falling", "leaves", "attached", "plant", "sugar_cane", "farmland", "crop", "vine", "climbable"]: schedule(cell, settings.fall_interval)
			offset += 1
			last_scanned += 1
		if offset >= 1024: _scan_jobs.erase(chunk)
		else: _scan_jobs[chunk] = offset
	while _random_remaining > 0 and not _active_chunks.is_empty() and last_updates < settings.max_updates_per_frame and Time.get_ticks_usec() - start < budget:
		_random_cursor %= _active_chunks.size()
		var chunk: Vector2i = _active_chunks[_random_cursor]
		_random_cursor += 1
		var cell: Vector2i = chunk * 32 + Vector2i(_rng.randi_range(0, 31), _rng.randi_range(0, 31))
		if _active(cell): update_cell(cell, true)
		_random_remaining -= 1
		last_updates += 1

func update_cell(cell: Vector2i, random_tick: bool = false) -> void:
	if not settings.enabled or not _active(cell): return
	var id: int = chunks.get_block(cell)
	var rule: Dictionary = rule_for(id)
	match str(rule.get("behavior", "")):
		"vine", "climbable":
			if not PlayerClimbing.supported(chunks,cell,id):_remove_with_drops(cell,id)
			elif world.farming!=null:world.farming.tick_vine(cell,id,random_tick)
		"farmland", "crop":
			if world.farming!=null: world.farming.tick(cell,id,random_tick)
		"falling": _fall(cell, id, rule)
		"attached":
			if not has_attachment_support(cell, id): _remove_with_drops(cell, id)
		"grass": _grass(cell, id, rule, random_tick)
		"soil":
			if random_tick: _soil(cell, rule)
		"leaves": _leaves(cell, rule)
		"sugar_cane": _sugar_cane(cell,id,rule,random_tick)
		"plant":
			if not _plant_supported(cell, rule): _remove_with_drops(cell, id)
			elif BlockDatabase.has_tag(id,"twisting_vine"):
				var target: int=BlockDatabase.id_for("twisting_vines_plant" if BlockDatabase.has_tag(chunks.get_block(cell+Vector2i.UP),"twisting_vine") else "twisting_vines")
				if target!=id:world.set_block(cell,target)

func _plant_supported(cell: Vector2i, rule: Dictionary) -> bool:
	var offset: Array=rule.get("support_offset",[0,1])
	var below: Vector2i = cell + Vector2i(offset[0],offset[1])
	if not chunks.is_cell_loaded(below): return true
	if rule.has("support_offset") and rule.get("substrates",[]).is_empty():return BlockDatabase.BLOCKS.get(chunks.get_block(below),{}).get("solid",false)
	var below_key: String = str(BlockDatabase.BLOCKS.get(chunks.get_block(below), {}).get("key", "air"))
	if rule.has("lower"): return below_key == str(rule["lower"])
	if below_key not in rule.get("substrates", []): return false
	if rule.has("upper"):
		var above: Vector2i = cell + Vector2i.UP
		if chunks.is_cell_loaded(above) and chunks.get_block(above) != BlockDatabase.id_for(str(rule["upper"])): return false
	if rule.get("clear_sides", false):
		for side in [Vector2i.LEFT, Vector2i.RIGHT]:
			if BlockDatabase.BLOCKS.get(chunks.get_block(cell + side), {}).get("solid", false): return false
	return true

func can_place_plant(cell: Vector2i, id: int) -> bool:
	var rule: Dictionary = rule_for(id)
	if rule.get("behavior")=="sugar_cane": return _cane_supported(cell,id,rule)
	var offset: Array=rule.get("support_offset",[0,1])
	if not chunks.is_cell_loaded(cell + Vector2i(offset[0],offset[1])): return false
	if rule.has("lower"): return false
	if rule.has("upper") and (not chunks.is_cell_loaded(cell + Vector2i.UP) or chunks.get_block(cell + Vector2i.UP) != 0): return false
	var support: Dictionary = rule.duplicate()
	support.erase("upper")
	if not _plant_supported(cell, support): return false
	if BlockDatabase.BLOCKS[id].get("solid", false):
		var center: Vector2 = world.ground.map_to_local(cell)
		var block_bounds: Rect2 = world.ground.global_transform * Rect2(center - Vector2(8, 8), Vector2(16, 16))
		var body: Rect2 = world.player_collision.global_transform * world.player_collision.shape.get_rect()
		if block_bounds.intersects(body): return false
	return true

func _fall(cell: Vector2i, id: int, rule: Dictionary) -> void:
	var below: Vector2i = cell + Vector2i.DOWN
	if below.y >= chunks.world_depth: return
	if not chunks.is_cell_loaded(below):
		schedule(cell, 0.5)
		return
	var below_id: int = chunks.get_block(below)
	var key: String = str(BlockDatabase.BLOCKS.get(below_id, {}).get("key", "air"))
	if key not in rule.get("fall_through", ["air"]): return
	if not falling.start(cell, id): schedule(cell, 0.25)

func has_attachment_support(cell: Vector2i, id: int) -> bool:
	var background: bool = bool(rule_for(id).get("background_support", false))
	# Unplaced cells may choose a valid support; existing torches retain theirs.
	var side: Vector2i = TorchMounting.resolve(chunks, cell, background) if TorchMounting.is_attached(chunks.get_block(cell)) else TorchMounting.choose(chunks, cell, background)
	return TorchMounting.valid(chunks, cell, side, background)

func _above_light(cell: Vector2i) -> int:
	var above: Vector2i = cell + Vector2i.UP
	if not chunks.is_cell_loaded(above) or not world.lighting.has_light_sample(above): return -1
	return world.lighting.sample_light_level(above)

func _covered(cell: Vector2i) -> bool:
	return BlockDatabase.has_tag(chunks.get_block(cell+Vector2i.UP),"fluid") or int(BlockDatabase.BLOCKS.get(chunks.get_block(cell + Vector2i.UP), {}).get("light_absorption", 0)) >= 15

func _grass(cell: Vector2i, _id: int, rule: Dictionary, allow_spread: bool) -> void:
	var light: int = _above_light(cell)
	var survival_light: int = world.lighting.sample_survival_light_level(cell+Vector2i.UP)
	var dark: bool = _covered(cell) or (survival_light >= 0 and survival_light < int(rule.get("death_light", 4)))
	if dark:
		if not _dark_since.has(cell): _dark_since[cell] = _clock
		if _clock - float(_dark_since[cell]) >= settings.grass_death_seconds:
			chunks.set_block(cell, BlockDatabase.id_for(str(rule.get("soil", "dirt"))))
		else: schedule(cell, 0.5)
		return
	_dark_since.erase(cell)
	if not allow_spread or light < int(rule.get("growth_light", 9)) or _rng.randf() > float(rule.get("spread_chance", 0.6)): return
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var target: Vector2i = cell + Vector2i(dx, dy)
			if _active(target): _soil(target, rule_for(chunks.get_block(target)))

func _soil(cell: Vector2i, rule: Dictionary) -> void:
	if rule.get("behavior") != "soil" or _covered(cell): return
	var grass_id: int = BlockDatabase.id_for(str(rule.get("grows_into", "grass")))
	var grass_rule: Dictionary = rule_for(grass_id)
	if _above_light(cell) < int(grass_rule.get("growth_light", 9)): return
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var neighbor: Vector2i = cell + Vector2i(dx, dy)
			if chunks.get_block(neighbor) == grass_id and not _covered(neighbor):
				chunks.set_block(cell, grass_id)
				return

## 1 = connected to a log through leaves, 0 = unsupported, -1 = unknown edge.
func leaf_support(cell: Vector2i, rule: Dictionary) -> int:
	var limit: int = int(rule.get("support_distance", 6))
	var queue: Array[Vector2i] = [cell]
	var distances: Dictionary = {cell: 0}
	var cursor: int = 0
	var unknown: bool = false
	while cursor < queue.size():
		var current: Vector2i = queue[cursor]
		cursor += 1
		var depth: int = int(distances[current])
		if depth >= limit: continue
		for offset in NEIGHBORS:
			var neighbor: Vector2i = current + offset
			if distances.has(neighbor): continue
			distances[neighbor] = depth + 1
			if neighbor.y < chunks.min_world_y or neighbor.y >= chunks.world_depth: continue
			if not chunks.is_cell_loaded(neighbor):
				unknown = true
				continue
			var id: int = chunks.get_block(neighbor)
			var key: String = str(BlockDatabase.BLOCKS.get(id, {}).get("key", "air"))
			if key in rule.get("logs", []): return 1
			if key in rule.get("leaves", []): queue.append(neighbor)
	return -1 if unknown else 0

func _leaves(cell: Vector2i, rule: Dictionary) -> void:
	if persistent_leaves.has(cell):
		_decay.erase(cell)
		return
	var support: int = leaf_support(cell, rule)
	if support == 1:
		_decay.erase(cell)
		return
	if support < 0:
		schedule(cell, 1.0)
		return
	if not _decay.has(cell): _decay[cell] = _clock + _rng.randf_range(settings.leaf_decay_min_seconds, settings.leaf_decay_max_seconds)
	if _clock >= float(_decay[cell]):
		_remove_with_drops(cell, chunks.get_block(cell))
	else: schedule(cell, float(_decay[cell]) - _clock)

func _remove_with_drops(cell: Vector2i, id: int) -> void:
	chunks.set_block(cell, 0)
	for drop in BlockDatabase.roll_drops(id, _rng):
		world.dropped_items.spawn_item(drop["id"], drop["count"], chunks.ground.to_global(chunks.ground.map_to_local(cell)))

func save_persistent_leaves() -> Array:
	var result: Array = []
	for cell in persistent_leaves: result.append([cell.x, cell.y])
	return result

func restore_persistent_leaves(records: Array) -> void:
	persistent_leaves.clear()
	for record in records:
		var cell := Vector2i(int(record[0]), int(record[1]))
		if rule_for(chunks.get_block(cell)).get("behavior") == "leaves": persistent_leaves[cell] = true

func _on_waterlogged_changed(cell: Vector2i) -> void:
	for offset in [Vector2i.ZERO,Vector2i.UP,Vector2i(-1,-1),Vector2i(1,-1)]: schedule(cell+offset)

func _cane_supported(cell: Vector2i, id: int, rule: Dictionary) -> bool:
	var below: Vector2i=cell+Vector2i.DOWN
	if not chunks.is_cell_loaded(below): return true
	var below_id: int=chunks.get_block(below)
	if below_id==id: return true
	if str(BlockDatabase.BLOCKS.get(below_id,{}).get("key","")) not in rule.get("substrates",[]): return false
	for side in [Vector2i.LEFT,Vector2i.RIGHT]:
		if not chunks.is_cell_loaded(below+side): return true
		if world.fluids != null and world.fluids.kind_at(below+side)=="water": return true
	return false

func _sugar_cane(cell: Vector2i, id: int, rule: Dictionary, random_tick: bool) -> void:
	if not _cane_supported(cell,id,rule):
		_remove_with_drops(cell,id)
		return
	if not random_tick or not chunks.is_cell_loaded(cell+Vector2i.UP) or chunks.get_block(cell+Vector2i.UP)!=0: return
	var height: int=1
	while height<int(rule["max_height"]) and chunks.get_block(cell+Vector2i.DOWN*height)==id: height+=1
	if height>=int(rule["max_height"]): return
	var age: int=int(plant_ages.get(cell,0))+1
	if age>=int(rule["growth_ticks"]):
		plant_ages.erase(cell)
		chunks.set_block(cell+Vector2i.UP,id)
	else: plant_ages[cell]=age

func save_plant_ages() -> Array:
	var records: Array=[]
	for cell in plant_ages:
		if rule_for(chunks.get_block(cell)).get("behavior")=="sugar_cane": records.append([cell.x,cell.y,plant_ages[cell]])
	return records

func restore_plant_ages(records: Array) -> void:
	plant_ages.clear()
	for record in records:
		var cell:=Vector2i(int(record[0]),int(record[1]))
		if rule_for(chunks.get_block(cell)).get("behavior")=="sugar_cane": plant_ages[cell]=int(record[2])
