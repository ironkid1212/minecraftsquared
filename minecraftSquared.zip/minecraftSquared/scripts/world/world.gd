extends Node2D

var dimensions:=WorldDimensions.new()
var portals: NetherPortals
var brewing: BrewingSystem
var end_progression: EndProgression
var pearls: PlayerPearls
func is_nether() -> bool:return chunks.dimension=="nether"


@export var settings: GameSettings = preload("res://data/settings/game.tres")

var world_seed: int
var world_depth: int
var surface_level: int
var hill_height: int
var dirt_depth: int
var interaction_reach: float

@onready var ground: TileMapLayer = $Ground
@onready var player: CharacterBody2D = $Player
@onready var player_collision: CollisionShape2D = $Player/CollisionShape2D
## A presentation host may place UI in the full-resolution root viewport.
var ui_layer: CanvasLayer
var external_pointer: bool = false
var pointer_position := Vector2.ZERO
var pointer_active: bool = true
var pointer_over_ui: bool = false
@onready var hotbar: BlockHotbar = (ui_layer if ui_layer != null else $UI).get_node("Hotbar")

var noise := FastNoiseLite.new()
var source_id: int
var atlas_source: TileSetAtlasSource

# Terrain, background walls, and lighting.
var chunks := ChunkWorld.new()
var lighting: WorldLighting
var inventory := BlockInventory.new()
var active_table_cell := Vector2i.ZERO
var has_active_table: bool = false
var inventory_screen: InventoryScreen
var dropped_items: DroppedItems
var world_updates: WorldUpdates
var mobs: MobSystem
var food: PlayerFood
var experience: PlayerExperience
var ranged: PlayerRanged
var structures: StructureSystem
var held_use: HeldUse
var shields: ShieldSystem
var combat: PlayerCombat
var storage: StorageSystem
var storage_screen: StorageScreen
var _interaction_slot: int=-1
var building := BuildingShapes.new()
var farming: FarmingSystem
var weather: WeatherSystem
var fluids: FluidSystem
var clock: DayNightCycle
var chat: ChatScreen
var survival: PlayerSurvival
var beds: BedSystem
var furnaces: FurnaceSystem
var furnace_screen: FurnaceScreen
var upgrade_screen: UpgradeScreen
var _mode_notice: Label
var _notice_time: float = 0.0
var _debug_key_down: bool = false
var _debug_press_event: InputEvent
var _debug_chord: bool = false
var _debug_screen: WorldDebugScreen

var mining_held: bool = false
var mining_cell := Vector2i.ZERO
var mining_block_id: int = BlockDatabase.ID.AIR
var mining_elapsed: float = 0.0
var mining_duration: float = 1.0
var mining_tool_slot: int = -1
var mining_tool_id: int = BlockDatabase.ID.AIR

var target_overlay: Node2D


func _ready() -> void:
	if not settings.validate():
		set_process(false)
		return
	if not building.setup(self): return
	RecipeDatabase.validate()
	HeldItemProfiles.validate()
	world_seed = settings.terrain.seed
	world_depth = settings.terrain.depth
	surface_level = settings.terrain.surface_level
	hill_height = settings.terrain.hill_height
	dirt_depth = settings.terrain.dirt_depth
	interaction_reach = settings.interaction_reach
	# Resolve generation keys before any chunks can be built.
	for key in [settings.terrain.surface_block, settings.terrain.soil_block, settings.terrain.rock_block, settings.tree.log_block, settings.tree.leaf_block]:
		BlockDatabase.id_for(key)
	if not DataFile.errors.is_empty():
		set_process(false)
		set_process_unhandled_input(false)
		return
	ItemDrawing.settings = settings.interface
	player.configure(settings.player, world_depth * 16.0)
	inventory.load_starting_items(settings.starting_inventory_path)
	if not DataFile.errors.is_empty():
		set_process(false)
		return
	if not prepare_tiles():
		return
	noise.seed = world_seed
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = settings.terrain.hill_frequency
	noise.fractal_octaves = settings.terrain.hill_octaves
	generate_world()
	if not DataFile.errors.is_empty():
		set_process(false)
		set_process_unhandled_input(false)
		return
	target_overlay = Node2D.new()
	target_overlay.name = "TargetOverlay"
	target_overlay.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	# Target and crack drawing sits above terrain, below Player (z = 20).
	target_overlay.z_index = 10
	add_child(target_overlay)
	target_overlay.draw.connect(_draw_target)
	hotbar.configure(atlas_source, inventory, settings.player)
	hotbar.selection_changed.connect(_sync_held_item)
	inventory.changed.connect(_sync_held_item)
	_sync_held_item()
	lighting = WorldLighting.new()
	lighting.name = "WorldLighting"
	add_child(lighting)
	lighting.setup(chunks, player, settings.lighting)
	dropped_items = DroppedItems.new()
	dropped_items.name = "DroppedItems"
	add_child(dropped_items)
	dropped_items.setup(chunks, player, inventory, lighting, atlas_source, settings.drop)
	var creative_inventory:=CreativeInventoryScreen.new();creative_inventory.world=self
	inventory_screen = creative_inventory
	inventory_screen.name = "InventoryScreen"
	(ui_layer if ui_layer != null else $UI).add_child(inventory_screen)
	inventory_screen.setup(inventory, atlas_source, settings.player)
	inventory_screen.preview_presentation = player.presentation
	inventory_screen.open_changed.connect(_inventory_open_changed)
	inventory_screen.drop_requested.connect(_drop_from_inventory)
	furnaces = FurnaceSystem.new()
	furnaces.name = "FurnaceSystem"
	add_child(furnaces)
	furnaces.setup(self)
	furnace_screen = BrewingScreen.new()
	furnace_screen.name = "FurnaceScreen"
	(ui_layer if ui_layer != null else $UI).add_child(furnace_screen)
	furnace_screen.setup(inventory, atlas_source, settings.player)
	furnace_screen.open_changed.connect(_furnace_open_changed)
	furnace_screen.drop_requested.connect(_drop_from_inventory)
	upgrade_screen=UpgradeScreen.new();upgrade_screen.name="UpgradeScreen"
	(ui_layer if ui_layer!=null else $UI).add_child(upgrade_screen)
	upgrade_screen.setup(inventory,atlas_source,settings.player)
	upgrade_screen.open_changed.connect(_upgrade_open_changed)
	upgrade_screen.drop_requested.connect(_drop_from_inventory)
	if not EnchantmentDatabase.validate():DataFile.fail("enchantments.json: invalid definitions.")

	_debug_screen = WorldDebugScreen.new()
	(ui_layer if ui_layer != null else $UI).add_child(_debug_screen)
	_debug_screen.setup(self)
	_mode_notice = Label.new()
	_mode_notice.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mode_notice.add_theme_font_override("font", ItemDrawing.settings.font)
	_mode_notice.add_theme_font_size_override("font_size", 20)
	_mode_notice.add_theme_color_override("font_shadow_color", Color.BLACK)
	_mode_notice.add_theme_constant_override("shadow_offset_x", 2)
	_mode_notice.add_theme_constant_override("shadow_offset_y", 2)
	(ui_layer if ui_layer != null else $UI).add_child(_mode_notice)
	world_updates = WorldUpdates.new()
	world_updates.name = "WorldUpdates"
	add_child(world_updates)
	if not world_updates.setup(self, settings.world_updates):
		set_process(false)
		set_process_unhandled_input(false)


	beds = BedSystem.new()
	if not beds.setup(self, settings.survival.beds_path): return
	survival = PlayerSurvival.new()
	survival.name = "PlayerSurvival"
	add_child(survival)
	survival.setup(self, settings.survival)
	shields=ShieldSystem.new();add_child(shields);shields.setup(self);player.shields=shields
	chat = ChatScreen.new()
	chat.name = "Chat"
	(ui_layer if ui_layer != null else $UI).add_child(chat)
	chat.setup(self)
	clock = DayNightCycle.new()
	clock.name = "DayNightCycle"
	add_child(clock)
	clock.setup(self,settings.day_night)
	fluids = FluidSystem.new()
	fluids.name = "FluidSystem"
	add_child(fluids)
	if not fluids.setup(self,settings.fluid): set_process(false)
	weather=WeatherSystem.new()
	weather.name="Weather"
	add_child(weather)
	weather.setup(self,settings.weather)
	farming=FarmingSystem.new()
	farming.name="Farming"
	add_child(farming)
	if not farming.setup(self,settings.farming): set_process(false)
	storage=StorageSystem.new();storage.name="Storage";add_child(storage);storage.setup(self)
	storage_screen=StorageScreen.new();storage_screen.name="StorageScreen"
	(ui_layer if ui_layer!=null else $UI).add_child(storage_screen)
	storage_screen.setup(inventory,atlas_source,settings.player)
	storage_screen.open_changed.connect(_inventory_open_changed.bind("storage"))
	storage_screen.drop_requested.connect(_drop_from_inventory)
	mobs=MobSystem.new();mobs.name="Mobs";add_child(mobs)
	if not mobs.setup(self):return
	combat=PlayerCombat.new();combat.name="Combat";add_child(combat);combat.setup(self)
	food=PlayerFood.new();add_child(food);food.setup(self)
	experience=PlayerExperience.new();add_child(experience);experience.setup(self)
	ranged=PlayerRanged.new();add_child(ranged);ranged.setup(self)
	held_use=HeldUse.new();add_child(held_use);held_use.setup(self)
	structures=StructureSystem.new();add_child(structures);structures.setup(self)
	var adventure_hud:=AdventureHUD.new();(ui_layer if ui_layer!=null else $UI).add_child(adventure_hud);adventure_hud.setup(self)
	brewing=BrewingSystem.new();add_child(brewing);brewing.setup(self)
	pearls=PlayerPearls.new();add_child(pearls);pearls.setup(self)
	end_progression=EndProgression.new();add_child(end_progression);end_progression.setup(self)
	if not dimensions.setup(self):return
	portals=NetherPortals.new();portals.name="NetherPortals";add_child(portals);portals.setup(self)


func prepare_tiles() -> bool:
	if ground.tile_set == null:
		push_error("Ground needs a TileSet.")
		return false

	if ground.tile_set.get_source_count() == 0:
		push_error("Add the texture atlas to Ground's TileSet first.")
		return false

	source_id = ground.tile_set.get_source_id(0)
	atlas_source = ground.tile_set.get_source(
		source_id
	) as TileSetAtlasSource

	if atlas_source == null:
		push_error("The first TileSet source must be your texture atlas.")
		return false

	AtlasDatabase.configure(atlas_source,"blocks")
	if not ContentCatalog.validate_sprites(BlockDatabase.BLOCKS):
		return false

	if ground.tile_set.get_physics_layers_count() == 0:
		ground.tile_set.add_physics_layer()

	ground.tile_set.set_physics_layer_collision_layer(0, 1)
	# Layer 2 contains exposed one-way platform tops.
	player.set_collision_mask_value(2, true)

	for definition in BlockDatabase.BLOCKS.values():
		var coordinates: Vector2i = definition["atlas"]
		if not definition.get("placeable", true):
			continue

		if not atlas_source.has_tile(coordinates):
			atlas_source.create_tile(coordinates)

		var alternative: int = int(definition.get("alternative_tile",-1))
		if alternative < 1 or not atlas_source.has_alternative_tile(coordinates,alternative):
			alternative = atlas_source.create_alternative_tile(coordinates)
		definition["alternative_tile"] = alternative
		var tile_data := atlas_source.get_tile_data(coordinates, alternative)
		tile_data.modulate = definition.get("tint", Color.WHITE)

		if definition["solid"]:
			var boxes: Array=definition.get("collision_boxes",[])
			if boxes.is_empty(): boxes=[[0,16-float(definition.get("collision_height",16)),16,float(definition.get("collision_height",16))]]
			tile_data.set_collision_polygons_count(0,boxes.size())
			for index in range(boxes.size()):
				var box: Array=boxes[index]
				var at:=Vector2(float(box[0])-8,float(box[1])-8)
				var size_value:=Vector2(float(box[2]),float(box[3]))
				tile_data.set_collision_polygon_points(0,index,PackedVector2Array([at,at+Vector2(size_value.x,0),at+size_value,at+Vector2(0,size_value.y)]))
		else:
			tile_data.set_collision_polygons_count(0, 0)

	for definition in BlockDatabase.BLOCKS.values():FenceConnections.configure(atlas_source,definition)
	return true


func generate_world() -> void:
	mining_held = false
	reset_mining()
	chunks.setup(ground, source_id, noise, world_depth, surface_level, hill_height, dirt_depth, settings)
	world_depth = chunks.world_depth
	if settings.terrain.modern_generation:
		var x: int = ground.local_to_map(ground.to_local(player.global_position)).x
		var surface: Vector2i = chunks.find_spawn_surface(x)
		player.global_position = ground.to_global(ground.map_to_local(surface)) - Vector2(0, 23)
		player.spawn_position = player.global_position
	chunks.update_around(player.global_position)


func set_block(cell: Vector2i, block_id: int) -> void:
	chunks.set_block(cell, block_id)


func get_block(cell: Vector2i) -> int:
	return chunks.get_block(cell)


func get_mouse_cell() -> Vector2i:
	if external_pointer:
		return ground.local_to_map(ground.get_global_transform_with_canvas().affine_inverse()*pointer_position)
	return ground.local_to_map(ground.get_local_mouse_position())


func _unhandled_input(event: InputEvent) -> void:
	if chat != null and chat.is_open: return
	if player.spectator or player.survival_dead: return
	if inventory_screen != null and inventory_screen.is_open or storage_screen != null and storage_screen.is_open or furnace_screen != null and furnace_screen.is_open or upgrade_is_open(): return
	if not is_instance_valid(target_overlay): return
	if not event is InputEventKey and not event is InputEventMouseButton: return
	if event is InputEventKey and event.echo: return
	if event.pressed and GameBindings.matches(event,"drop_item"):
		var index: int=hotbar.selected_slot
		var stack: Dictionary=inventory.stack(index)
		var amount: int=inventory.counts[index] if event.ctrl_pressed else 1
		if stack["id"]!=0 and inventory.remove_from_slot(index,amount)>0:_drop_from_inventory(stack["id"],amount,stack["durability"],stack["tags"])
		get_viewport().set_input_as_handled()
		return
	if GameBindings.matches(event,"mine"):
		var mob: MobActor=combat.target() if combat!=null else null
		if event.pressed and (shields.raising() or ranged.busy() or food.busy()):get_viewport().set_input_as_handled();return
		if event.pressed and mobs.projectiles.reflect_at_pointer():
			mining_held=false;reset_mining();get_viewport().set_input_as_handled();return
		if event.pressed and mob!=null:
			mining_held=false;reset_mining();combat.attack(mob);get_viewport().set_input_as_handled();return
		if event.pressed and combat!=null and get_block(get_mouse_cell())==0:combat.elapsed=0
		mining_held = event.pressed
		if mining_held: player.swing_hand("mine",pointer_global_position())
		else: reset_mining()
		get_viewport().set_input_as_handled()
		return
	if event.pressed and GameBindings.matches(event,"use_item"):
		var cell: Vector2i = get_mouse_cell()
		if event is InputEventMouseButton:
			cell = ground.local_to_map(ground.get_global_transform_with_canvas().affine_inverse() * event.position)
		held_use.press(cell)
		get_viewport().set_input_as_handled()


func _process(delta: float) -> void:
	if not is_instance_valid(target_overlay):
		return
	chunks.update_around(player.global_position, true)
	if _mode_notice != null:
		_notice_time = maxf(0.0, _notice_time - delta)
		_mode_notice.visible = _notice_time > 0 and not inventory_screen.is_open and not furnace_screen.is_open and not upgrade_is_open() and (storage_screen==null or not storage_screen.is_open) and not player.survival_dead and not (chat != null and chat.is_open)
		_mode_notice.position = Vector2(floorf((_mode_notice.get_viewport_rect().size.x - _mode_notice.size.x) * 0.5), maxf(0,HudLayout.text_bottom(self) - (chat.closed_text_height() if chat != null else 0.0) - _mode_notice.size.y - 4)).floor()
	if player.spectator or player.survival_dead:
		mining_held = false
		reset_mining()
		target_overlay.queue_redraw()
		return
	if furnace_screen != null and furnace_screen.is_open and not cell_is_reachable(furnace_screen.cell): furnace_screen.set_open(false)
	if storage_screen!=null and storage_screen.is_open and not storage.can_open(storage_screen.cells[0]):storage_screen.set_open(false)
	if has_active_table and inventory_screen.is_open and not _active_table_valid():
		inventory_screen.set_open(false)
	if (chat != null and chat.is_open) or ((inventory_screen != null and inventory_screen.is_open) or (storage_screen != null and storage_screen.is_open or furnace_screen != null and furnace_screen.is_open or upgrade_is_open())) or _pointer_over_hotbar() or (external_pointer and not pointer_active):
		mining_held = false
		reset_mining()
		target_overlay.queue_redraw()
		return
	if not Input.is_action_pressed("mine"):
		mining_held = false
	var cell := get_mouse_cell()
	if combat!=null and combat.target()!=null:
		reset_mining();target_overlay.queue_redraw();return
	if mining_held and cell_is_reachable(cell):
		update_mining(cell, delta)
	else:
		reset_mining()
	target_overlay.queue_redraw()


func cell_is_reachable(cell: Vector2i) -> bool:
	if not chunks.is_cell_loaded(cell):
		return false
	var center := ground.to_global(ground.map_to_local(cell))
	if player.global_position.distance_to(center)>interaction_reach:return false
	return cell_is_visible(cell)

func cell_is_visible(cell: Vector2i) -> bool:
	var target: Vector2=ground.to_global(ground.map_to_local(cell))
	var pointer: Vector2=pointer_global_position()
	if ground.local_to_map(ground.to_local(pointer))==cell:
		var center: Vector2=ground.to_local(target)
		target=ground.to_global(ground.to_local(pointer).clamp(center-Vector2(7.99,7.99),center+Vector2(7.99,7.99)))
	var origin: Vector2=ground.to_local(player.eye_position())
	var aim: Vector2=ground.to_local(target)
	var direction: Vector2=(aim-origin).normalized()
	var length: float=origin.distance_to(aim)
	var at: Vector2i=ground.local_to_map(origin)
	var step:=Vector2i(signi(roundi(direction.x*1000000)),signi(roundi(direction.y*1000000)))
	var stride:=Vector2(INF if step.x==0 else absf(16/direction.x),INF if step.y==0 else absf(16/direction.y))
	var crossing:=Vector2(INF,INF)
	if step.x!=0:crossing.x=((at.x+(1 if step.x>0 else 0))*16-origin.x)/direction.x
	if step.y!=0:crossing.y=((at.y+(1 if step.y>0 else 0))*16-origin.y)/direction.y
	# Read authoritative block shapes, so freshly placed walls obstruct immediately.
	for iteration in range(64):
		if not chunks.is_cell_loaded(at):return false
		if at==cell:return true
		var definition: Dictionary=BlockDatabase.BLOCKS.get(get_block(at),{})
		if definition.get("solid",false):
			var boxes: Array=FenceConnections.outline_boxes(chunks,at,definition) if definition.has("fence") else definition.get("collision_boxes",[])
			if boxes.is_empty():boxes=[[0,16-float(definition.get("collision_height",16)),16,float(definition.get("collision_height",16))]]
			for box: Array in boxes:
				var bounds:=Rect2(Vector2(at*16)+Vector2(box[0],box[1]),Vector2(box[2],box[3]))
				if is_finite(PlayerCombat.ray_entry(origin,aim,bounds,length)):return false
		if crossing.x<crossing.y:at.x+=step.x;crossing.x+=stride.x
		else:at.y+=step.y;crossing.y+=stride.y
	return false


func can_place_block(cell: Vector2i) -> bool:
	if player.spectator or player.survival_dead: return false
	var placed: int=building.resolve(cell,get_interaction_item(),pointer_global_position())
	if placed==0: return false
	if get_block(cell) != BlockDatabase.ID.AIR and not BlockDatabase.has_tag(get_block(cell),"fluid") and BlockDatabase.BLOCKS.get(placed,{}).get("building",{}).get("half","")!="double":
		return false
	if world_updates != null and world_updates.falling != null and world_updates.falling.overlaps_cell(cell):
		return false
	var selected: int = get_interaction_item()
	if selected == BlockDatabase.ID.AIR or not BlockDatabase.BLOCKS[selected].get("placeable", true):
		return false
	if BlockDatabase.BLOCKS[selected].has("climbable"):return PlayerClimbing.supported(chunks,cell,selected)
	if beds != null and beds.is_item(selected): return beds.can_place(cell, selected, player.facing)
	if beds != null and beds.parts.has(selected): return false
	if world_updates != null and world_updates.rule_for(selected).get("behavior") in ["plant","sugar_cane"]:
		return world_updates.can_place_plant(cell, selected)
	if world_updates != null and world_updates.rule_for(selected).get("behavior") == "attached":
		return world_updates.has_attachment_support(cell, selected)
	# A torch may attach to the cave wall behind its cell.
	if BlockDatabase.BLOCKS[selected].get("wall_attach", false) and chunks.has_background_wall(cell):
		return true
	var merging: bool=get_block(cell)!=0 and BlockDatabase.BLOCKS.get(placed,{}).get("building",{}).get("half","")=="double"
	if not merging and not has_block_neighbor(cell):
		return false
	if BlockDatabase.BLOCKS[selected].get("wall_attach", false):
		return true
	if mobs!=null and BlockDatabase.BLOCKS.get(placed,{}).get("solid",false):
		var origin: Vector2=ground.to_global(ground.map_to_local(cell))-Vector2(8,8)
		var entry: Dictionary=BlockDatabase.BLOCKS[placed]
		var boxes: Array=FenceConnections.collision_boxes(chunks,cell,entry) if entry.has("fence") else entry.get("collision_boxes",[[0,0,16,16]])
		for box: Array in boxes:
			var bounds:=Rect2(origin+Vector2(box[0],box[1]),Vector2(box[2],box[3]))
			for mob: MobActor in mobs.active.values():
				if not mob.dead and bounds.intersects(mob.bounds(mob.global_position)):return false
	return not building.overlaps_player(cell,placed)


func has_block_neighbor(cell: Vector2i) -> bool:
	for offset in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
		if get_block(cell + offset) != BlockDatabase.ID.AIR:
			return true
	return false


func update_mining(cell: Vector2i, delta: float) -> void:
	if player.spectator or player.survival_dead or not cell_is_reachable(cell):
		reset_mining();return
	var block_id: int = get_block(cell)
	if BlockDatabase.has_tag(block_id,"fire"):
		set_block(cell,0);reset_mining();return

	if block_id == BlockDatabase.ID.AIR or BlockDatabase.has_tag(block_id,"fluid") or not player.creative and not BlockDatabase.BLOCKS[block_id]["diggable"]:
		reset_mining()
		return

	if player.creative:break_block(cell);reset_mining();return
	player.begin_mining(ground.to_global(ground.map_to_local(cell)))
	var tool_id: int = hotbar.get_selected_block()
	if cell != mining_cell or block_id != mining_block_id or mining_tool_slot != hotbar.selected_slot or mining_tool_id != tool_id:
		mining_cell = cell
		mining_block_id = block_id
		mining_tool_slot = hotbar.selected_slot
		mining_tool_id = tool_id
		mining_duration = ToolDatabase.mining_time(block_id, tool_id,true,false,inventory.tags[hotbar.selected_slot])
		mining_elapsed = 0.0


	var duration: float = ToolDatabase.mining_time(block_id, tool_id, player.is_on_floor(), fluids != null and fluids.submerged(player.eye_position())=="water",inventory.tags[hotbar.selected_slot])
	if mining_duration > 0.0 and duration != mining_duration:
		mining_elapsed *= duration / mining_duration
	mining_duration = duration
	var break_time: float = mining_duration

	mining_elapsed += delta

	if mining_elapsed >= break_time:
		break_block(cell)
		reset_mining()


func reset_mining() -> void:
	player.stop_mining()
	mining_elapsed = 0.0
	mining_block_id = BlockDatabase.ID.AIR
	mining_tool_slot = -1
	mining_tool_id = BlockDatabase.ID.AIR


func _draw_target() -> void:
	if player.spectator or player.survival_dead: return
	if (chat != null and chat.is_open) or ((inventory_screen != null and inventory_screen.is_open) or (storage_screen != null and storage_screen.is_open or furnace_screen != null and furnace_screen.is_open or upgrade_is_open())) or _pointer_over_hotbar() or (external_pointer and not pointer_active):
		return

	if combat!=null and combat.target()!=null:return
	var cell := get_mouse_cell()

	if not cell_is_reachable(cell):
		return

	if get_block(cell) == BlockDatabase.ID.AIR:
		var wall_target: bool = (BlockDatabase.BLOCKS.get(get_interaction_item(), {}).get("wall_attach", false)
			and chunks.has_background_wall(cell))
		if not has_block_neighbor(cell) and not wall_target:
			return

	target_overlay.draw_set_transform_matrix(
		target_overlay.global_transform.affine_inverse()
		* ground.global_transform
	)

	var center := ground.map_to_local(cell)
	var size := Vector2(ground.tile_set.tile_size)
	var bounds := Rect2(center - size / 2.0, size)

	if (
		mining_held
		and mining_cell == cell
		and mining_block_id != BlockDatabase.ID.AIR
	):
		draw_mining_cracks(bounds)

	draw_target_border(bounds)


func draw_mining_cracks(bounds: Rect2) -> void:
	var break_time: float = mining_duration

	var progress: float = clampf(
		mining_elapsed / maxf(break_time, 0.001),
		0.0,
		1.0
	)

	var stage: int = clampi(
		floori(progress * BlockDatabase.DESTROY_STAGE_COUNT),
		0,
		BlockDatabase.DESTROY_STAGE_COUNT - 1
	)

	var coordinates: Vector2i = (
		BlockDatabase.DESTROY_START + Vector2i(stage, 0)
	)

	var region_position: Vector2i = (
		atlas_source.margins
		+ coordinates
		* (
			atlas_source.texture_region_size
			+ atlas_source.separation
		)
	)

	var texture_region := Rect2(
		Vector2(region_position),
		Vector2(atlas_source.texture_region_size)
	)

	target_overlay.draw_texture_rect_region(
		atlas_source.texture,
		bounds,
		texture_region,
		lighting.render_tint(mining_cell) if lighting != null else Color.WHITE
	)


func draw_target_border(bounds: Rect2) -> void:
	# Whole-pixel border drawn outside the targeted block.
	var t: float = 1.0
	var p := bounds.position
	var s := bounds.size

	# Top.
	target_overlay.draw_rect(
		Rect2(
			p - Vector2(t, t),
			Vector2(s.x + t * 2.0, t)
		),
		Color.BLACK
	)

	# Bottom.
	target_overlay.draw_rect(
		Rect2(
			p + Vector2(-t, s.y),
			Vector2(s.x + t * 2.0, t)
		),
		Color.BLACK
	)

	# Left.
	target_overlay.draw_rect(
		Rect2(
			p + Vector2(-t, 0),
			Vector2(t, s.y)
		),
		Color.BLACK
	)

	# Right.
	target_overlay.draw_rect(
		Rect2(
			p + Vector2(s.x, 0),
			Vector2(t, s.y)
		),
		Color.BLACK
	)


func try_place_block(cell: Vector2i) -> bool:
	if player.spectator or player.survival_dead: return false
	var id: int = get_interaction_item()
	if id == BlockDatabase.ID.AIR or inventory.counts[use_slot()] <= 0:
		return false
	if not cell_is_reachable(cell) or not can_place_block(cell):
		return false
	if beds.is_item(id):
		if not beds.place(cell, id, player.facing): return false
	else:
		id=building.resolve(cell,id,pointer_global_position())
		if id==0: return false
		set_block(cell, id)
		if get_block(cell) != id: return false
		world_updates.note_player_placement(cell, id, ground.to_local(pointer_global_position()))
		if storage!=null and storage.is_storage(id):
			var entity_tag: Variant=NBT.value(inventory.tags[use_slot()],"BlockEntityTag",{})
			if entity_tag is Dictionary:
				storage.block_tags[cell]=entity_tag.duplicate(true)
				for reserved in ["Items","id","x","y"]:storage.block_tags[cell].erase(reserved)
			var name_value: String=ItemTags.name(id,inventory.tags[use_slot()])
			if name_value!=BlockDatabase.BLOCKS[id]["name"]:storage.block_tags[cell]["CustomName"]=NBT.node(NBT.STRING,name_value)
	inventory.consume_for_placement(use_slot())
	player.swing_hand("place", ground.to_global(ground.map_to_local(cell)))
	return true


func break_block(cell: Vector2i) -> void:
	if not cell_is_reachable(cell):return
	if beds != null and not beds.can_break(cell): return
	if player.spectator or player.survival_dead: return
	if not chunks.is_cell_loaded(cell):
		return
	var id: int = get_block(cell)
	if id == BlockDatabase.ID.AIR or BlockDatabase.has_tag(id,"fluid") or not player.creative and not BlockDatabase.BLOCKS[id]["diggable"]:
		return
	if player.creative:set_block(cell,0);return
	var remains: int=0
	var storage_tags: Dictionary=storage.block_tags.get(cell,{}).duplicate(true) if storage!=null and storage.is_storage(id) else {}
	if not is_nether() and id==BlockDatabase.id_for("ice") and EnchantmentDatabase.level(inventory.tags[hotbar.selected_slot],"silk_touch")==0:
		var below: int=get_block(cell+Vector2i.DOWN)
		if BlockDatabase.BLOCKS.get(below,{}).get("solid",false) or BlockDatabase.has_tag(below,"water"):remains=BlockDatabase.id_for("water")
	set_block(cell,remains)
	if BlockDatabase.has_tag(id,"infested") and EnchantmentDatabase.level(inventory.tags[hotbar.selected_slot],"silk_touch")==0:CaveMobBrain.release(self,cell)
	var tool_id: int = hotbar.get_selected_block()
	food.add_exhaustion(float(food.rules.mine))
	if ToolDatabase.can_harvest(id, tool_id):
		var enchanted: Dictionary=EnchantmentDatabase.mining_drops(id,tool_id,inventory.tags[hotbar.selected_slot])
		var reward: Array=BlockDatabase.BLOCKS[id].get("experience",[0,0])
		if not enchanted.silk:experience.spawn(randi_range(int(reward[0]),int(reward[1])),ground.to_global(ground.map_to_local(cell)))
		var rolled: Array=enchanted.drops
		if BlockDatabase.has_tag(id,"infested"):
			rolled=[{"id":BlockDatabase.id_for(BlockDatabase.BLOCKS[id].key.trim_prefix("infested_")),"count":1}] if EnchantmentDatabase.level(inventory.tags[hotbar.selected_slot],"silk_touch")>0 else []
		if id==BlockDatabase.id_for("spawner"):rolled=[]
		if id==BlockDatabase.id_for("cobweb"):
			var kind: String=ToolDatabase.TOOLS.get(tool_id,{}).get("kind","")
			rolled=[{"id":BlockDatabase.id_for("cobweb" if kind=="shears" else "string"),"count":1}] if kind in ["sword","shears"] else []
		for drop in rolled:
			var metadata: Dictionary={}
			if not storage_tags.is_empty():
				metadata["BlockEntityTag"]=NBT.node(NBT.COMPOUND,storage_tags)
				if storage_tags.has("CustomName"):metadata["display"]=NBT.node(NBT.COMPOUND,{"Name":storage_tags["CustomName"]})
			dropped_items.spawn_item(drop["id"],drop["count"],ground.to_global(ground.map_to_local(cell)),Vector2.ZERO,-1,metadata)

	if ToolDatabase.TOOLS.has(tool_id) and float(BlockDatabase.BLOCKS[id]["hardness"]) > 0:
		inventory.damage_tool(hotbar.selected_slot, int(ToolDatabase.TOOLS[tool_id]["wear_per_block"]))


func _inventory_open_changed(open: bool, origin: String = "inventory") -> void:
	if open and held_use!=null:held_use.cancel()
	if open and origin!="storage" and storage_screen!=null and storage_screen.is_open:storage_screen.set_open(false)
	if open and chat != null: chat.set_open(false)
	player.set_interaction_enabled(not open and not player.survival_dead)
	if open:
		inventory_screen.preview_facing = player.facing
	if not open:
		has_active_table = false
	mining_held = false
	reset_mining()
	hotbar.visible = not open and not player.spectator and not player.survival_dead
	player.velocity = Vector2.ZERO
	player.set_physics_process(not open and not player.survival_dead)
	target_overlay.queue_redraw()


func _drop_from_inventory(id: int, count: int, remaining_durability: int = -1, metadata: Dictionary = {}) -> void:
	if player.spectator: return
	var origin: Vector2=player.eye_position()+Vector2(0,4.8)
	var direction: Vector2=pointer_global_position()-player.eye_position()
	if direction.length_squared()<.01:direction=Vector2(player.facing,0)
	var velocity: Vector2=direction.normalized()*settings.drop.throw_speed+Vector2(0,-settings.drop.throw_upward_bias)
	dropped_items.spawn_item(id,count,origin,velocity,remaining_durability,metadata,settings.drop.throw_pickup_delay)


func try_open_crafting_table(cell: Vector2i) -> bool:
	if player.spectator or player.survival_dead: return false
	if not cell_is_reachable(cell) or BlockDatabase.BLOCKS.get(get_block(cell), {}).get("interaction", "") != "crafting_table":
		return false
	# A solid wall between the player and the table blocks interaction.
	var target: Vector2 = ground.to_global(ground.map_to_local(cell))
	var query := PhysicsRayQueryParameters2D.create(player.global_position - Vector2(0, 8), target, 1)
	query.exclude = [player.get_rid()]
	var hit: Dictionary = ground.get_world_2d().direct_space_state.intersect_ray(query)
	if not hit.is_empty():
		var inside: Vector2 = Vector2(hit["position"]) - Vector2(hit["normal"]) * 0.5
		var hit_cell: Vector2i = ground.local_to_map(ground.to_local(inside))
		if hit_cell != cell:
			return false
	if inventory_screen.is_open:
		inventory_screen.set_open(false)
	active_table_cell = cell
	has_active_table = true
	inventory_screen.set_open(true, true)
	return true


func _active_table_valid() -> bool:
	return (cell_is_reachable(active_table_cell)
		and BlockDatabase.BLOCKS.get(get_block(active_table_cell), {}).get("interaction", "") == "crafting_table")


func _sync_held_item() -> void:
	var id: int = hotbar.get_selected_block()
	if inventory.counts[hotbar.selected_slot] <= 0:
		id = BlockDatabase.ID.AIR
	if mining_block_id != BlockDatabase.ID.AIR and (mining_tool_slot != hotbar.selected_slot or mining_tool_id != id):
		reset_mining()
	player.set_held_item(id, atlas_source)
	player.presentation.held_tags=inventory.tags[hotbar.selected_slot] if id!=0 else {}
	player.presentation.inventory=inventory
	if player.presentation.offhand==null:player.presentation.offhand=PlayerPresentation.new();player.presentation.offhand.configure(settings.player)
	player.presentation.offhand.is_offhand=true
	player.presentation.offhand.held_tags=inventory.tags[BlockInventory.OFFHAND]
	player.presentation.offhand.set_held_item(inventory.ids[BlockInventory.OFFHAND] if inventory.counts[BlockInventory.OFFHAND]>0 else 0,atlas_source)


func set_viewport_pointer(point: Vector2, active: bool, over_ui: bool) -> void:
	external_pointer = true
	pointer_position = point
	pointer_active = active
	pointer_over_ui = over_ui
	player.set_mouse_target(point,active)
	if not active or over_ui:
		mining_held = false
		reset_mining()


func pointer_global_position() -> Vector2:
	return get_global_transform_with_canvas().affine_inverse()*pointer_position if external_pointer else get_global_mouse_position()


func _pointer_over_hotbar() -> bool:
	return pointer_over_ui if external_pointer else hotbar.is_mouse_over()




func _furnace_open_changed(open: bool) -> void:
	_inventory_open_changed(open)
	inventory_screen.set_process_input(not open and not player.survival_dead)

func try_open_furnace(cell: Vector2i) -> bool:
	if player.spectator or player.survival_dead: return false
	if not cell_is_reachable(cell) or not furnaces.is_furnace(get_block(cell)): return false
	inventory_screen.set_open(false)
	furnace_screen.open_furnace(cell, furnaces)
	return true

func try_till(cell: Vector2i) -> bool:
	if player.spectator or player.survival_dead: return false
	var tool: int = get_interaction_item()
	if ToolDatabase.TOOLS.get(tool, {}).get("kind") != "hoe" or not cell_is_reachable(cell): return false
	if get_block(cell)==BlockDatabase.id_for("rooted_dirt"):
		set_block(cell,BlockDatabase.id_for("dirt"));dropped_items.spawn_item(BlockDatabase.id_for("hanging_roots"),1,ground.to_global(ground.map_to_local(cell)))
		inventory.damage_tool(use_slot(),1);player.swing_hand("place",ground.to_global(ground.map_to_local(cell)));return true
	if get_block(cell) not in [BlockDatabase.id_for("grass"), BlockDatabase.id_for("snowy_grass"), BlockDatabase.id_for("dirt")] or get_block(cell + Vector2i.UP) != 0: return false
	set_block(cell, BlockDatabase.id_for("farmland"))
	inventory.damage_tool(use_slot(), 1)
	player.swing_hand("place", ground.to_global(ground.map_to_local(cell)))
	return true

func _input(event: InputEvent) -> void:
	if chat != null and chat.is_open: return
	if player.survival_dead: return
	if (event is InputEventKey or event is InputEventMouseButton) and event.pressed and not (event is InputEventKey and event.echo) and GameBindings.matches(event,"swap_offhand") and not player.spectator and not inventory_screen.is_open and not furnace_screen.is_open and not upgrade_is_open() and (storage_screen==null or not storage_screen.is_open):
		inventory.swap_slots(hotbar.selected_slot,BlockInventory.OFFHAND);get_viewport().set_input_as_handled();return
	if not event is InputEventKey and not event is InputEventMouseButton: return
	if event is InputEventKey and event.echo: return
	if event is InputEventKey and event.pressed and event.physical_keycode == KEY_H and Input.is_physical_key_pressed(KEY_F3):
		_debug_chord = true
		var options: Node = get_node("/root/GameOptions")
		options.set_option("durability_tooltips", not ItemDrawing.settings.durability_tooltips)
		options.save_options()
		show_mode_notice("Durability Tooltips: " + ("ON" if ItemDrawing.settings.durability_tooltips else "OFF"))
		get_viewport().set_input_as_handled()
		return
	if event.pressed and GameBindings.matches(event,"spectator_toggle"):
		_debug_chord = true
		if not inventory_screen.is_open and not furnace_screen.is_open and not upgrade_is_open() and (storage_screen==null or not storage_screen.is_open): set_spectator(not player.spectator)
		get_viewport().set_input_as_handled()
		return
	var debug_release: bool = not event.pressed and _debug_key_down and _debug_press_event != null and _debug_press_event.is_match(event,false)
	if GameBindings.matches(event,"debug_screen") or debug_release:
		if event.pressed:
			_debug_key_down = true
			_debug_press_event = event.duplicate()
			_debug_chord = false
		else:
			if _debug_key_down and not _debug_chord: _debug_screen.visible = not _debug_screen.visible
			_debug_key_down = false
			_debug_press_event = null
		get_viewport().set_input_as_handled()
		return
	if player.spectator and event.pressed:
		var steps: int = 1 if GameBindings.matches(event,"spectator_faster") else -1 if GameBindings.matches(event,"spectator_slower") else 0
		if steps != 0:
			player.adjust_spectator_speed(steps)
			show_mode_notice("Spectator speed: %d%%" % roundi(player.spectator_speed * 100))
			get_viewport().set_input_as_handled()

func show_mode_notice(message: String) -> void:
	if _mode_notice == null: return
	_mode_notice.text = message
	_notice_time = 2.5

func set_spectator(value: bool, restoring: bool = false) -> bool:
	if player.survival_dead and not restoring: return false
	if player.spectator == value: return true
	if inventory_screen.is_open or furnace_screen.is_open or upgrade_is_open() or (storage_screen!=null and storage_screen.is_open): return false
	if not value and not restoring and not _survival_position_clear():
		show_mode_notice("Move into open space to return to Survival")
		return false
	player.set_spectator(value)
	inventory_screen.read_only = value
	hotbar.visible = not value
	mining_held = false
	reset_mining()
	target_overlay.queue_redraw()
	_sync_held_item()
	if not restoring: show_mode_notice("Spectator Mode" if value else "Survival Mode")
	return true

func _survival_position_clear() -> bool:
	# This game has no suffocation mechanic. Avoid trapping the player in solid
	# terrain or returning before collision chunks have finished streaming.
	var bounds: Rect2 = ground.global_transform.affine_inverse() * (player_collision.global_transform * player_collision.shape.get_rect())
	var first: Vector2i = ground.local_to_map(bounds.position + Vector2.ONE * 0.1)
	var last: Vector2i = ground.local_to_map(bounds.end - Vector2.ONE * 0.1)
	for y in range(first.y, last.y + 1):
		for x in range(first.x, last.x + 1):
			var cell := Vector2i(x, y)
			if y < chunks.min_world_y or y >= chunks.world_depth: return false
			if not chunks.is_cell_loaded(cell) or BlockDatabase.BLOCKS.get(get_block(cell), {}).get("solid", false): return false
	return true

func use_slot() -> int:return _interaction_slot if _interaction_slot>=0 else hotbar.selected_slot
func get_interaction_item() -> int:return inventory.ids[use_slot()] if inventory.counts[use_slot()]>0 else 0
func use_hand(cell: Vector2i, slot: int) -> bool:
	_interaction_slot=slot;player.action_offhand=slot==BlockInventory.OFFHAND
	var used: bool=false
	if not Input.is_action_pressed("crouch") and (use_cave_plant(cell) or try_open_upgrade(cell) or storage.use(cell) or beds.use(cell) or try_open_furnace(cell) or brewing.use(cell) or try_open_crafting_table(cell)):used=true
	elif get_interaction_item()!=0:
		used=end_progression.use(cell) or use_cave_plant(cell) or pearls.use() or fill_bottle(cell) or portals.use_igniter(cell) or try_spawn_egg(cell,slot) or Equipment.equip(inventory,slot) or fluids.use_bucket(cell) or try_drink_milk() or farming.use_item(cell) or try_till(cell) or try_place_block(cell) or ranged.begin(slot) or food.begin(slot) or shields.begin(slot)
	_interaction_slot=-1;player.action_offhand=false
	return used

func try_drink_milk() -> bool:
	if get_interaction_item()!=BlockDatabase.id_for("milk_bucket"):return false
	return food.begin(use_slot())


func game_mode() -> String:return "spectator" if player.spectator else "creative" if player.creative else "survival"
func set_game_mode(mode: String,restoring: bool=false) -> bool:
	if mode not in ["survival","creative","spectator"]:return false
	if not set_spectator(mode=="spectator",restoring):return false
	player.creative=mode=="creative";inventory.creative_mode=player.creative
	player.creative_flying=false;player.survival.reset_fall()
	if held_use!=null:held_use.cancel()
	food.cancel();ranged.cancel();shields.cancel()
	return true


func try_spawn_egg(cell: Vector2i,slot: int) -> bool:
	var kind: String=str(BlockDatabase.BLOCKS.get(get_interaction_item(),{}).get("spawn_mob",""))
	if kind.is_empty() or not MobCatalog.definitions.has(kind) or not cell_is_reachable(cell):return false
	var target: Vector2i=cell+Vector2i.UP if BlockDatabase.BLOCKS.get(get_block(cell),{}).get("solid",false) else cell
	var point: Vector2=mobs.feet(target)
	if not mobs.can_fit(kind,point) or mobs.spawn(kind,point)==null:return false
	inventory.consume_for_placement(slot);player.swing_hand("place",point);return true

func upgrade_is_open() -> bool:return upgrade_screen!=null and upgrade_screen.is_open
func any_inventory_open() -> bool:
	return inventory_screen!=null and inventory_screen.is_open or furnace_screen!=null and furnace_screen.is_open or storage_screen!=null and storage_screen.is_open or upgrade_is_open()
func _upgrade_open_changed(open: bool) -> void:
	_inventory_open_changed(open,"upgrade")
	inventory_screen.set_process_input(not open and not player.survival_dead)
	furnace_screen.set_process_input(not open and not player.survival_dead)
	if storage_screen!=null:storage_screen.set_process_input(not open and not player.survival_dead)
func try_open_upgrade(at: Vector2i) -> bool:
	if player.spectator or player.survival_dead or not cell_is_reachable(at):return false
	var action: String=BlockDatabase.BLOCKS.get(get_block(at),{}).get("interaction","")
	if action not in ["enchanting","anvil"]:return false
	inventory_screen.set_open(false);furnace_screen.set_open(false);storage_screen.set_open(false)
	upgrade_screen.open_station(at,action,self);return true

func fill_bottle(cell: Vector2i) -> bool:
	if get_interaction_item()!=BlockDatabase.id_for("glass_bottle") or not cell_is_reachable(cell) or fluids.kind_at(cell)!="water":return false
	var slot: int=use_slot()
	if not player.creative:inventory.remove_from_slot(slot,1)
	var bottle: int=BlockDatabase.id_for("water_bottle")
	if inventory.add_item(bottle,1)>0:dropped_items.spawn_item(bottle,1,player.global_position)
	player.swing_hand("place",ground.to_global(ground.map_to_local(cell)));return true

func use_cave_plant(cell: Vector2i) -> bool:
	if get_block(cell)==BlockDatabase.id_for("cave_vines_berries") and cell_is_reachable(cell):
		set_block(cell,BlockDatabase.id_for("cave_vines"));dropped_items.spawn_item(BlockDatabase.id_for("glow_berries"),1,ground.to_global(ground.map_to_local(cell)));player.swing_hand("place",ground.to_global(ground.map_to_local(cell)));return true
	var selected: int=get_interaction_item()
	if selected!=BlockDatabase.id_for("glow_berries"):return false
	if not cell_is_reachable(cell):return false
	var target: Vector2i=cell+Vector2i.DOWN if get_block(cell)!=0 else cell
	var above: int=get_block(target+Vector2i.UP)
	if get_block(target)!=0 or not BlockDatabase.BLOCKS.get(above,{}).get("solid",false) and above not in [BlockDatabase.id_for("cave_vines"),BlockDatabase.id_for("cave_vines_berries")]:return false
	set_block(target,BlockDatabase.id_for("cave_vines_berries"));inventory.consume_for_placement(use_slot());player.swing_hand("place",ground.to_global(ground.map_to_local(target)));return true
