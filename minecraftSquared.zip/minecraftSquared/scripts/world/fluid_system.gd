class_name FluidSystem
extends Node

const SIDES := [Vector2i.LEFT,Vector2i.RIGHT]
const NEIGHBORS := [Vector2i.UP,Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT]
var world: Node2D
var chunks: ChunkWorld
var settings: FluidSettings
var rules: Dictionary
var kinds: Dictionary = {}
var buckets: Dictionary = {}
var levels: Dictionary = {} # Only non-sources; 1..7 flowing, 8 falling. Source=0.
var _scheduled: Dictionary = {}
var _heap: Array[Dictionary] = []
var _known: Dictionary = {}
var _scan: Dictionary = {}
var _time: float = 0
var last_updates: int = 0
var last_scanned: int = 0
var renderer: FluidRenderer
var burning: float = 0
var _hurt: float = 0
var _fire_tick: float = 0

func setup(game: Node2D, config: FluidSettings) -> bool:
	set_process(false)
	set_physics_process(false)
	world=game
	chunks=game.chunks
	settings=config
	rules=DataFile.object_from(settings.rules_path)
	for name_text in ["water","lava"]:
		var rule: Variant = rules.get(name_text)
		if not rule is Dictionary or not ContentCatalog._number(rule.get("tick_seconds"),.05,30) or not ContentCatalog._number(rule.get("dropoff"),1,7,true) or not ContentCatalog._number(rule.get("slope_search"),1,8,true) or not rule.get("renewable") is bool or not ContentCatalog._vector(rule.get("tint"),4,0,1):
			DataFile.fail("fluids.json: invalid flow rule for "+name_text)
			return false
		var id: int=BlockDatabase.id_for(str(rule.get("block","")))
		var bucket: int=BlockDatabase.id_for(str(rule.get("bucket","")))
		if not BlockDatabase.has_tag(id,"fluid") or bucket==0:
			DataFile.fail("fluids.json: invalid fluid block or bucket reference for "+name_text)
			return false
		for texture_key in ["still","flow"]:
			if not rule.get(texture_key) is String or not ResourceLoader.exists(rule[texture_key]):
				DataFile.fail("fluids.json: missing animation texture")
				return false
		kinds[id]=name_text
		buckets[bucket]=id
	for key in ["source","flowing","downward"]:
		if BlockDatabase.id_for(str(rules.get("reactions",{}).get(key,"")))==0: return false
	if BlockDatabase.id_for(str(rules.get("empty_bucket","")))==0: return false
	chunks.cell_changed.connect(_changed)
	chunks.fluid_changed.connect(_logged_changed)
	chunks.changed.connect(sync_chunks)
	renderer=FluidRenderer.new()
	chunks.ground.add_child(renderer)
	renderer.setup(self)
	world.player.fluids=self
	sync_chunks()
	set_process(true)
	set_physics_process(true)
	return true

func kind_at(cell: Vector2i) -> String:
	return "water" if chunks.waterlogged.has(cell) else str(kinds.get(chunks.get_block(cell),""))

func level(cell: Vector2i) -> int:
	return int(levels.get(cell,0))

func height_at(cell: Vector2i) -> float:
	if kind_at(cell).is_empty(): return 0
	if chunks.waterlogged.has(cell): return 16
	if level(cell)==8 or kind_at(cell+Vector2i.UP)==kind_at(cell): return 16
	return 14.0 if level(cell)==0 else float(8-level(cell))*2.0

func submerged(point: Vector2) -> String:
	var local: Vector2=world.ground.to_local(point)
	var cell: Vector2i=world.ground.local_to_map(local)
	var name_text: String=kind_at(cell)
	if name_text.is_empty(): return ""
	var bottom: float=world.ground.map_to_local(cell).y+8
	return name_text if local.y >= bottom-height_at(cell) else ""

func body_kind() -> String:
	# Torso overlap makes entry responsive, including shallow flows at the feet.
	for offset in ([Vector2(0,9),Vector2(-8,9),Vector2(8,9)] if world.player.swimming else [Vector2(0,6),Vector2.ZERO,Vector2(0,-8)]):
		var name_text: String=submerged(world.player.global_position+offset)
		if not name_text.is_empty(): return name_text
	return ""

func current_at(cell: Vector2i) -> Vector2:
	# Horizontal level gradients, including spillways; a flat contained pool is still.
	if not chunks.is_cell_loaded(cell) or kind_at(cell)!="water":return Vector2.ZERO
	var own: float=float(8-(0 if level(cell)==8 else level(cell)))/9.0
	var flow:=Vector2.ZERO
	for side in SIDES:
		var next: Vector2i=cell+side
		if not chunks.is_cell_loaded(next):continue
		if kind_at(next)=="water":
			var other: float=float(8-(0 if level(next)==8 else level(next)))/9.0
			flow.x+=side.x*(own-other)
		elif kind_at(next).is_empty() and not BlockDatabase.BLOCKS.get(chunks.get_block(next),{}).get("solid",false) and kind_at(next+Vector2i.DOWN)=="water":
			var below: float=float(8-(0 if level(next+Vector2i.DOWN)==8 else level(next+Vector2i.DOWN)))/9.0
			flow.x+=side.x*(own-below+1)
	# In 2D a falling column pulls downward. Do not invent currents in source lakes.
	if level(cell)==8:flow.y=6
	return Vector2.ZERO if flow.is_zero_approx() else flow.normalized()

func current_for_bounds(bounds: Rect2) -> Vector2:
	var local: Rect2=world.ground.global_transform.affine_inverse()*bounds
	var first: Vector2i=world.ground.local_to_map(local.position+Vector2.ONE*.01)
	var last: Vector2i=world.ground.local_to_map(local.end-Vector2.ONE*.01)
	var total:=Vector2.ZERO;var area: float=0
	for y in range(first.y,last.y+1):
		for x in range(first.x,last.x+1):
			var cell:=Vector2i(x,y)
			if not chunks.is_cell_loaded(cell) or kind_at(cell)!="water":continue
			var height: float=height_at(cell)
			var origin: Vector2=world.ground.map_to_local(cell)-Vector2(8,8)
			var water:=Rect2(origin+Vector2(0,16-height),Vector2(16,height))
			var overlap: Rect2=local.intersection(water)
			if not overlap.has_area():continue
			var weight: float=overlap.get_area();area+=weight;total+=current_at(cell)*weight
	return total/area if area>0 else Vector2.ZERO

func current_velocity(bounds: Rect2,previous: Vector2,delta: float) -> Vector2:
	var flow: Vector2=current_for_bounds(bounds)
	if flow.is_zero_approx():return Vector2.ZERO
	# Approximately 1.4 blocks/sec at rest; independent of the physics frame rate.
	return previous.lerp(flow*settings.water_current_speed,1-pow(.8,delta*20))

func sync_chunks() -> void:
	if renderer != null: renderer.dirty = true
	for chunk in _known.keys():
		if not chunks.loaded_chunks.has(chunk):
			_known.erase(chunk)
			_scan.erase(chunk)
	for chunk in chunks.loaded_chunks:
		if _known.has(chunk): continue
		_known[chunk]=true
		_scan[chunk]=0
		# Wake both sides of a seam when the adjacent chunk becomes resident.
		for i in range(ChunkWorld.CHUNK_SIZE):
			for cell in [chunk*32+Vector2i(-1,i),chunk*32+Vector2i(32,i),chunk*32+Vector2i(i,-1),chunk*32+Vector2i(i,32)]:
				if chunks.is_cell_loaded(cell) and not kind_at(cell).is_empty(): schedule(cell)

func _push(entry: Dictionary) -> void:
	_heap.append(entry)
	var i: int=_heap.size()-1
	while i>0:
		var parent: int=(i-1)/2
		if _heap[parent]["due"] <= entry["due"]: break
		_heap[i]=_heap[parent]
		i=parent
	_heap[i]=entry

func _pop() -> Dictionary:
	var result: Dictionary=_heap[0]
	var tail: Dictionary=_heap.pop_back()
	if _heap.is_empty(): return result
	var i: int=0
	while i*2+1<_heap.size():
		var child: int=i*2+1
		if child+1<_heap.size() and _heap[child+1]["due"]<_heap[child]["due"]: child+=1
		if tail["due"]<=_heap[child]["due"]: break
		_heap[i]=_heap[child]
		i=child
	_heap[i]=tail
	return result

func schedule(cell: Vector2i) -> void:
	if not chunks.is_cell_loaded(cell): return
	var kind: String=kind_at(cell)
	if kind.is_empty(): return
	var due: float=_time+float(rules[kind]["tick_seconds"])
	if _scheduled.has(cell) and float(_scheduled[cell])<=due: return
	_scheduled[cell]=due
	_push({"cell":cell,"due":due})

var _mutation_depth: int = 0
var _mixing: bool = false

func _mix_around(cell: Vector2i) -> void:
	if _mutation_depth>0 or _mixing: return
	_mixing=true
	for offset in [Vector2i.ZERO,Vector2i.UP,Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT]:
		if chunks.is_cell_loaded(cell+offset): _react(cell+offset)
	_mixing=false

func _changed(cell: Vector2i, _old: int, _new: int) -> void:
	levels.erase(cell)
	schedule(cell)
	for offset in NEIGHBORS: schedule(cell+offset)
	if renderer!=null: renderer.dirty=true
	_mix_around(cell)

func set_fluid(cell: Vector2i, id: int, new_level: int = 0) -> void:
	if not chunks.is_cell_loaded(cell): return
	if chunks.waterlogged.has(cell) and id==0:
		chunks.set_waterlogged(cell,false)
		return
	var previous: int=chunks.get_block(cell)
	if previous==id and level(cell)==new_level: return
	_mutation_depth+=1
	if previous!=id: world.set_block(cell,id)
	_mutation_depth-=1
	if new_level==0 or not kinds.has(id): levels.erase(cell)
	else: levels[cell]=new_level
	for offset in NEIGHBORS: schedule(cell+offset)
	schedule(cell)
	if renderer!=null: renderer.dirty=true
	_mix_around(cell)

func configure_dimension() -> void:
	rules=DataFile.object_from(settings.rules_path)
	if world.is_nether():
		rules.lava.tick_seconds=WorldDimensions.DATA.environment.lava_tick_seconds
		rules.lava.dropoff=WorldDimensions.DATA.environment.lava_dropoff
		rules.lava.slope_search=WorldDimensions.DATA.environment.lava_search

func replaceable(cell: Vector2i, kind: String = "") -> bool:
	if not chunks.is_cell_loaded(cell): return false
	var id: int=chunks.get_block(cell)
	if id==0 or BlockDatabase.has_tag(id,"fire") or BlockDatabase.has_tag(id,"nether_portal"): return true
	if kinds.has(id): return kind.is_empty() or kinds[id]==kind
	var entry: Dictionary=BlockDatabase.BLOCKS[id]
	return entry["collision"]=="none" and (BlockDatabase.has_tag(id,"plant") or entry.get("wall_attach",false))

func downward_open(cell: Vector2i, kind: String) -> bool:
	var below: Vector2i=cell+Vector2i.DOWN
	if not replaceable(below,kind): return false
	return kind_at(below)!=kind or level(below)!=0

func _react(cell: Vector2i) -> bool:
	if kind_at(cell)!="lava": return false
	for offset in [Vector2i.UP,Vector2i.LEFT,Vector2i.RIGHT]:
		if kind_at(cell+offset)=="water":
			set_fluid(cell,BlockDatabase.id_for(rules["reactions"]["source" if level(cell)==0 else "flowing"]))
			return true
	return false

func flow_into(cell: Vector2i, kind: String, new_level: int) -> bool:
	if not chunks.is_cell_loaded(cell): return false
	var other: String=kind_at(cell)
	if not other.is_empty() and other!=kind:
		# Lava entering water from above makes stone at the water cell.
		if kind=="lava" and new_level==8:
			set_fluid(cell,BlockDatabase.id_for(rules["reactions"]["downward"]))
		elif kind=="water": _react(cell)
		return true
	if not replaceable(cell,kind): return false
	var id: int=BlockDatabase.id_for(str(rules[kind]["block"]))
	if other==kind:
		if level(cell)==0: return true
		if new_level!=8 and (level(cell)==8 or level(cell)<=new_level): return true
	else:
		var old: int=chunks.get_block(cell)
		if old!=0 and kind=="water": world.world_updates._remove_with_drops(cell,old)
	set_fluid(cell,id,new_level)
	return true

func _drop_distance(cell: Vector2i, direction: Vector2i, kind: String) -> int:
	for i in range(1,int(rules[kind]["slope_search"])+1):
		var next: Vector2i=cell+direction*i
		if not replaceable(next,kind): break
		if downward_open(next,kind): return i
	return 100

func update_cell(cell: Vector2i) -> void:
	if not chunks.is_cell_loaded(cell): return
	var kind: String=kind_at(cell)
	if kind.is_empty() or _react(cell): return
	# Keep boundary states frozen until their neighbors are loaded.
	for offset in NEIGHBORS:
		var neighbor: Vector2i=cell+offset
		if neighbor.y>=chunks.min_world_y and neighbor.y<chunks.world_depth and not chunks.is_cell_loaded(neighbor): return
	if level(cell)!=0:
		var next_level: int=9
		if kind_at(cell+Vector2i.UP)==kind: next_level=8
		else:
			var sources: int=0
			for side in SIDES:
				var neighbor: Vector2i=cell+side
				if kind_at(neighbor)!=kind: continue
				if level(neighbor)==0: sources+=1
				if not downward_open(neighbor,kind):
					var strength: int=0 if level(neighbor)==8 else level(neighbor)
					var candidate: int = strength+int(rules[kind]["dropoff"])
					if candidate < 8: next_level=mini(next_level,candidate)
			if rules[kind]["renewable"] and sources>=2 and not downward_open(cell,kind): next_level=0
		if next_level>7 and next_level!=8:
			set_fluid(cell,0)
			return
		set_fluid(cell,chunks.get_block(cell),next_level)
	var below: Vector2i=cell+Vector2i.DOWN
	if kind=="lava" and kind_at(below)=="water":
		flow_into(below,kind,8)
		return
	if downward_open(cell,kind):
		flow_into(below,kind,8)
		return
	var spread_level: int=(0 if level(cell)==8 else level(cell))+int(rules[kind]["dropoff"])
	if spread_level>7: return
	var left: int=_drop_distance(cell,Vector2i.LEFT,kind)
	var right: int=_drop_distance(cell,Vector2i.RIGHT,kind)
	if left<=right: flow_into(cell+Vector2i.LEFT,kind,spread_level)
	if right<=left: flow_into(cell+Vector2i.RIGHT,kind,spread_level)

func _process(delta: float) -> void:
	_time+=delta
	last_updates=0
	last_scanned=0
	var start: int=Time.get_ticks_usec()
	for chunk in _scan.keys():
		var index: int=_scan[chunk]
		while index<1024 and last_scanned<settings.scan_cells_per_frame:
			var cell: Vector2i=chunk*32+Vector2i(index%32,index/32)
			if not kind_at(cell).is_empty():
				for offset in NEIGHBORS:
					if kind_at(cell+offset)!=kind_at(cell):
						schedule(cell)
						break
			index+=1
			last_scanned+=1
			if Time.get_ticks_usec()-start>=settings.budget_ms*400: break
		if index>=1024: _scan.erase(chunk)
		else: _scan[chunk]=index
		if last_scanned>=settings.scan_cells_per_frame or Time.get_ticks_usec()-start>=settings.budget_ms*400: break
	var popped: int=0
	while not _heap.is_empty() and float(_heap[0]["due"])<=_time and popped<settings.max_updates_per_frame:
		if Time.get_ticks_usec()-start>=settings.budget_ms*1000: break
		var entry: Dictionary=_pop()
		popped+=1
		var cell: Vector2i=entry["cell"]
		if _scheduled.get(cell,-1.0)!=entry["due"]: continue
		_scheduled.erase(cell)
		update_cell(cell)
		last_updates+=1

func _physics_process(delta: float) -> void:
	if world.player.spectator or world.player.survival_dead:
		burning=0
		return
	var kind: String=body_kind()
	_hurt=maxf(0,_hurt-delta)
	if kind=="water":
		burning=0
		_fire_tick=0
	elif kind=="lava":
		burning=settings.burning_seconds
		if _hurt<=0:
			world.survival.take_damage(settings.lava_damage,"You tried to swim in lava")
			_hurt=settings.lava_damage_interval
	elif burning>0:
		burning=maxf(0,burning-delta)
		_fire_tick+=delta
		if _fire_tick>=1:
			_fire_tick=fmod(_fire_tick,1)
			world.survival.take_damage(1,"You burned to death")

func use_bucket(cell: Vector2i) -> bool:
	if not world.cell_is_reachable(cell) or world.player.spectator or world.player.survival_dead: return false
	var selected: int=world.get_interaction_item()
	var empty: int=BlockDatabase.id_for(rules["empty_bucket"])
	if selected==empty:
		var kind: String=kind_at(cell)
		if kind.is_empty() or level(cell)!=0: return false
		var filled: int=BlockDatabase.id_for(rules[kind]["bucket"])
		set_fluid(cell,0)
		_replace_bucket(filled)
	elif buckets.has(selected):
		var kind: String=kinds[buckets[selected]]
		var target: Vector2i=cell
		if kind=="water" and world.is_nether():
			_replace_bucket(empty);world.player.swing_hand("place",world.ground.to_global(world.ground.map_to_local(cell)))
			world.show_mode_notice("The water evaporated");return true
		if kind=="water" and BlockDatabase.BLOCKS.get(chunks.get_block(target),{}).get("waterloggable",false):
			if chunks.set_waterlogged(target,true):
				_replace_bucket(empty)
				world.player.swing_hand("place",world.ground.to_global(world.ground.map_to_local(cell)))
				return true
			return false
		if not replaceable(target):
			var toward: Vector2=world.player.global_position-world.ground.to_global(world.ground.map_to_local(cell))
			target+=Vector2i(signi(roundi(toward.x)),0) if absf(toward.x)>absf(toward.y) else Vector2i(0,signi(roundi(toward.y)))
		if not world.cell_is_reachable(target) or not replaceable(target): return false
		var other: String=kind_at(target)
		if other==kind and level(target)==0: return false
		if not other.is_empty() and other!=kind: return false
		else:
			var old: int=chunks.get_block(target)
			if old!=0 and not kinds.has(old) and kind=="water": world.world_updates._remove_with_drops(target,old)
			set_fluid(target,int(buckets[selected]),0)
		_replace_bucket(empty)
	else: return false
	world.player.swing_hand("place",world.ground.to_global(world.ground.map_to_local(cell)))
	return true

func _replace_bucket(id: int) -> void:
	var inventory: BlockInventory=world.inventory
	var slot: int=world.use_slot()
	var metadata: Dictionary=inventory.tags[slot].duplicate(true)
	if world.player.creative:
		if inventory.ids[slot]==BlockDatabase.id_for("bucket") and id!=inventory.ids[slot]:
			var present: bool=false
			for i in range(BlockInventory.MAIN_COUNT):
				if inventory.ids[i]==id and inventory.counts[i]>0:present=true;break
			if not present:inventory.add_item(id,1,0,36,-1,metadata)
		return
	if inventory.counts[slot]==1:
		inventory.ids[slot]=id
		inventory.durability[slot]=0
		inventory.changed.emit()
	else:
		inventory.remove_from_slot(slot,1)
		if inventory.add_item(id,1,0,36,-1,metadata)>0: world.dropped_items.spawn_item(id,1,world.player.global_position,Vector2.ZERO,-1,metadata)

func snapshot() -> Array:
	var records: Array=[]
	for cell in levels:
		if not kind_at(cell).is_empty(): records.append([cell.x,cell.y,int(levels[cell])])
	return records

func restore(records: Array) -> void:
	levels.clear()
	_scheduled.clear()
	_heap.clear()
	_known.clear()
	_scan.clear()
	for record in records:
		var cell:=Vector2i(int(record[0]),int(record[1]))
		if not kind_at(cell).is_empty(): levels[cell]=int(record[2])
	sync_chunks()
	if renderer!=null: renderer.dirty=true


func _logged_changed(cell: Vector2i) -> void:
	schedule(cell)
	for offset in NEIGHBORS: schedule(cell+offset)
	if renderer!=null: renderer.dirty=true
	_mix_around(cell)

func snapshot_waterlogged() -> Array:
	var records: Array=[]
	for cell in chunks.waterlogged: records.append([cell.x,cell.y])
	return records

func restore_waterlogged(records: Array) -> void:
	var previous: Array=chunks.waterlogged.keys()
	chunks.waterlogged.clear()
	for record in records:
		var cell:=Vector2i(int(record[0]),int(record[1]))
		if BlockDatabase.BLOCKS.get(chunks.get_block(cell),{}).get("waterloggable",false):
			chunks.waterlogged[cell]=true
			chunks.mark_visual_dirty(cell)
			chunks.fluid_changed.emit(cell)
	for cell in previous:
		chunks.mark_visual_dirty(cell)
		chunks.fluid_changed.emit(cell)
	_known.clear()
	sync_chunks()
