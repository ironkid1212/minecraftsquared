class_name StorageSystem
extends Node
var world: Node2D
var states: Dictionary={}
var pairs: Dictionary={}
var block_tags: Dictionary={}

func setup(game: Node2D) -> void:
	world=game;world.chunks.storage_pairs=pairs;world.chunks.cell_changed.connect(_changed)
func is_storage(id: int) -> bool:return BlockDatabase.BLOCKS.get(id,{}).has("storage")
func state_at(cell: Vector2i) -> BlockInventory:
	if not states.has(cell):
		states[cell]=BlockInventory.new(27)
		if world.structures!=null:world.structures.populate_container(cell,states[cell])
	return states[cell]
func _changed(cell: Vector2i,old: int,new_id: int) -> void:
	if is_storage(old):
		state_at(cell)
		if world.storage_screen!=null and world.storage_screen.is_open and cell in world.storage_screen.cells:world.storage_screen.set_open(false)
		if states.has(cell):
			var items: BlockInventory=states[cell]
			for i in range(items.capacity):
				if items.counts[i]>0:world.dropped_items.spawn_item(items.ids[i],items.counts[i],world.ground.to_global(world.ground.map_to_local(cell)),Vector2.ZERO,items.durability[i],items.tags[i])
		states.erase(cell);block_tags.erase(cell)
		if pairs.has(cell):
			world.chunks.mark_visual_dirty(pairs[cell]);pairs.erase(pairs[cell]);pairs.erase(cell)
	if is_storage(new_id):
		state_at(cell)
		if BlockDatabase.BLOCKS[new_id]["storage"]["pairs"]:
			for offset in [Vector2i.LEFT,Vector2i.RIGHT]:
				var other: Vector2i=cell+offset
				if not pairs.has(other) and world.chunks.is_cell_loaded(other) and world.get_block(other)==new_id:
					pairs[cell]=other;pairs[other]=cell;world.chunks.mark_visual_dirty(cell);world.chunks.mark_visual_dirty(other);break
func cells_for(cell: Vector2i) -> Array[Vector2i]:
	var result: Array[Vector2i]=[cell]
	if pairs.has(cell) and world.get_block(pairs[cell])==world.get_block(cell):result.append(pairs[cell])
	result.sort_custom(func(a: Vector2i,b: Vector2i):return a.x<b.x)
	return result
func can_open(cell: Vector2i) -> bool:
	if not world.cell_is_reachable(cell) or not is_storage(world.get_block(cell)):return false
	var kind: String=BlockDatabase.BLOCKS[world.get_block(cell)]["storage"]["kind"]
	if kind=="barrel":return true
	for at in cells_for(cell):
		var above: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(at+Vector2i.UP),{})
		if above.get("solid",false):
			var boxes: Array=above.get("collision_boxes",[[0,0,16,16]])
			for box in boxes:
				if float(box[1])+float(box[3])>=16:return false
	return true
func use(cell: Vector2i) -> bool:
	if not can_open(cell):return false
	world.inventory_screen.set_open(false);world.furnace_screen.set_open(false)
	world.storage_screen.open_container(cells_for(cell),self)
	return true
func title(cells: Array[Vector2i]) -> String:
	var custom: String=str(NBT.value(block_tags.get(cells[0],{}),"CustomName",""))
	if not custom.is_empty():return custom
	return "Large Chest" if cells.size()==2 else BlockDatabase.BLOCKS[world.get_block(cells[0])]["name"]
func inspect_nbt(cell: Vector2i) -> Dictionary:
	var result: Dictionary=block_tags.get(cell,{}).duplicate(true)
	result["id"]=NBT.node(NBT.STRING,"minecraft:"+str(BlockDatabase.BLOCKS[world.get_block(cell)]["key"]))
	result["x"]=NBT.node(NBT.INT,cell.x);result["y"]=NBT.node(NBT.INT,cell.y)
	var list: Array=[];var items: BlockInventory=state_at(cell)
	for i in range(27):
		if items.counts[i]<=0:continue
		list.append(NBT.node(NBT.COMPOUND,{"Slot":NBT.node(NBT.BYTE,i),"id":NBT.node(NBT.STRING,"minecraft:"+str(BlockDatabase.BLOCKS[items.ids[i]]["key"])),"Count":NBT.node(NBT.BYTE,items.counts[i]),"tag":NBT.node(NBT.COMPOUND,items.tags[i].duplicate(true))}))
	result["Items"]=NBT.node(NBT.LIST,list)
	return result
func snapshot() -> Array:
	var result: Array=[]
	for cell in states:
		if not is_storage(world.get_block(cell)):continue
		var items: BlockInventory=states[cell];var slots: Array=[]
		for i in range(27):slots.append({"item":BlockDatabase.BLOCKS.get(items.ids[i],{}).get("key","air"),"count":items.counts[i],"durability":items.durability[i],"tags":items.tags[i]})
		var partner: Array=[pairs[cell].x,pairs[cell].y] if pairs.has(cell) else []
		result.append({"cell":[cell.x,cell.y],"slots":slots,"partner":partner,"tags":block_tags.get(cell,{})})
	return result
func restore(records: Array) -> void:
	states.clear();pairs.clear();block_tags.clear()
	for record in records:
		var cell:=Vector2i(int(record["cell"][0]),int(record["cell"][1]))
		if not is_storage(world.get_block(cell)):continue
		var items: BlockInventory=state_at(cell)
		for i in range(27):
			var stack: Dictionary=record["slots"][i]
			items.set_stack(i,{"id":BlockDatabase.id_for(str(stack["item"])),"count":int(stack["count"]),"durability":int(stack.get("durability",0)),"tags":stack.get("tags",{})})
		block_tags[cell]=record.get("tags",{}).duplicate(true)
	for record in records:
		var cell:=Vector2i(int(record["cell"][0]),int(record["cell"][1]))
		var partner: Array=record.get("partner",[])
		if partner.size()!=2 or not states.has(cell) or pairs.has(cell):continue
		var other:=Vector2i(int(partner[0]),int(partner[1]))
		if states.has(other) and not pairs.has(other) and other.y==cell.y and absi(other.x-cell.x)==1 and world.get_block(other)==world.get_block(cell) and BlockDatabase.BLOCKS[world.get_block(cell)]["storage"]["pairs"]:
			pairs[cell]=other;pairs[other]=cell
			world.chunks.mark_visual_dirty(cell);world.chunks.mark_visual_dirty(other)
