class_name FenceConnections
extends RefCounted

# Bit 0: left, bit 1: right. Computed on edits/chunk drawing, never per frame.
static func connects(entry: Dictionary,neighbor: Dictionary,side: int) -> bool:
	if neighbor.has("fence"):return neighbor.fence.group==entry.fence.group
	if neighbor.has("gate"):return true
	# Only a full solid side accepts rails; plants, platforms and slabs do not.
	if not neighbor.get("solid",false) or int(neighbor.get("collision_height",16))<16:return false
	var boxes: Array=neighbor.get("collision_boxes",[])
	if boxes.is_empty():return true
	for box in boxes:
		if int(box[1])==0 and int(box[3])==16 and (int(box[0])==0 if side>0 else int(box[0])+int(box[2])==16):return true
	return false

static func mask(chunks: ChunkWorld,cell: Vector2i,entry: Dictionary) -> int:
	var result: int=0
	if connects(entry,BlockDatabase.BLOCKS.get(chunks.get_block(cell+Vector2i.LEFT),{}),-1):result|=1
	if connects(entry,BlockDatabase.BLOCKS.get(chunks.get_block(cell+Vector2i.RIGHT),{}),1):result|=2
	return result

static func configure(source: TileSetAtlasSource,entry: Dictionary) -> void:
	if not entry.has("fence"):return
	var variants: Array=[]
	var previous: Array=entry.get("fence_variants",[])
	for mask_value in range(4):
		var tile: Array=entry.fence.tiles[mask_value]
		var coords:=Vector2i(int(tile[0]),int(tile[1]))
		if not source.has_tile(coords):source.create_tile(coords)
		var alternative: int=int(previous[mask_value].alternative) if previous.size()==4 else -1
		if alternative<1 or not source.has_alternative_tile(coords,alternative):alternative=source.create_alternative_tile(coords)
		var data: TileData=source.get_tile_data(coords,alternative)
		data.modulate=entry.tint;data.set_collision_polygons_count(0,0 if entry.get("platform",false) else 1)
		if entry.get("platform",false):
			variants.append({"coords":coords,"alternative":alternative});continue
		var left: float=-8 if mask_value&1 else -2
		var right: float=8 if mask_value&2 else 2
		var top: float=8-float(entry.fence.collision_height)
		data.set_collision_polygon_points(0,0,PackedVector2Array([Vector2(left,top),Vector2(right,top),Vector2(right,8),Vector2(left,8)]))
		variants.append({"coords":coords,"alternative":alternative})
	entry["fence_variants"]=variants


static func outline_boxes(chunks: ChunkWorld,cell: Vector2i,entry: Dictionary) -> Array:
	var boxes: Array=[[6,0,4,16]]
	var connections: int=mask(chunks,cell,entry)
	for side in range(2):
		if connections&(1<<side):
			for y in [1,7]:boxes.append([0 if side==0 else 10,y,6,3])
	return boxes


static func collision_boxes(chunks: ChunkWorld,cell: Vector2i,entry: Dictionary) -> Array:
	var connections: int=mask(chunks,cell,entry)
	var left: int=0 if connections&1 else 6
	var right: int=16 if connections&2 else 10
	return [[left,16-int(entry.fence.collision_height),right-left,int(entry.fence.collision_height)]]
