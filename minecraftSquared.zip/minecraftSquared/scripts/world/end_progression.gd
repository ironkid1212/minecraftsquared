class_name EndProgression
extends Node2D
const PORTAL: Texture2D=preload("res://assets/environment/end/end_portal.png")
var world: Node2D
var eyes: Array[Dictionary]=[]
var active: Dictionary={}
var cooldown: float=0
var scan_time: float=0
var _busy: bool=false
var _time: float=0
static func frame_cells(center: Vector2i) -> Array[Vector2i]:
	var result: Array[Vector2i]=[]
	for i in range(-1,2):
		for offset in [Vector2i(i,-2),Vector2i(i,2),Vector2i(-2,i),Vector2i(2,i)]:result.append(center+offset)
	return result
func setup(game: Node2D) -> void:
	world=game;z_index=4;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	if not StrongholdGenerator.validate():DataFile.fail("strongholds.json: invalid generation or Eye rules.");set_process(false);return
	world.chunks.cell_changed.connect(changed)
func use(cell: Vector2i) -> bool:
	if world.get_interaction_item()!=BlockDatabase.id_for("ender_eye"):return false
	var rule: Dictionary=StrongholdGenerator.RULES.eye
	var frame: int=BlockDatabase.id_for("end_portal_frame")
	if world.get_block(cell)==frame and world.cell_is_reachable(cell):
		world.set_block(cell,BlockDatabase.id_for("end_portal_frame_filled"))
		if not world.player.creative:world.inventory.remove_from_slot(world.use_slot(),1)
		world.player.swing_hand("place",world.ground.to_global(world.ground.map_to_local(cell)))
		return true
	if world.is_nether() or cooldown>0 or eyes.size()>=int(rule.maximum_active):return true
	var plan: Dictionary=world.chunks.strongholds.nearest(world.mobs.cell(world.player.global_position))
	if plan.blocks.is_empty():world.show_mode_notice("The eye cannot locate a stronghold here.");return true
	var origin: Vector2=world.player.eye_position()
	var target: Vector2=world.ground.to_global(world.ground.map_to_local(plan.origin-Vector2i(0,3)))
	var dx: float=target.x-origin.x
	var near: bool=absf(dx)<=float(rule.near_range)*16
	var destination:=Vector2(target.x,target.y) if near else origin+Vector2(signf(dx)*float(rule.range)*16,-8*16)
	if near:destination=origin+Vector2(dx,clampf(target.y-origin.y,-12*16,12*16))
	eyes.append({"start":origin,"position":origin,"target":destination,"age":0.0,"creative":world.player.creative,"breaks":world.mobs.rng.randf()<float(rule.break_chance)})
	cooldown=float(rule.cooldown)
	if not world.player.creative:world.inventory.remove_from_slot(world.use_slot(),1)
	world.player.swing_hand("place",destination);queue_redraw();return true
func changed(cell: Vector2i,old: int,new: int) -> void:
	if _busy:return
	var frames: Array=[BlockDatabase.id_for("end_portal_frame"),BlockDatabase.id_for("end_portal_frame_filled")]
	if old not in frames and new not in frames:return
	for offset in frame_cells(Vector2i.ZERO):refresh_ring(cell-offset)
func refresh_ring(center: Vector2i) -> void:
	var complete: bool=true;var exists: bool=true
	for cell in frame_cells(center):
		if not world.chunks.is_cell_loaded(cell):return
		var id: int=world.get_block(cell)
		if id!=BlockDatabase.id_for("end_portal_frame_filled"):complete=false
		if id not in [BlockDatabase.id_for("end_portal_frame_filled"),BlockDatabase.id_for("end_portal_frame")]:exists=false
	if not exists and not active.has(center):return
	_busy=true
	for dx in range(-1,2):
		for dy in range(-1,2):
			var cell:=center+Vector2i(dx,dy)
			if complete and world.get_block(cell)!=BlockDatabase.id_for("end_portal"):world.set_block(cell,BlockDatabase.id_for("end_portal"))
			elif not complete and world.get_block(cell)==BlockDatabase.id_for("end_portal"):world.set_block(cell,0)
	if complete:active[center]=true
	else:active.erase(center)
	_busy=false;queue_redraw()
func _process(delta: float) -> void:
	var had_eyes: bool=not eyes.is_empty()
	if world.player.survival_dead:eyes.clear()
	_time+=delta;cooldown=maxf(0,cooldown-delta);scan_time-=delta
	if scan_time<=0:
		scan_time=.5
		if not world.is_nether() and world.chunks.strongholds.enabled():
			var index: int=world.chunks.strongholds.region_at(world.mobs.cell(world.player.global_position).x)
			for i in range(index-1,index+2):
				var p: Dictionary=world.chunks.strongholds.plan(i)
				if not p.blocks.is_empty():refresh_ring(p.portal)
		for center in active.keys():
			if world.chunks.is_cell_loaded(center):refresh_ring(center)
	for i in range(eyes.size()-1,-1,-1):
		var eye: Dictionary=eyes[i]
		if not world.chunks.is_cell_loaded(world.mobs.cell(eye.position)):continue
		eye.age+=delta
		var progress: float=clampf(float(eye.age)/maxf(.01,float(StrongholdGenerator.RULES.eye.flight_seconds)*.625),0,1)
		eye.position=Vector2(eye.start).lerp(eye.target,smoothstep(0,1,progress))
		if world.mobs.renderer.particles.size()<64 and fmod(eye.age,.15)<delta:world.mobs.renderer.particles.append({"position":eye.position,"velocity":Vector2(0,-2),"life":.5,"portal":true})
		if float(eye.age)>=float(StrongholdGenerator.RULES.eye.flight_seconds):
			if not eye.creative and not eye.breaks:world.dropped_items.spawn_item(BlockDatabase.id_for("ender_eye"),1,eye.position)
			else:world.mobs.renderer.portal_burst(eye.position)
			eyes.remove_at(i)
	if had_eyes or not eyes.is_empty() or not active.is_empty():queue_redraw()
func _draw() -> void:
	if world==null:return
	var view: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	for center in active:
		if not world.chunks.is_cell_loaded(center):continue
		for dx in range(-1,2):
			for dy in range(-1,2):
				var cell: Vector2i=center+Vector2i(dx,dy);var at: Vector2=world.ground.to_global(world.ground.map_to_local(cell))
				if not view.grow(8).has_point(at):continue
				var side: int=mini(16,PORTAL.get_width());var frames: int=maxi(1,PORTAL.get_height()/side)
				draw_texture_rect_region(PORTAL,Rect2(at-Vector2(8,8),Vector2(16,16)),Rect2(0,posmod(int(_time*8),frames)*side,side,side))
	for eye in eyes:
		if view.grow(8).has_point(eye.position):ItemDrawing.draw_icon(self,world.atlas_source,BlockDatabase.id_for("ender_eye"),Rect2(Vector2(eye.position)-Vector2(4,4),Vector2(8,8)),Color.WHITE)
func clear() -> void:eyes.clear();active.clear();cooldown=0;scan_time=0;queue_redraw()
func snapshot() -> Array:
	var result: Array=[]
	for e in eyes:result.append({"start":[e.start.x,e.start.y],"position":[e.position.x,e.position.y],"target":[e.target.x,e.target.y],"age":e.age,"creative":e.creative,"breaks":e.breaks})
	return result
func portal_snapshot() -> Array:
	var result: Array=[]
	for cell in active:result.append([cell.x,cell.y])
	return result
func restore(records: Array,portals: Array=[]) -> void:
	clear()
	for cell in portals:active[Vector2i(cell[0],cell[1])]=true
	for e in records:eyes.append({"start":Vector2(e.start[0],e.start[1]),"position":Vector2(e.position[0],e.position[1]),"target":Vector2(e.target[0],e.target[1]),"age":float(e.age),"creative":e.creative,"breaks":e.breaks})
static func valid(records: Variant) -> bool:
	if not records is Array or records.size()>int(StrongholdGenerator.RULES.eye.maximum_active):return false
	for e in records:
		if not e is Dictionary or not ContentCatalog._vector(e.get("start"),2,-160000000,160000000) or not ContentCatalog._vector(e.get("position"),2,-160000000,160000000) or not ContentCatalog._vector(e.get("target"),2,-160000000,160000000) or not ContentCatalog._number(e.get("age"),0,float(StrongholdGenerator.RULES.eye.flight_seconds)) or not e.get("creative") is bool or not e.get("breaks") is bool:return false
	return true
