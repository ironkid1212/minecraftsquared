class_name TorchMounting
extends RefCounted

const INVALID := Vector2i.UP
const SIDES := [Vector2i.DOWN, Vector2i.LEFT, Vector2i.RIGHT]

static func is_attached(id: int) -> bool:
	var key: String = str(BlockDatabase.BLOCKS.get(id, {}).get("key", ""))
	return BlockDatabase.UPDATE_RULES.get("blocks", {}).get(key, {}).get("behavior") == "attached"

static func valid(chunks: ChunkWorld, cell: Vector2i, side: Vector2i, background: bool = true) -> bool:
	if side == Vector2i.ZERO: return background and chunks.has_background_wall(cell)
	if side not in SIDES: return false
	var block: Dictionary = BlockDatabase.BLOCKS.get(chunks.get_block(cell + side), {})
	return "plant" not in block.get("tags", []) and bool(block.get("solid", false) or block.get("platform", false))

static func choose(chunks: ChunkWorld, cell: Vector2i, background: bool = true, pointer: Variant = null) -> Vector2i:
	var best: Vector2i = INVALID
	var distance: float = INF
	var center: Vector2 = chunks.ground.map_to_local(cell)
	for side in SIDES:
		if not valid(chunks, cell, side, background): continue
		if pointer == null: return side
		var candidate: float = Vector2(pointer).distance_squared_to(center + Vector2(side) * 8.0)
		if candidate < distance:
			distance = candidate
			best = side
	if best != INVALID: return best
	return Vector2i.ZERO if background and chunks.has_background_wall(cell) else INVALID

static func resolve(chunks: ChunkWorld, cell: Vector2i, background: bool = true) -> Vector2i:
	if chunks.torch_mounts.has(cell): return chunks.torch_mounts[cell]
	var side: Vector2i = choose(chunks, cell, background)
	if side != INVALID: chunks.torch_mounts[cell] = side
	return side

static func vertices(chunks: ChunkWorld, cell: Vector2i, side: Vector2i, size: Vector2, config: WorldUpdateSettings) -> PackedVector2Array:
	var p: Vector2 = chunks.ground.map_to_local(cell) - size * 0.5
	var result := PackedVector2Array([p, p + Vector2(size.x, 0), p + size, p + Vector2(0, size.y)])
	if side not in [Vector2i.LEFT, Vector2i.RIGHT]: return result
	var direction: float = 1.0 if side == Vector2i.LEFT else -1.0
	var anchor := Vector2(p.x + config.wall_torch_inset if side == Vector2i.LEFT else p.x + size.x - config.wall_torch_inset, p.y + size.y * 0.75)
	var pivot := p + Vector2(size.x * 0.5, size.y)
	var angle: float = deg_to_rad(config.wall_torch_angle) * direction
	for index in range(result.size()): result[index] = anchor + (result[index] - pivot).rotated(angle)
	return result
