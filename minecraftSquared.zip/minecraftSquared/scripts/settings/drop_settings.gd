class_name DropSettings
extends Resource
@export_group("Throwing")
@export_range(16.0,320.0) var throw_speed: float=96.0
@export_range(0.0,80.0) var throw_upward_bias: float=32.0
@export_range(0.0,5.0) var throw_pickup_delay: float=2.0

@export_group("Pickup (pixels and seconds)")
@export_range(0.0, 3.0) var pickup_delay: float = 0.35
@export_range(8.0, 128.0) var magnet_radius: float = 52.0
@export_range(4.0, 32.0) var pickup_radius: float = 14.0
@export_range(20.0, 400.0) var magnet_speed: float = 160.0
@export_range(0.0, 64.0) var merge_radius: float = 16.0
## Loaded seconds; drops freeze while their chunk is unloaded.
@export_range(10.0, 3600.0) var lifetime: float = 300.0
@export_group("Physics")
@export_range(100.0, 1500.0) var gravity: float = 480.0
@export_range(100.0, 600.0) var terminal_speed: float = 300.0
@export_range(0.0, 0.8) var bounce: float = 0.22
@export_range(4.0, 12.0) var icon_size: float = 8.0
