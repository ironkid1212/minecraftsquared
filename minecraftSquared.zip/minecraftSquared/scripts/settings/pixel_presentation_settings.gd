class_name PixelPresentationSettings
extends Resource

@export_group("World pixel grid")
## Select whole-number scale from window size. The field of view can expand slightly.
@export var automatic_scale: bool = true
## Approximately the previous world view at 1280x720 and camera zoom 3.
@export var reference_size := Vector2i(426,240)
@export_range(1,8,1) var fixed_scale: int = 3
@export_range(1,8,1) var maximum_scale: int = 8
@export var gutter_color := Color.BLACK

func scale_for(window_size: Vector2i) -> int:
	if not automatic_scale:
		return clampi(fixed_scale,1,maximum_scale)
	var reference: Vector2i = reference_size.max(Vector2i(2,2))
	return clampi(floori(minf(float(window_size.x)/reference.x,float(window_size.y)/reference.y)),1,maximum_scale)
