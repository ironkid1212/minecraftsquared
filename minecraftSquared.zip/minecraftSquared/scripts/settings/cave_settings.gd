class_name CaveSettings
extends Resource

@export_group("Generation mode")
## Turn off all caves without changing surface terrain.
@export var enabled: bool = true
## Old saves explicitly retain their previous carver. New worlds combine noise caves.
@export_storage var noise_caves: bool = true
@export_group("Minecraft-style noise caves")
## Larger values create wider, more widely spaced cavern features.
@export_range(0.003, 0.06, 0.001) var cavern_frequency: float = 0.018
## Lower values produce more large chambers. Raise this to retain more solid rock.
@export_range(0.1, 0.8, 0.01) var cavern_threshold: float = 0.38
@export_range(0.005, 0.08, 0.001) var tunnel_frequency: float = 0.026
## Width of the spaghetti noise band, not a radius in blocks.
@export_range(0.02, 0.2, 0.005) var tunnel_width: float = 0.085
## Minimum spaghetti half-width in blocks, adapted to a two-block-tall player.
@export_range(1.5, 4.0, 0.1) var spaghetti_min_radius: float = 2.0
## Higher values restrict spaghetti tunnels to fewer underground regions.
@export_range(-0.8, 0.8, 0.01) var tunnel_region_threshold: float = 0.05
@export var noodles_enabled: bool = true
@export_range(0.015, 0.1, 0.005) var noodle_width: float = 0.035
## Noise caves stay below this solid surface cap, except at dedicated entrances.
@export_range(4, 32, 1) var surface_cap: int = 8
@export_group("Entrance spacing")
## Horizontal width of each independent seeded cave region, in blocks.
@export_range(48, 512, 1) var region_width: int = 128
@export_storage var systems_per_region: int = 1
@export_storage var system_probability: float = 1.0
@export_storage var shallow_depth: int = 20
@export_storage var shallow_length: int = 65
@export_storage var shallow_radius: float = 2.8
@export_storage var branch_count: int = 2
@export_storage var branch_length: int = 20
@export_storage var branch_radius: float = 2.5
@export_storage var deep_enabled: bool = true
@export_storage var deep_depth_ratio: float = 0.7
@export_storage var deep_length: int = 45
@export_storage var deep_radius: float = 3.4
@export_storage var connection_radius: float = 2.6
@export_group("Chambers")
@export var rooms_enabled: bool = true
@export_storage var shallow_room_size := Vector2(8.0, 4.5)
@export_storage var deep_room_size := Vector2(10.0, 6.0)
@export_group("Surface and shape")
## 0 disables entrances; 1 creates one in every region; 2 every other region.
@export_range(0, 16, 1) var entrance_every: int = 2
@export_range(1.5, 8.0) var entrance_radius: float = 2.6
@export_storage var minimum_cover: int = 5
@export_storage var roof_clearance: int = 6
@export_range(1, 12, 1) var bottom_margin: int = 3
## Minimum tunnel half-width. Lower values permit narrow passages.
@export_storage var minimum_radius: float = 2.4
@export_storage var turn_jitter: float = 0.16
@export_storage var step_length: float = 1.3
@export_storage var radius_variation := Vector2(0.8, 1.65)
@export_storage var radius_smoothing: float = 0.16
@export_storage var smoothing_passes: int = 2
@export_storage var smoothing_neighbors: int = 5

@export_group("Cavern structure")
## Saved worlds without this field retain the original noise density.
@export_storage var layered_caverns: bool = true
## Lower values create taller chambers. Independent of horizontal frequency.
@export_range(0.7, 2.0, 0.05) var cavern_vertical_scale: float = 1.2
## Add irregular shelves within spacious chambers.
@export_range(0.0, 0.3, 0.01) var cavern_shelf_strength: float = 0.10
## Larger values leave fewer stone columns inside caverns.
@export_range(0.3, 0.9, 0.01) var cavern_pillar_threshold: float = 0.60
