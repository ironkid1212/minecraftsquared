class_name TreeSettings
extends Resource

@export_group("Oak distribution")
@export_range(1, 3, 1) var fancy_revision: int = 3
@export_file("*.json") var fancy_shapes_path: String = "res://data/fancy_oak_shapes.json"
@export_range(0, 4, 1) var fancy_extra_trunk: int = 2
@export_range(0.0, 1.0, 0.05) var fancy_mirror_chance: float = 0.35
@export_range(8, 48, 1) var slot_width: int = 12
@export_range(0.0, 1.0) var tree_chance: float = 0.8
@export_range(0.0, 1.0) var fancy_oak_chance: float = 0.18
@export_group("Height ranges (blocks)")
@export var regular_height := Vector2i(4, 6)
@export var fancy_height := Vector2i(3, 14)
@export_group("Materials")
@export var log_block: String = "oak_log"
@export var leaf_block: String = "oak_leaves"
