class_name LightingSettings
extends Resource

@export_group("Daylight and rock shading")
@export_range(4.0, 40.0) var surface_fade_depth: float = 18.0
@export_range(0.0, 1.0) var surface_ambient: float = 0.78
@export_range(0.0, 0.2) var underground_ambient: float = 0.045
@export_range(0, 8, 1) var solid_shade_depth: int = 4
@export_range(1, 6, 1) var solid_shade_loss: int = 3
@export_range(0.01, 0.3) var minimum_brightness: float = 0.04
@export_range(0.5, 3.0) var brightness_curve: float = 1.4
@export_group("Colors")
@export var sky_color := Color("#87b6d0")
@export var wall_tint := Color(0.48, 0.44, 0.40, 1.0)
@export var torch_tint := Color(1.0, 0.80, 0.55, 1.0)
