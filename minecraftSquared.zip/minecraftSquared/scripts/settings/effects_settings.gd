class_name EffectsSettings
extends Resource
@export_group("Sound")
@export_range(0,1,.01) var master_volume: float=.7
@export_range(0,1,.01) var blocks_volume: float=.75
@export_range(0,1,.01) var entities_volume: float=.8
@export_range(0,1,.01) var player_volume: float=.8
@export_range(0,1,.01) var ambient_volume: float=.35
@export_range(0,1,.01) var interface_volume: float=.5
@export_range(4,32,1) var sound_voices: int=20
@export_range(128,768,16) var hearing_distance: float=384
@export_group("Particles")
@export_range(0,1,.05) var particle_density: float=1
@export_range(32,512,16) var particle_limit: int=192
@export_range(16,128,8) var ambient_scan_budget: int=48
@export_range(1,16,1) var ambient_emit_budget: int=8
@export_range(16,128,8) var explosion_puff_limit: int=64
