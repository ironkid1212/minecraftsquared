class_name PlayerSettings
extends Resource

@export_group("Movement (pixels per second)")
@export_range(30.0, 400.0) var move_speed: float = 69.07489
@export_range(100.0, 600.0) var jump_speed: float = 134.4
@export_range(100.0, 2000.0) var gravity: float = 512.0
## Recover to spawn this far below the world bottom, in pixels.
@export var recovery_margin: float = 256.0
## Per-20Hz-tick friction; converted exponentially at the physics frame rate.
@export_range(0.1, 0.99) var ground_drag: float = 0.546
@export_range(0.1, 0.999) var air_drag: float = 0.91
@export_range(0.1, 1.0) var vertical_drag: float = 0.98
@export_range(0.0, 100.0) var sprint_jump_impulse: float = 64.0
@export_range(1.0, 2.0) var sprint_stride_factor: float = 1.3
## Minecraft's 0.6-block step height, expressed in this game's 16px blocks.
@export_range(0.0, 12.0, 0.1) var step_height: float = 9.6
## Contact tolerance only. Descending slabs/stairs uses gravity, not a step-height snap.
@export_range(0.0, 1.0, 0.05) var floor_snap_distance: float = 0.1
@export_group("Sneaking and sprinting")
@export_range(0.1, 1.0, 0.05) var crouch_speed_factor: float = 0.3
@export_range(1.0, 2.0, 0.05) var sprint_speed_factor: float = 1.3
@export_range(0.1, 0.6, 0.05) var double_tap_seconds: float = 0.35
@export_range(16.0, 27.0, 1.0) var crouch_height: float = 24.0
@export_range(8.0, 14.0, 1.0) var swim_height: float = 10.0
@export_range(1.0, 2.0, 0.05) var swim_sprint_speed_factor: float = 1.3
@export var sneak_edge_protection: bool = true
@export_group("2D skin")
## v1: 48x32 RGBA PNG, or an integer multiple, using our documented part layout.
@export var skin_texture: Texture2D = preload("res://assets/skins/steve_2d.png")
@export var outer_layers: bool = true
## Extra size on each edge, in model pixels; independent of skin resolution.
@export_range(0.0, 2.0, 0.05) var hat_layer_expansion: float = 0.5
@export_range(0.0, 2.0, 0.05) var clothing_layer_expansion: float = 0.25
@export_range(0.25, 1.0) var far_limb_brightness: float = 0.72
@export_group("Skin animation")
## Radians. Swing arms and legs around their shoulders/hips while walking.
@export_range(0.0, 1.2) var walk_swing: float = 0.45
## Pixels travelled per full walk cycle. Animation stops when pushing a wall.
@export_range(16.0, 80.0) var stride_length: float = 48.0
## Minecraft's normal leg swing is larger than its arm swing; no special jump pose.
@export_range(0.0, 2.0) var leg_swing_multiplier: float = 1.15

## Stop the visual gait promptly even while movement friction settles.
@export_range(1.0, 40.0) var walk_settle_speed: float = 20.0
@export_range(0.0, 1.2) var maximum_leg_swing: float = 0.6
@export_group("Mouse look")
@export_range(0.0, 85.0) var maximum_head_pitch: float = 60.0
@export_range(1.0, 30.0) var head_follow_speed: float = 14.0
## World pixels around the head where mouse X does not flip the body direction.
@export_range(0.0, 12.0) var mouse_turn_dead_zone: float = 3.0
@export_group("Held items")
@export_enum("Right", "Left") var main_hand: int = 0
@export_range(2.0, 16.0) var held_block_size: float = 6.0
@export_range(4.0, 20.0) var held_item_size: float = 9.0
## Additional rotation after the Minecraft display profile, in degrees.
@export_range(-90.0, 90.0) var held_block_angle_offset: float = 0.0
@export_range(-90.0, 90.0) var held_item_angle_offset: float = 0.0
## Forward arm tilt while holding an item, in degrees.
@export_range(0.0, 60.0) var holding_arm_angle: float = 18.0
## Forward tilt of the offhand while holding an item; shares the shoulder pivot.
@export_range(0.0, 60.0) var offhand_arm_angle: float = 10.0
@export_group("Hand actions")
## Eating arm tilt is independent of ordinary holding and mining poses.
@export_range(70.0, 140.0, 1.0) var eating_arm_angle: float = 110.0
@export_range(0.0, 0.3, 0.01) var eating_bob: float = 0.08
@export_range(0.1, 0.8) var mining_swing_duration: float = 0.3
@export_range(0.1, 0.8) var placing_swing_duration: float = 0.22
@export_range(0.0, 100.0) var mining_windup: float = 60.0
@export_range(0.0, 100.0) var placing_windup: float = 35.0
@export_range(0.0, 60.0) var action_follow_through: float = 22.0

@export_group("Spectator flight")
## Minecraft-like adjustable fly speed, converted to this game's 16px blocks.
@export_range(100.0, 2000.0, 10.0) var spectator_base_speed: float = 700.0
@export_range(1.0, 6.0, 0.1) var spectator_sprint_multiplier: float = 3.0
@export_range(1.0, 30.0, 0.5) var spectator_acceleration: float = 10.0
