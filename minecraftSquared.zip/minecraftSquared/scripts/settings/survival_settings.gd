class_name SurvivalSettings
extends Resource

@export_group("Health")
@export_range(2, 40, 2) var maximum_health: int = 20
@export_range(0.0, 10.0, 0.25) var safe_fall_blocks: float = 3.0
@export_range(0.0, 10.0, 0.25) var fall_damage_per_block: float = 1.0
@export_range(0.0, 3.0, 0.05) var damage_invulnerability: float = 0.5
@export_range(0.0, 10.0, 0.25) var respawn_invulnerability: float = 2.0
@export_range(0.0, 2.0, 0.05) var damage_flash_seconds: float = 0.5
@export_group("Heart feedback")
## HUD timing is independent of the player's red hurt tint.
@export_range(0.0, 3.0, 0.05) var health_blink_seconds: float = 1.0
@export_range(1, 10, 1) var heart_blink_ticks: int = 3
@export_range(0.0, 3.0, 0.05) var health_history_seconds: float = 1.0
@export var low_health_jitter: bool = true
@export_group("Recovery")
## Hunger and saturation determine healing speed; this enables natural regeneration.
@export var regeneration_enabled: bool = true
## Retained only for compatibility with old resources and pre-hunger callers.
@export_storage var regeneration_delay: float = 8.0
@export_storage var regeneration_interval: float = 4.0
@export_group("Death and respawn")
@export var drop_inventory_on_death: bool = true
@export_range(4, 64, 1) var respawn_search_radius: int = 32
@export_file("*.json") var beds_path: String = "res://data/beds.json"
## One-time upgrade supplies use counts from the existing starting inventory file.
@export var migration_starter_keys: PackedStringArray = PackedStringArray(["white_wool"])

func validate() -> bool:
	if maximum_health < 2 or maximum_health > 40 or safe_fall_blocks < 0 or fall_damage_per_block < 0 or damage_invulnerability < 0 or respawn_invulnerability < 0 or damage_flash_seconds < 0 or regeneration_delay < 0 or regeneration_interval <= 0 or health_blink_seconds < 0 or heart_blink_ticks < 1 or health_history_seconds < 0 or respawn_search_radius < 4 or respawn_search_radius > 64:
		DataFile.fail("survival.tres: invalid health, damage, recovery or respawn values.")
		return false
	return true
