class_name FarmingSettings
extends Resource
@export var enabled: bool = true
@export_file("*.json") var rules_path: String = "res://data/farming.json"
@export_range(0.1,20.0) var growth_multiplier: float = 1.0
