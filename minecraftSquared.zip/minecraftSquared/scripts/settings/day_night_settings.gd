class_name DayNightSettings
extends Resource

@export_group("Clock")
@export var enabled: bool = true
## A full 24,000-tick cycle takes twenty real minutes by default.
@export_range(10.0, 86400.0, 10.0) var cycle_seconds: float = 1200.0
@export_range(0, 23999, 1) var initial_time: int = 1000
@export_group("Lighting")
@export_range(0.0, 1.0, .01) var night_sky_light: float = .27
@export_range(0.0, 1.0, .01) var night_ambient_factor: float = .18
@export_range(16, 256, 1) var lighting_steps: int = 128
@export_group("Sky")
@export var day_zenith := Color("77a5ef")
@export var day_horizon := Color("bbd6ee")
@export var night_zenith := Color("020410")
@export var night_horizon := Color("10182a")
@export var twilight_color := Color("ed8658")
@export_range(.4, .95, .01) var horizon_height: float = .78
@export_range(.2, .75, .01) var arc_height: float = .60
@export_range(16, 240, 1) var sun_size: int = 240
@export_range(16, 240, 1) var moon_size: int = 192
@export_group("Stars and clouds")
@export_range(0, 500, 1) var star_count: int = 150
@export_range(.0, 1.0, .05) var star_brightness: float = .85
@export var clouds_enabled: bool = true
@export_range(0.0, 5.0, .1) var cloud_speed: float = 1.0

func validate() -> bool:
	if not ContentCatalog._number(cycle_seconds,10,86400) or initial_time<0 or initial_time>=24000 or not ContentCatalog._number(night_sky_light,0,1) or not ContentCatalog._number(night_ambient_factor,0,1) or lighting_steps<16 or lighting_steps>256 or sun_size<1 or sun_size>256 or moon_size<1 or moon_size>256 or star_count<0 or star_count>500 or not ContentCatalog._number(star_brightness,0,1) or not ContentCatalog._number(horizon_height,.4,.95) or not ContentCatalog._number(arc_height,.2,.75) or not ContentCatalog._number(cloud_speed,0,5):
		DataFile.fail("day_night.tres: invalid clock, lighting or sky settings.")
		return false
	return true
