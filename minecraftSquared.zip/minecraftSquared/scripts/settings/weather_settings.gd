class_name WeatherSettings
extends Resource

@export var enabled: bool = true
@export var cycling: bool = true
## Real seconds: vanilla clear delay is 12,000–180,000 ticks at 20Hz.
@export var clear_duration := Vector2(600,9000)
@export var rain_duration := Vector2(600,1200)
@export_range(0.0,1.0) var thunder_chance: float = 0.2
@export_range(0.1,30.0) var fade_seconds: float = 5.0
@export_range(0.1,1.0) var rain_daylight: float = 0.65
@export_range(0.1,1.0) var thunder_daylight: float = 0.35
@export var lightning_interval := Vector2(15,60)
@export_file("*.png") var rain_texture: String = "res://assets/environment/rain.png"
