class_name TerrainSettings
extends Resource

@export var structures_enabled: bool=true
@export var strongholds_enabled: bool=true
@export var lush_caves_enabled: bool=true
@export_range(1,2) var structures_revision: int=2

@export_range(1,4) var biome_revision: int = 4

@export_group("World dimensions (blocks)")
@export var seed: int = 12345
@export_storage var depth: int = 384
@export_range(6, 1000, 1) var surface_level: int = 257
@export_storage var hill_height: int = 10
@export_range(1, 32, 1) var dirt_depth: int = 4
@export_storage var hill_frequency: float = 0.035
@export_storage var hill_octaves: int = 3
@export_storage var region_frequency: float = 0.0015
@export_storage var plains_frequency: float = 0.008
@export_storage var mountain_frequency: float = 0.003
@export_group("Materials (block keys)")
@export_storage var surface_block: String = "grass"
@export var soil_block: String = "dirt"
@export_storage var rock_block: String = "stone"
@export_group("Streaming")
## Radius in 32x32-block chunks. Keep enough chunks to cover the camera.
@export var load_radius := Vector2i(2, 1)
## Soft budget in milliseconds; one column/chunk may exceed it.
@export_range(0.5, 10.0) var stream_budget_ms: float = 2.0

@export_storage var gravel_enabled: bool = true
@export_storage var gravel_block: String = "gravel"
@export_storage var gravel_frequency: float = 0.09
@export_storage var gravel_threshold: float = 0.58
@export_storage var gravel_min_depth: int = 10

@export_group("Modern Overworld")
@export_storage var biome_generation: bool = true
@export_file("*.json") var biomes_path: String = "res://data/biomes.json"
@export_storage var modern_generation: bool = true
@export var top_y: int = 319
@export var bottom_y: int = -64
@export_storage var mountain_height: int = 72
## Larger thresholds reserve raised terrain for rarer regions.
@export_storage var mountain_start: float = 0.12
@export_storage var mountain_full: float = 0.55
## Average neighboring samples to soften abrupt changes without flat plateaus.
@export_storage var surface_smoothing_radius: int = 8

@export_group("Biome scale and soil")
## Horizontal climate scale: 0.5 gives roughly half the old biome width.
@export_range(0.1, 4.0, 0.05) var biome_size: float = 0.5
## Scale of continental/erosion/peak regions. Does not increase mountain height.
@export_range(0.25, 4.0, 0.05) var terrain_region_size: float = 0.75
## Guaranteed dirt blocks below grass; additional noisy soil remains below this.
@export_range(0, 12, 1) var minimum_dirt_depth: int = 3

@export_group("Coherent biome regions")
## Existing saves keep their original per-column climate selection.
@export_storage var coherent_biomes: bool = true
## Nominal width before applying Biome Size. Boundaries receive seeded jitter.
@export_range(64, 512, 1) var biome_region_width: int = 192
## Absolute floor preventing thin biome strips, even with small Biome Size.
@export_range(16, 256, 1) var minimum_biome_width: int = 64
## Vegetation taper width and maximum underground seam spread.
## Revision 2 uses one continuous boundary, never random material patches.
@export_range(0, 64, 1) var biome_transition_width: int = 24

## New worlds use climate placement, continuous seams and balanced 2D ores.
## Saved worlds retain the revision they were created with.
@export_storage var generation_revision: int = 2
