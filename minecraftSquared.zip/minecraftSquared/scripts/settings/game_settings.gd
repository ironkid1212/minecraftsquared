class_name GameSettings
extends Resource

@export_group("Gameplay")
@export_range(16.0, 160.0) var interaction_reach: float = 64.0
@export_file("*.json") var starting_inventory_path: String = "res://data/starting_inventory.json"

@export_group("Systems")
@export var weather: WeatherSettings = preload("res://data/settings/weather.tres")
@export var farming: FarmingSettings = preload("res://data/settings/farming.tres")
@export var fluid: FluidSettings = preload("res://data/settings/fluid.tres")
@export var world_updates: WorldUpdateSettings = preload("res://data/settings/world_updates.tres")
@export var cave: CaveSettings = preload("res://data/settings/cave.tres")
@export var terrain: TerrainSettings = preload("res://data/settings/terrain.tres")
@export var tree: TreeSettings = preload("res://data/settings/tree.tres")
@export var interface: InterfaceSettings = preload("res://data/settings/interface.tres")
@export var lighting: LightingSettings = preload("res://data/settings/lighting.tres")
@export var drop: DropSettings = preload("res://data/settings/drop.tres")
@export var day_night: DayNightSettings = preload("res://data/settings/day_night.tres")
@export var survival: SurvivalSettings = preload("res://data/settings/survival.tres")
@export var player: PlayerSettings = preload("res://data/settings/player.tres")


func validate() -> bool:
	var issues: PackedStringArray = []
	if weather!=null:
		for duration in [weather.clear_duration,weather.rain_duration,weather.lightning_interval]:
			if not is_finite(duration.x) or not is_finite(duration.y) or duration.x<=0 or duration.y<duration.x: issues.append("Weather: invalid duration range.")
		for value in [weather.rain_daylight,weather.thunder_daylight,weather.thunder_chance]:
			if not ContentCatalog._number(value,0,1): issues.append("Weather: factors must be between zero and one.")
		if not ContentCatalog._number(weather.fade_seconds,.1,30) or not ResourceLoader.exists(weather.rain_texture): issues.append("Weather: invalid fade time or rain texture.")
	if fluid != null and not fluid.validate(): return false
	if day_night != null and not day_night.validate(): return false
	if survival != null and not survival.validate(): return false
	if weather == null or farming == null or fluid == null or day_night == null or survival == null or world_updates == null or terrain == null or cave == null or tree == null or interface == null or lighting == null or drop == null or player == null:
		DataFile.fail("game.tres: every system settings resource is required.")
		return false
	for entry in [[player.crouch_speed_factor,.1,1],[player.sprint_speed_factor,1,2],[player.double_tap_seconds,.1,.6],[player.crouch_height,16,27],[player.swim_height,8,14],[player.swim_sprint_speed_factor,1,2]]:
		if not ContentCatalog._number(entry[0],entry[1],entry[2]): issues.append("Player: invalid sneak/sprint/swim setting.")
	for entry in [[player.ground_drag,.1,.99],[player.air_drag,.1,.999],[player.vertical_drag,.1,1],[player.sprint_jump_impulse,0,100],[player.sprint_stride_factor,1,2],[player.move_speed,1,400],[player.jump_speed,1,600],[player.gravity,1,2000]]:
		if not ContentCatalog._number(entry[0],entry[1],entry[2]): issues.append("Player: invalid movement/drag setting.")
	if terrain.biome_revision not in [1,2,3,4]: issues.append("Terrain: unsupported biome revision.")
	if terrain.structures_revision not in [1,2]:issues.append("Terrain: unsupported structure revision.")
	for entry in [[player.step_height,0,12],[player.walk_settle_speed,1,40],[player.maximum_leg_swing,0,1.2]]:
		if not ContentCatalog._number(entry[0],entry[1],entry[2]): issues.append("Player: invalid step or gait setting.")
	if tree.fancy_revision not in [1,2,3] or not ContentCatalog._number(tree.fancy_extra_trunk,0,4,true) or not ContentCatalog._number(tree.fancy_mirror_chance,0,1): issues.append("Trees: invalid fancy oak settings.")
	if world_updates.budget_ms <= 0 or world_updates.max_updates_per_frame < 1 or world_updates.scan_cells_per_frame < 1 or world_updates.random_tick_interval <= 0 or world_updates.random_samples_per_chunk < 0 or world_updates.fall_interval <= 0 or world_updates.grass_death_seconds <= 0 or world_updates.leaf_decay_min_seconds <= 0 or world_updates.leaf_decay_max_seconds < world_updates.leaf_decay_min_seconds or world_updates.simulation_radius.x < 0 or world_updates.simulation_radius.y < 0:
		issues.append("World updates: positive budgets/times, ordered leaf delays and nonnegative radius required.")
	if world_updates.falling_gravity <= 0 or world_updates.falling_terminal_speed <= 0 or world_updates.falling_drag <= 0 or world_updates.falling_drag > 1 or world_updates.max_falling_blocks < 1:
		issues.append("Falling blocks: positive acceleration, speed, capacity and drag in (0,1] required.")
	if terrain.gravel_enabled and (terrain.gravel_frequency <= 0 or terrain.gravel_threshold < 0 or terrain.gravel_threshold > 1 or terrain.gravel_min_depth < 1):
		issues.append("Gravel: positive frequency/depth and threshold in [0,1] required.")
	if terrain.depth < 96 or terrain.surface_level < 6 or terrain.surface_level >= terrain.depth - 24 or terrain.dirt_depth < 1:
		issues.append("Terrain: depth >= 96, surface in [6, depth-24), and dirt depth >= 1 required.")
	if terrain.load_radius.x < 1 or terrain.load_radius.y < 1 or terrain.stream_budget_ms <= 0:
		issues.append("Terrain: positive load radius and streaming budget required.")
	if terrain.modern_generation and (terrain.top_y - terrain.bottom_y + 1 < 96 or terrain.surface_level >= terrain.top_y - terrain.bottom_y - 23 or terrain.mountain_height < 0):
		issues.append("Modern terrain: height >= 96, surface above the bottom margin, and nonnegative mountain height required.")
	if terrain.modern_generation and (terrain.mountain_full <= terrain.mountain_start or terrain.surface_smoothing_radius < 0 or terrain.surface_smoothing_radius > 64):
		issues.append("Modern terrain: mountain full must exceed mountain start; smoothing radius must be 0-64.")
	if terrain.generation_revision not in [1, 2]:
		issues.append("Terrain: unsupported generation revision.")
	if terrain.biome_size < 0.1 or terrain.terrain_region_size < 0.25 or terrain.minimum_dirt_depth < 0 or terrain.minimum_dirt_depth > 12:
		issues.append("Biomes: positive climate/terrain scale and dirt depth 0-12 required.")
	if terrain.biome_region_width < 64 or terrain.minimum_biome_width < 16 or terrain.minimum_biome_width > 256 or terrain.biome_transition_width < 0 or terrain.biome_transition_width > 64:
		issues.append("Biome regions: nominal width >= 64, minimum width 16-256 and transition 0-64 required.")
	if cave.cavern_vertical_scale < 0.7 or cave.cavern_vertical_scale > 2.0 or cave.cavern_shelf_strength < 0 or cave.cavern_shelf_strength > 0.3 or cave.cavern_pillar_threshold < 0.3 or cave.cavern_pillar_threshold > 0.9:
		issues.append("Caverns: vertical scale 0.7-2, shelves 0-0.3 and pillar threshold 0.3-0.9 required.")
	if cave.cavern_frequency <= 0 or cave.tunnel_frequency <= 0 or cave.tunnel_width <= 0 or cave.noodle_width <= 0 or cave.surface_cap < 4 or cave.spaghetti_min_radius < 1.5 or cave.spaghetti_min_radius > 4:
		issues.append("Noise caves: positive frequencies/widths and surface cap >= 4 required.")
	if player.spectator_base_speed <= 0 or player.spectator_sprint_multiplier < 1 or player.spectator_acceleration <= 0:
		issues.append("Spectator: positive speed/acceleration and sprint multiplier >= 1 required.")
	if cave.region_width < 48 or cave.systems_per_region < 0 or cave.systems_per_region > 4 or cave.system_probability < 0 or cave.system_probability > 1:
		issues.append("Caves: region width >= 48, systems 0-4, probability 0-1 required.")
	if cave.shallow_radius < 1 or cave.deep_radius < 1 or cave.branch_radius < 1 or cave.connection_radius < 1 or cave.entrance_radius < 1 or cave.minimum_radius < 1:
		issues.append("Caves: all radii must be at least one block.")
	if cave.shallow_length < 1 or cave.deep_length < 1 or cave.branch_length < 1 or cave.bottom_margin < 1 or cave.minimum_cover < 1 or cave.roof_clearance < 1:
		issues.append("Caves: lengths and clearances must be positive.")
	if cave.radius_variation.x <= 0 or cave.radius_variation.y < cave.radius_variation.x or cave.radius_smoothing <= 0 or cave.radius_smoothing > 1 or cave.step_length <= 0:
		issues.append("Caves: invalid radius variation, smoothing or step length.")
	if tree.slot_width < 8 or tree.regular_height.x < 1 or tree.regular_height.y < tree.regular_height.x or tree.fancy_height.x < 1 or tree.fancy_height.y < tree.fancy_height.x:
		issues.append("Trees: slot width >= 8 and ordered positive height ranges required.")
	if drop.pickup_radius > drop.magnet_radius:
		issues.append("Drops: pickup radius must not exceed magnet radius.")
	if interaction_reach <= 0 or interface.maximum_scale < 1 or interface.font == null:
		issues.append("Gameplay/UI: positive reach, UI scale and a font required.")
	if not PlayerSkinDrawing.valid_texture(player.skin_texture):
		issues.append("Player: skin texture must be a 48x32 PNG or integer multiple of that layout.")
	if player.stride_length <= 0:
		issues.append("Player: stride length must be positive.")
	if player.mining_swing_duration <= 0 or player.placing_swing_duration <= 0 or player.head_follow_speed <= 0:
		issues.append("Player: action durations and head follow speed must be positive.")
	for message in issues:
		DataFile.fail(message)
	return issues.is_empty()
