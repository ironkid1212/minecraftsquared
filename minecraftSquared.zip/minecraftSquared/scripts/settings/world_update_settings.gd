class_name WorldUpdateSettings
extends Resource

@export var enabled: bool = true
@export_group("Work budget")
## Only loaded chunks this near the player simulate.
@export var simulation_radius := Vector2i(2, 1)
@export_range(0.2, 8.0, 0.1) var budget_ms: float = 1.5
@export_range(1, 256, 1) var max_updates_per_frame: int = 24
@export_range(16, 2048, 16) var scan_cells_per_frame: int = 256
@export_group("Random ticks")
@export_range(0.05, 5.0, 0.05) var random_tick_interval: float = 0.2
@export_range(0, 64, 1) var random_samples_per_chunk: int = 8
@export_group("Block behavior")
## Delay before a newly unsupported block starts falling.
@export_range(0.03, 1.0, 0.01) var fall_interval: float = 0.08
@export_range(0.1, 60.0, 0.1) var grass_death_seconds: float = 6.0
@export_range(0.1, 600.0, 0.1) var leaf_decay_min_seconds: float = 20.0
@export_range(0.1, 600.0, 0.1) var leaf_decay_max_seconds: float = 90.0

@export_group("Smooth falling blocks")
## 16 pixels = one block. Acceleration is applied independently of rendering.
@export_range(16.0, 4096.0, 16.0) var falling_gravity: float = 256.0
@export_range(16.0, 4096.0, 16.0) var falling_terminal_speed: float = 640.0
## Retained velocity per 1/20 second (1 disables drag).
@export_range(0.8, 1.0, 0.001) var falling_drag: float = 0.98
@export_range(8, 512, 1) var max_falling_blocks: int = 128

@export_group("Wall torch appearance")
@export_range(0.0, 45.0, 0.5) var wall_torch_angle: float = 22.5
## Stem base's distance from the supporting wall, in world pixels.
@export_range(0.0, 4.0, 0.25) var wall_torch_inset: float = 0.0
