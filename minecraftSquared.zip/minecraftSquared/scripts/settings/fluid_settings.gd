class_name FluidSettings
extends Resource

@export_file("*.json") var rules_path: String = "res://data/fluids.json"
@export_group("Simulation budgets")
@export_range(0.1, 8.0, 0.1) var budget_ms: float = 1.25
@export_range(8, 1024, 1) var max_updates_per_frame: int = 96
@export_range(32, 4096, 1) var scan_cells_per_frame: int = 512
@export_group("New world generation")
@export var generation_enabled: bool = true
@export_range(64, 512, 1) var surface_region_width: int = 192
@export_range(0.0, 1.0, 0.01) var lake_chance: float = 0.55
@export_range(0.0, 1.0, 0.01) var channel_chance: float = 0.22
@export_range(4, 48, 1) var lake_radius: int = 14
@export_range(2, 12, 1) var lake_depth: int = 5
@export_range(2, 12, 1) var channel_radius: int = 5
@export_range(1, 8, 1) var channel_depth: int = 3
@export_range(1, 16, 1) var maximum_bank_relief: int = 6
@export_range(0.0, 1.0, 0.01) var underground_pool_chance: float = 0.35
@export_range(-60, 0, 1) var lava_level: int = -54
@export var lakebed_block: String = "sand"
@export var lakebed_patch: String = "gravel"
@export_range(1, 4, 1) var lakebed_depth: int = 2
@export_group("Shorelines and sugar cane")
@export_range(1, 2, 1) var shore_revision: int = 2
@export_range(1, 6, 1) var shore_width: int = 3
@export_range(1, 4, 1) var shore_depth: int = 2
@export_range(4, 24, 1) var shore_blend_width: int = 8
@export_range(0.0, 1.0, 0.05) var sugar_cane_chance: float = 0.6
@export_group("Movement and hazards")
@export_range(0.0, 64.0, 0.1) var water_current_speed: float = 22.4
@export_range(0.1, 1.0, 0.05) var water_move_factor: float = 0.510
@export_range(0.1, 1.0, 0.01) var lava_move_factor: float = 0.18
@export_range(10.0, 160.0, 1.0) var swim_speed: float = 43.2
@export_range(10.0, 100.0, 1.0) var sinking_speed: float = 35.0
@export_range(0.1, 5.0, 0.1) var lava_damage_interval: float = 0.5
@export_range(1, 20, 1) var lava_damage: int = 4
@export_range(0.0, 30.0, 1.0) var burning_seconds: float = 15.0

func validate() -> bool:
	var valid: bool = not rules_path.is_empty() and BlockDatabase.id_for(lakebed_block)!=0 and BlockDatabase.id_for(lakebed_patch)!=0
	valid = valid and lake_chance+channel_chance <= 1.0 and surface_region_width >= 2*(maxi(lake_radius,channel_radius)+shore_width+shore_blend_width+2)
	for entry in [[water_current_speed,0,64],[shore_revision,1,2],[shore_width,1,6],[shore_depth,1,4],[shore_blend_width,4,24],[sugar_cane_chance,0,1],[budget_ms,.1,8],[max_updates_per_frame,8,1024],[scan_cells_per_frame,32,4096],
		[surface_region_width,64,512],[lake_chance,0,1],[channel_chance,0,1],[lake_radius,4,48],
		[lake_depth,2,12],[channel_radius,2,12],[channel_depth,1,8],[underground_pool_chance,0,1],
		[maximum_bank_relief,1,16],[lakebed_depth,1,4],[lava_level,-60,0],[water_move_factor,.1,1],[lava_move_factor,.1,1],
		[swim_speed,10,160],[sinking_speed,10,100],[lava_damage_interval,.1,5],[lava_damage,1,20],[burning_seconds,0,30]]:
		valid = ContentCatalog._number(entry[0],entry[1],entry[2]) and valid
	if not valid: DataFile.fail("fluid.tres: invalid simulation, generation or movement settings.")
	return valid
