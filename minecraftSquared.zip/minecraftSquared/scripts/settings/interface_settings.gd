class_name InterfaceSettings
extends Resource

@export_group("Scale and icons")
@export_range(1, 4, 1) var maximum_scale: int = 3
## Logical pixels in a 16-pixel slot. 13.333 gives 40px at UI scale 3.
@export_range(8.0, 16.0, 0.001) var inventory_icon_size: float = 13.333333
@export_range(8.0, 16.0, 0.001) var hotbar_icon_size: float = 10.666667
@export_group("Stack labels")
@export_range(4, 16, 1) var stack_font_size: int = 8
## Offset from the slot's bottom-right, before UI scaling.
@export var stack_offset := Vector2(1, 0)
@export var stack_shadow_offset := Vector2(1, 1)
@export var font: Font = preload("res://assets/fonts/minecraft_font.otf")

@export_group("Enchantment glint")
## Applies to inventory icons, held and dropped items, and equipped armor.
## Zero disables the visual effect; enchantments continue to function.
@export_range(0.0, 1.0, 0.01) var enchantment_glint_strength: float = 0.3:
	set(value):
		enchantment_glint_strength=clampf(value,0,1)
		emit_changed()

@export_group("UI assets")
@export var inventory_texture: Texture2D = preload("res://assets/ui/inventory.png")
@export var crafting_table_texture: Texture2D = preload("res://assets/ui/crafting_table_ui.png")
@export var hotbar_texture: Texture2D = preload("res://assets/ui/hotbar.png")
@export var selector_texture: Texture2D = preload("res://assets/ui/hotbar_selection.png")

@export_group("Tooltips")
@export var durability_tooltips: bool = false
@export var tooltip_background: Texture2D = preload("res://assets/ui/tooltip_background.png")
@export var tooltip_frame: Texture2D = preload("res://assets/ui/tooltip_frame.png")
## Source-pixel slice borders, matching the supplied Minecraft .mcmeta files.
@export_range(0, 32, 1) var tooltip_background_border: int = 9
@export_range(0, 32, 1) var tooltip_frame_border: int = 10
## Logical GUI pixels, scaled with the inventory. Text is drawn at its final size.
@export_range(4, 16, 1) var tooltip_font_size: int = 8
@export var tooltip_padding := Vector2(3, 3)
## The source frame has 9 transparent pixels outside its visible border.
@export_range(0, 24, 1) var tooltip_outer_margin: int = 9
@export_range(0, 8, 1) var tooltip_line_gap: int = 2
@export var tooltip_cursor_offset := Vector2(12, -12)
@export_range(0, 16, 1) var tooltip_screen_margin: int = 4
@export var tooltip_name_color := Color.WHITE
@export var tooltip_detail_color := Color(0.667, 0.667, 0.667)
@export var tooltip_text_shadow: bool = true


func gui_scale(viewport_size: Vector2) -> float:
	var width_scale: float = (viewport_size.x - 20.0) / 182.0
	var height_scale: float = (viewport_size.y - 48.0) / 166.0
	var fit_scale: float = floorf(minf(width_scale, height_scale))
	return clampf(fit_scale, 1.0, float(maximum_scale))
