class_name MagmaCubeMotion
extends RefCounted

## Cubes hop, rather than navigating/stepping like a walking humanoid.
static func think(mob: MobActor) -> void:
	var system: MobSystem=mob.system
	var player: CharacterBody2D=system.world.player
	var target: Vector2=player.eye_position()
	var alive: bool=not player.creative and not player.spectator and not player.survival_dead
	var sight: bool=alive and mob.center().distance_to(target)<float(mob.definition.follow_range)*16 and system.visible(mob.center(),target)
	mob.goal="pursue" if sight else "wander"
	mob.path.clear();mob.idle+=float(MobCatalog.rules.ai_interval)
	if sight:
		mob.idle=0;mob.glance=0;mob.last_target=target;mob.desired=signf(target.x-mob.global_position.x)
		# Keep an existing long idle delay from delaying the first attack hop.
		mob.hop_time=minf(mob.hop_time,2.0)
	else:
		mob.wander_time-=float(MobCatalog.rules.ai_interval)
		if mob.wander_time<=0:
			mob.wander_time=system.rng.randf_range(2,5);mob.desired=system.rng.randi_range(0,1)*2-1
	if absf(mob.desired)>.01:mob.facing=1 if mob.desired>0 else -1

static func delay(mob: MobActor) -> float:
	var rule: Dictionary=mob.definition.cube_motion
	return mob.system.rng.randf_range(float(rule.jump_delay[0]),float(rule.jump_delay[1]))/(float(rule.pursuit_delay_divisor) if mob.goal=="pursue" else 1.0)

static func step(mob: MobActor,delta: float,fluid: String) -> void:
	var rule: Dictionary=mob.definition.cube_motion
	var immersed: bool=not fluid.is_empty()
	var grounded: bool=mob.is_on_floor()
	if immersed:
		# Lava does not halve cube speed. Buoyancy repeatedly lets it leave lava.
		mob.velocity.y=minf(mob.velocity.y+float(mob.definition.gravity)*.1*delta,35)
		if mob.hop_time<=0:
			mob.velocity.y=-(.22+mob.cube_size*.05)*320
			mob.hop_time=.45 if fluid=="lava" else .3
	else:
		mob.velocity.y=minf(mob.velocity.y+float(mob.definition.gravity)*delta,520)
		if grounded and mob.hop_time<=0:
			mob.velocity.y=-float(mob.definition.jump_speed);mob.hop_time=delay(mob)
	# Calibrate the horizontal projection to ~1.5 body lengths per hop.
	# Treating Minecraft's movement attribute as blocks/tick made cubes rocket
	# across the entire screen in this two-dimensional movement model.
	var flight: float=2*float(mob.definition.jump_speed)/float(mob.definition.gravity)
	var speed: float=float(mob.definition.size[0])*float(rule.jump_distance_multiplier)/flight*mob.effects.speed_factor()
	var moving: bool=immersed or not grounded or mob.velocity.y<0
	var target_speed: float=mob.desired*speed if moving else 0
	mob.velocity.x=move_toward(mob.velocity.x,target_speed,delta*float(rule.acceleration))
	if not moving:mob.velocity.x=0
	mob.current_velocity=mob.system.world.fluids.current_velocity(mob.bounds(mob.global_position),mob.current_velocity,delta)
	mob.velocity+=mob.current_velocity;mob.velocity.x+=mob.knockback_x
	mob.move_and_slide()
	mob.velocity.x=0 if mob.is_on_wall() else mob.velocity.x-mob.knockback_x-mob.current_velocity.x
	if not mob.is_on_floor() and not mob.is_on_ceiling():mob.velocity.y-=mob.current_velocity.y
	mob.knockback_x*=pow(.6,delta*20);mob.peak=mob.global_position.y
	mob.fire=0
	# Slimes and magma cubes deal contact damage, not a melee attack at reach.
	var player: CharacterBody2D=mob.system.world.player
	if mob.attack_time<=0 and not player.creative and not player.spectator and not player.survival_dead:
		var player_bounds: Rect2=mob.system.world.player_collision.global_transform*mob.system.world.player_collision.shape.get_rect()
		if mob.bounds(mob.global_position).intersects(player_bounds):
			if not mob.system.world.shields.block(float(mob.definition.attack_damage),mob.center(),"melee",mob) and mob.system.world.survival.take_damage(float(mob.definition.attack_damage),"You were slain by a Magma Cube"):
				player.receive_knockback(mob.center(),MobCatalog.rules.knockback)
			mob.attack_time=float(mob.definition.attack_interval)
