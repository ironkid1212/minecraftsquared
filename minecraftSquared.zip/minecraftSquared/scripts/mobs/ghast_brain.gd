class_name GhastBrain
extends RefCounted

static func step(mob: MobActor,delta: float) -> void:
	var system: MobSystem=mob.system;var world: Node2D=system.world
	var rule: Dictionary=mob.definition.ghast_attack
	var target: Vector2=world.player.eye_position()
	var visible: bool=not world.player.creative and not world.player.spectator and not world.player.survival_dead and mob.center().distance_to(target)<float(rule.range)*16 and system.visible(mob.center(),target)
	if visible:
		mob.bow_charge+=delta
		mob.charging=mob.bow_charge>float(rule.warning_seconds)
		if mob.bow_charge>=float(rule.charge_seconds):
			system.projectiles.ghast_fireball(mob,target);mob.bow_charge=-float(rule.recovery_seconds);mob.charging=false
		mob.facing=1 if target.x>mob.center().x else -1
	else:
		mob.bow_charge=move_toward(mob.bow_charge,0,delta);mob.charging=false
	mob.wander_time-=delta
	if mob.wander_time<=0 or mob.global_position.distance_to(mob.last_target)<12:
		mob.wander_time=system.rng.randf_range(2,5)
		for attempt in range(4):
			var point: Vector2=mob.global_position+Vector2(system.rng.randf_range(-160,160),system.rng.randf_range(-96,96))
			if system.can_fit("ghast",point) and not mob.test_move(mob.global_transform,point-mob.global_position):mob.last_target=point;break
	var direction: Vector2=(mob.last_target-mob.global_position).normalized()
	mob.velocity=mob.velocity.lerp(direction*float(rule.flight_speed),1-exp(-delta*.8))
	mob.move_and_slide()
	if mob.is_on_wall() or mob.is_on_ceiling() or mob.is_on_floor():mob.wander_time=0
	mob.phase=fmod(mob.phase+delta*2,TAU);mob.peak=mob.global_position.y
	mob.hazard_time+=delta
	if mob.hazard_time>=.5:mob.hazard_time=0;system.hazards(mob)
