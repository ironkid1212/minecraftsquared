class_name SkeletonBowPose
extends RefCounted

## Shared wrist/grip geometry for drawing and arrow launch position.
const SPRITE_GRIP:=Vector2(5.5,5.5)
const SPRITE_SCALE: float=.75
static func make(mob: MobActor,phase: float=-INF) -> Dictionary:
	if not is_finite(phase):phase=mob.phase
	var shoulder:=Vector2(0,-22)
	var swing: float=-sin(phase)*.65*mob.walk_amount
	var grip: Vector2=shoulder+Vector2(12,0).rotated(mob.head_pitch) if mob.charging else shoulder+Vector2(0,12).rotated(swing)
	var angle: float=mob.head_pitch if mob.charging else PI*.5
	var bow:=Transform2D(angle+deg_to_rad(float(mob.definition.ranged.bow_rotation_degrees)),grip)
	var stage: int=2 if mob.bow_charge>=.9 else 1 if mob.bow_charge>=.65 else 0
	var nock: Vector2=[Vector2(10,10),Vector2(11,11),Vector2(12,12)][stage]
	var pull: Vector2=bow*((nock-SPRITE_GRIP)*SPRITE_SCALE) if mob.charging else shoulder+Vector2(0,12).rotated(-swing)
	return {"shoulder":shoulder,"grip":grip,"pull":pull,"bow":bow}

static func arrow_origin(mob: MobActor) -> Vector2:
	var pose: Dictionary=make(mob)
	return mob.global_position+Vector2(mob.facing,1)*(Vector2(pose.pull)+Vector2(4,0).rotated(mob.head_pitch))
