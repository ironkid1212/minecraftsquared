class_name MobNameplates
extends Control

var system: MobSystem
var labels: Array[Dictionary]=[]
func setup(host: MobSystem) -> void:
	system=host;mouse_filter=Control.MOUSE_FILTER_IGNORE;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST

static func custom_name(tags: Dictionary) -> String:
	var value: String=str(NBT.value(tags,"CustomName",""))
	if value.begins_with("{"):
		var parsed: Variant=JSON.parse_string(value)
		if parsed is Dictionary:value=str(parsed.get("text",""))
	return value.replace("\n"," ").replace("\r"," ").left(64)

func _process(_delta: float) -> void:queue_redraw()
func _draw() -> void:
	labels.clear()
	if system==null or not is_instance_valid(system.world):return
	var world: Node2D=system.world
	if world.any_inventory_open() or world.player.survival_dead or get_tree().paused or world.chat.is_open:return
	var host: Node=world.get_viewport().get_parent()
	var scale: float=float(host.pixel_scale) if host is PixelGame else 1.0
	scale*=world.get_viewport().get_canvas_transform().get_scale().x
	var font_size: int=maxi(8,roundi(9*.4*scale))
	var font: Font=ItemDrawing.settings.font
	var pointer: Vector2=world.pointer_global_position()
	var view:=Rect2(Vector2.ZERO,get_viewport_rect().size)
	for mob: MobActor in system.active.values():
		var text: String=custom_name(mob.tags)
		if mob.dead or text.is_empty() or mob.center().distance_to(world.player.eye_position())>64*16:continue
		var always: bool=bool(NBT.value(mob.tags,"CustomNameVisible",0))
		if not always and (world.pointer_over_ui or not mob.bounds(mob.global_position).has_point(pointer) or not system.visible(world.player.eye_position(),mob.center())):continue
		var feet: Vector2=mob.previous_position.lerp(mob.global_position,Engine.get_physics_interpolation_fraction())
		var point: Vector2=world.get_canvas_transform()*(feet-Vector2(0,mob.body_size().y+8))
		if host is PixelGame:point=host.world_viewport_to_screen(point)
		var width: float=font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x
		var at: Vector2=(point-Vector2(width*.5,0)).round()
		var bounds:=Rect2(at-Vector2(1,font.get_ascent(font_size)),Vector2(width+2,font.get_height(font_size)))
		if not view.intersects(bounds) or world.hotbar.visible and world.hotbar.get_global_rect().intersects(bounds):continue
		labels.append({"text":text,"bounds":bounds})
		draw_rect(bounds,Color(0,0,0,.25))
		draw_string(font,at,text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,Color.WHITE)

