class_name MobSystem
extends Node
var world: Node2D
var active: Dictionary={}
var sleeping: Dictionary={}
var regions: Dictionary={}
var rng:=RandomNumberGenerator.new()
var next_id: int=1
var enabled: bool=true
var spawn_time: float=0
var renderer: MobDrawing
var nameplates: MobNameplates
var projectiles: MobProjectiles
var explosions: MobExplosions
var mob_griefing: bool=true
var _path_budget: int=1
var _fortress_kinds: Array[String]=[]
var _fortress_weights:=PackedFloat32Array()
func _physics_process(_delta: float) -> void:_path_budget=int(MobCatalog.rules.path_jobs_per_tick)
func setup(game: Node2D) -> bool:
	world=game
	if not MobCatalog.validate():DataFile.fail("Invalid mob catalog.");return false
	var weights: Variant=WorldDimensions.DATA.get("fortress_spawn_weights",{})
	if not weights is Dictionary or weights.is_empty():DataFile.fail("Missing fortress spawn weights.");return false
	for key in weights:
		if not MobCatalog.definitions.has(key) or not ContentCatalog._number(weights[key],.001,1000):DataFile.fail("Invalid fortress spawn weight: "+str(key));return false
		_fortress_kinds.append(key);_fortress_weights.append(float(weights[key]))
	enabled=MobCatalog.rules.enabled;rng.seed=world.world_seed^483192
	mob_griefing=MobCatalog.rules.mob_griefing
	explosions=MobExplosions.new();world.add_child(explosions);explosions.setup(self)
	projectiles=MobProjectiles.new();world.add_child(projectiles);projectiles.setup(self)
	renderer=MobDrawing.new();world.add_child(renderer);renderer.setup(self)
	world.chunks.cell_changed.connect(func(cell: Vector2i,_old: int,new: int):ColdMobs.placed(self,cell,new))
	nameplates=MobNameplates.new();(world.ui_layer if world.ui_layer!=null else world.get_node("UI")).add_child(nameplates);nameplates.setup(self)
	return true
func cell(point: Vector2) -> Vector2i:return world.ground.local_to_map(world.ground.to_local(point))
func feet(at: Vector2i) -> Vector2:return world.ground.to_global(world.ground.map_to_local(at))+Vector2(0,8)
func remove(mob: MobActor) -> void:
	active.erase(mob.serial);mob.set_physics_process(false);mob.queue_free()
	if is_instance_valid(renderer):renderer.queue_redraw()
func spawn(kind: String,point: Vector2,record: Dictionary = {}) -> MobActor:
	if not MobCatalog.definitions.has(kind) or active.size()>=int(MobCatalog.rules.maximum_active) or active.size()+sleeping.size()>=int(MobCatalog.rules.record_limit):return null
	if record.is_empty():
		record={"id":next_id,"position":[point.x,point.y]};next_id+=1
		var biome: String=str(world.chunks.biomes.column(cell(point).x).biome) if world.chunks.biomes!=null else "nether_wastes"
		record.variant="warm" if biome in ["savanna","desert","badlands"] else "cold" if biome in ["snowy_plains","taiga","snowy_taiga","stony_peaks"] else "temperate"
	if kind=="magma_cube" and not record.has("cube_size"):
		record.cube_size=1<<rng.randi_range(0,2)
		if not can_fit(kind,point,Vector2.ONE*float(record.cube_size)*8.32,true):return null
	var mob:=MobActor.new();add_child(mob);mob.setup(self,kind,record);active[mob.serial]=mob;return mob
func can_fit(kind: String,point: Vector2,size_override: Vector2=Vector2.ZERO,allow_fluid: bool=false) -> bool:
	var size: Array=MobCatalog.definitions[kind].size if size_override.is_zero_approx() else [size_override.x,size_override.y]
	var bounds:=Rect2(point-Vector2(float(size[0])*.5,float(size[1])),Vector2(size[0],size[1]))
	var first: Vector2i=cell(bounds.position+Vector2.ONE*.1);var last: Vector2i=cell(bounds.end-Vector2.ONE*.1)
	for y in range(first.y,last.y+1):
		for x in range(first.x,last.x+1):
			var at:=Vector2i(x,y)
			if not world.chunks.is_cell_loaded(at) or BlockDatabase.BLOCKS.get(world.get_block(at),{}).get("solid",false) or not allow_fluid and not world.fluids.kind_at(at).is_empty():return false
	return true
func support(at: Vector2i,natural: bool=false) -> bool:
	if not world.chunks.is_cell_loaded(at):return false
	var block: Dictionary=BlockDatabase.BLOCKS.get(world.get_block(at),{})
	return bool(block.get("solid",false)) and not block.has("fence") and not block.has("gate") and not block.has("door") and (not natural or not block.has("building"))
func visible(from: Vector2,to: Vector2) -> bool:
	var query:=PhysicsRayQueryParameters2D.create(from,to,1)
	query.exclude=[world.player.get_rid()]
	return world.ground.get_world_2d().direct_space_state.intersect_ray(query).is_empty()
func safe_step(mob: MobActor,direction: float) -> bool:
	var ahead: Vector2i=cell(mob.global_position+Vector2(direction*(float(mob.definition.size[0])*.5+5),0))
	var fluid: String=world.fluids.kind_at(ahead+Vector2i.UP)
	if fluid=="lava" or fluid=="water" and mob.goal=="wander" and world.fluids.kind_at(cell(mob.center())).is_empty():return false
	for y in range(-1,4):
		if support(ahead+Vector2i(0,y)):return true
	return false
func think(mob: MobActor) -> void:
	MobBrain.think(self,mob)
func holding_food(mob: MobActor) -> bool:
	for key in mob.definition.get("tempt_items",[]):
		var item: int=BlockDatabase.id_for(key)
		if world.inventory.ids[world.hotbar.selected_slot]==item or world.inventory.ids[BlockInventory.OFFHAND]==item:return true
	return false
func route(mob: MobActor,target: Vector2i) -> Array[Vector2i]:
	if _path_budget<=0:return mob.path
	_path_budget-=1
	var start: Vector2i=cell(mob.global_position-Vector2(0,1));var frontier: Array[Vector2i]=[start];var came: Dictionary={start:start};var costs: Dictionary={start:0.0};var best: Vector2i=start
	for _step in range(int(MobCatalog.rules.navigation_nodes)):
		if frontier.is_empty():break
		frontier.sort_custom(func(a: Vector2i,b: Vector2i):return float(costs[a])+a.distance_to(target)<float(costs[b])+b.distance_to(target))
		var current: Vector2i=frontier.pop_front()
		if current.distance_to(target)<best.distance_to(target):best=current
		if current==target:break
		for direction in [-1,1]:
			for fall in [0,-1,1,2,3]:
				var next: Vector2i=current+Vector2i(direction,fall)
				if absi(next.x-start.x)>12 or absi(next.y-start.y)>8 or not support(next+Vector2i.DOWN) or not can_fit(mob.definition.key,feet(next)):continue
				# Avoid a diagonal jump through a ceiling/overhang.
				if fall<0 and not can_fit(mob.definition.key,feet(current+Vector2i.UP)):continue
				var cost: float=float(costs[current])+1+absf(fall)*.4
				if cost<float(costs.get(next,INF)):costs[next]=cost;came[next]=current;frontier.append(next)
				break
	var result: Array[Vector2i]=[]
	while best!=start:result.push_front(best);best=came[best]
	return result
func hazards(mob: MobActor) -> void:
	if mob.definition.rig=="snow_golem":ColdMobs.hazards(mob)
	var head: Vector2i=cell(mob.global_position-Vector2(0,float(mob.definition.size[1])*.9))
	var kind: String=world.fluids.kind_at(head)
	if mob.definition.rig=="enderman" and (kind=="water" or world.fluids.kind_at(cell(mob.center()))=="water" or world.weather.raining_at(head) and world.weather.strength>.2):
		mob.hurt(1,mob.center(),"water");NetherMobBrain.teleport(mob);mob.anger=0;return
	if mob.definition.rig=="blaze" and (kind=="water" or world.weather.raining_at(head) and world.weather.strength>.2):mob.hurt(1,mob.center(),"water")
	if mob.definition.get("fire_immune",false):mob.fire=0
	if kind=="water":
		mob.fire=0;mob.air=maxf(0,mob.air-.5) if not mob.definition.get("undead",false) else 15
		if mob.air==0:mob.hurt(2,mob.center(),"drown")
	else:mob.air=minf(15,mob.air+2)
	if not mob.definition.get("fire_immune",false) and world.fluids.kind_at(cell(mob.center()))=="lava":mob.hurt(4,mob.center(),"lava");mob.fire=15
	var raining: bool = world.weather.raining_at(head) and world.weather.strength > 0.2
	if raining:mob.fire=0
	if world.chunks.dimension=="overworld" and mob.definition.get("sun_burn",false) and MobCatalog.rules.daylight_burn and world.clock.daylight()>.7 and not raining and kind!="water":
		var beam: PackedByteArray=world.lighting._sky_columns.column(head.x)
		var index: int=head.y-world.chunks.min_world_y
		if index>=0 and index<beam.size() and beam[index]==15:mob.fire=maxf(mob.fire,8)
func loot(mob: MobActor,player_hit: bool) -> void:
	if AnimalBreeding.baby(mob):return
	if player_hit and world.experience!=null:
		var rule: Dictionary=world.experience.rules
		world.experience.spawn(int(mob.definition.get("experience",int(rule.mob_hostile) if mob.definition.hostile else rng.randi_range(int(rule.mob_passive[0]),int(rule.mob_passive[1])))),mob.center())
	if mob.carried_block>0:world.dropped_items.spawn_item(mob.carried_block,1,mob.center())
	if mob.definition.rig=="magma_cube":
		if mob.cube_size>1:
			for i in range(rng.randi_range(2,4)):
				var p: Vector2=mob.global_position+Vector2((i-1)*4,-2)
				var record: Dictionary={"id":next_id,"position":[p.x,p.y],"cube_size":mob.cube_size/2,"variant":"temperate"};next_id+=1
				if can_fit("magma_cube",p,Vector2.ONE*float(record.cube_size)*8.32,true):spawn("magma_cube",p,record)
		if mob.cube_size==1:return
	if mob.definition.rig=="polar_bear":
		var fish: String="cod" if rng.randf()<.75 else "salmon"
		var amount: int=rng.randi_range(0,2)
		if amount>0:world.dropped_items.spawn_item(BlockDatabase.id_for(("cooked_" if mob.fire>0 else "")+fish),amount,mob.center())
		return
	for drop in mob.definition.drops:
		if drop.get("player_only",false) and not player_hit:continue
		if rng.randf()>float(drop.get("chance",1)):continue
		if drop.get("wool",false) and mob.sheared:continue
		var count: int=rng.randi_range(drop.min,drop.max)
		var key: String=drop.get("cooked",drop.item) if mob.fire>0 else drop.item
		if count>0:world.dropped_items.spawn_item(BlockDatabase.id_for(key),count,mob.center())
	if player_hit and mob.definition.has("rare_drops") and rng.randf()<float(mob.definition.rare_drops.chance):
		var keys: Array=mob.definition.rare_drops.items;world.dropped_items.spawn_item(BlockDatabase.id_for(keys[rng.randi_range(0,keys.size()-1)]),1,mob.center())
func use_mob(mob: MobActor,slot: int) -> bool:
	if mob==null or mob.dead or world.player.spectator or world.player.survival_dead:return false
	var id: int=world.inventory.ids[slot]
	if id==BlockDatabase.id_for("name_tag"):
		var custom: String=ItemTags.name(id,world.inventory.tags[slot])
		if custom!=str(BlockDatabase.BLOCKS[id].name) and not custom.strip_edges().is_empty():
			mob.tags["CustomName"]=NBT.node(NBT.STRING,custom)
			if not world.player.creative:world.inventory.remove_from_slot(slot,1)
			swing(slot,mob.center());return true
	if AnimalBreeding.feed(mob,slot):return true
	if AnimalBreeding.baby(mob):return false
	if mob.definition.key=="bogged" and id==BlockDatabase.id_for("shears") and not mob.sheared:
		mob.sheared=true;world.inventory.damage_tool(slot)
		for i in range(2):world.dropped_items.spawn_item(BlockDatabase.id_for("red_mushroom" if rng.randf()<.5 else "brown_mushroom"),1,mob.center())
		swing(slot,mob.center());return true
	if mob.definition.key=="mooshroom":
		if id==BlockDatabase.id_for("bowl"):
			if not world.player.creative:world.inventory.remove_from_slot(slot,1)
			if world.inventory.add_item(BlockDatabase.id_for("mushroom_stew"),1)>0:world.dropped_items.spawn_item(BlockDatabase.id_for("mushroom_stew"),1,mob.center())
			swing(slot,mob.center());return true
		if id==BlockDatabase.id_for("shears"):
			world.inventory.damage_tool(slot);world.dropped_items.spawn_item(BlockDatabase.id_for("red_mushroom"),5,mob.center())
			mob.definition=MobCatalog.definitions.cow;mob.variant="temperate";swing(slot,mob.center());return true
	if mob.definition.interactions.has("shear") and not mob.sheared and id==BlockDatabase.id_for("shears"):
		mob.sheared=true;world.inventory.damage_tool(slot);world.dropped_items.spawn_item(BlockDatabase.id_for(mob.definition.interactions.shear),1 if mob.definition.rig=="snow_golem" else rng.randi_range(1,3),mob.center());swing(slot,mob.center());return true
	if mob.definition.interactions.has("milk") and id==BlockDatabase.id_for("bucket"):
		world._interaction_slot=slot;world.fluids._replace_bucket(BlockDatabase.id_for(mob.definition.interactions.milk));world._interaction_slot=-1;swing(slot,mob.center());return true
	return false
func swing(slot: int,at: Vector2) -> void:
	world.player.action_offhand=slot==BlockInventory.OFFHAND;world.player.swing_hand("place",at);world.player.action_offhand=false
func spawn_allowed(kind: String,at: Vector2i) -> bool:
	var def: Dictionary=MobCatalog.definitions[kind]
	if kind in ["silverfish","endermite","bat"]:return false
	if world.is_end():return kind=="enderman" and support(at+Vector2i.DOWN) and can_fit(kind,feet(at)) and world.lighting.has_light_sample(at) and world.lighting.sample_levels(at).y<=7
	if def.get("nether_only",false) and not world.is_nether():return false
	if world.is_nether():
		var biome: String=world.chunks.nether.biome_at(at.x)
		var fortress: bool=world.chunks.nether.fortresses.contains(at)
		if kind=="ghast":
			if biome not in ["nether_wastes","soul_sand_valley","basalt_deltas"] or fortress:return false
			var count: int=0
			for mob in active.values():
				if not mob.dead and mob.definition.key=="ghast":count+=1
			return count<int(def.ghast_attack.natural_cap) and can_fit(kind,feet(at)) and rng.randi_range(0,19)==0
		var allowed: bool=kind in ["wither_skeleton","blaze"] and fortress or kind=="skeleton" and (biome=="soul_sand_valley" or fortress) or kind=="enderman" and biome=="warped_forest" or kind=="magma_cube" and (biome in ["basalt_deltas","nether_wastes"] or fortress)
		# Natural spawning checks the largest cube BEFORE selecting its size.
		var size: Vector2=Vector2.ONE*33.28 if kind=="magma_cube" else Vector2.ZERO
		return allowed and support(at+Vector2i.DOWN,not fortress) and can_fit(kind,feet(at),size) and (kind=="magma_cube" or world.lighting.has_light_sample(at) and world.lighting.sample_levels(at).y<=7)
	if def.hostile and world.chunks.biomes!=null and world.chunks.biomes.column(at.x).biome=="mushroom_fields":return false
	if not support(at+Vector2i.DOWN,true) or not can_fit(kind,feet(at)):return false
	var spawn_rules: Dictionary=def.get("spawn_rules",{})
	if spawn_rules.has("biomes") and world.chunks.biomes.column(at.x).biome not in spawn_rules.biomes:return false
	var depth: int=at.y-world.chunks.get_surface_y(at.x)
	if depth<int(spawn_rules.get("minimum_depth",-100000)):return false
	if spawn_rules.get("surface_only",false) and depth>0:return false
	if spawn_rules.get("surface_only",false) and at.y>world.weather.roof(at.x):return false
	var rabbit_sand: bool=def.key=="rabbit" and world.get_block(at+Vector2i.DOWN) in [BlockDatabase.id_for("sand"),BlockDatabase.id_for("red_sand")]
	var cold_ground: bool=kind in ["polar_bear","rabbit"] and world.get_block(at+Vector2i.DOWN) in [BlockDatabase.id_for("snow_block"),BlockDatabase.id_for("packed_ice"),BlockDatabase.id_for("snow_layer_8")]
	if not def.hostile and not cold_ground and not rabbit_sand and not (def.key=="mooshroom" and world.get_block(at+Vector2i.DOWN)==BlockDatabase.id_for("mycelium")) and world.get_block(at+Vector2i.DOWN) not in [BlockDatabase.id_for("grass"),BlockDatabase.id_for("snowy_grass")]:return false
	if not world.lighting.has_light_sample(at):return false
	var light: Vector2i=world.lighting.sample_levels(at)
	if def.hostile:return light.y==0 and light.x<=rng.randi_range(0,7)
	return maxi(light.x,light.y)>=9 and world.chunks.biomes.column(at.x).biome in def.biomes
func _process(delta: float) -> void:
	spawn_time-=delta
	if spawn_time>0:return
	spawn_time=MobCatalog.rules.spawn_interval
	stream_entities()
	if not enabled or world.player.spectator or world.player.survival_dead:return
	seed_animals();seed_ambient()
	var count: int=0
	for mob in active.values():
		if mob.definition.hostile and not mob.dead:count+=1
	if count>=int(MobCatalog.rules.hostile_cap):return
	var origin: Vector2i=cell(world.player.global_position)
	for _attempt in range(int(MobCatalog.rules.spawn_attempts)):
		var at: Vector2i=origin+Vector2i(rng.randi_range(-int(MobCatalog.rules.spawn_max_distance),int(MobCatalog.rules.spawn_max_distance)),rng.randi_range(-20,24))
		var kind: String=pick_hostile(at)
		if kind.is_empty() or at.distance_to(origin)<float(MobCatalog.rules.spawn_min_distance) or not spawn_allowed(kind,at):continue
		var herd: Array=MobCatalog.definitions[kind].herd
		for member in range(rng.randi_range(int(herd[0]),int(herd[1]))):
			if count>=int(MobCatalog.rules.hostile_cap):break
			var spot: Vector2i=at+Vector2i(member*2,0)
			if spot.distance_to(origin)>=float(MobCatalog.rules.spawn_min_distance) and spawn_allowed(kind,spot) and not occupied(feet(spot)):
				if spawn(kind,feet(spot))!=null:count+=1
		break
func pick_hostile(at: Vector2i=Vector2i(2147483647,2147483647)) -> String:
	if world.is_end():return "enderman"
	if world.is_nether():
		if at.x==2147483647:at=cell(world.player.global_position)
		var biome: String=world.chunks.nether.biome_at(at.x)
		if biome in ["nether_wastes","soul_sand_valley","basalt_deltas"] and rng.randf()<.1:return "ghast"
		if world.chunks.nether.fortresses.contains(at):return _fortress_kinds[rng.rand_weighted(_fortress_weights)]
		if biome=="basalt_deltas":return "magma_cube"
		if biome=="warped_forest":return "enderman"
		if biome=="soul_sand_valley":return "skeleton"
		# Without the as-yet unimplemented piglin population, empty attempts
		# preserve rare wastes cubes instead of filling the biome with them.
		return "magma_cube" if biome=="nether_wastes" and rng.randi_range(0,74)<2 else ""
	var candidates: Array[String]=[];var total: float=0
	for def in MobCatalog.definitions.values():
		if def.hostile and not def.get("nether_only",false) and float(def.spawn_weight)>0:
			var rule: Dictionary=def.get("spawn_rules",{})
			if at.x!=2147483647 and rule.has("biomes") and world.chunks.biomes.column(at.x).biome not in rule.biomes:continue
			if at.x!=2147483647 and rule.get("surface_only",false) and at.y>=world.chunks.get_surface_y(at.x):continue
			candidates.append(def.key);total+=float(def.spawn_weight)
	var roll: float=rng.randf()*total
	for key in candidates:
		roll-=float(MobCatalog.definitions[key].spawn_weight)
		if roll<=0:return key
	return candidates[-1] if not candidates.is_empty() else ""
func occupied(point: Vector2) -> bool:
	for mob in active.values():
		if not mob.dead and mob.global_position.distance_to(point)<20:return true
	return false
func seed_animals() -> void:
	if world.chunks.dimension!="overworld":return
	var count: int=0
	for mob in active.values():
		if not mob.definition.hostile and not mob.definition.get("ambient",false) and not mob.dead:count+=1
	var origin: Vector2i=cell(world.player.global_position);var width: int=MobCatalog.rules.passive_region_width
	for region in range(floori(float(origin.x-48)/width),floori(float(origin.x+48)/width)+1):
		if regions.has(region) or count>=int(MobCatalog.rules.passive_cap):continue
		var seeded:=RandomNumberGenerator.new();seeded.seed=world.world_seed^region*734287^83462
		if seeded.randf()>float(MobCatalog.rules.passive_region_chance):regions[region]=true;continue
		var x: int=region*width+seeded.randi_range(8,width-9)
		var y: int=world.chunks.get_surface_y(x)-1
		if not world.chunks.is_cell_loaded(Vector2i(x,y)):continue
		var candidates: Array[String]=[];var total: float=0
		var biome: String=world.chunks.biomes.column(x).biome
		for def in MobCatalog.definitions.values():
			if not def.hostile and biome in def.biomes:candidates.append(def.key);total+=float(def.spawn_weight)
		if candidates.is_empty():regions[region]=true;continue
		var roll: float=seeded.randf()*total;var kind: String=candidates[-1]
		for candidate in candidates:
			roll-=float(MobCatalog.definitions[candidate].spawn_weight)
			if roll<=0:kind=candidate;break
		if not spawn_allowed(kind,Vector2i(x,y)):continue
		regions[region]=true
		var herd: Array=MobCatalog.definitions[kind].herd
		for member in range(seeded.randi_range(int(herd[0]),int(herd[1]))):
			if count>=int(MobCatalog.rules.passive_cap):break
			var at:=Vector2i(x+member*2,world.chunks.get_surface_y(x+member*2)-1)
			if spawn_allowed(kind,at) and feet(at).distance_to(world.player.global_position)>96 and not occupied(feet(at)):spawn(kind,feet(at),{"id":next_id,"position":[feet(at).x,feet(at).y],"growing_age":-float(MobCatalog.definitions[kind].juvenile.seconds) if kind=="polar_bear" and member>0 else 0});next_id+=1;count+=1
func stream_entities() -> void:
	for record in sleeping.values():
		var point:=Vector2(record.position[0],record.position[1])
		if record.kind!="shulker" and not record.get("tags",{}).has("CustomName") and MobCatalog.definitions[record.kind].hostile and point.distance_to(world.player.global_position)>float(MobCatalog.rules.despawn_distance)*16:sleeping.erase(int(record.id));continue
		if active.size()<int(MobCatalog.rules.maximum_active) and point.distance_to(world.player.global_position)<float(MobCatalog.rules.active_distance)*16 and world.chunks.is_cell_loaded(cell(point-Vector2(0,1))):
			sleeping.erase(int(record.id));spawn(record.kind,point,record)
	for mob in active.values():
		var distance: float=mob.global_position.distance_to(world.player.global_position)/16
		if mob.dead:continue
		if mob.definition.rig!="shulker" and not mob.tags.has("CustomName"):
			if mob.definition.get("ambient",false) and distance>32:remove(mob);continue
			if mob.definition.hostile and (distance>float(MobCatalog.rules.despawn_distance) or distance>32 and mob.idle>30 and rng.randf()<.0247):remove(mob);continue
		if distance>float(MobCatalog.rules.active_distance) or not world.chunks.is_cell_loaded(cell(mob.global_position-Vector2(0,1))):
			sleeping[mob.serial]=mob.snapshot();remove(mob)
func snapshot() -> Dictionary:
	var records: Array=sleeping.values().duplicate(true)
	for mob in active.values():
		if not mob.dead:records.append(mob.snapshot())
	return {"entities":records,"regions":regions.keys(),"rng":str(rng.state),"next_id":next_id,"mob_griefing":mob_griefing}
func restore(state: Dictionary) -> void:
	projectiles.arrows.clear();projectiles.queue_redraw()
	for mob in active.values():remove(mob)
	sleeping.clear();regions.clear();next_id=int(state.get("next_id",1));rng.seed=world.world_seed^483192
	mob_griefing=bool(state.get("mob_griefing",MobCatalog.rules.mob_griefing))
	if state.has("rng"):rng.state=int(state.rng)
	for region in state.get("regions",[]):regions[int(region)]=true
	for record in state.get("entities",[]):sleeping[int(record.id)]=record.duplicate(true)
	stream_entities();spawn_time=1

func seed_ambient() -> void:
	if world.chunks.dimension!="overworld":return
	var count: int=0
	for mob in active.values():
		if mob.definition.get("ambient",false):count+=1
	if count>=6:return
	var origin: Vector2i=cell(world.player.global_position)
	for i in range(4):
		var at:=origin+Vector2i(rng.randi_range(-26,26),rng.randi_range(-12,12))
		if at.distance_to(origin)<8 or not world.chunks.is_cell_loaded(at) or at.y<world.chunks.get_surface_y(at.x)+6 or not can_fit("bat",feet(at)) or not world.lighting.has_light_sample(at):continue
		var light: Vector2i=world.lighting.sample_levels(at)
		if maxi(light.x,light.y)>3:continue
		if spawn("bat",feet(at))!=null:return
