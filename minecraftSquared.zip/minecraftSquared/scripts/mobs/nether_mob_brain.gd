class_name NetherMobBrain
extends RefCounted
static func eye(mob: MobActor) -> Vector2:return mob.global_position-Vector2(0,40.8)
static func stared_at(mob: MobActor) -> bool:
	var world: Node2D=mob.system.world;var player: CharacterBody2D=world.player
	if player.spectator or player.creative or player.survival_dead or player.input_blocked or world.any_inventory_open() or world.chat.is_open:return false
	var direction: Vector2=world.pointer_global_position()-player.eye_position();var target: Vector2=eye(mob)-player.eye_position()
	if direction.is_zero_approx() or target.length()>float(mob.definition.follow_range)*16:return false
	return direction.normalized().dot(target.normalized())>1-.025/maxf(.1,target.length()/16) and mob.system.visible(player.eye_position(),eye(mob))
static func teleport(mob: MobActor,towards: bool=false,attempts: int=32) -> bool:
	var system: MobSystem=mob.system;var world: Node2D=system.world;var start: Vector2i=system.cell(mob.global_position-Vector2(0,1))
	var radius: int=int(mob.definition.teleport.range)
	for attempt in range(attempts):
		var x: int=start.x+system.rng.randi_range(-radius,radius)
		if towards:x=system.cell(world.player.global_position).x+system.rng.randi_range(-8,8)
		var y: int=clampi(start.y+system.rng.randi_range(-radius,radius),world.chunks.min_world_y+3,world.chunks.world_depth-2)
		for drop in range(radius):
			var floor:=Vector2i(x,y+drop)
			if not world.chunks.is_cell_loaded(floor):break
			if not system.support(floor):continue
			var at: Vector2=system.feet(floor+Vector2i.UP)
			if at.distance_to(mob.global_position)<16 or not system.can_fit("enderman",at):break
			var box: Rect2=mob.bounds(at);var first: Vector2i=system.cell(box.position+Vector2.ONE*.1);var last: Vector2i=system.cell(box.end-Vector2.ONE*.1)
			var wet: bool=false
			for xx in range(first.x,last.x+1):
				for yy in range(first.y,last.y+1):
					if not world.fluids.kind_at(Vector2i(xx,yy)).is_empty() or world.chunks.waterlogged.has(Vector2i(xx,yy)):wet=true
			if wet or not world.fluids.kind_at(floor).is_empty():break
			system.renderer.portal_burst(mob.center());mob.global_position=at;mob.previous_position=at;mob.velocity=Vector2.ZERO;mob.peak=at.y;mob.path.clear();mob.current_velocity=Vector2.ZERO
			system.renderer.portal_burst(mob.center());return true
	return false
static func enderman(mob: MobActor,dt: float) -> void:
	var system: MobSystem=mob.system;var world: Node2D=system.world;var rule: Dictionary=mob.definition.teleport
	for target: MobActor in system.active.values():
		if target.definition.key=="endermite" and not target.dead and mob.center().distance_to(target.center())<64*16 and system.visible(mob.center(),target.center()):
			mob.revenge_id=target.serial;mob.anger=20;MobBrain.think(system,mob);return
	var stare: bool=stared_at(mob)
	mob.stare_time=mob.stare_time+dt if stare else 0
	if mob.stare_time>=float(rule.stare_seconds) and mob.anger<=0:mob.anger=system.rng.randf_range(rule.anger_seconds[0],rule.anger_seconds[1]);mob.stare_time=0
	if stare and mob.anger>0 and mob.global_position.distance_to(world.player.global_position)<256:
		mob.desired=0;mob.goal="stare";MobBrain.look(mob,world.player.eye_position());mob.path.clear()
		mob.teleport_time+=dt
		if mob.global_position.distance_to(world.player.global_position)<64 and mob.teleport_time>1:teleport(mob);mob.teleport_time=0
		return
	MobBrain.think(system,mob)
	if mob.anger>0:
		mob.teleport_time+=dt
		if mob.global_position.distance_to(world.player.global_position)>256 and mob.teleport_time>=float(rule.chase_seconds):teleport(mob,true);mob.teleport_time=0
	else:
		mob.teleport_time=0
		if system.mob_griefing and system.rng.randf()<dt/100:
			if mob.carried_block==0:
				var at: Vector2i=system.cell(mob.global_position)+Vector2i(system.rng.randi_range(-2,2),system.rng.randi_range(-1,0))
				var value: int=world.get_block(at)
				if BlockDatabase.BLOCKS.get(value,{}).get("key","") in ["grass","dirt","sand","gravel","netherrack","warped_nylium"] and world.chunks.is_cell_loaded(at):mob.carried_block=value;world.set_block(at,0)
			else:
				var at: Vector2i=system.cell(mob.global_position)+Vector2i(mob.facing,0)
				if world.chunks.is_cell_loaded(at) and world.get_block(at)==0 and system.support(at+Vector2i.DOWN) and not world.chunks.waterlogged.has(at):world.set_block(at,mob.carried_block);mob.carried_block=0
static func blaze(mob: MobActor,dt: float) -> void:
	var world: Node2D=mob.system.world;var target: Vector2=world.player.eye_position();var distance: float=mob.center().distance_to(target)
	var hostile: bool=not world.player.spectator and not world.player.creative and not world.player.survival_dead
	var visible: bool=hostile and distance<float(mob.definition.follow_range)*16 and mob.system.visible(mob.center(),target)
	mob.goal="idle";mob.desired=0;mob.charging=false
	if not visible:mob.blaze_step=0;return
	MobBrain.look(mob,target);mob.goal="pursue"
	mob.desired=signf(target.x-mob.center().x) if distance>160 else 0
	if distance<32:
		if mob.attack_time<=0:
			mob.attack_time=1
			if not world.shields.block(6,mob.center(),"melee",mob):world.survival.take_damage(6,"You were slain by a Blaze")
		return
	mob.charging=mob.blaze_step>0;mob.goal="ranged"
	if mob.attack_time>0:return
	var rule: Dictionary=mob.definition.blaze_attack
	mob.blaze_step+=1
	if mob.blaze_step==1:mob.attack_time=float(rule.charge_seconds);mob.charging=true
	elif mob.blaze_step<=int(rule.shots)+1:
		mob.system.projectiles.fireball(mob,target);mob.attack_time=float(rule.shot_interval)
	else:mob.attack_time=float(rule.recovery_seconds);mob.blaze_step=0;mob.charging=false
