class_name CaveMobBrain
extends RefCounted
static func infestations() -> Dictionary:
	return {"stone":"infested_stone","deepslate":"infested_deepslate","stone_bricks":"infested_stone_bricks","mossy_stone_bricks":"infested_mossy_stone_bricks","cracked_stone_bricks":"infested_cracked_stone_bricks"}
static func release(world: Node2D,cell: Vector2i) -> MobActor:
	if not world.chunks.is_cell_loaded(cell):return null
	var mob: MobActor=world.mobs.spawn("silverfish",world.mobs.feet(cell))
	if mob!=null:mob.anger=20
	return mob
static func disturb(mob: MobActor) -> void:
	var world: Node2D=mob.system.world;var center: Vector2i=mob.system.cell(mob.center());var count: int=0
	for dy in range(-5,6):
		for distance in range(11):
			for direction in [-1,1]:
				var at:=center+Vector2i(distance*direction,dy)
				if not world.chunks.is_cell_loaded(at) or not BlockDatabase.has_tag(world.get_block(at),"infested"):continue
				var original: String=BlockDatabase.BLOCKS[world.get_block(at)].key.trim_prefix("infested_")
				world.set_block(at,0 if mob.system.mob_griefing else BlockDatabase.id_for(original))
				if mob.system.mob_griefing:release(world,at)
				count+=1
				if count>=4:return
static func bug_think(mob: MobActor) -> void:
	MobBrain.think(mob.system,mob)
	if mob.definition.key!="silverfish":return
	if mob.stare_time>0:
		mob.stare_time=maxf(0,mob.stare_time-float(MobCatalog.rules.ai_interval))
		if mob.stare_time==0:disturb(mob)
	if mob.goal=="pursue" or mob.idle<8 or not mob.system.mob_griefing:return
	var at: Vector2i=mob.system.cell(mob.global_position)+Vector2i(mob.facing,0)
	var id: int=mob.system.world.get_block(at)
	var key: String=BlockDatabase.BLOCKS.get(id,{}).get("key","")
	if infestations().has(key) and mob.system.rng.randf()<.1:
		mob.system.world.set_block(at,BlockDatabase.id_for(infestations()[key]));mob.system.remove(mob)
static func bat(mob: MobActor,delta: float) -> void:
	var world: Node2D=mob.system.world;var rule: Dictionary=mob.definition.flight
	mob.hazard_time+=delta
	if mob.hazard_time>=.5:mob.hazard_time=0;mob.system.hazards(mob)
	if mob.fire>0:
		mob.fire=maxf(0,mob.fire-delta);mob.burn_time+=delta
		if mob.burn_time>=1:mob.burn_time=0;mob.hurt(1,mob.center(),"fire")
	var head: Vector2i=mob.system.cell(mob.global_position-Vector2(0,float(mob.definition.size[1])+1))
	var ceiling: bool=BlockDatabase.BLOCKS.get(world.get_block(head),{}).get("solid",false)
	var near: bool=mob.center().distance_to(world.player.eye_position())<float(rule.wake_range)*16
	if mob.bat_hanging and (not ceiling or near):mob.bat_hanging=false;mob.wander_time=0
	if mob.bat_hanging:mob.velocity=Vector2.ZERO;mob.walk_amount=0;return
	mob.wander_time-=delta
	if mob.wander_time<=0:
		mob.wander_time=float(rule.decision_seconds)
		var point: Vector2=mob.global_position+Vector2(mob.system.rng.randf_range(-80,80),mob.system.rng.randf_range(-48,48))
		if mob.system.can_fit("bat",point):mob.last_target=point
		if not near and ceiling and mob.system.rng.randf()<float(rule.hang_chance):
			var ceiling_bottom: float=world.ground.to_global(world.ground.map_to_local(head)).y+8
			if absf(mob.global_position.y-float(mob.definition.size[1])-ceiling_bottom)<3:
				mob.global_position.y=ceiling_bottom+float(mob.definition.size[1]);mob.bat_hanging=true;mob.velocity=Vector2.ZERO;return
	var direction: Vector2=(mob.last_target-mob.global_position).normalized()
	mob.velocity=mob.velocity.lerp(direction*float(rule.speed),1-exp(-delta*3))
	mob.velocity.x+=mob.knockback_x;mob.move_and_slide();mob.velocity.x-=mob.knockback_x;mob.knockback_x*=pow(.6,delta*20)
	if mob.is_on_wall() or mob.is_on_ceiling():mob.wander_time=0
	if absf(mob.velocity.x)>1:mob.facing=1 if mob.velocity.x>0 else -1
	mob.phase=fmod(mob.phase+delta*22,TAU);mob.walk_amount=1;mob.peak=mob.global_position.y
