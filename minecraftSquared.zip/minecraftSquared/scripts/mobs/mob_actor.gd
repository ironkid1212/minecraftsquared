class_name MobActor
extends CharacterBody2D
var effects:=EntityEffects.new()
var hop_time: float=0
var system: MobSystem
var definition: Dictionary
var serial: int
var health: float
var facing: int=1
var variant: String="temperate"
var sheared: bool=false
var tags: Dictionary={}
var panic: float=0
var hurt_time: float=0
var flash: float=0
var last_damage: float=0
var dead: bool=false
var death_time: float=0
var fire: float=0
var air: float=15
var idle: float=0
var eat_time: float=0
var phase: float=0
var walk_amount: float=0
var previous_position: Vector2
var previous_phase: float=0
var desired: float=0
var ai_time: float=0
var wander_time: float=0
var attack_time: float=0
var hazard_time: float=0
var burn_time: float=0
var knockback_x: float=0
var peak: float=0
var path: Array[Vector2i]=[]
var path_time: float=0
var aggro_time: float=0
var tempted: bool=false
var player_credit: float=0
var fuse: float=0
var fuse_direction: int=-1
var goal: String="idle"
var head_pitch: float=0
var glance: float=0
var glance_time: float=10
var last_target: Vector2
var shelter: Vector2=Vector2(INF,INF)
var revenge_id: int=0
var anger: float=0
var bow_charge: float=0
var charging: bool=false
var leap_time: float=0
var current_velocity: Vector2=Vector2.ZERO
var egg_time: float=0
var stare_time: float=0
var teleport_time: float=0
var carried_block: int=0
var blaze_step: int=0
var creature_age: float=0
var bat_hanging: bool=false
var growing_age: float=0
var love_time: float=0
var mate_time: float=0
var cube_size: int=2
var hover_y: float=0
func setup(host: MobSystem,kind: String,record: Dictionary) -> void:
	system=host;definition=MobCatalog.definitions[kind];serial=int(record.id);health=float(record.get("health",definition.health));variant=record.get("variant","temperate");sheared=record.get("sheared",false);tags=record.get("tags",{}).duplicate(true)
	global_position=Vector2(record.position[0],record.position[1]);previous_position=global_position;peak=global_position.y
	var v: Array=record.get("velocity",[0,0]);velocity=Vector2(v[0],v[1]);facing=int(record.get("facing",1));fire=float(record.get("fire",0));idle=float(record.get("idle",0));air=float(record.get("air",15))
	creature_age=float(record.get("creature_age",0));bat_hanging=bool(record.get("bat_hanging",false))
	growing_age=float(record.get("growing_age",0));love_time=float(record.get("love_time",0))
	anger=float(record.get("anger",0));stare_time=float(record.get("stare_time",0));teleport_time=float(record.get("teleport_time",0));carried_block=int(record.get("carried_block",0));hover_y=global_position.y
	if definition.get("cube",false):
		cube_size=int(record.get("cube_size",2));definition=definition.duplicate(true);definition.size=[cube_size*8.32,cube_size*8.32];definition.health=cube_size*cube_size;definition.armor=cube_size*3;definition.attack_damage=cube_size+2;definition.experience=cube_size;definition.jump_speed=(.42+cube_size*.1)*320
		health=float(record.get("health",definition.health))
	collision_layer=4;collision_mask=3;floor_snap_length=0 if definition.get("cube",false) else 9.7;safe_margin=.02
	# The player shares the terrain layer. In 2D entities must be able to pass.
	add_collision_exception_with(system.world.player)
	effects.remaining=record.get("effects",{}).duplicate(true);effects.amplifiers=record.get("effect_amplifiers",{}).duplicate(true)
	fuse=float(record.get("fuse",0))
	if definition.has("egg_interval"):egg_time=float(record.egg_time) if record.has("egg_time") else system.rng.randf_range(definition.egg_interval[0],definition.egg_interval[1])
	var collider:=CollisionShape2D.new();var shape:=RectangleShape2D.new();shape.size=Vector2(definition.size[0],definition.size[1]);collider.shape=shape;collider.position.y=-shape.size.y*.5;add_child(collider)
	collider.name="CollisionShape2D"
	if definition.has("breeding"):AnimalBreeding.resize(self)
	ai_time=system.rng.randf_range(0,MobCatalog.rules.ai_interval)
	glance_time=system.rng.randf_range(MobCatalog.rules.glance_interval[0],MobCatalog.rules.glance_interval[1]);last_target=global_position
func body_size() -> Vector2:return Vector2(definition.size[0],definition.size[1])*(float(definition.breeding.baby_scale) if AnimalBreeding.baby(self) else 1.0)
func bounds(at: Vector2) -> Rect2:
	var size: Vector2=body_size();return Rect2(at-Vector2(size.x*.5,size.y),size)
func center() -> Vector2:return global_position-Vector2(0,body_size().y*.5)
func snapshot() -> Dictionary:
	return {"id":serial,"kind":definition.key,"position":[global_position.x,global_position.y],"velocity":[velocity.x,velocity.y],"health":health,"facing":facing,"sheared":sheared,"variant":variant,"tags":tags.duplicate(true),"fire":fire,"idle":idle,"air":air,"fuse":fuse,"egg_time":egg_time,"effects":effects.remaining.duplicate(true),"effect_amplifiers":effects.amplifiers.duplicate(true),"anger":anger,"stare_time":stare_time,"teleport_time":teleport_time,"carried_block":carried_block,"cube_size":cube_size,"creature_age":creature_age,"bat_hanging":bat_hanging,"growing_age":growing_age,"love_time":love_time}
func hurt(amount: float,source: Vector2,kind: String="melee",player_hit: bool=false,strong_knockback: bool=false,attacker: MobActor=null) -> bool:
	if dead or amount<=0:return false
	if definition.get("fire_immune",false) and kind in ["fire","lava"] or definition.get("cube",false) and kind=="fall":return false
	if definition.rig=="enderman" and kind=="projectile":
		NetherMobBrain.teleport(self,false,int(definition.teleport.projectile_attempts));return false
	var incoming: float=amount
	var fresh: bool=hurt_time<=0
	if hurt_time>0:
		if amount<=last_damage:return false
		amount-=last_damage
	last_damage=incoming
	love_time=0;mate_time=0
	if fresh:hurt_time=.5;flash=.5
	if player_hit:player_credit=5;anger=system.rng.randf_range(20,39) if definition.rig=="enderman" else 20;revenge_id=0
	if attacker!=null:revenge_id=attacker.serial;anger=20
	if kind in ["melee","projectile"] and float(definition.armor)>0:
		var armor: float=definition.armor;amount*=1-clampf(armor-amount/2,armor*.2,20)/25
	health=maxf(0,health-amount)
	if not definition.hostile and kind!="melee":panic=float(definition.panic_seconds);desired=system.rng.randi_range(0,1)*2-1
	if kind in ["melee","projectile"] and fresh:
		var direction: float=signf(center().x-source.x)
		if direction==0:direction=-facing
		knockback_x=direction*MobCatalog.rules.knockback*(1.75 if strong_knockback else 1.0)
		if is_on_floor():velocity.y=maxf(-128,velocity.y*.5-128)
		panic=float(definition.panic_seconds);desired=direction
	if definition.key=="silverfish" and health>0 and stare_time<=0:stare_time=1.0
	if definition.key=="bat" and health>0:bat_hanging=false;wander_time=0
	if health<=0:
		dead=true;death_time=0;collision_layer=0;collision_mask=0;velocity=Vector2.ZERO;system.loot(self,player_hit or player_credit>0)
	return true
func _physics_process(delta: float) -> void:
	previous_position=global_position;previous_phase=phase
	if dead:
		death_time+=delta
		if death_time>=1:system.remove(self)
		return
	if not system.world.chunks.is_cell_loaded(system.cell(global_position-Vector2(0,1))):return
	creature_age=minf(100000,creature_age+delta)
	AnimalBreeding.step(self,delta)
	if float(definition.get("creature_lifetime",0))>0 and creature_age>=float(definition.creature_lifetime) and not tags.has("CustomName"):
		system.remove(self);return
	effects.tick(self,delta);hop_time=maxf(0,hop_time-delta)
	glance=maxf(0,glance-delta);glance_time-=delta;anger=maxf(0,anger-delta);leap_time=maxf(0,leap_time-delta)
	if charging and definition.rig!="ghast":bow_charge+=delta
	hurt_time=maxf(0,hurt_time-delta);flash=maxf(0,flash-delta);panic=maxf(0,panic-delta);player_credit=maxf(0,player_credit-delta);attack_time=maxf(0,attack_time-delta);path_time-=delta;ai_time-=delta
	if definition.rig=="bat":CaveMobBrain.bat(self,delta);return
	if definition.rig=="ghast":GhastBrain.step(self,delta);return
	if ai_time<=0:
		ai_time=.05 if definition.rig in ["enderman","blaze"] else float(MobCatalog.rules.ai_interval)
		if definition.rig=="enderman":NetherMobBrain.enderman(self,.05)
		elif definition.rig=="blaze":NetherMobBrain.blaze(self,.05)
		elif definition.get("cube",false):MagmaCubeMotion.think(self)
		elif definition.rig in ["silverfish","endermite"]:CaveMobBrain.bug_think(self)
		else:system.think(self)
	if definition.has("fuse_seconds"):
		if system.world.player.spectator or system.world.player.survival_dead:fuse_direction=-1
		fuse=clampf(fuse+delta*fuse_direction,0,float(definition.fuse_seconds))
		if fuse>=float(definition.fuse_seconds):system.explosions.detonate(self);return
	if definition.has("egg_interval") and not AnimalBreeding.baby(self):
		egg_time-=delta
		if egg_time<=0:
			system.world.dropped_items.spawn_item(BlockDatabase.id_for("egg"),1,center());egg_time=system.rng.randf_range(definition.egg_interval[0],definition.egg_interval[1])
	var immersion: String=system.world.fluids.kind_at(system.cell(center()))
	if definition.get("cube",false):
		MagmaCubeMotion.step(self,delta,immersion)
		hazard_time+=delta
		if hazard_time>=.5:hazard_time=0;system.hazards(self)
		if global_position.y>system.world.chunks.world_depth*16+64:system.remove(self)
		return
	if not immersion.is_empty():
		velocity.y=minf(velocity.y+float(definition.gravity)*.1*delta,35) if definition.get("sinks",false) else move_toward(velocity.y,-24 if immersion=="water" else -8,100*delta);fire=0 if immersion=="water" else maxf(fire,15)
	elif definition.get("flying",false):
		var target_y: float=system.world.player.global_position.y-24 if goal in ["pursue","ranged"] else hover_y
		velocity.y=move_toward(velocity.y,clampf((target_y-global_position.y)*1.5,-64,64),80*delta)
	else:velocity.y=minf(velocity.y+float(definition.gravity)*delta,520)
	if definition.get("cube",false) and immersion=="lava" and hop_time<=0:velocity.y=-(.22+cube_size*.05)*320;hop_time=1.5
	if definition.get("fire_immune",false):fire=0
	if definition.get("slow_fall",false) and velocity.y>0:velocity.y*=pow(.6,delta*20)
	var speed_goal: float=float(definition.panic_multiplier) if panic>0 and not definition.hostile else float(definition.tempt_multiplier) if tempted else float(definition.chase_multiplier) if goal=="pursue" else 1.0
	var speed: float=MobCatalog.walk_speed(definition,speed_goal)*effects.speed_factor()
	if not immersion.is_empty():speed*=.5
	velocity.x=lerpf(desired*speed,velocity.x,pow(float(MobCatalog.rules.ground_drag),delta*20))
	var stepped: bool=try_step(velocity.x*delta) if immersion.is_empty() else false
	if is_on_floor() and not stepped and (is_on_wall() and desired!=0 or not path.is_empty() and path[0].y<system.cell(global_position-Vector2(0,1)).y):velocity.y=-float(definition.jump_speed)
	if is_on_floor() and desired!=0 and panic<=0 and not definition.get("flying",false) and not definition.get("climbs",false) and not system.safe_step(self,desired):velocity.x=0;desired=0;wander_time=0
	if definition.has("hopping") and immersion.is_empty():
		if is_on_floor() and desired!=0 and hop_time<=0:
			velocity.y=-float(definition.hopping.obstacle_jump if is_on_wall() else definition.jump_speed);hop_time=float(definition.hopping.moving_delay if panic>0 or tempted or definition.hostile and goal=="pursue" else definition.hopping.idle_delay)
		elif is_on_floor():velocity.x=0
	if absf(desired)>.01 and goal not in ["ranged","swell"]:facing=1 if desired>0 else -1
	if definition.get("climbs",false) and is_on_wall() and goal=="pursue":velocity.y=-48
	current_velocity=system.world.fluids.current_velocity(bounds(global_position),current_velocity,delta)
	var before: Vector2=global_position;var grounded: bool=is_on_floor()
	velocity+=current_velocity;velocity.x+=knockback_x;move_and_slide();velocity.x=0 if is_on_wall() else velocity.x-knockback_x-current_velocity.x;velocity.y-=current_velocity.y if not is_on_floor() and not is_on_ceiling() else 0;knockback_x*=pow(.6,delta*20)
	if is_on_wall():knockback_x=0
	if grounded and is_on_floor():peak=global_position.y
	else:
		peak=minf(peak,global_position.y)
		if is_on_floor() and immersion.is_empty():
			var fall: int=ceili(maxf(0,(global_position.y-peak)/16-3.05))
			if fall>0 and not definition.get("slow_fall",false):hurt(fall,center(),"fall")
			peak=global_position.y
	if not immersion.is_empty():peak=global_position.y
	var distance: float=absf(global_position.x-before.x);walk_amount=move_toward(walk_amount,clampf(distance/maxf(delta*80,.001),0,1),delta*12)
	phase=fmod(phase+distance/16*4*.6662,TAU)
	hazard_time+=delta
	if hazard_time>=.5:hazard_time=0;system.hazards(self)
	if fire>0:
		fire=maxf(0,fire-delta);burn_time+=delta
		if burn_time>=1:burn_time=0;hurt(1,center(),"fire")
	else:burn_time=0
	if global_position.y>system.world.chunks.world_depth*16+64:system.remove(self)

func try_step(distance: float) -> bool:
	if not is_on_floor() or velocity.y<0 or absf(distance)<.001 or not test_move(global_transform,Vector2(distance,0)):return false
	var maximum: float=16.0 if definition.rig=="enderman" else 9.6;var above:=KinematicCollision2D.new();var rise: float=maximum
	if test_move(global_transform,Vector2(0,-maximum),above):rise=maxf(0,-above.get_travel().y-.02)
	if rise<.05:return false
	var raised: Transform2D=global_transform;raised.origin.y-=rise
	if test_move(raised,Vector2(distance,0)):return false
	raised.origin.x+=distance
	var floor_hit:=KinematicCollision2D.new()
	if not test_move(raised,Vector2(0,rise+.1),floor_hit) or floor_hit.get_normal().y>-.7:return false
	var climb: float=rise-floor_hit.get_travel().y
	if climb<=.02 or climb>maximum+.02:return false
	global_position.y-=climb;return true
