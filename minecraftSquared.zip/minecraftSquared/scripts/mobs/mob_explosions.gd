class_name MobExplosions
extends Node2D
var system: MobSystem
var effects: Array[Dictionary]=[]
const TEXTURE: Texture2D=preload("res://assets/mobs/explosion.png")
func setup(host: MobSystem) -> void:system=host;z_index=19;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
func _process(delta: float) -> void:
	if effects.is_empty():return
	for i in range(effects.size()-1,-1,-1):
		effects[i].age+=delta
		if effects[i].age>=.6:effects.remove_at(i)
	queue_redraw()
func _draw() -> void:
	var visible: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	for effect in effects:
		var size: float=effect.power*32
		var box:=Rect2(effect.position-Vector2.ONE*size*.5,Vector2.ONE*size)
		if not visible.intersects(box):continue
		var width: int=TEXTURE.get_width();var frame: int=clampi(int(effect.age/.6*16),0,15)
		draw_texture_rect_region(TEXTURE,box,Rect2(0,frame*width,width,width))
func exposure(origin: Vector2,bounds: Rect2) -> float:
	var clear: int=0
	for p in [bounds.get_center(),bounds.position+bounds.size*.15,bounds.position+bounds.size*.85,bounds.position+Vector2(bounds.size.x*.15,bounds.size.y*.85),bounds.position+Vector2(bounds.size.x*.85,bounds.size.y*.15)]:
		if system.visible(origin,p):clear+=1
	return clear/5.0
static func blast_damage(distance: float,exposed: float,power: float) -> int:
	var fraction: float=distance/(power*32)
	if fraction>1 or exposed<=0:return 0
	var impact: float=(1-fraction)*exposed
	return floori((impact*impact+impact)*.5*7*power*2+1)
func detonate(mob: MobActor) -> void:
	if mob.dead:return
	var world: Node2D=system.world;var origin: Vector2=mob.global_position-Vector2(0,8);var power: float=mob.definition.explosion_power
	mob.dead=true;mob.collision_layer=0;mob.collision_mask=0
	explode(origin,power,"You were blown up by a Creeper",system.mob_griefing)
	system.remove(mob)
func explode(origin: Vector2,power: float,reason: String,damage_blocks: bool=true) -> void:
	var world: Node2D=system.world
	if effects.size()>=4:effects.pop_front()
	effects.append({"position":origin,"power":power,"age":0.0});queue_redraw()
	# Resolve exposure against the intact terrain before carving the crater.
	if not world.player.spectator and not world.player.survival_dead:
		var bounds: Rect2=world.player_collision.global_transform*world.player_collision.shape.get_rect()
		var exposed: float=exposure(origin,bounds);var distance: float=origin.distance_to(world.player.global_position)
		var damage: int=blast_damage(distance,exposed,power)
		if damage>0 and not world.shields.block(damage,origin,"explosion"):
			world.survival.take_damage(damage,reason)
			if not world.player.survival_dead:
				var push: Vector2=(world.player.global_position-origin).normalized()*maxf(0,1-distance/(power*32))*exposed*320
				world.player.knockback_x+=push.x;world.player.velocity.y+=push.y
	for other: MobActor in system.active.values():
		if other.dead:continue
		var exposed: float=exposure(origin,other.bounds(other.global_position));var distance: float=origin.distance_to(other.center())
		var damage: int=blast_damage(distance,exposed,power)
		if damage>0:
			other.hurt(damage,origin,"explosion")
			if not other.dead:
				var push: Vector2=(other.center()-origin).normalized()*maxf(0,1-distance/(power*32))*exposed*320
				other.knockback_x+=push.x;other.velocity.y+=push.y
	if damage_blocks:carve(origin,power)
func carve(origin: Vector2,power: float) -> void:
	var world: Node2D=system.world;var destroyed: Dictionary={}
	for ray in range(int(MobCatalog.rules.blast_rays)):
		var angle: float=ray*TAU/float(MobCatalog.rules.blast_rays);var direction:=Vector2(cos(angle),sin(angle));var energy: float=power*system.rng.randf_range(.7,1.3);var point: Vector2=origin
		for step in range(40):
			var at: Vector2i=system.cell(point)
			if not world.chunks.is_cell_loaded(at):break
			var id: int=world.get_block(at);var def: Dictionary=BlockDatabase.BLOCKS.get(id,{})
			if id!=0:energy-=(float(def.get("blast_resistance",0))+.3)*.3
			if energy<=0:break
			if id!=0 and def.get("diggable",false):destroyed[at]=true
			if destroyed.size()>=int(MobCatalog.rules.blast_block_budget):break
			point+=direction*4.8;energy-=.225
		if destroyed.size()>=int(MobCatalog.rules.blast_block_budget):break
	for at in destroyed:destroy_block(at,power)
func destroy_block(at: Vector2i,power: float) -> void:
	var world: Node2D=system.world;var id: int=world.get_block(at)
	if id==0 or not BlockDatabase.BLOCKS[id].get("diggable",false) or not world.beds.can_break(at):return
	var metadata: Dictionary={};var block_tags: Dictionary=world.storage.block_tags.get(at,{}).duplicate(true)
	if not block_tags.is_empty():
		metadata["BlockEntityTag"]=NBT.node(NBT.COMPOUND,block_tags)
		if block_tags.has("CustomName"):metadata["display"]=NBT.node(NBT.COMPOUND,{"Name":block_tags.CustomName})
	var drops: Array[Dictionary]=[]
	if world.beds.parts.has(id):drops.append({"id":world.beds.parts[id].item,"count":1})
	else:drops=BlockDatabase.roll_drops(id,system.rng)
	world.set_block(at,0)
	# Container contents are released by their existing cell-change handlers.
	for drop in drops:
		if system.rng.randf()<=1.0/power:world.dropped_items.spawn_item(drop.id,drop.count,world.ground.to_global(world.ground.map_to_local(at)),Vector2.ZERO,-1,metadata)
