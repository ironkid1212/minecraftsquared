class_name MobDrawing
extends Node2D
var system: MobSystem
var textures: Dictionary={}
var drawn: int=0
var particles: Array[Dictionary]=[]
var _collect_death: bool=false
var _death_parts: Array[Dictionary]=[]
const HEADS: Texture2D=preload("res://assets/mobs/front_heads.png")
const ATTACHMENTS: Texture2D=preload("res://assets/mobs/head_attachments.png")
const PULLING: Array[Texture2D]=[preload("res://assets/mobs/bow_pulling_0.png"),preload("res://assets/mobs/bow_pulling_1.png"),preload("res://assets/mobs/bow_pulling_2.png")]
const BOW: Texture2D=preload("res://assets/mobs/skeleton_bow.png")
const EYES: Texture2D=preload("res://assets/mobs/spider_eyes.png")
const HEART: Texture2D=preload("res://assets/mobs/heart.png")
const FIRE: Texture2D=preload("res://assets/mobs/fire.png")
const CRITICAL: Texture2D=preload("res://assets/mobs/critical_hit.png")
const DAMAGE: Texture2D=preload("res://assets/mobs/damage.png")
func burst(at: Vector2,critical: bool) -> void:
	for i in range(8 if critical else 3):
		if particles.size()>=64:break
		particles.append({"position":at+Vector2(randf_range(-5,5),randf_range(-8,8)),"velocity":Vector2(randf_range(-24,24),randf_range(-30,-10)),"life":.45,"critical":critical})
func setup(host: MobSystem) -> void:
	system=host;z_index=18;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	for def in MobCatalog.definitions.values():
		for path in [def.texture]+([def.overlay_texture] if def.has("overlay_texture") else [])+([def.front_texture] if def.has("front_texture") else [])+([def.shooting_texture] if def.has("shooting_texture") else [])+([def.mushroom_texture] if def.has("mushroom_texture") else [])+def.get("variants",{}).values()+([def.wool_texture] if def.has("wool_texture") else []):
			if not textures.has(path):textures[path]=load(path)
func _process(delta: float) -> void:
	var had_particles: bool=not particles.is_empty()
	for i in range(particles.size()-1,-1,-1):
		particles[i].life-=delta;particles[i].position+=particles[i].velocity*delta;particles[i].velocity.y+=40*delta
		if particles[i].life<=0:particles.remove_at(i)
	if not system.active.is_empty() or had_particles:queue_redraw()
func part(texture: Texture2D,source: Rect2,bounds: Rect2,transform: Transform2D,tint: Color=Color.WHITE) -> void:
	if _collect_death:
		_death_parts.append({"texture":texture,"source":source,"bounds":bounds,"transform":transform,"tint":tint});return
	draw_set_transform_matrix(transform);draw_texture_rect_region(texture,bounds,source,tint)
func _draw() -> void:
	if system==null:return
	drawn=0
	var visible: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	var fraction: float=Engine.get_physics_interpolation_fraction()
	for mob: MobActor in system.active.values():
		var p: Vector2=mob.previous_position.lerp(mob.global_position,fraction)
		if not visible.intersects(mob.bounds(p).grow(24)):continue
		drawn+=1
		var transform:=Transform2D(0,Vector2(mob.facing,1)*float(mob.definition.get("render_scale",1))*(AnimalBreeding.baby_scale(mob) if AnimalBreeding.baby(mob) else 1.0),0,p)
		if mob.dead:
			var fallen:=Transform2D(-minf(PI*.5,sqrt(mob.death_time*2)*PI*.5),Vector2.ZERO)
			transform*=fallen
		_collect_death=mob.dead;_death_parts.clear()
		if mob.fuse>0:
			var progress: float=mob.fuse/float(mob.definition.fuse_seconds)
			transform*=Transform2D(0,Vector2(1+.15*progress*progress,1+.05*progress*progress),0,Vector2.ZERO)
		var tint: Color=system.world.lighting.render_tint(system.cell(mob.center()))*(Color(1,.4,.4) if mob.flash>0 else Color.WHITE)
		if mob.fuse>0 and int(mob.fuse*10)%2==0:tint=Color.WHITE
		var phase: float=lerp_angle(mob.previous_phase,mob.phase,fraction)
		if mob.definition.rig=="shulker":EndCitySystem.draw_shulker(self,mob,transform,tint)
		elif mob.definition.rig=="zombie":zombie(mob,transform,tint,phase)
		elif mob.definition.rig=="polar_bear":polar_bear(mob,transform,tint,phase)
		elif mob.definition.rig=="snow_golem":snow_golem(mob,transform,tint)
		elif mob.definition.rig=="pig":pig(mob,transform,tint,phase)
		elif mob.definition.rig=="chicken":chicken(mob,transform,tint,phase)
		elif mob.definition.rig=="creeper":creeper(mob,transform,tint,phase)
		elif mob.definition.rig=="skeleton":skeleton(mob,transform,tint,phase)
		elif mob.definition.rig=="spider":spider(mob,transform,tint,phase)
		elif mob.definition.rig=="rabbit":rabbit(mob,transform,tint,phase)
		elif mob.definition.rig=="enderman":enderman(mob,transform,tint,phase)
		elif mob.definition.rig=="blaze":blaze(mob,transform,tint)
		elif mob.definition.rig in ["silverfish","endermite"]:cave_bug(mob,transform,tint,phase)
		elif mob.definition.rig=="bat":bat(mob,transform,tint,phase)
		elif mob.definition.rig=="ghast":ghast(mob,transform,tint,phase)
		elif mob.definition.rig=="magma_cube":magma_cube(mob,transform,tint)
		else:animal(mob,transform,tint,phase)
		_collect_death=false
		if mob.dead and not _death_parts.is_empty():
			# Settle the actual posed geometry on its feet plane. A fixed 32px
			# humanoid box made tall, short and narrow species float during death.
			var bottom: float=-INF
			for command in _death_parts:bottom=maxf(bottom,(Transform2D(command.transform)*Rect2(command.bounds)).end.y)
			for command in _death_parts:
				var posed: Transform2D=command.transform;posed.origin.y+=p.y-bottom
				part(command.texture,command.source,command.bounds,posed,command.tint)
			_death_parts.clear()
		if mob.fire>0 and not mob.dead:
			var frame: int=int(Time.get_ticks_msec()/50)%maxi(1,FIRE.get_height()/16)
			part(FIRE,Rect2(0,frame*16,16,16),Rect2(-10,-float(mob.definition.size[1]),20,float(mob.definition.size[1])),Transform2D(0,p),Color(1,1,1,.8))
	draw_set_transform_matrix(Transform2D.IDENTITY)
	for particle in particles:
		if particle.get("portal",false):
			if visible.has_point(particle.position):draw_rect(Rect2(particle.position,Vector2.ONE),Color(.7,.15,1,particle.life*2))
			continue
		if particle.get("heart",false):
			if visible.has_point(particle.position):draw_texture_rect(HEART,Rect2(Vector2(particle.position).floor()-Vector2(2,2),Vector2(5,5)),false,Color(1,1,1,minf(1,particle.life*3)))
			continue
		if visible.has_point(particle.position):draw_texture_rect(CRITICAL if particle.critical else DAMAGE,Rect2(Vector2(particle.position).floor()-Vector2(2,2),Vector2(4,4)),false,Color(1,1,1,clampf(particle.life*5,0,1)))
func animal(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var cow: bool=mob.definition.rig=="cow"
	var texture: Texture2D=textures[mob.definition.get("variants",{}).get(mob.variant,mob.definition.texture)]
	var swing: float=sin(phase)*1.4*mob.walk_amount
	for near in [false,true]:
		var shade: Color=tint*(Color.WHITE if near else Color(.65,.65,.65))
		for front in [false,true]:
			var x: float=(6 if cow else 5) if front else -7
			var angle: float=swing*(1 if front==near else -1)
			var joint: Transform2D=t*Transform2D(angle,Vector2(x,-12))
			part(texture,Rect2(24,0,4,12),Rect2(-2,0,4,12),joint,shade)
			if not cow and not mob.sheared:part(textures[mob.definition.wool_texture],Rect2(24,0,4,6),Rect2(-2.5,-.5,5,7),joint,shade)
		if not near:
			part(texture,Rect2(6 if cow else 8,0,18 if cow else 16,10 if cow else 6),Rect2(-10 if cow else -8,-22 if cow else -18,18 if cow else 16,10 if cow else 6),t,tint)
			if not cow and not mob.sheared:part(textures[mob.definition.wool_texture],Rect2(8,0,16,6),Rect2(-9.75,-19.75,19.5,9.5),t,tint)
	if mob.definition.has("mushroom_texture") and not AnimalBreeding.baby(mob):
		for x in [-6,1]:part(textures[mob.definition.mushroom_texture],Rect2(0,0,16,16),Rect2(x-4,-30,8,8),t,tint)
	var head: Transform2D=t*Transform2D(.65 if mob.eat_time>0 else mob.head_pitch,Vector2(9 if cow else 8,-20 if cow else -18))
	if cow:part(texture,Rect2(20,0,4,8),Rect2(6,-22,5,8),t,tint)
	var front: bool=mob.glance>0 and not mob.dead
	# The wool cube is six pixels deep; the bare head is eight. Leave the nose exposed.
	if not cow and not mob.sheared and front:part(textures[mob.definition.wool_texture],Rect2(0,0,6,6),Rect2(-1.6,-4.6,7.2,7.2),head,tint)
	if mob.definition.has("mushroom_texture") and not AnimalBreeding.baby(mob):part(textures[mob.definition.mushroom_texture],Rect2(0,0,16,16),Rect2(0,-10,6,6),head,tint)
	head_part(mob,texture,Rect2(0,0,6 if cow else 8,8 if cow else 6),Rect2(-1 if cow else -2,-4,6 if cow else 8,8 if cow else 6),head,tint)
	if not cow and not mob.sheared and not front:part(textures[mob.definition.wool_texture],Rect2(0,0,6,6),Rect2(-2.6,-4.6,7.2,7.2),head,tint)
func zombie(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.texture]
	# The compact humanoid atlas already contains both direction banks.
	var base: Transform2D=t*Transform2D(0,Vector2(1.0/mob.facing,1),0,Vector2.ZERO)*Transform2D(0,Vector2(0,-14))
	var swing: float=sin(phase)*1.4*mob.walk_amount
	var f: int=mob.facing
	var head_angle: float=mob.head_pitch*f
	if absf(head_angle)<deg_to_rad(float(mob.definition.get("head_neutral_angle",0))):head_angle=0
	for near in [false,true]:
		var shade: Color=tint*(Color.WHITE if near else Color(.65,.65,.65))
		var leg: String="near_leg" if near else "far_leg"
		part(texture,PlayerSkinDrawing.region(leg,f,texture),Rect2(-2,0,4,12),base*Transform2D(swing*f*(1 if near else -1),Vector2(0,2)),shade)
		if not near:
			part(texture,PlayerSkinDrawing.region("body",f,texture),Rect2(-2,-10,4,12),base,tint)
			head_part(mob,texture,PlayerSkinDrawing.region("head",f,texture),Rect2(-4,-8,8,8),base*Transform2D(head_angle,Vector2(0,-10)),tint)
		var arm: String="near_arm" if near else "far_arm"
		part(texture,PlayerSkinDrawing.region(arm,f,texture),Rect2(-2,-2,4,12),base*Transform2D((-PI*.5+sin(phase)*.08)*f,Vector2(0,-8)),shade)

func pig(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.variants.get(mob.variant,mob.definition.texture)]
	var swing: float=sin(phase)*1.4*mob.walk_amount
	for near in [false,true]:
		var shade: Color=tint*(Color.WHITE if near else Color(.65,.65,.65))
		for front in [false,true]:
			var joint: Transform2D=t*Transform2D(swing*(1 if front==near else -1),Vector2(5 if front else -7,-6))
			part(texture,Rect2(24,0,4,6),Rect2(-2,0,4,6),joint,shade)
		if not near:
			part(texture,Rect2(8,0,16,8),Rect2(-8,-14,16,8),t,tint)
			if mob.variant=="cold":part(texture,Rect2(8,12,16,8),Rect2(-8.5,-14.5,17,9),t,tint)
	head_part(mob,texture,Rect2(0,0,8,8),Rect2(0,-4,8,8),t*Transform2D(mob.head_pitch,Vector2(6,-12)),tint)
func chicken(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.variants.get(mob.variant,mob.definition.texture)]
	var swing: float=sin(phase)*1.4*mob.walk_amount
	for near in [false,true]:
		part(texture,Rect2(24,0,3,5),Rect2(-1.5,0,3,5),t*Transform2D(swing*(1 if near else -1),Vector2(.7 if near else -.7,-5)),tint*(Color.WHITE if near else Color(.65,.65,.65)))
	part(texture,Rect2(8,0,8,6),Rect2(-4,-11,8,6),t,tint)
	head_part(mob,texture,Rect2(0,0,3,6),Rect2(0,-3,3,6),t*Transform2D(mob.head_pitch,Vector2(2,-12)),tint)
	var flap: float=sin(Time.get_ticks_msec()*.025)*.7 if not mob.is_on_floor() else 0
	part(texture,Rect2(28,0,6,4),Rect2(-3,0,6,4),t*Transform2D(flap,Vector2(0,-10)),tint)
func creeper(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.texture];var swing: float=sin(phase)*1.4*mob.walk_amount
	for near in [false,true]:
		for front in [false,true]:
			part(texture,Rect2(24,0,4,6),Rect2(-2,0,4,6),t*Transform2D(swing*(1 if front==near else -1),Vector2(2 if front else -2,-6)),tint*(Color.WHITE if near else Color(.65,.65,.65)))
		if not near:part(texture,Rect2(8,0,4,12),Rect2(-2,-18,4,12),t,tint)
	# Side UV is the normal pose; front UV appears only during an idle glance.
	head_part(mob,texture,Rect2(0,0,8,8),Rect2(-4,-8,8,8),t*Transform2D(mob.head_pitch,Vector2(0,-18)),tint)

func head_part(mob: MobActor,texture: Texture2D,source: Rect2,bounds: Rect2,t: Transform2D,tint: Color) -> void:
	if mob.glance>0 and not mob.dead:
		var uv: Array=mob.definition.front_head
		var region:=Rect2(uv[0],uv[1],uv[2],uv[3])
		if mob.definition.rig in ["cow","pig","chicken"]:region.position.y+=16*(["temperate","warm","cold"].find(mob.variant))
		var width: float=region.size.x
		if mob.definition.has("front_texture"):
			var uv_front: Array=mob.definition.front_uv
			region=Rect2(uv_front[0],uv_front[1],uv_front[2],uv_front[3]);width=region.size.x
			var front_texture: Texture2D=texture if mob.definition.rig=="rabbit" else textures[mob.definition.front_texture]
			part(front_texture,region,Rect2(bounds.get_center()-Vector2(width,bounds.size.y)*.5,Vector2(width,bounds.size.y)),t,tint)
		else:part(HEADS,region,Rect2(bounds.get_center()-Vector2(width,bounds.size.y)*.5,Vector2(width,bounds.size.y)),t,tint)
	else:part(texture,source,bounds,t,tint)
	var front: bool=mob.glance>0 and not mob.dead
	var attachments: Dictionary=mob.definition.get("head_attachments",{})
	attachments=attachments.get("variants",{}).get(mob.variant,attachments)
	for attachment: Dictionary in attachments.get("front" if front else "side",[]):
		var uv: Array=attachment.source;var box: Array=attachment.bounds
		var own_texture: bool=attachment.get("texture","")=="self"
		var region:=Rect2(uv[0],uv[1]+(0 if own_texture else 16*["temperate","warm","cold"].find(mob.variant)),uv[2],uv[3])
		var target:=Rect2(box[0],box[1],box[2],box[3])
		if front:target.position+=bounds.get_center()
		part(texture if own_texture else ATTACHMENTS,region,target,t,tint)

static func bow_stage(mob: MobActor) -> int:
	if not mob.charging:return -1
	var seconds: float=mob.bow_charge
	return 2 if seconds>=.9 else 1 if seconds>=.65 else 0

static func bow_transform(mob: MobActor,t: Transform2D) -> Transform2D:
	return t*Transform2D(SkeletonBowPose.make(mob).bow)

func skeleton(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	if mob.definition.has("melee_item"):melee_skeleton(mob,t,tint,phase);return
	var texture: Texture2D=textures[mob.definition.texture]
	var swing: float=sin(phase)*1.1*mob.walk_amount
	var pose: Dictionary=SkeletonBowPose.make(mob,phase)
	# Rear arm draws the string independently of the hand holding the bow.
	skeleton_arm(mob,texture,pose.shoulder,pose.pull,t,tint*Color(.65,.65,.65))
	for near in [false,true]:
		var shade: Color=tint*(Color.WHITE if near else Color(.65,.65,.65))
		skeleton_part(mob,texture,Rect2(0,18,2,12),Rect2(-1,0,2,12),t*Transform2D(swing*(1 if near else -1),Vector2(0,-12)),shade)
		if not near:
			var spine: Dictionary=mob.definition.spine
			var uv: Array=spine.source;var box: Array=spine.bounds
			part(texture,Rect2(uv[0],uv[1],uv[2],uv[3]),Rect2(box[0],box[1],box[2],box[3]),t,tint)
			part(texture,Rect2(0,18,2,3),Rect2(-1,-25,2,4),t,tint)
			skeleton_part(mob,texture,Rect2(16,20,4,12),Rect2(-2,-24,4,12),t,tint)
			head_part(mob,texture,Rect2(0,8,8,8),Rect2(-4,-8,8,8),t*Transform2D(mob.head_pitch,Vector2(0,-24)),tint)
			if mob.definition.has("overlay_texture"):
				part(textures[mob.definition.overlay_texture],Rect2(8 if mob.glance>0 else 0,8,8,8),Rect2(-4,-8,8,8).grow(.3),t*Transform2D(mob.head_pitch,Vector2(0,-24)),tint)
	if mob.definition.get("head_mushrooms",false) and not mob.sheared:
		var head: Transform2D=t*Transform2D(mob.head_pitch,Vector2(0,-24))
		part(preload("res://assets/mobs/red_mushroom.png"),Rect2(0,0,16,16),Rect2(-5,-13,6,6),head,tint)
		part(preload("res://assets/mobs/brown_mushroom.png"),Rect2(0,0,16,16),Rect2(0,-13,6,6),head,tint)
	var stage: int=bow_stage(mob)
	part(BOW if stage<0 else PULLING[stage],Rect2(0,0,16,16),Rect2(-SkeletonBowPose.SPRITE_GRIP*SkeletonBowPose.SPRITE_SCALE,Vector2(12,12)),t*Transform2D(pose.bow),tint)
	skeleton_arm(mob,texture,pose.shoulder,pose.grip,t,tint)

func skeleton_arm(mob: MobActor,texture: Texture2D,shoulder: Vector2,wrist: Vector2,t: Transform2D,tint: Color) -> void:
	var offset: Vector2=wrist-shoulder
	var joint: Transform2D=t*Transform2D(offset.angle()-PI*.5,shoulder)
	skeleton_part(mob,texture,Rect2(40,18,2,12),Rect2(-1,0,2,offset.length()),joint,tint)

func spider(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.texture]
	for near in [false,true]:
		var shade: Color=tint*(Color.WHITE if near else Color(.6,.6,.6))
		for n in range(4):
			var x: float=-5+n*3
			var foot: Vector2=Vector2(x+(n-1.5)*2+sin(phase+n*PI*.5+(0 if near else PI))*mob.walk_amount*3,0)
			var joint:=Vector2(x,-6);var elbow: Vector2=(joint+foot)*.5+Vector2(1,-3)
			segment(texture,joint,elbow,t,shade);segment(texture,elbow,foot,t,shade)
		if not near:
			part(texture,Rect2(0,24,12,8),Rect2(-12,-14,12,8),t,tint)
			part(texture,Rect2(0,6,6,6),Rect2(-1,-12,6,6),t,tint)
	var head: Transform2D=t*Transform2D(mob.head_pitch,Vector2(6,-10))
	head_part(mob,texture,Rect2(32,12,8,8),Rect2(-2,-4,8,8),head,tint)
	# Eyes stay visible in darkness, matching the emissive vanilla eye layer.
	if mob.glance>0:part(EYES,Rect2(40,12,8,8),Rect2(-2,-4,8,8),head)
	else:part(EYES,Rect2(32,12,8,8),Rect2(-2,-4,8,8),head)

func segment(texture: Texture2D,a: Vector2,b: Vector2,t: Transform2D,tint: Color) -> void:
	part(texture,Rect2(20,2,16,2),Rect2(0,-1,a.distance_to(b),2),t*Transform2D((b-a).angle(),a),tint)

func skeleton_part(mob: MobActor,texture: Texture2D,source: Rect2,bounds: Rect2,t: Transform2D,tint: Color) -> void:
	part(texture,source,bounds,t,tint)
	if mob.definition.has("overlay_texture"):part(textures[mob.definition.overlay_texture],source,bounds.grow(.3),t,tint)

func rabbit(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.variants[mob.variant]]
	var angle: float=-.4 if not mob.is_on_floor() and mob.velocity.y<0 else .15 if not mob.is_on_floor() else 0
	for near in [false,true]:
		var shade: Color=tint*(Color.WHITE if near else Color(.65,.65,.65))
		part(texture,Rect2(20,30,6,1),Rect2(-5,-1,6,1),t*Transform2D(angle,Vector2.ZERO),shade)
		part(texture,Rect2(36,20,2,4),Rect2(3,-4,2,4),t*Transform2D(-angle,Vector2.ZERO),shade)
		if not near:
			part(texture,Rect2(0,10,10,6),Rect2(-6,-8,10,6),t,tint)
			part(texture,Rect2(20,20,4,4),Rect2(-6,-5.5,4,4),t,tint)
	head_part(mob,texture,Rect2(0,21,5,5),Rect2(0,-5,5,5),t*Transform2D(mob.head_pitch,Vector2(1,-7)),tint)

func portal_burst(at: Vector2) -> void:
	for i in range(12):
		if particles.size()>=64:break
		particles.append({"position":at+Vector2(randf_range(-5,5),randf_range(-12,12)),"velocity":Vector2(randf_range(-20,20),randf_range(-20,10)),"life":.5,"critical":false,"portal":true})
func enderman(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.texture]
	var swing: float=clampf(sin(phase)*.4*mob.walk_amount,-.4,.4)
	var lift: float=5.0 if mob.anger>0 else 0.0
	var head: Transform2D=t*Transform2D(mob.head_pitch,Vector2(0,-41-lift))
	var region:=Rect2(8 if mob.glance>0 else 0,8,8,8)
	for near in [false,true]:
		var color: Color=tint if near else tint*Color(.65,.65,.65)
		part(texture,Rect2(56,2,2,30),Rect2(-1,0,2,30),t*Transform2D(swing*(1 if near else -1),Vector2(0,-30)),color)
		if not near:
			part(texture,Rect2(32,20,4,12),Rect2(-2,-42,4,12),t,tint)
			# The 3D angry jaw lift exposes a gap in a flat projection. A narrow
			# textured neck joins the head's pivot to the torso in every pose.
			part(texture,Rect2(32,20,2,6),Rect2(-1,-43-lift,2,5+lift),t,tint)
			part(texture,region,Rect2(-4,-8,8,8),head,tint)
			part(preload("res://assets/mobs/enderman_eyes.png"),region,Rect2(-4,-8,8,8),head,Color.WHITE)
		if near and mob.carried_block>0:
			var hand: Vector2=Transform2D(-.5,Vector2(0,-42))*Vector2(0,28)
			var definition: Dictionary=BlockDatabase.BLOCKS[mob.carried_block]
			var atlas: TileSetAtlasSource=ItemDrawing.get_icon_source(system.world.atlas_source,mob.carried_block)
			var origin: Vector2i=atlas.margins+Vector2i(definition.icon_tile)*(atlas.texture_region_size+atlas.separation)
			part(atlas.texture,Rect2(origin,atlas.texture_region_size),Rect2(hand-Vector2(4,7),Vector2(8,8)),t,tint*definition.icon_tint)
		part(texture,Rect2(56,2,2,30),Rect2(-1,-2,2,30),t*Transform2D(-.5 if mob.carried_block>0 else -swing*.5*(1 if near else -1),Vector2(0,-40)),color)
func blaze(mob: MobActor,t: Transform2D,tint: Color) -> void:
	var texture: Texture2D=textures[mob.definition.texture];var time: float=Time.get_ticks_msec()*.001
	if mob.charging:tint=tint.lerp(Color.WHITE,.65)
	for near in [false,true]:
		for ring in range(3):
			for rod in range(4):
				var angle: float=time*(1.8 if ring!=1 else -1.3)+rod*TAU/4+ring*.7
				if (sin(angle)>0)!=near:continue
				var x: float=cos(angle)*(9-ring*2);var y: float=-23+ring*6+cos(time*2+rod)*.7
				part(texture,Rect2(0,18,2,8),Rect2(x-1,y,2,8),t,tint if near else tint*Color(.65,.65,.65))
		if not near:part(texture,Rect2(8 if mob.glance>0 else 0,8,8,8),Rect2(-4,-28,8,8),t*Transform2D(mob.head_pitch,Vector2.ZERO),tint)
func magma_cube(mob: MobActor,t: Transform2D,tint: Color) -> void:
	var texture: Texture2D=textures[mob.definition.texture];var size: float=float(mob.definition.size[0]);var gap: float=0 if mob.is_on_floor() else minf(size*.05,absf(mob.velocity.y)*.002)
	var rows: Array=mob.definition.cube_drawing.front_rows if mob.glance>0 else mob.definition.cube_drawing.slice_rows
	# Native layer faces occupy one-pixel strips, separated by top/bottom UVs.
	# Advancing vertically by one sampled transparent space on the side bank.
	var bright: Color=Color(1,.4,.4) if mob.flash>0 else Color.WHITE
	if gap>0:
		var core: Array=mob.definition.cube_drawing.core_uv
		part(texture,Rect2(core[0],core[1],core[2],core[3]),Rect2(-size*.28,-size*.8-gap*3,size*.56,size*.6),t,bright)
	for slice in range(8):
		part(texture,Rect2(8 if mob.glance>0 else 0,int(rows[slice]),8,1),Rect2(-size*.5,-size-gap*7+slice*(size/8+gap),size,size/8),t,bright)

func cave_bug(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.texture]
	var sizes: Array=[[3,2,2],[4,3,2],[6,4,3],[3,3,3],[2,2,3],[2,1,2],[1,1,2]] if mob.definition.rig=="silverfish" else [[4,3,2],[6,4,5],[3,3,1],[1,2,1]]
	var uv: Array=[[0,0],[0,4],[0,9],[0,16],[0,22],[11,0],[13,4]] if mob.definition.rig=="silverfish" else [[0,0],[0,5],[0,14],[0,18]]
	var length: float=0
	for size in sizes:length+=float(size[2])
	var x: float=length*.5;var scale: float=.72 if mob.definition.rig=="silverfish" else 1
	for i in range(sizes.size()):
		var size: Array=sizes[i];var depth: float=size[2];x-=depth
		var sway: float=sin(phase*.8+i*.6)*mob.walk_amount*.45
		part(texture,Rect2(uv[i][0],int(uv[i][1])+int(depth),depth,size[1]),Rect2(x*scale,-float(size[1])*scale+sway,depth*scale,float(size[1])*scale),t,tint)
func hearts(at: Vector2,count: int=5) -> void:
	for i in range(count):
		if particles.size()>=64:return
		particles.append({"position":at+Vector2(randf_range(-4,4),randf_range(-5,2)),"velocity":Vector2(randf_range(-3,3),-10),"life":.8,"heart":true})

func ghast(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.shooting_texture if mob.charging else mob.definition.texture]
	# Vanilla packs can provide the 64x32 UV layout at 128x64 resolution.
	var uv_scale: Vector2=texture.get_size()/Vector2(64,32)
	for near in [false,true]:
		for leg in range(3):
			var length: int=[8,11,9][leg]
			part(texture,Rect2(Vector2(0,2)*uv_scale,Vector2(2,length)*uv_scale),Rect2(-3,0,6,length*1.5),t*Transform2D(sin(phase+leg*1.3)*.2,Vector2(-17+leg*16,-17)),tint if near else tint*Color(.65,.65,.65))
		if not near:part(texture,Rect2(Vector2(16 if mob.glance>0 else 0,16)*uv_scale,Vector2(16,16)*uv_scale),Rect2(-24,-64,48,48),t,tint)

func bat_wing(texture: Texture2D,t: Transform2D,tint: Color,right: bool,phase: float,hanging: bool) -> void:
	# Project the full wing membrane rather than the edge of a 3D plane.
	# Left and right occupy opposite sides; the tips have their own hinges.
	var mirror:=Transform2D(0,Vector2(-1 if right else 1,1),0,Vector2.ZERO)
	if hanging:
		part(texture,Rect2(16,8 if right else 0,6,8),Rect2(-3,-8.5,3,7.5),t*mirror,tint)
		return
	var flap: float=1.25 if hanging else .15+sin(phase)*.65
	var shoulder: Transform2D=t*Transform2D(0,Vector2(1.5 if right else -1.5,-7.5))*mirror*Transform2D(-flap,Vector2.ZERO)
	part(texture,Rect2(12,7 if right else 0,2,7),Rect2(-2,-2,2,7),shoulder,tint)
	var tip: Transform2D=shoulder*Transform2D(.95 if hanging else sin(phase-.35)*.3,Vector2(-2,0))
	part(texture,Rect2(16,8 if right else 0,6,8),Rect2(-6,-2,6,8),tip,tint)

func bat(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.texture]
	var body: Transform2D=t*Transform2D(PI,Vector2(0,-14.4)) if mob.bat_hanging else t
	bat_wing(texture,body,tint*Color(.75,.75,.75),false,phase,mob.bat_hanging)
	# The front faces preserve eyes and body detail in this readable 2D
	# projection; facing mirrors the model as a whole without losing a wing.
	part(texture,Rect2(2,2,3,5),Rect2(-1.5,-8,3,5),body,tint)
	part(texture,Rect2(16,16,3,2),Rect2(-1.5,-3,3,2),body,tint)
	var head: Transform2D=body*Transform2D(clampf(mob.head_pitch*.25,-.15,.15),Vector2(0,-8))
	part(texture,Rect2(8,15,3,5),Rect2(-4,-7,3,5),head,tint)
	part(texture,Rect2(1,15,3,5),Rect2(1,-7,3,5),head,tint)
	part(texture,Rect2(2,9,4,3),Rect2(-2,-3,4,3),head,tint)
	bat_wing(texture,body,tint,true,phase,mob.bat_hanging)

func melee_skeleton(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.texture];var swing: float=sin(phase)*mob.walk_amount
	for near in [false,true]:
		var shade: Color=tint*(Color.WHITE if near else Color(.65,.65,.65))
		part(texture,Rect2(0,18,2,12),Rect2(-1,0,2,12),t*Transform2D(swing*(1 if near else -1),Vector2(0,-12)),shade)
		if not near:
			var spine: Dictionary=mob.definition.spine;var uv: Array=spine.source;var box: Array=spine.bounds
			part(texture,Rect2(uv[0],uv[1],uv[2],uv[3]),Rect2(box[0],box[1],box[2],box[3]),t,tint)
			part(texture,Rect2(0,18,2,3),Rect2(-1,-25,2,4),t,tint)
			part(texture,Rect2(16,20,4,12),Rect2(-2,-24,4,12),t,tint)
			head_part(mob,texture,Rect2(0,8,8,8),Rect2(-4,-8,8,8),t*Transform2D(mob.head_pitch,Vector2(0,-24)),tint)
		var pose: Dictionary=melee_pose(mob,phase)
		var arm: Transform2D=t*Transform2D(pose.arm_angle if near else swing*.6,Vector2(0,-22))
		part(texture,Rect2(40,18,2,12),Rect2(-1,0,2,12),arm,shade)
		if near:
			var id: int=BlockDatabase.id_for(mob.definition.melee_item);var entry: Dictionary=BlockDatabase.BLOCKS[id]
			var source: TileSetAtlasSource=ItemDrawing.get_icon_source(system.world.atlas_source,id)
			var origin: Vector2i=source.margins+entry.icon_tile*(source.texture_region_size+source.separation)
			part(source.texture,Rect2(origin,source.texture_region_size),Rect2(-Vector2(pose.grip)*float(pose.scale),Vector2.ONE*16*float(pose.scale)),t*Transform2D(pose.item_transform),tint)

static func melee_pose(mob: MobActor,phase: float=0) -> Dictionary:
	var data: Dictionary=mob.definition.get("melee_pose",{})
	var angle: float=deg_to_rad(float(data.get("attack_arm_degrees",-90))) if mob.goal=="pursue" else deg_to_rad(float(data.get("idle_arm_degrees",0)))-sin(phase)*mob.walk_amount*.6
	var arm:=Transform2D(angle,Vector2(0,-22))
	var grip: Array=data.get("grip",[3.5,12.5])
	return {"arm_angle":angle,"grip":Vector2(grip[0],grip[1]),"scale":float(data.get("item_scale",.9)),"item_transform":arm*Transform2D(deg_to_rad(float(data.get("item_angle_degrees",90))),Vector2(0,11))}

func polar_bear(mob: MobActor,t: Transform2D,tint: Color,phase: float) -> void:
	var texture: Texture2D=textures[mob.definition.texture];var swing: float=sin(phase)*.65*mob.walk_amount
	var raised: float=.5 if mob.goal=="pursue" and mob.attack_time>.4 else 0
	var body: Transform2D=t*Transform2D(-raised,Vector2(-3,-9))
	for near in [false,true]:
		var shade: Color=tint*(Color.WHITE if near else Color(.65,.65,.65))
		for front in [false,true]:
			var limb: Transform2D=body*Transform2D(swing*(1 if front==near else -1),Vector2(9 if front else -9,0))
			part(texture,Rect2(50,30,8,10),Rect2(-3,0,6,9),limb,shade)
		if not near:part(texture,Rect2(0,30,11,14),Rect2(-12,-13,25,14),body,tint)
	var head: Transform2D=body*Transform2D(mob.head_pitch,Vector2(13,-9))
	part(texture,Rect2(7 if mob.glance>0 else 0,7,7,7),Rect2(-1,-4,9,9),head,tint)
	part(texture,Rect2(27,1,2,2),Rect2(0,-6,2,2),head,tint)
	if mob.glance>0:
		part(texture,Rect2(27,1,2,2),Rect2(5,-6,2,2),head,tint)
		part(texture,Rect2(3,47,5,3),Rect2(1,1,6,4),head,tint)
	else:part(texture,Rect2(0,47,3,3),Rect2(7,0,4,4),head,tint)
func snow_golem(mob: MobActor,t: Transform2D,tint: Color) -> void:
	var texture: Texture2D=textures[mob.definition.texture]
	part(texture,Rect2(0,48,12,12),Rect2(-6,-12,12,12),t,tint)
	part(texture,Rect2(0,26,10,10),Rect2(-5,-22,10,10),t,tint)
	var head: Transform2D=t*Transform2D(mob.head_pitch,Vector2(0,-26))
	part(texture,Rect2(0 if mob.glance<=0 else 8,8,8,8),Rect2(-4,-4,8,8),head,tint)
	if not mob.sheared and mob.glance<=0:part(preload("res://assets/mobs/snow_golem_pumpkin_side.png"),Rect2(0,0,16,16),Rect2(-5,-5,10,10),head,tint)
	elif not mob.sheared:part(system.world.atlas_source.texture,Rect2(Vector2(system.world.atlas_source.margins+BlockDatabase.BLOCKS[BlockDatabase.id_for("carved_pumpkin")].atlas*(system.world.atlas_source.texture_region_size+system.world.atlas_source.separation)),Vector2(16,16)),Rect2(-5,-5,10,10),head,tint)
	for near in [false,true]:
		var arm: Transform2D=t*Transform2D((-.45 if mob.goal=="ranged" else .1)*(1 if near else -1),Vector2(0,-19))
		part(texture,Rect2(32,0,12,2),Rect2(-1 if near else -11,0,12,2),arm,tint*(Color.WHITE if near else Color(.6,.6,.6)))
