class_name MobProjectiles
extends Node2D

var system: MobSystem
var arrows: Array[Dictionary]=[]
const TEXTURE: Texture2D=preload("res://assets/mobs/arrow.png")

func setup(host: MobSystem) -> void:
	system=host;z_index=19;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST

func shoot(mob: MobActor,target: Vector2) -> void:
	if system.world.effects!=null:system.world.effects.sound("entity.arrow.shoot",mob.center(),"entities",.7,1,2,.15)
	if arrows.size()>=int(MobCatalog.rules.projectile_cap):return
	var rule: Dictionary=mob.definition.ranged
	var origin: Vector2=SkeletonBowPose.arrow_origin(mob) if mob.definition.rig=="skeleton" else mob.center()+Vector2(mob.facing*5,-5)
	var offset: Vector2=target-origin
	# Compensate gravity, with vanilla-style inaccuracy instead of perfect tracking.
	var travel: float=offset.length()/float(rule.speed)
	var aim: Vector2=(offset-Vector2(0,.5*float(rule.gravity)*travel*travel)).normalized()
	aim=aim.rotated(system.rng.randfn(0,float(rule.inaccuracy)))
	arrows.append({"position":origin,"velocity":aim*float(rule.speed),"owner":mob.serial,"shooter":mob.definition.name,"gravity":float(rule.gravity),"damage":float(rule.damage),"life":8.0,"stuck":false,"effect":rule.get("effect",{}).duplicate(true),"deflected":false})
	queue_redraw()

func _physics_process(dt: float) -> void:
	if arrows.is_empty():return
	var player: CharacterBody2D=system.world.player
	for i in range(arrows.size()-1,-1,-1):
		var arrow: Dictionary=arrows[i];arrow.life-=dt
		var from: Vector2=arrow.position
		if arrow.life<=0 or not system.world.chunks.is_cell_loaded(system.cell(from)):
			arrows.remove_at(i);continue
		if arrow.stuck:
			if arrow.get("recoverable",false) and not player.spectator and not player.survival_dead and player.global_position.distance_to(from)<20:
				if system.world.inventory.add_item(BlockDatabase.id_for("arrow"),1)==0:arrows.remove_at(i)
			continue
		var to: Vector2=from+Vector2(arrow.velocity)*dt
		var query:=PhysicsRayQueryParameters2D.create(from,to,3)
		query.exclude=[player.get_rid()]
		var hit: Dictionary=get_world_2d().direct_space_state.intersect_ray(query)
		var reach: float=from.distance_to(to)
		var terrain: float=from.distance_to(hit.position) if not hit.is_empty() else INF
		var nearest: float=terrain;var target: MobActor=null;var player_hit: bool=false
		if not player.spectator and not player.survival_dead and not arrow.get("deflected",false) and not arrow.get("from_player",false) and not arrow.get("reflected",false):
			var shape: CollisionShape2D=player.get_node("CollisionShape2D")
			var box:=Rect2(shape.global_position-shape.shape.size*.5,shape.shape.size)
			var at: float=PlayerCombat.ray_entry(from,to,box,reach)
			if at<nearest:nearest=at;player_hit=true
		for mob: MobActor in system.active.values():
			if mob.dead or mob.serial==int(arrow.owner):continue
			var at: float=PlayerCombat.ray_entry(from,to,mob.bounds(mob.global_position),reach)
			if at<nearest:nearest=at;target=mob;player_hit=false
		if system.world.end_city_system!=null and system.world.end_city_system.intercept(from,to,nearest):arrows.remove_at(i);continue
		var boss_hit: Dictionary=system.world.end_fight.ray_hit(from,to,nearest) if system.world.end_fight!=null else {}
		if not boss_hit.is_empty() and float(boss_hit.distance)<nearest:
			system.world.end_fight.hit_target(boss_hit,projectile_damage(arrow),"projectile",bool(arrow.get("from_player",false)));arrows.remove_at(i);continue
		if target!=null:
			if target.definition.rig=="shulker" and target.shulker_peek<=.05 and not arrow.get("fireball",false) and not arrow.get("snowball",false):
				var direction: Vector2=(to-from).normalized();arrow.position=from+direction*nearest-direction*.5;arrow.velocity=-Vector2(arrow.velocity)*.1;arrow.owner=target.serial;arrow.deflected=true;continue
			if arrow.get("snowball",false):
				if target.definition.rig=="enderman":NetherMobBrain.teleport(target);arrows.remove_at(i);continue
				var owner_mob: MobActor=system.active.get(int(arrow.owner))
				if target.definition.rig=="blaze":target.hurt(3,from,"projectile",arrow.get("from_player",false),false,owner_mob)
				else:target.knockback_x=signf(to.x-from.x)*32;target.revenge_id=int(arrow.owner) if owner_mob!=null else 0;target.anger=10
				system.renderer.burst(target.center(),false);arrows.remove_at(i);continue
			if target.definition.rig=="enderman":
				target.hurt(float(arrow.damage),from,"projectile",arrow.get("from_player",false));arrow.position=to;continue
			var owner_mob: MobActor=system.active.get(int(arrow.owner))
			var damage: float=float(arrow.damage)
			if arrow.get("large_fireball",false):
				if target.definition.rig=="ghast" and arrow.get("reflected",false):damage=1000
				target.hurt(damage,from,"projectile",arrow.get("reflected",false),false,owner_mob)
				large_impact(arrow,from+(to-from).normalized()*nearest);arrows.remove_at(i);continue
			damage=projectile_damage(arrow)
			if target.hurt(damage,from,"projectile",arrow.get("from_player",false),false,owner_mob):system.renderer.burst(target.center(),false);target.effects.apply(arrow.get("effect",{}))
			if arrow.get("fireball",false) and not target.definition.get("fire_immune",false):target.fire=maxf(target.fire,5)
			arrows.remove_at(i);continue
		if player_hit:
			if arrow.get("large_fireball",false):
				if not system.world.shields.block(float(arrow.damage),from,"projectile"):system.world.survival.take_damage(float(arrow.damage),"You were fireballed by a Ghast")
				large_impact(arrow,from+(to-from).normalized()*nearest);arrows.remove_at(i);continue
			if system.world.shields.block(float(arrow.damage),from,"projectile"):
				if arrow.get("fireball",false):arrows.remove_at(i);continue
				arrow.velocity=-Vector2(arrow.velocity)*.15;arrow.deflected=true;arrow.owner=0;arrow.position=from;continue
			if system.world.survival.take_damage(int(arrow.damage),("You were burned by a Blaze" if arrow.get("fireball",false) else "You were shot by a "+str(arrow.get("shooter","Skeleton")))):player.receive_knockback(from,80);system.world.survival.apply_effect(arrow.get("effect",{}))
			if arrow.get("fireball",false) and not system.world.survival.dead and not system.world.survival.effects.remaining.has("fire_resistance"):system.world.fluids.burning=maxf(system.world.fluids.burning,5)
			arrows.remove_at(i);continue
		if arrow.get("fireball",false) and not hit.is_empty():
			if arrow.get("large_fireball",false):large_impact(arrow,hit.position);arrows.remove_at(i);continue
			var at: Vector2i=system.cell(Vector2(hit.position)+Vector2(hit.normal)*3)
			if system.mob_griefing and system.world.get_block(at)==0 and system.world.get_block(at+Vector2i.DOWN)!=0:system.world.set_block(at,BlockDatabase.id_for("fire"))
			arrows.remove_at(i);continue
		if not hit.is_empty() and arrow.get("snowball",false):arrows.remove_at(i);continue
		if not hit.is_empty():arrow.position=hit.position;arrow.stuck=true;arrow.life=60 if arrow.get("recoverable",false) else 5
		else:
			arrow.position=to
			var v: Vector2=arrow.velocity
			if arrow.get("from_player",false):v*=pow(.99,dt*20)
			v.y+=float(arrow.gravity)*dt
			if system.world.fluids.submerged(to)=="water":v*=pow(.6,dt*20)
			arrow.velocity=v
	queue_redraw()

func _draw() -> void:
	var view: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	for arrow in arrows:
		if not view.grow(12).has_point(arrow.position):continue
		if arrow.get("snowball",false):
			draw_set_transform_matrix(Transform2D.IDENTITY);ItemDrawing.draw_icon(self,system.world.atlas_source,BlockDatabase.id_for("snowball"),Rect2(Vector2(arrow.position)-Vector2(2,2),Vector2(4,4)),system.world.lighting.render_tint(system.cell(arrow.position)));continue
		if arrow.get("fireball",false):
			draw_set_transform_matrix(Transform2D.IDENTITY)
			if arrow.get("large_fireball",false):draw_texture_rect(preload("res://assets/mobs/large_fireball.png"),Rect2(arrow.position-Vector2(6,6),Vector2(12,12)),false);continue
			var frame: int=posmod(Time.get_ticks_msec()/50,32)
			draw_texture_rect_region(preload("res://assets/environment/nether/fire_0.png"),Rect2(arrow.position-Vector2(4,4),Vector2(8,8)),Rect2(0,frame*16,16,16));continue
		draw_set_transform(arrow.position,Vector2(arrow.velocity).angle()+PI*.25)
		draw_texture_rect(TEXTURE,Rect2(-6,-6,12,12),false,system.world.lighting.render_tint(system.cell(arrow.position)))
	draw_set_transform_matrix(Transform2D.IDENTITY)

func shoot_player(origin: Vector2,aim: Vector2,power: float,rule: Dictionary,power_level: int=0) -> bool:
	if arrows.size()>=int(MobCatalog.rules.projectile_cap):return false
	arrows.append({"position":origin,"velocity":aim*float(rule.speed)*power,"owner":-1,"shooter":"Player","gravity":float(rule.gravity),"power_level":power_level,"damage":6*power,"life":30.0,"stuck":false,"effect":{},"deflected":false,"from_player":true,"recoverable":not system.world.player.creative,"critical":power>=1})
	if system.world.effects!=null:system.world.effects.sound("entity.arrow.shoot",origin,"player",.7,1,2,.15)
	queue_redraw();return true

func snapshot_player() -> Array:
	var result: Array=[]
	for arrow in arrows:
		if not arrow.get("from_player",false) or arrow.get("snowball",false):continue
		result.append({"position":[arrow.position.x,arrow.position.y],"velocity":[arrow.velocity.x,arrow.velocity.y],"gravity":arrow.gravity,"life":arrow.life,"stuck":arrow.stuck,"critical":arrow.critical,"power_level":int(arrow.get("power_level",0))})
	return result
func restore_player(records: Array) -> void:
	arrows.clear()
	for record in records:
		arrows.append({"position":Vector2(record.position[0],record.position[1]),"velocity":Vector2(record.velocity[0],record.velocity[1]),"owner":-1,"shooter":"Player","gravity":float(record.gravity),"damage":0,"life":float(record.life),"stuck":record.stuck,"effect":{},"deflected":false,"from_player":true,"recoverable":true,"critical":record.critical,"power_level":int(record.get("power_level",0))})
	queue_redraw()

func fireball(mob: MobActor,target: Vector2) -> void:
	if arrows.size()>=int(MobCatalog.rules.projectile_cap):return
	var rule: Dictionary=mob.definition.blaze_attack
	var origin: Vector2=mob.center()-Vector2(0,4)
	var aim: Vector2=(target-origin).normalized().rotated(system.rng.randfn(0,float(rule.spread)))
	arrows.append({"position":origin,"velocity":aim*float(rule.speed),"owner":mob.serial,"shooter":"Blaze","gravity":0.0,"damage":float(rule.damage),"life":8.0,"stuck":false,"effect":{},"deflected":false,"fireball":true})
	queue_redraw()

func ghast_fireball(mob: MobActor,target: Vector2) -> void:
	if arrows.size()>=int(MobCatalog.rules.projectile_cap):return
	var rule: Dictionary=mob.definition.ghast_attack
	var aim: Vector2=(target-mob.center()).normalized()
	var origin: Vector2=mob.center()+aim*28
	arrows.append({"position":origin,"velocity":aim*float(rule.speed),"owner":mob.serial,"shooter":"Ghast","gravity":0.0,"damage":float(rule.damage),"power":float(rule.power),"life":12.0,"stuck":false,"effect":{},"deflected":false,"fireball":true,"large_fireball":true})
	queue_redraw()

func large_impact(shot: Dictionary,point: Vector2) -> void:
	system.explosions.explode(point,float(shot.power),"You were blown up by a Ghast",system.mob_griefing)
	if system.mob_griefing:
		var cell: Vector2i=system.cell(point)
		if system.world.get_block(cell)==0 and system.support(cell+Vector2i.DOWN):system.world.set_block(cell,BlockDatabase.id_for("fire"))

func reflect_at_pointer() -> bool:
	var world: Node2D=system.world
	if world.player.spectator or world.player.survival_dead:return false
	var eye: Vector2=world.player.eye_position();var pointer: Vector2=world.pointer_global_position()
	var nearest: Dictionary={};var distance: float=INF
	for shot in arrows:
		if not shot.get("large_fireball",false) or shot.stuck:continue
		var box:=Rect2(Vector2(shot.position)-Vector2(7,7),Vector2(14,14))
		if not box.has_point(pointer):continue
		var at: float=PlayerCombat.ray_entry(eye,pointer,box,float(MobCatalog.rules.attack_reach)*16)
		if at<distance and system.visible(eye,shot.position):nearest=shot;distance=at
	if nearest.is_empty():return false
	var aim: Vector2=(pointer-eye).normalized()
	if aim.is_zero_approx():aim=Vector2(world.player.facing,0)
	nearest.velocity=aim*maxf(160,Vector2(nearest.velocity).length());nearest.owner=-1;nearest.reflected=true
	world.player.swing_hand("mine",nearest.position);world.combat.elapsed=0;queue_redraw();return true

func snowball(origin: Vector2,aim: Vector2,owner: int,player_owned: bool) -> bool:
	if arrows.size()>=int(MobCatalog.rules.projectile_cap):return false
	var rule: Dictionary=MobCatalog.definitions.snow_golem.cold
	arrows.append({"position":origin,"velocity":aim*float(rule.speed),"owner":owner,"shooter":"Snow Golem","gravity":float(rule.gravity),"damage":0.0,"life":8.0,"stuck":false,"effect":{},"deflected":true,"snowball":true,"from_player":player_owned})
	queue_redraw();return true

func projectile_damage(arrow: Dictionary) -> float:
	if arrow.get("snowball",false):return 0
	var damage: float=float(arrow.damage)
	if arrow.get("from_player",false):
		damage=ceilf(Vector2(arrow.velocity).length()/160*(1+(.5+.5*int(arrow.get("power_level",0)))/2 if int(arrow.get("power_level",0))>0 else 1))
		if arrow.get("critical",false):damage+=system.rng.randi_range(0,int(damage/2)+1)
	return damage
