class_name PlayerCombat
extends Node
var world: Node2D
var elapsed: float=1
var last_item: int=-1
var indicator: CombatIndicator
var last_critical: bool=false
func setup(game: Node2D) -> void:
	world=game;indicator=CombatIndicator.new();(world.ui_layer if world.ui_layer!=null else world.get_node("UI")).add_child(indicator);indicator.combat=self
	world.hotbar.selection_changed.connect(_selected)
func _selected() -> void:
	var item: int=world.hotbar.get_selected_block()
	if item!=last_item:elapsed=0;last_item=item
func cooldown() -> float:
	return 1.0/float(ToolDatabase.TOOLS.get(world.hotbar.get_selected_block(),{}).get("attack_speed",4))
func strength() -> float:return clampf((elapsed+.025)/cooldown(),0,1)
func _process(delta: float) -> void:
	_selected();elapsed=minf(10,elapsed+delta);indicator.queue_redraw()
func target() -> MobActor:
	if world.player.spectator or world.player.survival_dead:return null
	var point: Vector2=world.pointer_global_position();var eye: Vector2=world.player.eye_position();var nearest: MobActor=null;var distance: float=INF
	# Explicit clicking fits a 2D mining game; along that ray the nearer mob wins.
	var focus: bool=false
	for mob: MobActor in world.mobs.active.values():
		if not mob.dead and mob.bounds(mob.global_position).grow(.5).has_point(point):focus=true;break
	if not focus:return null
	for mob: MobActor in world.mobs.active.values():
		if mob.dead:continue
		var d: float=ray_entry(eye,point,mob.bounds(mob.global_position).grow(.5),float(MobCatalog.rules.attack_reach)*16)
		var hit: Vector2=eye+(point-eye).normalized()*d if is_finite(d) else point
		if d<distance and world.mobs.visible(eye,hit):nearest=mob;distance=d
	return nearest
static func ray_entry(origin: Vector2,aim: Vector2,bounds: Rect2,reach: float) -> float:
	var direction: Vector2=(aim-origin).normalized()
	if direction.is_zero_approx():return 0 if bounds.has_point(origin) else INF
	var enter: float=0;var exit: float=reach
	for axis in range(2):
		if absf(direction[axis])<.000001:
			if origin[axis]<bounds.position[axis] or origin[axis]>bounds.end[axis]:return INF
			continue
		var a: float=(bounds.position[axis]-origin[axis])/direction[axis];var b: float=(bounds.end[axis]-origin[axis])/direction[axis]
		enter=maxf(enter,minf(a,b));exit=minf(exit,maxf(a,b))
		if enter>exit:return INF
	return enter
func attack(mob: MobActor) -> void:
	if mob==null or target()!=mob:return
	var charged: float=strength();var tool: Dictionary=ToolDatabase.TOOLS.get(world.hotbar.get_selected_block(),{})
	var damage: float=(float(tool.get("attack_damage",1))+(3*(1+int(world.survival.effects.amplifiers.get("strength",0))) if world.survival.effects.remaining.has("strength") else 0))*(.2+.8*charged*charged)
	last_critical=charged>.9 and world.player.velocity.y>0 and not world.player.is_on_floor() and not world.player.sprinting and world.fluids.body_kind().is_empty()
	if last_critical:damage*=1.5
	var sharpness: int=EnchantmentDatabase.level(world.inventory.tags[world.hotbar.selected_slot],"sharpness")
	if sharpness>0:damage+=(.5+.5*sharpness)*charged
	var strong: bool=charged>.9 and world.player.sprinting
	elapsed=0;world.player.swing_hand("mine",mob.center())
	world.food.add_exhaustion(float(world.food.rules.attack))
	if mob.hurt(damage,world.player.eye_position(),"melee",true,strong):
		if not tool.is_empty() and tool.get("kind")!="shears":world.inventory.damage_tool(world.hotbar.selected_slot,1 if tool.get("kind")=="sword" else 2)
		world.mobs.renderer.burst(mob.center(),last_critical)
		if strong:world.player.velocity.x*=.6;world.player.locomotion._sprint_latched=false
		if charged>.9 and tool.get("kind")=="sword" and not last_critical and not strong and world.player.is_on_floor() and absf(world.player.velocity.x)<world.settings.player.move_speed:
			for other: MobActor in world.mobs.active.values():
				var eye: Vector2=world.player.eye_position();var box: Rect2=other.bounds(other.global_position)
				if other!=mob and not other.dead and other.center().distance_to(mob.center())<float(MobCatalog.rules.sweep_radius)*16 and eye.distance_to(eye.clamp(box.position,box.end))<=float(MobCatalog.rules.attack_reach)*16 and world.mobs.visible(mob.center(),other.center()):other.hurt(1,eye,"melee",true)
