class_name CombatIndicator
extends Control
var combat: PlayerCombat
const BACK: Texture2D=preload("res://assets/ui/crosshair_attack_indicator_background.png")
const PROGRESS: Texture2D=preload("res://assets/ui/crosshair_attack_indicator_progress.png")
const FULL: Texture2D=preload("res://assets/ui/crosshair_attack_indicator_full.png")
func _ready() -> void:mouse_filter=Control.MOUSE_FILTER_IGNORE;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
func _draw() -> void:
	if combat==null:return
	var world: Node2D=combat.world
	if world.player.spectator or world.player.survival_dead or world.upgrade_is_open() or world.inventory_screen.is_open or world.storage_screen.is_open or world.furnace_screen.is_open or world.chat.is_open or world._pointer_over_hotbar() or world.external_pointer and not world.pointer_active:return
	var charge: float=combat.strength()
	if charge>=1 and (combat.cooldown()<=.25 or combat.target()==null):return
	var scale_value: float=maxf(1,world.hotbar.UI_SCALE*.5);scale_value=floorf(scale_value)
	var pointer: Vector2=world.pointer_position if world.external_pointer else get_viewport().get_mouse_position()
	var origin: Vector2=(pointer+Vector2(-8,12)*scale_value).floor()
	if origin.y+(FULL.get_height() if charge>=1 else 4)*scale_value>=HudLayout.text_bottom(world):return
	if charge>=1:
		draw_texture_rect(FULL,Rect2(origin,FULL.get_size()*scale_value),false);return
	draw_texture_rect(BACK,Rect2(origin,Vector2(16,4)*scale_value),false)
	var width: int=floori(16*charge)
	if width>0:draw_texture_rect_region(PROGRESS,Rect2(origin,Vector2(width,4)*scale_value),Rect2(0,0,width,4))
