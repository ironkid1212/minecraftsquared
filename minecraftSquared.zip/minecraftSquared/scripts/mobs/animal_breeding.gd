class_name AnimalBreeding
extends RefCounted

## Ages and cooldowns advance only in loaded chunks, like other entity state.
static func baby(mob: MobActor) -> bool:return mob.growing_age<0 and mob.definition.has("breeding")
static func resize(mob: MobActor) -> void:
	var scale: float=float(mob.definition.breeding.baby_scale) if baby(mob) else 1.0
	var shape: CollisionShape2D=mob.get_node("CollisionShape2D")
	shape.shape.size=Vector2(mob.definition.size[0],mob.definition.size[1])*scale;shape.position.y=-shape.shape.size.y*.5
static func feed(mob: MobActor,slot: int) -> bool:
	if not mob.definition.has("breeding"):return false
	var world: Node2D=mob.system.world;var rule: Dictionary=mob.definition.breeding
	var key: String=str(BlockDatabase.BLOCKS.get(world.inventory.ids[slot],{}).get("key",""))
	if key not in rule.foods:return false
	if baby(mob):
		# Feeding removes 10% of remaining childhood, with a one-second minimum.
		mob.growing_age=minf(0,mob.growing_age+maxf(1,-mob.growing_age*.1))
		if mob.growing_age==0 and not mob.system.can_fit(mob.definition.key,mob.global_position):mob.growing_age=-.001
		resize(mob)
	elif mob.growing_age==0 and mob.love_time<=0:mob.love_time=float(rule.love_seconds)
	else:return false
	if not world.player.creative:world.inventory.remove_from_slot(slot,1)
	mob.system.swing(slot,mob.center());mob.system.renderer.hearts(mob.center());return true
static func step(mob: MobActor,delta: float) -> void:
	if not mob.definition.has("breeding"):return
	var was_baby: bool=baby(mob)
	if mob.growing_age<0:
		var amount: float=minf(-mob.growing_age,delta)
		# Wait to grow when the adult body would intersect terrain.
		if mob.growing_age+amount<0 or mob.system.can_fit(mob.definition.key,mob.global_position):mob.growing_age+=amount
	else:mob.growing_age=maxf(0,mob.growing_age-delta)
	if was_baby!=baby(mob):resize(mob)
	mob.love_time=maxf(0,mob.love_time-delta)
	if mob.love_time>0 and fmod(mob.love_time,.5)<delta:mob.system.renderer.hearts(mob.center(),1)
	if mob.love_time<=0 or mob.panic>0 or mob.growing_age!=0:mob.mate_time=0
static func think(mob: MobActor) -> bool:
	if not mob.definition.has("breeding") or mob.panic>0:return false
	var rule: Dictionary=mob.definition.breeding;var mate: MobActor=null;var nearest: float=float(rule.mate_range)*16
	for other: MobActor in mob.system.active.values():
		if other==mob or other.dead or other.definition.key!=mob.definition.key:continue
		if baby(mob):
			if baby(other):continue
		elif mob.love_time<=0 or other.love_time<=0 or other.growing_age!=0:continue
		var distance: float=mob.global_position.distance_to(other.global_position)
		if distance<nearest and mob.system.visible(mob.center(),other.center()):nearest=distance;mate=other
	if mate==null:mob.mate_time=0;return false
	mob.goal="follow_parent" if baby(mob) else "breed";mob.eat_time=0;mob.glance=0
	MobBrain.look(mob,mate.center());MobBrain.navigate(mob.system,mob,mate.global_position,true)
	if baby(mob):
		if nearest<32:mob.desired=0
		return true
	if nearest>32:mob.mate_time=0;return true
	mob.desired=0;mob.mate_time+=float(MobCatalog.rules.ai_interval)
	# One parent owns creation; both parents are reset atomically after success.
	if mob.serial>mate.serial or mob.mate_time<float(rule.courtship_seconds):return true
	var point: Vector2=(mob.global_position+mate.global_position)*.5
	var scale: float=float(rule.baby_scale);var size:=Vector2(mob.definition.size[0],mob.definition.size[1])*scale
	if not mob.system.can_fit(mob.definition.key,point,size):return true
	var record: Dictionary={"id":mob.system.next_id,"position":[point.x,point.y],"growing_age":-float(rule.baby_seconds),"variant":mob.variant if mob.system.rng.randf()<.5 else mate.variant}
	var child: MobActor=mob.system.spawn(mob.definition.key,point,record)
	if child==null:return true
	mob.system.next_id+=1
	mob.love_time=0;mate.love_time=0;mob.mate_time=0;mate.mate_time=0
	mob.growing_age=float(rule.cooldown_seconds);mate.growing_age=float(rule.cooldown_seconds)
	mob.system.renderer.hearts(point);mob.system.world.experience.spawn(mob.system.rng.randi_range(1,7),point)
	return true
