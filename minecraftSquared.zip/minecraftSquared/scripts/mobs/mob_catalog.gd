class_name MobCatalog
extends RefCounted
static var data: Dictionary=DataFile.object_from("res://data/mobs.json")
static var rules: Dictionary=data.get("rules",{})
static var definitions: Dictionary={}
static var _validated: bool=false
static func validate() -> bool:
	if _validated:return true
	definitions.clear()
	if data.get("version")!=1 or not data.get("mobs") is Array:DataFile.fail("mobs.json: invalid version or mob list.");return false
	for key in ["active_distance","despawn_distance","hostile_cap","passive_cap","record_limit","spawn_interval","spawn_attempts","spawn_min_distance","spawn_max_distance","passive_region_width","ai_interval","navigation_nodes","attack_reach","knockback","maximum_active","path_jobs_per_tick"]:
		if not ContentCatalog._number(rules.get(key),.001,100000):DataFile.fail("mobs.json: invalid rule "+key);return false
	if not rules.get("enabled") is bool or not rules.get("daylight_burn") is bool or not ContentCatalog._number(rules.get("passive_region_chance"),0,1) or rules.spawn_min_distance>=rules.spawn_max_distance or rules.active_distance>rules.despawn_distance:return false
	if not ContentCatalog._number(rules.get("ground_drag"),.01,.999):return false
	if not rules.get("mob_griefing") is bool or not ContentCatalog._number(rules.get("sweep_radius"),0,3) or not ContentCatalog._number(rules.get("blast_rays"),8,128,true) or not ContentCatalog._number(rules.get("blast_block_budget"),1,512,true):return false
	for field in ["glance_interval","glance_duration"]:
		if not ContentCatalog._vector(rules.get(field),2,.1,120) or rules[field][1]<rules[field][0]:DataFile.fail("mobs.json: invalid "+field);return false
	if not ContentCatalog._number(rules.get("projectile_cap"),1,128,true):return false
	for entry in data.mobs:
		if not entry is Dictionary or not entry.get("key") is String or not entry.key.is_valid_identifier() or definitions.has(entry.key) or entry.get("rig") not in ["cow","sheep","zombie","pig","chicken","creeper","skeleton","spider","rabbit","enderman","blaze","magma_cube","silverfish","endermite","bat","ghast"]:DataFile.fail("mobs.json: invalid/duplicate mob or rig.");return false
		for key in ["health","movement_attribute","jump_speed","gravity","follow_range","panic_multiplier","attack_interval","tempt_multiplier","spawn_weight"]:
			if not ContentCatalog._number(entry.get(key),0 if key=="spawn_weight" else .001,2000):DataFile.fail("mobs.json: invalid "+key);return false
		if not entry.get("hostile") is bool or not ContentCatalog._vector(entry.get("size"),2,1,64) or not ContentCatalog._number(entry.get("armor"),0,30) or not ContentCatalog._number(entry.get("attack_damage"),0,100) or not entry.get("texture") is String or not ResourceLoader.exists(entry.texture):return false
		if not ContentCatalog._number(entry.movement_attribute,.001,1) or not ContentCatalog._number(entry.panic_multiplier,.1,4) or not ContentCatalog._number(entry.tempt_multiplier,.1,4):return false
		if not entry.get("drops") is Array or not entry.get("biomes") is Array or not ContentCatalog._vector(entry.get("herd"),2,1,8,true):return false
		if entry.herd[1]<entry.herd[0]:return false
		if not entry.get("grazes") is bool or not entry.get("interactions") is Dictionary:return false
		if not entry.get("tempt_items") is Array or not entry.get("sun_burn") is bool:return false
		if not ContentCatalog._vector(entry.get("front_head"),4,0,128) or entry.front_head[2]<=0 or entry.front_head[3]<=0:return false
		for field in ["target_memory","chase_multiplier","look_range","panic_seconds"]:
			if not ContentCatalog._number(entry.get(field),.1,120):DataFile.fail("mobs.json: invalid "+field);return false
		for field in ["wander_seconds","idle_seconds"]:
			if not ContentCatalog._vector(entry.get(field),2,.1,120) or entry[field][1]<entry[field][0]:return false
		for field in ["climbs","sinks","undead","avoid_sun","neutral","flying","fire_immune","cube","nether_only"]:
			if entry.has(field) and not entry[field] is bool:return false
		if not ContentCatalog._number(entry.get("experience",5),0,1000,true):return false
		if entry.rig=="enderman":
			if not entry.get("teleport") is Dictionary:return false
			for field in ["range","attempts","stare_seconds","chase_seconds","projectile_attempts"]:
				if not ContentCatalog._number(entry.teleport.get(field),.01,128):return false
			if not ContentCatalog._vector(entry.teleport.get("anger_seconds"),2,1,120):return false
		if not ContentCatalog._number(entry.get("creature_lifetime",0),0,100000) or not entry.get("ambient",false) is bool:return false
		if entry.rig=="bat":
			if not entry.get("flight") is Dictionary:return false
			for field in ["speed","decision_seconds","wake_range"]:
				if not ContentCatalog._number(entry.flight.get(field),.01,320):return false
			if not ContentCatalog._number(entry.flight.get("hang_chance"),0,1):return false
		if entry.rig=="blaze":
			if not entry.get("blaze_attack") is Dictionary:return false
			for field in ["charge_seconds","shot_interval","recovery_seconds","shots","speed","damage","burn_seconds","spread"]:
				if not ContentCatalog._number(entry.blaze_attack.get(field),.001,1000):return false
		if entry.has("neutral_brightness") and not ContentCatalog._number(entry.neutral_brightness,0,15,true):return false
		for field in ["overlay_texture","front_texture","shooting_texture"]:
			if entry.has(field) and (not entry[field] is String or not ResourceLoader.exists(entry[field])):return false
		if entry.has("front_texture") and not ContentCatalog._vector(entry.get("front_uv"),4,0,64):return false
		if not ContentCatalog._number(entry.get("render_scale",1),.1,2):return false
		if entry.has("breeding"):
			var b: Variant=entry.breeding
			if not b is Dictionary or entry.hostile or not b.get("foods") is Array or b.foods.is_empty():return false
			for food in b.foods:
				if not food is String or BlockDatabase.id_for(food)==0:return false
			for field in ["love_seconds","cooldown_seconds","baby_seconds","courtship_seconds","mate_range"]:
				if not ContentCatalog._number(b.get(field),.1,2400):return false
			if not ContentCatalog._number(b.get("baby_scale"),.25,1):return false
		if entry.rig=="ghast":
			if not entry.get("ghast_attack") is Dictionary or not entry.has("shooting_texture"):return false
			for field in ["range","warning_seconds","charge_seconds","recovery_seconds","speed","damage","power","flight_speed","natural_cap"]:
				if not ContentCatalog._number(entry.ghast_attack.get(field),.1,1000):return false
		if entry.rig=="skeleton":
			if not entry.get("spine") is Dictionary or not ContentCatalog._vector(entry.spine.get("source"),4,0,64) or not ContentCatalog._vector(entry.spine.get("bounds"),4,-32,32):return false
		if entry.get("cube",false):
			var drawing: Variant=entry.get("cube_drawing")
			if not drawing is Dictionary or not ContentCatalog._vector(drawing.get("slice_rows"),8,0,63,true) or not ContentCatalog._vector(drawing.get("front_rows"),8,0,63,true) or not ContentCatalog._vector(drawing.get("core_uv"),4,0,64,true):return false
			var motion: Variant=entry.get("cube_motion")
			if not motion is Dictionary or not ContentCatalog._vector(motion.get("jump_delay"),2,.1,20):return false
			for field in ["pursuit_delay_divisor","jump_distance_multiplier","acceleration"]:
				if not ContentCatalog._number(motion.get(field),.01,1000):return false
		if entry.has("hopping"):
			if not entry.hopping is Dictionary:return false
			for field in ["idle_delay","moving_delay","avoid_distance","obstacle_jump"]:
				if not ContentCatalog._number(entry.hopping.get(field),.01,256):return false
		if entry.has("spawn_rules"):
			var spawn_rule: Variant=entry.spawn_rules
			if not spawn_rule is Dictionary or not spawn_rule.get("surface_only",false) is bool or not ContentCatalog._number(spawn_rule.get("minimum_depth",0),0,384):return false
			if not spawn_rule.get("biomes",[]) is Array:return false
			for biome in spawn_rule.get("biomes",[]):
				if not biome is String:return false
		for effect in ([entry.attack_effect] if entry.has("attack_effect") else [])+([entry.ranged.effect] if entry.get("ranged",{}) is Dictionary and entry.get("ranged",{}).has("effect") else []):
			if not effect is Dictionary or effect.get("name") not in ["poison","slowness"] or not ContentCatalog._number(effect.get("seconds"),.1,120):return false
		if entry.has("head_attachments"):
			if not entry.head_attachments is Dictionary:return false
			if not entry.head_attachments.get("variants",{}) is Dictionary:return false
			for variant in entry.head_attachments.get("variants",{}):
				if variant not in ["temperate","warm","cold"]:return false
			for group in [entry.head_attachments]+entry.head_attachments.get("variants",{}).values():
				if not group is Dictionary:return false
				for view in ["side","front"]:
					if not group.get(view) is Array or group[view].size()>8:return false
					for part in group[view]:
						if not part is Dictionary or not ContentCatalog._vector(part.get("source"),4,0,64) or not ContentCatalog._vector(part.get("bounds"),4,-32,32):return false
						if part.source[2]<=0 or part.source[3]<=0 or part.bounds[2]<=0 or part.bounds[3]<=0:return false
		if entry.has("ranged"):
			if not entry.ranged is Dictionary:return false
			for field in ["range","retreat_range","hold_range","charge_seconds","cooldown","speed","gravity","damage","inaccuracy"]:
				if not ContentCatalog._number(entry.ranged.get(field),.001,1000):return false
			if entry.ranged.retreat_range>=entry.ranged.hold_range or entry.ranged.hold_range>=entry.ranged.range:return false
			if not ContentCatalog._number(entry.ranged.get("bow_rotation_degrees"),-360,360):return false
		if entry.has("leap"):
			if not entry.leap is Dictionary:return false
			for field in ["minimum","maximum","chance","cooldown","speed","jump"]:
				if not ContentCatalog._number(entry.leap.get(field),.001,1000):return false
			if entry.leap.minimum>=entry.leap.maximum or entry.leap.chance>1:return false
		for item in entry.tempt_items:
			if not item is String or BlockDatabase.id_for(item)==0:return false
		if entry.has("egg_interval") and not ContentCatalog._vector(entry.egg_interval,2,1,86400):return false
		if entry.has("egg_interval") and entry.egg_interval[1]<entry.egg_interval[0]:return false
		if entry.has("fuse_seconds"):
			for field in ["fuse_trigger","fuse_release","explosion_power"]:
				if not ContentCatalog._number(entry.get(field),.1,16):return false
		for key in ["fuse_seconds","fuse_trigger","fuse_release","explosion_power"]:
			if entry.has(key) and not ContentCatalog._number(entry[key],.1,16):return false
		if not entry.get("variants",{}) is Dictionary:return false
		for item in entry.interactions.values():
			if not item is String or BlockDatabase.id_for(item)==0:return false
		for path in entry.get("variants",{}).values()+([entry.wool_texture] if entry.has("wool_texture") else []):
			if not path is String or not ResourceLoader.exists(path):return false
		for drop in entry.drops:
			if not drop is Dictionary or BlockDatabase.id_for(str(drop.get("item","")))==0 or not ContentCatalog._number(drop.get("min"),0,64,true) or not ContentCatalog._number(drop.get("max"),drop.min,64,true):return false
			if not drop.get("player_only",false) is bool or not ContentCatalog._number(drop.get("chance",1),0,1):return false
		definitions[entry.key]=entry
	_validated=definitions.has("cow") and definitions.has("sheep") and definitions.has("zombie")
	return _validated

static func walk_speed(definition: Dictionary,goal: float=1.0) -> float:
	# MoveControl sets both speed and forward input. On ordinary ground the
	# steady velocity is (attribute*goal)^2 * .98 / (1-.6*.91) blocks/tick.
	return pow(float(definition.movement_attribute)*goal,2)*.98/(1-float(rules.ground_drag))*20*16

static func valid_state(state: Variant) -> bool:
	if not validate() or not state is Dictionary:return false
	if state.is_empty():return true
	if not state.get("mob_griefing",true) is bool:return false
	if not state.get("entities") is Array or state.entities.size()>int(rules.record_limit) or not state.get("regions") is Array or state.regions.size()>100000 or not state.get("rng") is String or not state.rng.is_valid_int() or not ContentCatalog._number(state.get("next_id"),1,2147483647,true):return false
	var seen: Dictionary={}
	for record in state.entities:
		if not record is Dictionary or not definitions.has(record.get("kind")) or not ContentCatalog._number(record.get("id"),1,2147483646,true) or seen.has(int(record.id)) or int(record.id)>=int(state.next_id):return false
		seen[int(record.id)]=true
		if not ContentCatalog._vector(record.get("position"),2,-160000000,160000000) or not ContentCatalog._vector(record.get("velocity"),2,-8192,8192) or not ContentCatalog._number(record.get("health"),.000001,(16 if record.kind=="magma_cube" else definitions[record.kind].health)) or not ContentCatalog._number(record.get("facing"),-1,1,true) or int(record.facing)==0 or not record.get("sheared") is bool or record.get("variant") not in ["temperate","warm","cold"] or not NBT.valid_tags(record.get("tags",{})):return false
		for field in ["fire","idle","air","fuse","egg_time","anger","stare_time","teleport_time"]:
			if not ContentCatalog._number(record.get(field,0),0,100000):return false
		if not EntityEffects.valid(record.get("effects",{})) or not EntityEffects.valid_amplifiers(record.get("effect_amplifiers",{})):return false
		if not ContentCatalog._number(record.get("carried_block",0),0,100000,true) or int(record.get("carried_block",0))!=0 and not BlockDatabase.BLOCKS.has(int(record.carried_block)):return false
		if not ContentCatalog._number(record.get("cube_size",2),1,4,true) or int(record.get("cube_size",2)) not in [1,2,4]:return false
		if record.kind=="magma_cube" and float(record.health)>pow(int(record.get("cube_size",2)),2):return false
		if not ContentCatalog._number(record.get("creature_age",0),0,100000) or not record.get("bat_hanging",false) is bool:return false
		if not ContentCatalog._number(record.get("growing_age",0),-2400,2400) or not ContentCatalog._number(record.get("love_time",0),0,120):return false
		var definition: Dictionary=definitions[record.kind]
		if float(record.get("fuse",0))>float(definition.get("fuse_seconds",0)):return false
		if float(record.get("egg_time",0))>float(definition.get("egg_interval",[0,0])[1]):return false
	for region in state.regions:
		if not ContentCatalog._number(region,-10000000,10000000,true):return false
	return true
