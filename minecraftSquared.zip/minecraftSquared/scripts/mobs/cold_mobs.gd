class_name ColdMobs
extends RefCounted
static var building: bool=false
static func protect(mob: MobActor) -> void:
	if AnimalBreeding.baby(mob):mob.anger=0;return
	var player: Node2D=mob.system.world.player
	if player.creative or player.spectator or player.survival_dead:return
	for cub: MobActor in mob.system.active.values():
		if cub.dead or cub.definition.rig!="polar_bear" or not AnimalBreeding.baby(cub):continue
		if cub.center().distance_to(mob.center())<float(mob.definition.cold.protect_radius)*16 and cub.center().distance_to(player.global_position)<float(mob.definition.cold.warning_radius)*16:mob.anger=maxf(mob.anger,5);return
static func think_golem(mob: MobActor) -> bool:
	var system: MobSystem=mob.system;var world: Node2D=system.world;var best: MobActor=null;var distance: float=float(mob.definition.cold.range)*16
	for target: MobActor in system.active.values():
		if target.dead or not target.definition.hostile or target.definition.rig=="ghast":continue
		var d: float=mob.center().distance_to(target.center())
		if d<distance and system.visible(mob.center(),target.center()):best=target;distance=d
	if system.mob_griefing and world.chunks.dimension=="overworld":
		var at: Vector2i=system.cell(mob.global_position-Vector2(0,.1))
		var climate: Dictionary=world.chunks.biomes.definition(at.x).get("color_climate",{}) if world.chunks.biomes!=null else {}
		if float(climate.get("temperature",.5))<.8 and world.get_block(at)==0 and system.support(at+Vector2i.DOWN):world.set_block(at,BlockDatabase.id_for("snow_layer"))
	if best==null:return false
	mob.goal="ranged";mob.desired=0;mob.glance=0;mob.facing=1 if best.center().x>mob.center().x else -1;MobBrain.look(mob,best.center())
	if mob.attack_time<=0:
		var origin: Vector2=mob.center()-Vector2(0,8);var offset: Vector2=best.center()-origin;var time: float=offset.length()/float(mob.definition.cold.speed)
		system.projectiles.snowball(origin,(offset-Vector2(0,.5*float(mob.definition.cold.gravity)*time*time)).normalized(),mob.serial,false)
		mob.attack_time=float(mob.definition.cold.interval)
	return true
static func hazards(mob: MobActor) -> void:
	var world: Node2D=mob.system.world;var at: Vector2i=mob.system.cell(mob.center())
	var heat: bool=world.is_nether()
	if world.chunks.biomes!=null:heat=float(world.chunks.biomes.definition(at.x).get("color_climate",{}).get("temperature",.5))>float(mob.definition.cold.heat_threshold)
	if heat or world.fluids.kind_at(at)=="water" or world.weather.raining_at(at) and world.weather.strength>.2:mob.hurt(float(mob.definition.cold.water_damage),mob.center(),"melt")
static func placed(system: MobSystem,cell: Vector2i,new: int) -> void:
	if building or new not in [BlockDatabase.id_for("carved_pumpkin"),BlockDatabase.id_for("jack_o_lantern")]:return
	var world: Node2D=system.world;var snow: int=BlockDatabase.id_for("snow_block")
	for direction in [Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT,Vector2i.UP]:
		if world.get_block(cell+direction)!=snow or world.get_block(cell+direction*2)!=snow:continue
		var lower: Vector2i=cell+direction*2 if direction.y>0 else cell if direction.y<0 else cell+Vector2i.DOWN
		var point: Vector2=system.feet(lower)
		# The pattern itself is removed before the entity collider is created.
		if system.active.size()>=int(MobCatalog.rules.maximum_active):return
		building=true
		var saved: Dictionary={}
		for at in [cell,cell+direction,cell+direction*2]:saved[at]=world.get_block(at)
		for at in [cell,cell+direction,cell+direction*2]:world.set_block(at,0)
		if not system.can_fit("snow_golem",point):
			for at in saved:world.set_block(at,saved[at])
			building=false;return
		var mob: MobActor=system.spawn("snow_golem",point)
		building=false
		if mob!=null:system.renderer.burst(mob.center(),false)
		return
static func use(world: Node2D,cell: Vector2i) -> bool:
	var id: int=world.get_interaction_item()
	if id==BlockDatabase.id_for("snowball"):
		if not world.player.presentation.action_kind.is_empty() and world.player.presentation.action_elapsed<.25:return true
		var origin: Vector2=world.player.eye_position();var aim: Vector2=(world.pointer_global_position()-origin).normalized()
		if world.mobs.projectiles.snowball(origin+aim*5,aim,-1,true):world.inventory.consume_for_placement(world.use_slot());world.player.swing_hand("place",world.pointer_global_position())
		return true
	if id==BlockDatabase.id_for("shears") and world.get_block(cell)==BlockDatabase.id_for("pumpkin") and world.cell_is_reachable(cell):
		world.set_block(cell,BlockDatabase.id_for("carved_pumpkin"));world.inventory.damage_tool(world.use_slot());world.dropped_items.spawn_item(BlockDatabase.id_for("pumpkin_seeds"),4,world.ground.to_global(world.ground.map_to_local(cell)));return true
	return false
