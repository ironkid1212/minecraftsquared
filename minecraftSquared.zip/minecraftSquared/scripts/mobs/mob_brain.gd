class_name MobBrain
extends RefCounted

## Goal selection is staggered by MobActor; navigation keeps the shared job budget.
static func think(system: MobSystem, mob: MobActor) -> void:
	var dt: float=MobCatalog.rules.ai_interval
	mob.idle+=dt;mob.wander_time-=dt;mob.aggro_time=maxf(0,mob.aggro_time-dt)
	mob.tempted=false;mob.goal="idle";mob.charging=false
	var player: CharacterBody2D=system.world.player
	var alive: bool=not player.spectator and not player.creative and not player.survival_dead
	var target: Vector2=player.global_position+Vector2(0,14)
	var victim: MobActor=system.active.get(mob.revenge_id)
	if is_instance_valid(victim) and not victim.dead:target=victim.global_position
	else:mob.revenge_id=0;victim=null
	var target_eye: Vector2=victim.center() if victim!=null else player.eye_position()
	var distance: float=mob.center().distance_to(target_eye)
	var sight: bool=(victim!=null or alive) and distance<float(mob.definition.follow_range)*16 and system.visible(mob.center(),target_eye)
	if mob.definition.rig=="polar_bear":ColdMobs.protect(mob)
	var hostile: bool=mob.definition.hostile and not mob.definition.get("neutral",false)
	if mob.definition.has("neutral_brightness") and mob.anger<=0:
		var light: Vector2i=system.world.lighting.sample_levels(system.cell(mob.center()))
		hostile=light.y<int(mob.definition.neutral_brightness) and light.x*system.world.clock.daylight()<float(mob.definition.neutral_brightness)
	if (hostile or mob.anger>0 or victim!=null) and sight:
		mob.aggro_time=float(mob.definition.target_memory);mob.last_target=target
	if not alive and victim==null:mob.aggro_time=0
	var combat: bool=mob.aggro_time>0 and (hostile or mob.anger>0 or victim!=null)
	if mob.definition.has("hopping") and not system.holding_food(mob) and sight and distance<float(mob.definition.hopping.avoid_distance)*16:
		mob.goal="avoid";mob.desired=-signf(target.x-mob.global_position.x);mob.eat_time=0;mob.glance=0;return
	# Passive panic outranks feeding and strolling, including environmental damage.
	if not mob.definition.hostile and mob.panic>0 and (mob.definition.rig!="polar_bear" or AnimalBreeding.baby(mob)):
		mob.goal="panic";mob.eat_time=0;mob.path.clear();mob.glance=0
		return
	# Skeletons seek reachable shade before remaining in exposed sunlight.
	if mob.definition.get("avoid_sun",false) and exposed(system,mob):
		if mob.path_time<=0:
			mob.path_time=1
			mob.shelter=shelter(system,mob)
		if is_finite(mob.shelter.x):
			mob.goal="shelter";navigate(system,mob,mob.shelter,false);look(mob,mob.shelter);return
	if mob.definition.has("fuse_seconds"):
		var charging: bool=combat and sight and distance<float(mob.definition.fuse_trigger)*16
		if mob.fuse>0 and sight and distance<float(mob.definition.fuse_release)*16:charging=true
		mob.fuse_direction=1 if charging else -1
		if charging or mob.fuse>0:
			mob.goal="swell";mob.desired=0;mob.path.clear();mob.glance=0;look(mob,target_eye);return
	if combat:
		mob.goal="pursue";mob.idle=0;mob.glance=0;mob.eat_time=0
		var remembered: Vector2=target if sight else mob.last_target
		look(mob,target_eye if sight else remembered)
		if mob.definition.has("ranged") and sight and distance<=float(mob.definition.ranged.range)*16 and system.world.fluids.kind_at(system.cell(mob.center()))!="water":
			var rule: Dictionary=mob.definition.ranged
			mob.goal="ranged";mob.path.clear()
			mob.desired=-signf(target.x-mob.global_position.x) if distance<float(rule.retreat_range)*16 else signf(target.x-mob.global_position.x) if distance>float(rule.hold_range)*16 else 0
			if mob.desired!=0 and not system.safe_step(mob,mob.desired):mob.desired=0
			# Recovery must finish before starting the next draw; do not charge in parallel.
			mob.charging=mob.attack_time<=0
			if not mob.charging:mob.bow_charge=0;return
			if mob.attack_time<=0 and mob.bow_charge>=float(rule.charge_seconds):
				system.projectiles.shoot(mob,target_eye);mob.attack_time=float(rule.cooldown);mob.bow_charge=0;mob.charging=false
			return
		mob.bow_charge=0
		navigate(system,mob,remembered,sight)
		if mob.definition.has("leap") and sight and mob.is_on_floor() and mob.leap_time<=0:
			var leap: Dictionary=mob.definition.leap
			if distance>=float(leap.minimum)*16 and distance<=float(leap.maximum)*16 and system.rng.randf()<float(leap.chance):
				mob.velocity.y=-float(leap.jump);mob.knockback_x=signf(target.x-mob.global_position.x)*float(leap.speed);mob.leap_time=float(leap.cooldown)
		var reach: float=float(mob.definition.size[0])*.5+12
		var melee: bool=not mob.definition.has("ranged") or system.world.fluids.kind_at(system.cell(mob.center()))=="water"
		if float(mob.definition.attack_damage)>0 and sight and melee:
			if absf(target.x-mob.global_position.x)<reach and absf(target.y-mob.global_position.y)<20 and mob.attack_time<=0:
				mob.attack_time=float(mob.definition.attack_interval)
				if victim!=null:
					if victim.hurt(float(mob.definition.attack_damage),mob.center(),"melee",false,false,mob) and mob.definition.has("attack_effect") and not (mob.definition.attack_effect.name=="wither" and victim.definition.get("wither_immune",false)):victim.effects.apply(mob.definition.attack_effect)
				elif not system.world.shields.block(float(mob.definition.attack_damage),mob.center(),"melee",mob) and system.world.survival.take_damage(int(mob.definition.attack_damage),"You were slain by a "+str(mob.definition.name)):
					player.receive_knockback(mob.center(),MobCatalog.rules.knockback)
					if mob.definition.has("attack_effect"):system.world.survival.apply_effect(mob.definition.attack_effect)
		return
	mob.bow_charge=0
	if AnimalBreeding.think(mob):return
	if not mob.definition.hostile and sight and distance<160 and system.holding_food(mob):
		mob.goal="tempt";mob.tempted=true;mob.glance=0;mob.eat_time=0
		mob.desired=signf(target.x-mob.global_position.x) if absf(target.x-mob.global_position.x)>28 else 0
		look(mob,target_eye);return
	if mob.eat_time>0:
		mob.goal="graze";mob.desired=0;mob.glance=0;mob.eat_time=maxf(0,mob.eat_time-dt)
		if mob.eat_time==0:
			var at: Vector2i=system.cell(mob.global_position+Vector2(0,1))
			if system.world.get_block(at) in [BlockDatabase.id_for("grass"),BlockDatabase.id_for("snowy_grass")]:
				if system.mob_griefing:system.world.set_block(at,BlockDatabase.id_for("dirt"))
				mob.sheared=false
		return
	if mob.wander_time<=0:
		mob.path.clear()
		if mob.desired!=0:
			mob.desired=0;mob.wander_time=system.rng.randf_range(mob.definition.idle_seconds[0],mob.definition.idle_seconds[1])
		else:
			mob.desired=system.rng.randi_range(0,1)*2-1;mob.wander_time=system.rng.randf_range(mob.definition.wander_seconds[0],mob.definition.wander_seconds[1])
		if mob.definition.grazes and system.rng.randf()<.12 and system.world.get_block(system.cell(mob.global_position+Vector2(0,1)))==BlockDatabase.id_for("grass"):mob.eat_time=2;mob.desired=0
	if mob.desired!=0:
		mob.goal="wander";mob.glance=0;mob.head_pitch=0
	else:
		if sight and distance<float(mob.definition.look_range)*16:look(mob,target_eye)
		else:mob.head_pitch=move_toward(mob.head_pitch,0,dt)
		if mob.glance_time<=0:
			mob.glance=system.rng.randf_range(MobCatalog.rules.glance_duration[0],MobCatalog.rules.glance_duration[1])
			mob.glance_time=system.rng.randf_range(MobCatalog.rules.glance_interval[0],MobCatalog.rules.glance_interval[1])

static func look(mob: MobActor,point: Vector2) -> void:
	var offset: Vector2=point-(mob.center()-Vector2(0,float(mob.definition.size[1])*.3))
	if absf(offset.x)>2:mob.facing=1 if offset.x>0 else -1
	mob.head_pitch=clampf(atan2(offset.y,maxf(2,absf(offset.x))),-.55,.55)

static func navigate(system: MobSystem,mob: MobActor,target: Vector2,direct: bool) -> void:
	mob.desired=signf(target.x-mob.global_position.x) if absf(target.x-mob.global_position.x)>6 else 0
	if mob.path_time<=0:
		mob.path_time=.8
		if absf(target.y-mob.global_position.y)<8 and not mob.is_on_wall() and direct:mob.path.clear()
		else:mob.path=system.route(mob,system.cell(target-Vector2(0,1)))
	while not mob.path.is_empty() and system.feet(mob.path[0]).distance_to(mob.global_position)<7:mob.path.pop_front()
	if not mob.path.is_empty():mob.desired=signf(system.feet(mob.path[0]).x-mob.global_position.x)

static func exposed(system: MobSystem,mob: MobActor) -> bool:
	var at: Vector2i=system.cell(mob.center())
	return system.world.chunks.dimension=="overworld" and system.world.clock.daylight()>.7 and not system.world.weather.raining_at(at) and system.world.fluids.kind_at(at)!="water" and system.world.lighting.sample_levels(at).x==15

static func shelter(system: MobSystem,mob: MobActor) -> Vector2:
	var origin: Vector2i=system.cell(mob.global_position-Vector2(0,1))
	for distance in range(1,9):
		for sign_value in [-1,1]:
			for dy in [0,-1,1,2]:
				var at: Vector2i=origin+Vector2i(distance*sign_value,dy)
				if system.support(at+Vector2i.DOWN) and system.can_fit(mob.definition.key,system.feet(at)) and system.world.lighting.sample_levels(at+Vector2i.UP).x<15:
					var path: Array[Vector2i]=system.route(mob,at)
					if not path.is_empty() and path[-1]==at:mob.path=path;return system.feet(at)
	return Vector2(INF,INF)
