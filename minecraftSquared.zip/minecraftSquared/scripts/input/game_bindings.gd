class_name GameBindings
extends RefCounted

signal changed(action: String)
var definitions: Array = []
var defaults: Dictionary = {}
var bindings: Dictionary = {}
var _saved: ConfigFile
static var _mapped_events: Dictionary = {}
static var _hold_keys: Dictionary = {}

func setup(preferences: ConfigFile) -> void:
	defaults.clear()
	bindings.clear()
	_mapped_events.clear()
	_hold_keys.clear()
	_saved = preferences
	var data: Dictionary = DataFile.object_from("res://data/keybindings.json")
	if data.get("version") != 1 or not data.get("actions") is Array:
		DataFile.fail("keybindings.json requires version 1 and an actions array.")
		return
	definitions = data["actions"]
	for definition in definitions:
		var action: String = str(definition.get("action", ""))
		if not action.is_valid_identifier() or defaults.has(action) or not definition.get("bindings") is Array:
			DataFile.fail("keybindings.json: invalid or duplicate action " + action)
			continue
		defaults[action] = _normalize_list(definition["bindings"])
		if defaults[action].size() != definition["bindings"].size():
			DataFile.fail("keybindings.json: invalid or duplicate default binding for " + action)
		var stored: Variant = _saved.get_value("keybindings", action, defaults[action])
		bindings[action] = _normalize_list(stored) if stored is Array else defaults[action].duplicate(true)
		if stored is Array and not stored.is_empty() and bindings[action].is_empty(): bindings[action] = defaults[action].duplicate(true)
		_apply(action)

func _normalize_list(values: Array) -> Array:
	var result: Array = []
	for value in values:
		if not value is Dictionary: continue
		var binding: Dictionary = normalize(value)
		if not binding.is_empty() and binding not in result: result.append(binding)
	return result

static func normalize(value: Dictionary) -> Dictionary:
	var result: Dictionary = {}
	for field in value:
		if field not in ["key","mouse","hold","ctrl","alt","shift","meta"]: return {}
	if value.has("key") and value.has("mouse"): return {}
	for modifier in ["ctrl","alt","shift","meta"]:
		if value.has(modifier) and not value[modifier] is bool: return {}
	if value.has("key"):
		var code: int = OS.find_keycode_from_string(value["key"]) if value["key"] is String else int(value["key"]) if ContentCatalog._number(value["key"],1,2147483647,true) else 0
		if code <= 0 or code == KEY_ESCAPE: return {}
		result["key"] = code
	elif value.has("mouse") and ContentCatalog._number(value["mouse"], 1, 9, true):
		result["mouse"] = int(value["mouse"])
	else: return {}
	for modifier in ["ctrl", "alt", "shift", "meta"]:
		if value.get(modifier, false) == true: result[modifier] = true
	var hold: Variant = value.get("hold", 0)
	var hold_code: int = OS.find_keycode_from_string(hold) if hold is String else int(hold) if ContentCatalog._number(hold,0,2147483647,true) else 0
	if value.has("hold") and (hold_code <= 0 or hold_code == KEY_ESCAPE): return {}
	if hold_code > 0: result["hold"] = hold_code
	return result

static func event_for(value: Dictionary) -> InputEvent:
	var event: InputEventWithModifiers
	if value.has("key"):
		var key := InputEventKey.new()
		key.physical_keycode = int(value["key"])
		event = key
	else:
		var mouse := InputEventMouseButton.new()
		mouse.button_index = int(value["mouse"])
		event = mouse
	event.ctrl_pressed = bool(value.get("ctrl", false))
	event.alt_pressed = bool(value.get("alt", false))
	event.shift_pressed = bool(value.get("shift", false))
	event.meta_pressed = bool(value.get("meta", false))
	return event

func _apply(action: String) -> void:
	if not InputMap.has_action(action): InputMap.add_action(action, .2)
	Input.action_release(action)
	InputMap.action_erase_events(action)
	var events: Array = []
	var holds: Array = []
	for value in bindings[action]:
		var event: InputEvent = event_for(value)
		InputMap.action_add_event(action, event)
		events.append(event)
		holds.append(int(value.get("hold", 0)))
	_mapped_events[action] = events
	_hold_keys[action] = holds

static func matches(event: InputEvent, action: String) -> bool:
	var events: Array = _mapped_events.get(action, [])
	for index in range(events.size()):
		if not events[index].is_match(event, false): continue
		var modifiers_match: bool = true
		for property in ["ctrl_pressed", "alt_pressed", "shift_pressed", "meta_pressed"]:
			if bool(events[index].get(property)) and not bool(event.get(property)): modifiers_match = false
		if not modifiers_match: continue
		var hold: int = int(_hold_keys[action][index])
		if hold == 0 or Input.is_physical_key_pressed(hold): return true
	return false

func set_binding(action: String, value: Dictionary) -> bool:
	if not defaults.has(action): return false
	var normalized: Dictionary = normalize(value)
	if not value.is_empty() and normalized.is_empty(): return false
	bindings[action] = [] if normalized.is_empty() else [normalized]
	_commit(action)
	changed.emit(action)
	return true

func _commit(action: String) -> void:
	_apply(action)
	_saved.set_value("keybindings", action, bindings[action])

func reset_action(action: String) -> void:
	if not defaults.has(action): return
	bindings[action] = defaults[action].duplicate(true)
	_commit(action)
	changed.emit(action)

func reset_all() -> void:
	for action in defaults:
		bindings[action] = defaults[action].duplicate(true)
		_commit(action)
	changed.emit("")

static func binding_text(value: Dictionary) -> String:
	var text: String = ""
	if value.has("hold"): text += OS.get_keycode_string(int(value["hold"])) + " + "
	if value.get("ctrl", false): text += "Ctrl + "
	if value.get("alt", false): text += "Alt + "
	if value.get("shift", false): text += "Shift + "
	if value.get("meta", false): text += "Meta + "
	if value.has("key"): return text + OS.get_keycode_string(int(value["key"]))
	return text + str({1:"Left Mouse", 2:"Right Mouse", 3:"Middle Mouse", 4:"Wheel Up", 5:"Wheel Down", 6:"Wheel Left", 7:"Wheel Right", 8:"Mouse 4", 9:"Mouse 5"}.get(int(value.get("mouse",0)), "Unbound"))

func label(action: String) -> String:
	var parts := PackedStringArray()
	for value in bindings.get(action, []): parts.append(binding_text(value))
	return " / ".join(parts) if not parts.is_empty() else "Unbound"

func conflicts(action: String) -> PackedStringArray:
	var result := PackedStringArray()
	var context: String = "global"
	for definition in definitions:
		if definition["action"] == action: context = definition["context"]
	for other in definitions:
		if other["action"] == action: continue
		if context != other["context"] and context != "global" and other["context"] != "global" and context != "movement" and other["context"] != "movement": continue
		for value in bindings.get(action, []):
			for candidate in bindings.get(other["action"], []):
				# Unmodified bindings also match while modifiers/hold keys are down.
				if value.get("key",0) == candidate.get("key",-1) or value.get("mouse",0) == candidate.get("mouse",-1):
					if str(other["label"]) not in result: result.append(str(other["label"]))
	return result

func shutdown() -> void:
	_mapped_events.clear()
	_hold_keys.clear()
	for action in bindings:
		if InputMap.has_action(action): InputMap.action_erase_events(action)
