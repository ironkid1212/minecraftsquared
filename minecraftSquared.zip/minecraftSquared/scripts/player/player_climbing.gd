class_name PlayerClimbing
extends RefCounted
var player: CharacterBody2D
var world: Node2D
var active: bool=false
var rules: Dictionary=DataFile.object_from("res://data/traversal.json")
func setup(body: CharacterBody2D) -> void:
	player=body;world=body.get_parent()
	for field in ["climb_speed","slide_speed","horizontal_speed"]:
		if not ContentCatalog._number(rules.get(field),1,320):DataFile.fail("traversal.json: speeds must be numbers from 1 to 320 world pixels per second.")
func contact() -> bool:
	active=false
	if player.spectator or player.survival_dead:return false
	var shape: CollisionShape2D=player.get_node("CollisionShape2D")
	var bounds: Rect2=shape.global_transform*shape.shape.get_rect()
	var first: Vector2i=world.ground.local_to_map(world.ground.to_local(bounds.position+Vector2.ONE*.1))
	var last: Vector2i=world.ground.local_to_map(world.ground.to_local(bounds.end-Vector2.ONE*.1))
	for y in range(first.y,last.y+1):
		for x in range(first.x,last.x+1):
			if BlockDatabase.BLOCKS.get(world.get_block(Vector2i(x,y)),{}).has("climbable"):active=true;return true
	return false
func apply(delta: float) -> void:
	if not active:return
	player.sprinting=false;player.swim_sprinting=false
	player.velocity.x=clampf(player.velocity.x,-float(rules.horizontal_speed),float(rules.horizontal_speed))
	if player.input_blocked:player.velocity.y=0
	elif Input.is_action_pressed("crouch"):player.velocity.y=0
	elif Input.is_action_pressed("climb_down"):player.velocity.y=float(rules.slide_speed)
	elif Input.is_action_pressed("jump"):player.velocity.y=-float(rules.climb_speed)
	else:player.velocity.y=move_toward(maxf(0,player.velocity.y),float(rules.slide_speed),float(player.settings.gravity)*delta)
	if player.survival!=null:player.survival.reset_fall()
static func supported(chunks: ChunkWorld,cell: Vector2i,id: int) -> bool:
	if BlockDatabase.has_tag(id,"cave_vine"):
		var above: Vector2i=cell+Vector2i.UP
		if not chunks.is_cell_loaded(above):return true
		var top: int=chunks.get_block(above)
		return BlockDatabase.has_tag(top,"cave_vine") or BlockDatabase.BLOCKS.get(top,{}).get("solid",false)
	if chunks.has_background_wall(cell):return true
	for offset in [Vector2i.LEFT,Vector2i.RIGHT]:
		if not chunks.is_cell_loaded(cell+offset):return true
		var block: Dictionary=BlockDatabase.BLOCKS.get(chunks.get_block(cell+offset),{})
		if block.get("solid",false) or block.get("platform",false) and "plant" not in block.get("tags",[]):return true
	if BlockDatabase.BLOCKS.get(id,{}).get("climbable",{}).get("support")=="hanging":
		var above: Vector2i=cell+Vector2i.UP
		if not chunks.is_cell_loaded(above):return true
		var support: int=chunks.get_block(above)
		if BlockDatabase.has_tag(id,"cave_vine") and BlockDatabase.has_tag(support,"cave_vine"):return true
		return support==id or chunks.trees.is_leaf(support) or chunks.trees.is_log(support) or BlockDatabase.BLOCKS.get(support,{}).get("solid",false)
	return false
