class_name PlayerRanged
extends Node
var world: Node2D
var slot: int=-1
var bow_id: int=0
var charge: float=0
func setup(game: Node2D) -> void:world=game
func busy() -> bool:return slot>=0
func ammo_slot() -> int:
	var inventory: BlockInventory=world.inventory
	if inventory.ids[BlockInventory.OFFHAND]==BlockDatabase.id_for("arrow") and inventory.counts[BlockInventory.OFFHAND]>0:return BlockInventory.OFFHAND
	for i in range(36):
		if inventory.ids[i]==BlockDatabase.id_for("arrow") and inventory.counts[i]>0:return i
	return -1
func begin(index: int) -> bool:
	var id: int=world.inventory.ids[index]
	if not BlockDatabase.BLOCKS.get(id,{}).has("ranged"):return false
	if ammo_slot()<0 and not world.player.creative:return false
	slot=index;bow_id=id;charge=0;world.shields.cancel();world.food.cancel();world.reset_mining();world.mining_held=false
	return true
func cancel() -> void:
	slot=-1;charge=0;bow_id=0
	world.player.presentation.bow_charge=-1
	if world.player.presentation.offhand!=null:world.player.presentation.offhand.bow_charge=-1
func release() -> void:
	if not busy():return
	var rule: Dictionary=BlockDatabase.BLOCKS[bow_id].ranged
	var ammo: int=ammo_slot()
	if (ammo>=0 or world.player.creative) and charge>=float(rule.minimum_charge):
		var t: float=minf(1,charge/float(rule.charge_seconds));var power: float=minf(1,(t*t+2*t)/3)
		var p: CharacterBody2D=world.player
		var visual: PlayerPresentation=p.presentation.offhand if slot==BlockInventory.OFFHAND else p.presentation
		visual.bow_charge=charge;visual.head_pitch=p.presentation.head_pitch
		var shoulder:=Vector2(4*p.facing,-4) if p.crouching else Vector2(0,-8)
		var model:=Transform2D(0,p.global_position)
		if p.swimming:model*=Transform2D(p.presentation.swim_angle,Vector2(0,9))
		var origin: Vector2=model*(shoulder+PlayerSkinDrawing._bow_wrist(visual,false)*Vector2(p.facing,1))
		var aim: Vector2=(world.pointer_global_position()-origin).normalized()
		if aim.is_zero_approx():aim=Vector2(world.player.facing,0)
		# A held model may overlap a wall; never start an arrow beyond that wall.
		var query:=PhysicsRayQueryParameters2D.create(p.eye_position(),origin,3);query.exclude=[p.get_rid()]
		var hit: Dictionary=p.get_world_2d().direct_space_state.intersect_ray(query)
		if not hit.is_empty():origin=Vector2(hit.position)-aim*.2
		if world.mobs.projectiles.shoot_player(origin,aim,power,rule,EnchantmentDatabase.level(world.inventory.tags[slot],"power")):
			if not world.player.creative:world.inventory.remove_from_slot(ammo,1);world.inventory.damage_tool(slot,1)
	cancel()
func _physics_process(dt: float) -> void:
	if not busy():return
	var p: CharacterBody2D=world.player
	if p.input_blocked or not p.interaction_enabled or p.spectator or p.survival_dead or world.inventory.ids[slot]!=bow_id or slot!=BlockInventory.OFFHAND and slot!=world.hotbar.selected_slot:cancel();return
	if not Input.is_action_pressed("use_item"):release();return
	charge=minf(2,charge+dt)
	var visual: PlayerPresentation=p.presentation.offhand if slot==BlockInventory.OFFHAND else p.presentation
	visual.bow_charge=charge;visual.head_pitch=p.presentation.head_pitch
