class_name PlayerExperience
extends Node2D
var world: Node2D
var rules: Dictionary
var total: int=0
var enchant_seed: int=randi_range(1,2147483646)
var orbs: Array[Dictionary]=[]
const TEXTURE: Texture2D=preload("res://assets/mobs/experience_orb.png")
func setup(game: Node2D) -> void:
	world=game;rules=AdventureData.DATA.xp;z_index=18;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
static func cost(level: int) -> int:return 2*level+7 if level<16 else 5*level-38 if level<31 else 9*level-158
static func threshold(level: int) -> int:
	return level*level+6*level if level<=16 else int(2.5*level*level-40.5*level+360) if level<=31 else int(4.5*level*level-162.5*level+2220)
func level() -> int:
	var lo: int=0;var hi: int=22000
	while lo<hi:
		var mid: int=(lo+hi+1)/2
		if threshold(mid)<=total:lo=mid
		else:hi=mid-1
	return lo
func spend_levels(amount: int) -> bool:
	var current: int=level()
	if amount<0 or current<amount:return false
	var fraction: float=progress();var next: int=current-amount
	total=threshold(next)+floori(fraction*cost(next));return true
func progress() -> float:
	var lv: int=level();return float(total-threshold(lv))/cost(lv)
func spawn(amount: int,point: Vector2) -> void:
	if amount<=0:return
	var remaining: int=amount
	while remaining>0:
		if orbs.size()>=int(rules.orb_cap):orbs[orbs.size()-1].value+=remaining;return
		var value: int=1
		for size_value in [2477,1237,617,307,149,73,37,17,7,3,1]:
			if remaining>=size_value:value=size_value;break
		remaining-=value
		orbs.append({"position":point,"velocity":Vector2(randf_range(-24,24),-36),"value":value,"age":0.0})
func _physics_process(dt: float) -> void:
	if orbs.is_empty():return
	for i in range(orbs.size()-1,-1,-1):
		var orb: Dictionary=orbs[i]
		if not world.chunks.is_cell_loaded(world.ground.local_to_map(world.ground.to_local(orb.position))):continue
		orb.age+=dt
		if orb.age>=float(rules.lifetime):orbs.remove_at(i);continue
		var offset: Vector2=world.player.global_position-orb.position
		if not world.player.spectator and not world.player.survival_dead:
			if offset.length()<float(rules.pickup_range)*16 and orb.age>.5:
				var before: int=level();total=mini(2000000000,total+int(orb.value));orbs.remove_at(i)
				if world.effects!=null:world.effects.sound("entity.player.levelup" if level()>before else "entity.experience_orb.pickup",world.player.global_position,"player",.4,1,2,.15)
				continue
			if offset.length()<float(rules.attract_range)*16:orb.velocity=Vector2(orb.velocity).move_toward(offset.normalized()*90,dt*180)
		var from: Vector2=orb.position;var to: Vector2=from+Vector2(orb.velocity)*dt
		var query:=PhysicsRayQueryParameters2D.create(from,to,3);query.exclude=[world.player.get_rid()]
		var hit: Dictionary=get_world_2d().direct_space_state.intersect_ray(query)
		if hit.is_empty():orb.position=to;orb.velocity.y+=120*dt
		else:orb.position=Vector2(hit.position)+Vector2(hit.normal)*.5;orb.velocity=Vector2(orb.velocity).bounce(hit.normal)*.35
	queue_redraw()
func _draw() -> void:
	var view: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	for orb in orbs:
		if not view.grow(6).has_point(orb.position):continue
		var color:=Color(.4+.2*sin(orb.age*5),1,.12)
		draw_texture_rect_region(TEXTURE,Rect2(Vector2(orb.position)-Vector2(3,3),Vector2(6,6)),Rect2(0,0,16,16),color)
func on_death() -> void:
	spawn(mini(100,level()*7),world.player.global_position);total=0
func snapshot() -> Dictionary:
	var records: Array=[]
	for orb in orbs:records.append({"position":[orb.position.x,orb.position.y],"velocity":[orb.velocity.x,orb.velocity.y],"value":orb.value,"age":orb.age})
	return {"total":total,"orbs":records,"enchant_seed":enchant_seed}
func restore(data: Dictionary) -> void:
	total=clampi(int(data.get("total",0)),0,2000000000);orbs.clear()
	enchant_seed=clampi(int(data.get("enchant_seed",enchant_seed)),1,2147483646)
	for record in data.get("orbs",[]):
		orbs.append({"position":Vector2(record.position[0],record.position[1]),"velocity":Vector2(record.velocity[0],record.velocity[1]),"value":int(record.value),"age":float(record.age)})
