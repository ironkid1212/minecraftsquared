class_name HeldUse
extends Node
var world: Node2D
var armed: bool=false
var cooldown: float=0
var require_release: bool=false
var last_selected: int=-1
func setup(game: Node2D) -> void:world=game;last_selected=world.hotbar.selected_slot
func allowed() -> bool:
	return world.player.interaction_enabled and not world.player.input_blocked and not world.player.spectator and not world.player.survival_dead and not get_tree().paused
func press(cell: Vector2i) -> void:
	if not allowed():return
	require_release=false;armed=true;cooldown=.2;last_selected=world.hotbar.selected_slot
	attempt(cell,true)
func cancel() -> void:
	armed=false;require_release=Input.is_action_pressed("use_item")
func attempt(cell: Vector2i,initial: bool=false) -> void:
	if world.food.busy() or world.ranged.busy():return
	if world.shields.raising():
		if world.shields.slot!=BlockInventory.OFFHAND:return
		# Recheck main-hand use while the offhand guards: a newly valid place
		# target or food must be usable without releasing and clicking again.
		if world.use_hand(cell,world.hotbar.selected_slot):world.shields.cancel()
		return
	var mob: MobActor=world.combat.target()
	var used: bool=false
	if mob!=null:used=world.mobs.use_mob(mob,world.hotbar.selected_slot) or world.mobs.use_mob(mob,BlockInventory.OFFHAND)
	if not used:used=world.use_hand(cell,world.hotbar.selected_slot) or world.use_hand(cell,BlockInventory.OFFHAND)
	if initial and world.food.level>=20 and not world.player.creative and BlockDatabase.BLOCKS.get(world.hotbar.get_selected_block(),{}).has("food"):
		world.show_mode_notice("You're not hungry")
func _physics_process(dt: float) -> void:
	if not Input.is_action_pressed("use_item"):
		armed=false;require_release=false;cooldown=0;return
	if not allowed():cancel();return
	if last_selected!=world.hotbar.selected_slot:
		last_selected=world.hotbar.selected_slot
		world.food.cancel();world.ranged.cancel();world.shields.cancel();cooldown=0
	if require_release or not armed:return
	cooldown=maxf(0,cooldown-dt)
	if cooldown>0 or world._pointer_over_hotbar():return
	if world.food.busy() or world.ranged.busy() or world.shields.raising() and world.shields.slot!=BlockInventory.OFFHAND:return
	cooldown=.2;attempt(world.get_mouse_cell())
