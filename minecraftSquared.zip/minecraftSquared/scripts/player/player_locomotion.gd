class_name PlayerLocomotion
extends RefCounted

var player: CharacterBody2D
var collider: CollisionShape2D
var pose: String = "standing"
var _clock: float = 0
var _last_tap: float = -100
var _tap_direction: int = 0
var _sprint_latched: bool = false
var _vertical_tick: float = 0.0
var current_velocity := Vector2.ZERO

func setup(body: CharacterBody2D) -> void:
	player=body
	player.floor_snap_length=player.settings.step_height+.1
	collider=player.get_node("CollisionShape2D")
	collider.shape=collider.shape.duplicate()

func _size(mode: String) -> Vector2:
	return Vector2(28,player.settings.swim_height) if mode=="swimming" else Vector2(8,player.settings.crouch_height) if mode=="crouching" else Vector2(8,28)

func fits(mode: String) -> bool:
	var size: Vector2=_size(mode)
	if collider.shape.size.is_equal_approx(size): return true
	var shape:=RectangleShape2D.new()
	shape.size=size-Vector2.ONE*.1
	var query:=PhysicsShapeQueryParameters2D.new()
	query.shape=shape
	query.transform=Transform2D(0,player.global_position+Vector2(0,14-size.y*.5))
	query.collision_mask=player.collision_mask
	query.exclude=[player.get_rid()]
	return player.get_world_2d().direct_space_state.intersect_shape(query,1).is_empty()

func set_pose(mode: String, force: bool = false) -> bool:
	if not force and not fits(mode): return false
	pose=mode
	var size: Vector2=_size(mode)
	collider.shape.size=size
	collider.position=Vector2(0,14-size.y*.5)
	player.crouching=mode=="crouching"
	player.swimming=mode=="swimming"
	player.presentation.pose=mode
	return true

func restore_pose(mode: String) -> void:
	set_pose(mode if mode in ["standing","crouching","swimming"] else "standing",true)
	reset_motion()

func reset_motion() -> void:
	current_velocity=Vector2.ZERO
	_vertical_tick=0.0
	_sprint_latched=false
	_last_tap=-100
	player.sprinting=false
	player.swim_sprinting=false

func _support_at(point: Vector2) -> bool:
	for x in [-3.5,0.0,3.5]:
		var from: Vector2=point+Vector2(x,13.75)
		var query:=PhysicsRayQueryParameters2D.create(from,from+Vector2(0,2.0),player.collision_mask)
		query.exclude=[player.get_rid()]
		if not player.get_world_2d().direct_space_state.intersect_ray(query).is_empty(): return true
	return false

func try_step(distance: float) -> bool:
	var maximum: float=player.settings.step_height
	if maximum<=0 or absf(distance)<.001 or not player.is_on_floor() or player.velocity.y<0: return false
	var transform: Transform2D=player.global_transform
	if not player.test_move(transform,Vector2(distance,0)): return false
	var headroom:=KinematicCollision2D.new()
	var rise: float=maximum
	if player.test_move(transform,Vector2(0,-maximum),headroom): rise=maxf(0,-headroom.get_travel().y-.02)
	if rise<.05: return false
	var raised: Transform2D=transform
	raised.origin.y-=rise
	if player.test_move(raised,Vector2(distance,0)): return false
	raised.origin.x+=distance
	var support:=KinematicCollision2D.new()
	if not player.test_move(raised,Vector2(0,rise+.1),support) or support.get_normal().y>-.7: return false
	var climb: float=rise-support.get_travel().y
	if climb<=.02 or climb>maximum+.02: return false
	player.global_position.y-=climb
	return true

func step(delta: float) -> float:
	_clock+=delta
	var config: PlayerSettings=player.settings
	var fluid: FluidSystem=player.fluids
	if player.creative and player.creative_flying:
		set_pose("standing",true);player.sprinting=false;player.swim_sprinting=false
		var axis:=Vector2(Input.get_axis("move_left","move_right"),float(Input.is_action_pressed("crouch"))-float(Input.is_action_pressed("jump"))) if not player.input_blocked else Vector2.ZERO
		player.velocity=axis.limit_length()*config.move_speed*2.5*(2 if Input.is_action_pressed("sprint") else 1)
		player.move_and_slide();player.survival.reset_fall()
		if player.is_on_floor():player.creative_flying=false
		return 0
	player.climbing.contact()
	var immersion: String=fluid.body_kind() if fluid!=null else ""
	var direction: float=0 if player.input_blocked else Input.get_axis("move_left","move_right")
	var sneak: bool=not player.input_blocked and Input.is_action_pressed("crouch")
	var sprint_key: bool=not player.input_blocked and Input.is_action_pressed("sprint")
	if not player.input_blocked:
		for action in ["move_left","move_right"]:
			if Input.is_action_just_pressed(action):
				var sign_value: int=-1 if action=="move_left" else 1
				if sign_value==_tap_direction and _clock-_last_tap<=config.double_tap_seconds: _sprint_latched=true
				_tap_direction=sign_value
				_last_tap=_clock
	if direction==0 or player.input_blocked or sneak and immersion!="water": _sprint_latched=false
	elif sprint_key: _sprint_latched=true
	var game: Node2D=player.get_parent()
	var can_fast: bool=game.food==null or game.food.can_sprint()
	var wants_fast: bool=direction!=0 and _sprint_latched and can_fast and not player.climbing.active
	var head_in_water: bool=fluid!=null and fluid.submerged(player.eye_position())=="water"
	var wants_swim: bool=immersion=="water" and wants_fast and (head_in_water or player.swimming)
	if wants_swim and set_pose("swimming"):
		player.swim_sprinting=true
	else:
		player.swim_sprinting=false
		if sneak and immersion.is_empty(): set_pose("crouching")
		elif not set_pose("standing"):
			if not set_pose("crouching"): set_pose("swimming")
	player.sprinting=wants_fast and not player.crouching and immersion.is_empty()
	var movement_factor: float=(player.shields.move_factor() if player.shields!=null else 1.0)*(player.survival.effects.speed_factor() if player.survival!=null else 1.0)
	if player.is_on_floor():
		var at: Vector2i=game.ground.local_to_map(game.ground.to_local(player.global_position+Vector2(0,15)))
		movement_factor*=float(BlockDatabase.BLOCKS.get(game.get_block(at),{}).get("movement_multiplier",1))
	if game.ranged!=null and game.ranged.busy() or game.food!=null and game.food.busy():movement_factor*=.3;player.sprinting=false;player.swim_sprinting=false
	if player.shields!=null and player.shields.raising():player.sprinting=false;player.swim_sprinting=false
	if player.swim_sprinting:
		var pitch: float=player.presentation.head_pitch
		var aim:=Vector2(direction*cos(pitch),sin(pitch))
		if Input.is_action_pressed("jump"): aim.y=-1
		elif sneak: aim.y=1
		player.velocity=aim.normalized()*config.move_speed*config.swim_sprint_speed_factor*movement_factor
		player.presentation.swim_angle=player.velocity.angle()+PI*.5
	else:
		if not immersion.is_empty():
			_vertical_tick=0.0
			var drag: float=.8 if immersion=="water" else .5
			player.velocity.y*=pow(drag,delta*20)
			player.velocity.y=minf(player.velocity.y+config.gravity*.1*delta,fluid.settings.sinking_speed)
			if not player.input_blocked and Input.is_action_pressed("jump"):
				player.velocity.y=-fluid.settings.swim_speed*(1 if immersion=="water" else .55)
				if player.is_on_wall() and immersion=="water": player.velocity.y=-config.jump_speed*.7
			elif sneak: player.velocity.y=fluid.settings.swim_speed*.65
		elif not player.is_on_floor():
			_vertical_tick+=delta
			while _vertical_tick>=.05-0.000001:
				_vertical_tick-=.05
				player.velocity.y=(player.velocity.y+config.gravity*.05)*config.vertical_drag
		else: _vertical_tick=0.0
		var factor: float=fluid.settings.water_move_factor if immersion=="water" else fluid.settings.lava_move_factor if immersion=="lava" else config.crouch_speed_factor if player.crouching or player.swimming else config.sprint_speed_factor if player.sprinting else 1.0
		var drag: float=config.ground_drag if player.is_on_floor() else config.air_drag
		var target_speed: float=config.move_speed*factor*movement_factor
		if immersion.is_empty() and not player.is_on_floor(): target_speed*=1.02948
		if not immersion.is_empty(): drag=.8 if immersion=="water" else .5
		player.velocity.x=lerpf(direction*target_speed,player.velocity.x,pow(drag,delta*20))
		if player.input_blocked: player.velocity.x=0
		if not player.input_blocked and Input.is_action_pressed("jump") and player.is_on_floor() and immersion.is_empty() and not player.climbing.active:
			if game.food!=null:game.food.add_exhaustion(float(game.food.rules.sprint_jump if player.sprinting else game.food.rules.jump))
			player.velocity.y=-config.jump_speed
			_vertical_tick=0.0
			if player.sprinting: player.velocity.x+=direction*config.sprint_jump_impulse
		if player.crouching and immersion.is_empty() and config.sneak_edge_protection and player.is_on_floor() and player.velocity.y>=0:
			var distance: float=player.velocity.x*delta
			while absf(distance)>.001 and not _support_at(player.global_position+Vector2(distance,0)):
				distance=move_toward(distance,0,.25)
			player.velocity.x=distance/maxf(delta,.001)
	if not player._has_mouse_target and direction!=0:
		player.facing=1 if direction>0 else -1
		player.presentation.facing=player.facing
	if player.climbing.active:
		player.climbing.apply(delta);_vertical_tick=0
	var before: Vector2=player.global_position
	var grounded: bool=player.is_on_floor()
	if immersion.is_empty(): try_step(player.velocity.x*delta)
	if game.get_block(game.ground.local_to_map(game.ground.to_local(player.global_position)))==BlockDatabase.id_for("cobweb"):
		player.velocity.x*=.25;player.velocity.y*=.05
	var push: float=player.knockback_x
	current_velocity=fluid.current_velocity(Rect2(collider.global_position-collider.shape.size*.5,collider.shape.size),current_velocity,delta) if fluid!=null else Vector2.ZERO
	player.velocity+=current_velocity
	player.velocity.x+=push
	player.move_and_slide()
	player.velocity.x=0 if player.is_on_wall() else player.velocity.x-push-current_velocity.x
	if not player.is_on_floor() and not player.is_on_ceiling():player.velocity.y-=current_velocity.y
	player.knockback_x=0 if player.is_on_wall() else player.knockback_x*pow(.6,delta*20)
	if player.is_on_wall() and immersion.is_empty(): _sprint_latched=false
	if player.creative and player.creative_flying:
		set_pose("standing",true);player.sprinting=false;player.swim_sprinting=false
		var axis:=Vector2(Input.get_axis("move_left","move_right"),float(Input.is_action_pressed("crouch"))-float(Input.is_action_pressed("jump"))) if not player.input_blocked else Vector2.ZERO
		player.velocity=axis.limit_length()*config.move_speed*2.5*(2 if Input.is_action_pressed("sprint") else 1)
		player.move_and_slide();player.survival.reset_fall()
		if player.is_on_floor():player.creative_flying=false
		return 0
	player.climbing.contact()
	if player.climbing.active and player.survival!=null:player.survival.reset_fall()
	if player.survival!=null: player.survival.observe_motion(grounded,before.y,player.global_position.y,player.is_on_floor())
	return player.global_position.distance_to(before) if player.swimming else absf(player.global_position.x-before.x)
