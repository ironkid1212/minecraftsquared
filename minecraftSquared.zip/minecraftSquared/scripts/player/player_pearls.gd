class_name PlayerPearls
extends Node2D
static var RULES: Dictionary=DataFile.object_from("res://data/projectiles.json").get("ender_pearl",{})
var world: Node2D
var pearls: Array[Dictionary]=[]
var cooldown: float=0
func setup(game: Node2D) -> void:
	world=game;z_index=19;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	for key in ["speed","gravity","cooldown","damage","maximum_active"]:
		if not ContentCatalog._number(RULES.get(key),.01,2000):DataFile.fail("projectiles.json: invalid ender pearl "+key);set_physics_process(false);return
func use() -> bool:
	if world.get_interaction_item()!=BlockDatabase.id_for("ender_pearl"):return false
	if cooldown>0:return true
	var rule: Dictionary=RULES
	if pearls.size()>=int(rule.maximum_active):return true
	var aim: Vector2=(world.pointer_global_position()-world.player.eye_position()).normalized()
	if aim.is_zero_approx():return false
	pearls.append({"position":world.player.eye_position(),"velocity":aim*float(rule.speed),"life":30.0})
	cooldown=float(rule.cooldown)
	if not world.player.creative:world.inventory.remove_from_slot(world.use_slot(),1)
	world.player.swing_hand("place",world.pointer_global_position());queue_redraw();return true
func fits(point: Vector2) -> bool:
	var size: Vector2=world.player_collision.shape.size
	var local: Rect2=world.ground.global_transform.affine_inverse()*Rect2(point-size*.5,size)
	var first: Vector2i=world.ground.local_to_map(local.position+Vector2.ONE*.1);var last: Vector2i=world.ground.local_to_map(local.end-Vector2.ONE*.1)
	for x in range(first.x,last.x+1):
		for y in range(first.y,last.y+1):
			var at:=Vector2i(x,y)
			if not world.chunks.is_cell_loaded(at) or BlockDatabase.BLOCKS.get(world.get_block(at),{}).get("solid",false):return false
	return true
func land(point: Vector2,normal: Vector2) -> bool:
	if world.player.survival_dead or world.player.spectator:return false
	var mite_origin: Vector2=world.player.global_position+Vector2(0,14)
	var size: Vector2=world.player_collision.shape.size
	var target: Vector2=point+normal*(size*.5+Vector2.ONE*.2)
	var destination: Vector2=Vector2(INF,INF)
	# Stay on the impact side; never search through the struck wall.
	for offset in [Vector2.ZERO,Vector2(0,-8),Vector2(0,-16),Vector2(0,8),Vector2(0,16)]:
		if fits(target+offset):destination=target+offset;break
	if not is_finite(destination.x):return false
	world.mobs.renderer.portal_burst(world.player.global_position);world.player.teleport_to(destination);world.chunks.update_around(destination)
	world.survival.reset_fall();world.mobs.renderer.portal_burst(destination)
	if world.mobs.rng.randf()<.05 and world.mobs.can_fit("endermite",mite_origin):world.mobs.spawn("endermite",mite_origin)
	world.survival.take_damage(float(RULES.damage),"Ender pearl fall",true)
	return true
func _physics_process(delta: float) -> void:
	cooldown=maxf(0,cooldown-delta)
	if world.player.survival_dead:pearls.clear();queue_redraw();return
	if pearls.is_empty():return
	for i in range(pearls.size()-1,-1,-1):
		var pearl: Dictionary=pearls[i]
		var from: Vector2=pearl.position
		# Unloaded throws pause with their dimension until the area is resident again.
		if not world.chunks.is_cell_loaded(world.mobs.cell(from)):continue
		pearl.life-=delta
		if pearl.life<=0:pearls.remove_at(i);continue
		var to: Vector2=from+Vector2(pearl.velocity)*delta
		var query:=PhysicsRayQueryParameters2D.create(from,to,3);query.exclude=[world.player.get_rid()]
		var hit: Dictionary=get_world_2d().direct_space_state.intersect_ray(query)
		var nearest: float=from.distance_to(hit.position) if not hit.is_empty() else INF
		var mob_hit: bool=false
		for mob: MobActor in world.mobs.active.values():
			if mob.dead:continue
			var distance: float=PlayerCombat.ray_entry(from,to,mob.bounds(mob.global_position),from.distance_to(to))
			if distance<nearest and mob.definition.rig=="enderman":NetherMobBrain.teleport(mob);continue
			if distance<nearest:
				nearest=distance;hit={"position":from+(to-from).normalized()*distance,"normal":-(to-from).normalized()};mob_hit=true
		if world.gateways!=null and world.gateways.pearl_segment(from,to,nearest):pearls.remove_at(i);continue
		if not hit.is_empty():
			pearls.remove_at(i);land(hit.position,Vector2.UP if mob_hit else hit.normal)
			if world.player.survival_dead:break
			continue
		pearl.position=to;pearl.velocity=Vector2(pearl.velocity)*pow(.99,delta*20)+Vector2(0,float(RULES.gravity)*delta)
	queue_redraw()
func _draw() -> void:
	var view: Rect2=get_global_transform_with_canvas().affine_inverse()*get_viewport_rect()
	for pearl in pearls:
		if view.grow(4).has_point(pearl.position):ItemDrawing.draw_icon(self,world.atlas_source,BlockDatabase.id_for("ender_pearl"),Rect2(pearl.position-Vector2(3,3),Vector2(6,6)),world.lighting.render_tint(world.mobs.cell(pearl.position)))
func snapshot() -> Array:
	var records: Array=[]
	for pearl in pearls:records.append({"position":[pearl.position.x,pearl.position.y],"velocity":[pearl.velocity.x,pearl.velocity.y],"life":pearl.life})
	return records
func restore(records: Array) -> void:
	pearls.clear()
	for record in records:pearls.append({"position":Vector2(record.position[0],record.position[1]),"velocity":Vector2(record.velocity[0],record.velocity[1]),"life":float(record.life)})
	queue_redraw()
static func valid(records: Variant) -> bool:
	if not records is Array or records.size()>int(RULES.maximum_active):return false
	for record in records:
		if not record is Dictionary or not ContentCatalog._vector(record.get("position"),2,-160000000,160000000) or not ContentCatalog._vector(record.get("velocity"),2,-8192,8192) or not ContentCatalog._number(record.get("life"),0,30):return false
	return true
