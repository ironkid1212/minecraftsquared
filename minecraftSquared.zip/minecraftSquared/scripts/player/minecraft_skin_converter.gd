class_name MinecraftSkinConverter
extends RefCounted

## Converts classic 64x64 (or legacy 64x32) Minecraft UVs into our 48x32
## side-view atlas. Uses exact pixel copies, never interpolation or resampling.
## Each 24px direction bank contains base parts and their optional outer layer.
const DESTINATIONS: Dictionary = {
	"head": Rect2i(0, 0, 8, 8), "hat": Rect2i(8, 0, 8, 8),
	"body": Rect2i(0, 8, 4, 12), "near_arm": Rect2i(4, 8, 4, 12),
	"far_arm": Rect2i(8, 8, 4, 12), "jacket": Rect2i(12, 8, 4, 12),
	"near_sleeve": Rect2i(16, 8, 4, 12), "far_sleeve": Rect2i(20, 8, 4, 12),
	"near_leg": Rect2i(0, 20, 4, 12), "far_leg": Rect2i(4, 20, 4, 12),
	"near_trousers": Rect2i(8, 20, 4, 12), "far_trousers": Rect2i(12, 20, 4, 12),
}
# Bank 0 faces right (the right anatomical side is nearest the viewer).
# Bank 1 faces left (the left anatomical side is nearest the viewer).
const SOURCE_UVS: Array[Dictionary] = [
	{"head": Vector2i(0, 8), "hat": Vector2i(32, 8),
	 "body": Vector2i(16, 20), "jacket": Vector2i(16, 36),
	 "near_arm": Vector2i(40, 20), "far_arm": Vector2i(32, 52),
	 "near_sleeve": Vector2i(40, 36), "far_sleeve": Vector2i(48, 52),
	 "near_leg": Vector2i(0, 20), "far_leg": Vector2i(16, 52),
	 "near_trousers": Vector2i(0, 36), "far_trousers": Vector2i(0, 52)},
	{"head": Vector2i(16, 8), "hat": Vector2i(48, 8),
	 "body": Vector2i(28, 20), "jacket": Vector2i(28, 36),
	 "near_arm": Vector2i(40, 52), "far_arm": Vector2i(48, 20),
	 "near_sleeve": Vector2i(56, 52), "far_sleeve": Vector2i(48, 36),
	 "near_leg": Vector2i(24, 52), "far_leg": Vector2i(8, 20),
	 "near_trousers": Vector2i(8, 52), "far_trousers": Vector2i(8, 36)},
]


static func convert(source: Image, slim: bool = false) -> Dictionary:
	if source == null or source.is_empty() or source.get_width() % 64 != 0:
		return {"error": "Input must be a classic 64x64 or legacy 64x32 PNG (integer HD multiples accepted)."}
	var factor: int = source.get_width() / 64
	if factor < 1 or source.get_height() not in [32 * factor, 64 * factor]:
		return {"error": "Input must have dimensions 64N x 64N or 64N x 32N."}
	var legacy: bool = source.get_height() == 32 * factor
	if slim and legacy:
		return {"error": "Legacy 64x32 skins use the Classic model. Select Classic/Steve."}
	var result := Image.create(48 * factor, 32 * factor, false, Image.FORMAT_RGBA8)
	result.fill(Color.TRANSPARENT)
	for bank in range(2):
		for part: String in DESTINATIONS:
			var destination: Rect2i = DESTINATIONS[part]
			var origin: Vector2i = SOURCE_UVS[bank][part]
			# Slim arms remain four pixels deep in side view, but their opposite
			# side UVs move left by one pixel because the front is three wide.
			if slim and bank == 1 and part in ["near_arm", "far_arm", "near_sleeve", "far_sleeve"]:
				origin.x -= 1
			var flip: bool = false
			if legacy:
				if part in ["jacket", "near_sleeve", "far_sleeve", "near_trousers", "far_trousers"]:
					continue
				if bank == 0 and part in ["far_arm", "far_leg"]:
					origin = Vector2i(48, 20) if part == "far_arm" else Vector2i(8, 20)
					flip = true
				elif bank == 1 and part in ["near_arm", "near_leg"]:
					origin = Vector2i(40, 20) if part == "near_arm" else Vector2i(0, 20)
					flip = true
			var piece: Image = source.get_region(Rect2i(origin * factor, destination.size * factor))
			if flip:
				piece.flip_x()
			# Classic base layers are opaque; transparency belongs to outer layers.
			if part in ["head", "body", "near_arm", "far_arm", "near_leg", "far_leg"]:
				for y in range(piece.get_height()):
					for x in range(piece.get_width()):
						var color: Color = piece.get_pixel(x, y)
						color.a = 1.0
						piece.set_pixel(x, y, color)
			result.blit_rect(piece, Rect2i(Vector2i.ZERO, piece.get_size()),
				(destination.position + Vector2i(bank * 24, 0)) * factor)
	return {"image": result, "legacy": legacy, "scale": factor}
