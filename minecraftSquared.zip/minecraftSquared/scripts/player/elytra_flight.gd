class_name ElytraFlight
extends RefCounted
const WINGS: Texture2D=preload("res://assets/equipment/elytra.png")
var active: bool=false
var jump_held: bool=false
var boost: float=0
var wear_clock: float=0
var tick_clock: float=0
var use_clock: float=0
func cancel() -> void:active=false;boost=0;wear_clock=0;tick_clock=0
func equipped(world: Node2D) -> bool:return world.inventory.ids[BlockInventory.CHEST]==BlockDatabase.id_for("elytra") and world.inventory.counts[BlockInventory.CHEST]>0 and world.inventory.durability[BlockInventory.CHEST]>1
func step(player: CharacterBody2D,dt: float) -> bool:
	use_clock=maxf(0,use_clock-dt)
	var pressed: bool=Input.is_action_pressed("jump");var deploy_pressed: bool=pressed and not jump_held;jump_held=pressed
	var world: Node2D=player.get_parent();var fluid: String=player.fluids.body_kind() if player.fluids!=null else ""
	var allowed: bool=equipped(world) and fluid.is_empty() and not player.spectator and not player.survival_dead and not player.survival.effects.remaining.has("levitation") and not player.creative_flying
	if not allowed or player.is_on_floor():cancel()
	if not active and allowed and not player.is_on_floor() and not player.input_blocked and deploy_pressed:
		active=player.locomotion.set_pose("gliding");tick_clock=0;wear_clock=0
	if not active:
		player.floor_snap_length=player.settings.floor_snap_distance
		return false
	player.floor_snap_length=0;player.locomotion.set_pose("gliding",true);player.sprinting=false;player.swim_sprinting=false;player.climbing.active=false
	var pitch: float=clampf(player.presentation.head_pitch,-1.3,1.3);var look:=Vector2(player.facing*cos(pitch),sin(pitch));var horizontal: float=signf(look.x)
	tick_clock+=dt;boost=maxf(0,boost-dt)
	while tick_clock>=.05:
		tick_clock-=.05;var v: Vector2=player.velocity/320;var lift: float=pow(cos(pitch),2)
		v.y+=.08-.06*lift
		if v.y>0:
			var recovered: float=v.y*.1*lift;v.y-=recovered;v.x+=horizontal*recovered
		if pitch<0:
			var climb: float=absf(v.x)*-sin(pitch)*.04;v.y-=climb*3.2;v.x-=horizontal*climb
		v.x+=(horizontal*absf(v.x)-v.x)*.1;v*=Vector2(.99,.98)
		if boost>0:v+=look*.1+(look*(float(EndCityGenerator.RULES.elytra.rocket_speed)/320)-v)*.5
		player.velocity=v*320
	var speed: float=absf(player.velocity.x);var before: Vector2=player.global_position
	if boost>0 and world.effects!=null and world.effects.rng.randf()<minf(1,dt*24):world.effects.emit_particle("spark",player.global_position-look*8,-look*12,.45,2)
	player.move_and_slide();player.survival.reset_fall();player.presentation.swim_angle=player.velocity.angle()+PI/2
	if player.is_on_wall() and speed>float(EndCityGenerator.RULES.elytra.wall_damage_threshold):world.survival.take_damage(maxf(0,(speed-absf(player.velocity.x))/320*10-3),"You experienced kinetic energy",true);cancel()
	if player.is_on_floor():cancel()
	wear_clock+=dt
	while wear_clock>=1 and active:
		wear_clock-=1
		if not player.creative:
			var cost: int=EnchantmentDatabase.durability_cost(BlockDatabase.id_for("elytra"),world.inventory.tags[BlockInventory.CHEST],1)
			world.inventory.durability[BlockInventory.CHEST]=maxi(1,world.inventory.durability[BlockInventory.CHEST]-cost);world.inventory.changed.emit()
			if world.inventory.durability[BlockInventory.CHEST]<=1:cancel()
	world.food.add_exhaustion(before.distance_to(player.global_position)/16*.01)
	return true
func use_rocket(world: Node2D) -> bool:
	if world.get_interaction_item()!=BlockDatabase.id_for("firework_rocket"):return false
	if use_clock>0:return true
	use_clock=.3
	if world.effects!=null:world.effects.sound("entity.firework_rocket.launch",world.player.global_position,"player",.8,1,2,.2)
	if active:
		var data: Variant=NBT.value(world.inventory.tags[world.use_slot()],"Fireworks",{})
		var flight: int=clampi(int(NBT.value(data,"Flight",1)) if data is Dictionary else 1,0,3)
		boost=.5*(1+flight)+world.mobs.rng.randf_range(0,.6)
	else:world.end_city_system.launch_rocket(world.player.eye_position())
	if not world.player.creative:world.inventory.remove_from_slot(world.use_slot(),1)
	world.player.swing_hand("place",world.pointer_global_position());return true
static func draw(canvas: CanvasItem,items: BlockInventory,facing: int,t: Transform2D,gliding: bool=false) -> void:
	if items==null or items.ids[BlockInventory.CHEST]!=BlockDatabase.id_for("elytra") or items.counts[BlockInventory.CHEST]<=0:return
	var transform: Transform2D=t*Transform2D(.35*facing if gliding else -.1*facing,Vector2(-3*facing,-9))
	canvas.draw_set_transform_matrix(transform)
	canvas.draw_texture_rect_region(WINGS,Rect2(-8 if facing>0 else 0,0,8,18),Rect2(34,2,12,20),Color.WHITE)
	if EnchantmentGlint.active(items.ids[BlockInventory.CHEST],items.tags[BlockInventory.CHEST]):EnchantmentGlint.draw(canvas,WINGS,Rect2i(34,2,12,20),Rect2(-8 if facing>0 else 0,0,8,18),Color.WHITE)
