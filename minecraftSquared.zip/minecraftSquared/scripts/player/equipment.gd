class_name Equipment
extends RefCounted
static var _textures: Dictionary={}
static func totals(items: BlockInventory) -> Vector2:
	var result:=Vector2.ZERO
	for i in range(BlockInventory.HEAD,BlockInventory.FEET+1):
		if items.counts[i]<=0:continue
		var armor: Dictionary=BlockDatabase.BLOCKS.get(items.ids[i],{}).get("armor",{})
		result+=Vector2(float(armor.get("points",0)),float(armor.get("toughness",0)))
	return result
static func after_armor(damage: float,items: BlockInventory,reason: String) -> float:
	var reduction: int=0
	for i in range(BlockInventory.HEAD,BlockInventory.FEET+1):
		if items.counts[i]>0:reduction+=EnchantmentDatabase.level(items.tags[i],"protection")
	var result: float=_after_armor(damage,items,reason)
	var text: String=reason.to_lower()
	if "void" in text or "killed" in text or "starv" in text:return result
	return result*(1-mini(20,reduction)*.04)
static func _after_armor(damage: float,items: BlockInventory,reason: String) -> float:
	var text: String=reason.to_lower()
	for bypass in ["fell","fall","drown","void","killed","burn","starv","suffocat","poison","wither","magic"]:
		if bypass in text:return damage
	var armor: Vector2=totals(items)
	if armor.x<=0:return damage
	var protection: float=clampf(armor.x-damage/(2+armor.y/4),armor.x*.2,20)
	for i in range(BlockInventory.HEAD,BlockInventory.FEET+1):
		if items.counts[i]>0:items.damage_tool(i,maxi(1,floori(damage/4)))
	return damage*(1-protection/25)
static func equip(items: BlockInventory,source: int) -> bool:
	var armor: Dictionary=BlockDatabase.BLOCKS.get(items.ids[source],{}).get("armor",{})
	if armor.is_empty():return false
	var slot: int=BlockInventory.HEAD+["head","chest","legs","feet"].find(str(armor["slot"]))
	return source!=slot and items.swap_slots(source,slot)
static func _part(canvas: CanvasItem,items: BlockInventory,slot: int,part: String,facing: int,transform: Transform2D,bounds: Rect2,tint: Color) -> void:
	if items==null or items.counts[slot]<=0 or items.ids[slot]==BlockDatabase.id_for("elytra"):return
	var armor: Dictionary=BlockDatabase.BLOCKS.get(items.ids[slot],{}).get("armor",{})
	if armor.is_empty():return
	var path: String=armor["texture"]
	if not _textures.has(path):_textures[path]=load(path)
	var texture: Texture2D=_textures[path]
	if texture==null:return
	canvas.draw_set_transform_matrix(transform)
	canvas.draw_texture_rect_region(texture,bounds.grow(.5 if part=="head" else .25),PlayerSkinDrawing.region(part,facing,texture),tint)
	if EnchantmentGlint.active(items.ids[slot],items.tags[slot]):EnchantmentGlint.draw(canvas,texture,Rect2i(PlayerSkinDrawing.region(part,facing,texture)),bounds.grow(.5 if part=="head" else .25),tint)
static func draw_part(canvas: CanvasItem,items: BlockInventory,part: String,facing: int,transform: Transform2D,bounds: Rect2,tint: Color = Color.WHITE) -> void:
	if items==null:return
	if part=="head":_part(canvas,items,BlockInventory.HEAD,part,facing,transform,bounds,tint)
	elif part=="body":
		_part(canvas,items,BlockInventory.LEGS,part,facing,transform,bounds,tint)
		_part(canvas,items,BlockInventory.CHEST,part,facing,transform,bounds,tint)
	elif "arm" in part:_part(canvas,items,BlockInventory.CHEST,part,facing,transform,bounds,tint)
	elif "leg" in part:
		_part(canvas,items,BlockInventory.LEGS,part,facing,transform,bounds,tint)
		_part(canvas,items,BlockInventory.FEET,part,facing,transform,bounds,tint)

