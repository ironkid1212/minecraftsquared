class_name PlayerFood
extends Node
var world: Node2D
var rules: Dictionary
var level: int=20
var saturation: float=5
var exhaustion: float=0
var timer: float=0
var slot: int=-1
var item: int=0
var elapsed: float=0
var motion_position:=Vector2.ZERO

func setup(game: Node2D) -> void:
	world=game;rules=AdventureData.DATA.hunger
	reset()
	motion_position=world.player.global_position
func begin(index: int) -> bool:
	var id: int=world.inventory.ids[index]
	var food: Dictionary=BrewingData.consumable(id)
	if world.inventory.counts[index]<=0 or food.is_empty() or level>=20 and not world.player.creative and not food.get("always_edible",false):return false
	slot=index;item=id;elapsed=0;world.shields.cancel();world.reset_mining();world.mining_held=false
	return true
func cancel() -> void:
	slot=-1;item=0;elapsed=0
	world.player.presentation.eating_time=-1
	if world.player.presentation.offhand!=null:world.player.presentation.offhand.eating_time=-1
func busy() -> bool:return slot>=0
func add_exhaustion(amount: float) -> void:
	if world.player.spectator or world.player.creative or world.survival.dead:return
	exhaustion=minf(40,exhaustion+maxf(0,amount))
func can_sprint() -> bool:return level>6 and not busy()
func consume() -> void:
	if slot<0:return
	var food: Dictionary=BrewingData.consumable(item)
	if not world.player.creative and world.inventory.remove_from_slot(slot,1)<=0:cancel();return
	level=mini(20,level+int(food.nutrition));saturation=minf(level,saturation+float(food.saturation))
	var effect: Dictionary=food.get("effect",{})
	if not effect.is_empty() and randf()<float(effect.get("chance",1)):world.survival.effects.apply(effect)
	var potion: String=BrewingData.key_for(item)
	if not potion.is_empty():
		var rule: Dictionary=BrewingData.DATA.potions[potion]
		if rule.effect=="instant_health":world.survival.heal(4*pow(2,int(rule.get("amplifier",0))))
		elif not str(rule.effect).is_empty():world.survival.effects.apply({"name":rule.effect,"seconds":rule.seconds,"amplifier":int(rule.get("amplifier",0))})
		if not world.player.creative:
			var bottle: int=BlockDatabase.id_for("glass_bottle")
			if world.inventory.counts[slot]==0:world.inventory.set_stack(slot,{"id":bottle,"count":1})
			elif world.inventory.add_item(bottle,1)>0:world.dropped_items.spawn_item(bottle,1,world.player.global_position)
		world.inventory.changed.emit()
	var key: String=BlockDatabase.BLOCKS[item].key
	if key=="milk_bucket":
		world.survival.effects.clear();world.survival.absorption=0
		if not world.player.creative:
			var bucket: int=BlockDatabase.id_for("bucket")
			if world.inventory.counts[slot]==0:world.inventory.set_stack(slot,{"id":bucket,"count":1})
			elif world.inventory.add_item(bucket,1)>0:world.dropped_items.spawn_item(bucket,1,world.player.global_position)
	if key in ["golden_apple","enchanted_golden_apple"]:
		world.survival.effects.apply({"name":"regeneration","seconds":5 if key=="golden_apple" else 20,"amplifier":1})
		world.survival.effects.apply({"name":"absorption","seconds":120,"amplifier":3 if key=="enchanted_golden_apple" else 0})
		world.survival.absorption=maxf(world.survival.absorption,4 if key=="golden_apple" else 16)
		if key=="enchanted_golden_apple":
			world.survival.effects.apply({"name":"resistance","seconds":300})
			world.survival.effects.apply({"name":"fire_resistance","seconds":300})
	var used: int=slot
	cancel()
	if Input.is_action_pressed("use_item"):begin(used)
func _physics_process(dt: float) -> void:
	var p: CharacterBody2D=world.player
	var distance: float=p.global_position.distance_to(motion_position)/16
	motion_position=p.global_position
	if p.spectator or p.survival_dead:cancel();return
	if distance<2:
		if p.sprinting:add_exhaustion(distance*float(rules.sprint_per_block))
		elif p.fluids!=null and p.fluids.body_kind()=="water":add_exhaustion(distance*float(rules.swim_per_block))
	if busy():
		if not Input.is_action_pressed("use_item") and elapsed>0 and elapsed<float(BrewingData.consumable(item).seconds):
			var drinking: bool=not BrewingData.key_for(item).is_empty() or item==BlockDatabase.id_for("milk_bucket")
			world.show_mode_notice("Hold "+world.get_node("/root/GameOptions").keybinds.label("use_item")+(" to drink" if drinking else " to eat"))
		if p.input_blocked or not p.interaction_enabled or not Input.is_action_pressed("use_item") or world.inventory.ids[slot]!=item or slot!=BlockInventory.OFFHAND and slot!=world.hotbar.selected_slot:cancel()
		else:
			elapsed+=dt
			var visual: PlayerPresentation=p.presentation.offhand if slot==BlockInventory.OFFHAND else p.presentation
			visual.eating_time=elapsed
			if elapsed>=float(BrewingData.consumable(item).seconds):consume()
	if p.creative:return
	if world.survival.effects.remaining.has("hunger"):add_exhaustion(.1*dt)
	while exhaustion>=float(rules.exhaustion_step):
		exhaustion-=float(rules.exhaustion_step)
		if saturation>0:saturation=maxf(0,saturation-1)
		else:level=maxi(0,level-1)
	var health: float=world.survival.health
	if world.survival.settings.regeneration_enabled and health<world.survival.settings.maximum_health and level>=18:
		timer+=dt
		var interval: float=.5 if level==20 and saturation>0 else 4
		if timer>=interval:
			timer=0
			var amount: float=minf(saturation,6)/6 if level==20 and saturation>0 else 1
			world.survival.health=minf(world.survival.settings.maximum_health,health+amount)
			add_exhaustion(amount*float(rules.heal_exhaustion));world.survival.health_changed.emit()
	elif level<=0:
		timer+=dt
		if timer>=float(rules.starve_seconds):
			timer=0
			if health>float(rules.starve_floor):world.survival.take_damage(minf(1,health-float(rules.starve_floor)),"Starvation",true)
	else:timer=0
func reset() -> void:level=20;saturation=float(rules.starting_saturation);exhaustion=0;timer=0;cancel()
func snapshot() -> Dictionary:return {"level":level,"saturation":saturation,"exhaustion":exhaustion}
func restore(record: Dictionary) -> void:
	reset();level=clampi(int(record.get("level",20)),0,20);saturation=clampf(float(record.get("saturation",5)),0,level);exhaustion=clampf(float(record.get("exhaustion",0)),0,40)
	motion_position=world.player.global_position
