class_name ShieldSystem
extends Node
var world: Node2D
var slot: int=-1
var elapsed: float=0
var disabled: float=0
var flash: float=0
var requested: bool=false
func setup(game: Node2D) -> void:world=game
func definition(index: int) -> Dictionary:
	return BlockDatabase.BLOCKS.get(world.inventory.ids[index],{}).get("shield",{}) if index>=0 and index<world.inventory.counts.size() and world.inventory.counts[index]>0 else {}
func begin(index: int) -> bool:
	if definition(index).is_empty() or disabled>0:return false
	if slot!=index:elapsed=0
	slot=index;requested=true;world.mining_held=false;world.reset_mining();return true
func begin_available() -> bool:return begin(world.hotbar.selected_slot) or begin(BlockInventory.OFFHAND)
func cancel() -> void:
	requested=false;slot=-1;elapsed=0
	world.player.presentation.blocking=false
	if world.player.presentation.offhand!=null:world.player.presentation.offhand.blocking=false
func raising() -> bool:return requested and slot>=0 and disabled<=0 and not definition(slot).is_empty()
func active() -> bool:return raising() and elapsed>=float(definition(slot).delay)
func move_factor() -> float:return float(definition(slot).move_factor) if raising() else 1.0
func _physics_process(delta: float) -> void:
	disabled=maxf(0,disabled-delta);flash=maxf(0,flash-delta)
	if requested and slot!=BlockInventory.OFFHAND and slot!=world.hotbar.selected_slot:cancel()
	if not requested:return
	if not Input.is_action_pressed("use_item") or not world.player.interaction_enabled or world.player.input_blocked or world.player.spectator or world.player.survival_dead or definition(slot).is_empty() or slot!=BlockInventory.OFFHAND and slot!=world.hotbar.selected_slot:cancel();return
	elapsed+=delta
	world.player.presentation.blocking=slot!=BlockInventory.OFFHAND
	if world.player.presentation.offhand!=null:
		world.player.presentation.offhand.blocking=slot==BlockInventory.OFFHAND
		world.player.presentation.offhand.head_pitch=world.player.presentation.head_pitch
func block(damage: float,source: Vector2,kind: String="melee",attacker: MobActor=null) -> bool:
	if not active() or kind not in ["melee","projectile","explosion"] or world.player.spectator or world.player.survival_dead:return false
	var toward: Vector2=source-world.player.global_position
	# Minecraft's blocking test is horizontal. Looking up/down must not expose
	# the front of the shield to a nearby enemy in this side-view adaptation.
	if toward.is_zero_approx() or toward.x*world.player.facing<0:return false
	var disable_seconds: float=float(definition(slot).disable_seconds) if attacker!=null and attacker.definition.get("wields_axe",false) else 0
	flash=.2
	if damage>=float(definition(slot).wear_threshold):world.inventory.damage_tool(slot,ceili(damage))
	if attacker!=null:
		attacker.knockback_x=signf(attacker.center().x-world.player.global_position.x)*80
	if definition(slot).is_empty():cancel()
	elif disable_seconds>0:disabled=disable_seconds;cancel()
	return true
