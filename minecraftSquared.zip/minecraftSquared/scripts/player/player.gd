extends CharacterBody2D
var elytra:=ElytraFlight.new()

var settings: PlayerSettings = preload("res://data/settings/player.tres")
var fall_limit_y: float = 2304.0
var facing: int = 1
var walk_phase: float = 0.0
var walk_amount: float = 0.0
var presentation := PlayerPresentation.new()
var interaction_enabled: bool = true
var action_offhand: bool=false
var knockback_x: float=0
var fluids: FluidSystem
var shields: ShieldSystem
var survival: PlayerSurvival
var survival_dead: bool = false
var input_blocked: bool = false
var creative: bool=false
var creative_flying: bool=false
var _creative_jump_time: float=-10
var spectator: bool = false
var spectator_speed: float = 0.4
var crouching: bool = false
var sprinting: bool = false
var swimming: bool = false
var swim_sprinting: bool = false
var climbing:=PlayerClimbing.new()
var locomotion := PlayerLocomotion.new()
var _survival_layer: int
var _survival_mask: int
var _mouse_screen_position := Vector2.ZERO
var _has_mouse_target: bool = false
# Interpolate visuals only; collisions and gameplay retain full physics precision.
var _previous_position := Vector2.ZERO
var _current_position := Vector2.ZERO
var _previous_walk_phase: float = 0.0
var _previous_walk_amount: float = 0.0
var _skin_visual: Node2D
var _follow_camera: Camera2D

@onready var spawn_position: Vector2 = global_position


func configure(config: PlayerSettings, world_bottom: float) -> void:
	settings = config
	floor_snap_length=settings.floor_snap_distance
	presentation.configure(config)
	fall_limit_y = world_bottom + settings.recovery_margin
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_redraw_skin()


func _ready() -> void:
	climbing.setup(self)
	locomotion.setup(self)
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	process_priority = -90
	_previous_position = global_position
	_current_position = global_position
	_follow_camera = get_node_or_null("Camera2D") as Camera2D
	if _follow_camera != null:
		_follow_camera.top_level = true
		_follow_camera.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
		_follow_camera.position_smoothing_enabled = false
		_follow_camera.process_callback = Camera2D.CAMERA2D_PROCESS_IDLE
		_follow_camera.process_priority = -80
	_skin_visual = Node2D.new()
	_skin_visual.name = "SkinVisual"
	_skin_visual.top_level = true
	_skin_visual.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	_skin_visual.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(_skin_visual)
	_skin_visual.draw.connect(_draw_skin)
	update_render_camera()
	_redraw_skin()
	presentation.configure(settings)
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST


func _physics_process(delta: float) -> void:
	if survival_dead: return
	# A spawn/load/teleport between ticks must never blend across the map.
	_previous_position = _current_position if global_position.is_equal_approx(_current_position) else global_position
	_previous_walk_phase = walk_phase
	_previous_walk_amount = walk_amount
	if spectator:
		var direction := Vector2.ZERO if input_blocked else Vector2(Input.get_axis("move_left", "move_right"),
			float(Input.is_action_pressed("spectator_down")) - float(Input.is_action_pressed("spectator_up")))
		var speed: float = settings.spectator_base_speed * spectator_speed
		if not input_blocked and Input.is_action_pressed("spectator_boost"): speed *= settings.spectator_sprint_multiplier
		velocity = velocity.lerp(direction.limit_length() * speed, 1.0 - exp(-settings.spectator_acceleration * delta))
		global_position += velocity * delta
		_current_position = global_position
		return
	var moved: float = locomotion.step(delta)
	# Minecraft-style locomotion continues during a moving jump. A straight
	# vertical jump has no horizontal swing and settles into the standing pose.
	var walking: bool = moved > 0.01
	if walking:
		walk_phase = fmod(walk_phase + moved / maxf(settings.stride_length*(settings.sprint_stride_factor if sprinting else 1.0), 1.0) * TAU, TAU)
	var driven: bool=not input_blocked and absf(Input.get_axis("move_left","move_right"))>.01
	var target_amount: float=clampf(absf(velocity.x)/maxf(settings.move_speed,1.0),0,1) if walking and driven else 0.0
	walk_amount = move_toward(walk_amount,target_amount,delta*(settings.walk_settle_speed if target_amount<walk_amount else 10.0))
	if walk_amount<=.001 and not driven: walk_phase=0.0
	if global_position.y > fall_limit_y:
		if survival != null: survival.take_damage(survival.settings.maximum_health, "You fell out of the world", true)
		else: teleport_to(spawn_position)
	_current_position = global_position
	_redraw_skin()


func _draw_skin() -> void:
	if survival_dead:return
	var fraction: float = _render_fraction()
	var phase: float = lerp_angle(_previous_walk_phase, walk_phase, fraction)
	var amount: float = lerpf(_previous_walk_amount, walk_amount, fraction)
	_skin_visual.self_modulate = self_modulate * (Color(1,.4,.4) if survival != null and survival.damage_flash > 0 else Color.WHITE)
	PlayerSkinDrawing.draw_model(_skin_visual, settings, Vector2.ZERO, 1.0,
		facing, phase, amount, Transform2D.IDENTITY, presentation)


func _process(delta: float) -> void:
	update_render_camera()
	_redraw_skin()
	if not interaction_enabled:
		return
	if _has_mouse_target:
		# Event coordinates stay in viewport space. Recompute the local target
		# with the current camera/player transform, even if the mouse is still.
		var target: Vector2 = to_local(get_canvas_transform().affine_inverse() * _mouse_screen_position) - to_local(render_anchor())
		presentation.look_at(target, delta)
	facing = presentation.facing
	presentation.advance(delta)
	if presentation.offhand!=null:presentation.offhand.advance(delta)
	_redraw_skin()


func _input(event: InputEvent) -> void:
	if creative and interaction_enabled and not input_blocked and event is InputEventKey and event.pressed and not event.echo and GameBindings.matches(event,"jump"):
		var now: float=Time.get_ticks_msec()/1000.0
		if now-_creative_jump_time<.3:creative_flying=not creative_flying;velocity.y=0;_creative_jump_time=-10
		else:_creative_jump_time=now
	if event is InputEventMouseMotion or event is InputEventMouseButton:
		set_mouse_target(event.position,get_viewport_rect().has_point(event.position))


func set_held_item(id: int, source: TileSetAtlasSource) -> void:
	presentation.set_held_item(id, source)
	_redraw_skin()


func begin_mining(global_target: Vector2) -> void:
	if interaction_enabled:
		presentation.begin_mining(to_local(global_target))


func stop_mining() -> void:
	presentation.stop_mining()


func swing_hand(kind: String, global_target: Vector2) -> void:
	if interaction_enabled:
		var hand: PlayerPresentation=presentation.offhand if action_offhand and presentation.offhand!=null else presentation
		hand.swing_once(kind,to_local(global_target))


func set_interaction_enabled(value: bool) -> void:
	interaction_enabled = value and not spectator and not survival_dead
	if not value:
		var world: Node=get_parent()
		if world.held_use!=null:world.held_use.cancel()
		if world.food!=null:world.food.cancel()
		if world.ranged!=null:world.ranged.cancel()
		if world.shields!=null:world.shields.cancel()
		presentation.cancel_actions()
	_redraw_skin()


func set_mouse_target(viewport_position: Vector2, active: bool) -> void:
	_mouse_screen_position = viewport_position
	_has_mouse_target = active


func _render_fraction() -> float:
	if not is_physics_processing() or not global_position.is_equal_approx(_current_position):
		return 1.0
	return clampf(Engine.get_physics_interpolation_fraction(), 0.0, 1.0)


func render_anchor() -> Vector2:
	var point: Vector2 = global_position
	if is_physics_processing() and global_position.is_equal_approx(_current_position):
		point = _previous_position.lerp(_current_position, _render_fraction())
	var zoom: Vector2 = _follow_camera.zoom if is_instance_valid(_follow_camera) else Vector2.ONE
	return (point * zoom).round() / zoom


func update_render_camera() -> void:
	if not is_instance_valid(_follow_camera):
		return
	# One shared pixel grid for terrain, camera, and the entire player model.
	# Align the canvas translation too, including odd-sized viewport windows.
	var center: Vector2 = get_viewport_rect().size * 0.5
	var zoom: Vector2 = _follow_camera.zoom
	var translation: Vector2 = center.round() - (render_anchor() * zoom).round()
	_follow_camera.global_position = (center - translation) / zoom
	_follow_camera.force_update_scroll()



func _redraw_skin() -> void:
	if not is_instance_valid(_skin_visual):
		return
	# A separate top-level visual avoids GPU cancellation between a fractional
	# physics transform and its opposite local drawing offset.
	_skin_visual.visible = not spectator and not survival_dead
	_skin_visual.global_position = render_anchor()
	_skin_visual.z_as_relative = false
	_skin_visual.z_index = z_index
	_skin_visual.queue_redraw()


func receive_knockback(source: Vector2,strength: float) -> void:
	if spectator or survival_dead:return
	var direction: float=signf(global_position.x-source.x)
	if direction==0:direction=-facing
	knockback_x=direction*strength
	if is_on_floor():velocity.y=maxf(-128,velocity.y*.5-128)

func set_spectator(value: bool) -> void:
	knockback_x=0
	if survival != null: survival.reset_fall()
	locomotion.reset_motion()
	if value: locomotion.set_pose("standing",true)
	if spectator == value: return
	if value:
		_survival_layer = collision_layer
		_survival_mask = collision_mask
		collision_layer = 0
		collision_mask = 0
	else:
		collision_layer = _survival_layer
		collision_mask = _survival_mask
	spectator = value
	velocity = Vector2.ZERO
	_previous_position = global_position
	_current_position = global_position
	set_interaction_enabled(not value)
	_redraw_skin()

func adjust_spectator_speed(steps: int) -> void:
	spectator_speed = clampf(spectator_speed + steps * 0.025, 0.05, 1.0)

func teleport_to(point: Vector2) -> void:
	elytra.cancel()
	knockback_x=0
	locomotion.reset_motion()
	global_position = point
	velocity = Vector2.ZERO
	walk_phase = 0
	walk_amount = 0
	_previous_position = point
	_current_position = point
	_previous_walk_phase = 0
	_previous_walk_amount = 0
	if survival != null: survival.reset_fall()
	update_render_camera()
	_redraw_skin()

func eye_position() -> Vector2:
	if swimming: return global_position+Vector2(0,9)+Vector2(0,-14).rotated(presentation.swim_angle)
	return global_position+Vector2(5*facing,-10) if crouching else global_position+Vector2(0,-12)
