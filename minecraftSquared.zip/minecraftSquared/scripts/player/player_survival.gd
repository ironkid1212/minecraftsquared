class_name PlayerSurvival
extends Node

signal health_changed
var effects:=EntityEffects.new()
var world: Node2D
var settings: SurvivalSettings
var health: float = 20
var absorption: float=0
var previous_health: float = 20
var dead: bool = false
var death_reason: String = ""
var damage_flash: float = 0.0
var health_blink_time: float = 0.0
var health_history_time: float = 0.0
var invulnerability: float = 0.0
var _last_hit_damage: float=INF
var since_damage: float = 0.0
var _regen: float = 0.0
var tracking_fall: bool = false
var fall_peak_y: float = 0.0
var world_spawn := Vector2.ZERO
var has_bed: bool = false
var bed_anchor := Vector2i.ZERO
var screen: SurvivalScreen

func setup(game: Node2D, config: SurvivalSettings) -> void:
	world = game
	settings = config
	health = settings.maximum_health
	previous_health = health
	world_spawn = world.player.spawn_position
	world.player.survival = self
	reset_fall()
	screen = SurvivalScreen.new()
	(world.ui_layer if world.ui_layer != null else world.get_node("UI")).add_child(screen)
	screen.setup(self)

func reset_fall() -> void:
	tracking_fall = false
	fall_peak_y = world.player.global_position.y

func fall_damage(blocks: float) -> int:
	# Small tolerance avoids damage from collider margins at an exact block height.
	return ceili(maxf(0, blocks - settings.safe_fall_blocks - .05) * settings.fall_damage_per_block)

func observe_motion(was_grounded: bool, before: float, after: float, grounded: bool) -> void:
	if dead or world.player.spectator or world.player.climbing.active or world.fluids != null and not world.fluids.body_kind().is_empty():
		reset_fall()
		return
	if was_grounded and grounded:
		reset_fall()
		return
	if not tracking_fall:
		tracking_fall = true
		fall_peak_y = minf(before, after)
	else: fall_peak_y = minf(fall_peak_y, minf(before, after))
	if grounded:
		var amount: int = fall_damage((after - fall_peak_y) / 16.0)
		reset_fall()
		if amount > 0: take_damage(amount, "You fell from a high place")

func take_damage(amount: float, reason: String = "You died", bypass_invulnerability: bool = false) -> bool:
	if dead or world.player.spectator or world.player.creative and reason!="You were killed by a command" or amount <= 0:return false
	if effects.remaining.has("fire_resistance") and ("burn" in reason.to_lower() or "lava" in reason.to_lower() or "fire" in reason.to_lower()):return false
	var applied: float=amount
	var fresh: bool=invulnerability<=0 or bypass_invulnerability
	if not fresh:
		if amount<=_last_hit_damage:return false
		applied=amount-_last_hit_damage
	_last_hit_damage=amount
	# Preserve the pre-hit display across closely spaced hits for one second.
	if health_history_time <= 0: previous_health = health
	health_blink_time = settings.health_blink_seconds
	health_history_time = settings.health_history_seconds
	var damage: float=Equipment.after_armor(applied,world.inventory,reason)
	if effects.remaining.has("resistance") and reason.to_lower() not in ["starvation","void"]:damage*=maxf(0,1-.2*(1+int(effects.amplifiers.get("resistance",0))))
	var absorbed: float=minf(absorption,damage);absorption-=absorbed
	health = maxf(0, health - (damage-absorbed))
	damage_flash = settings.damage_flash_seconds
	if fresh:invulnerability = settings.damage_invulnerability
	since_damage = 0
	_regen = 0
	if world.food!=null and reason not in ["Poison","Starvation"]:world.food.add_exhaustion(float(world.food.rules.damage))
	health_changed.emit()
	if health == 0: _die(reason, true)
	return true

func heal(amount: int) -> void:
	if dead or amount <= 0: return
	health = mini(settings.maximum_health, health + amount)
	health_changed.emit()

func hearts_blinking() -> bool:
	# Vanilla HUD uses 20 ticks/sec and alternates every three ticks.
	var ticks: int = ceili(health_blink_time * 20.0 - .00001)
	return ticks > 0 and (ticks / settings.heart_blink_ticks) % 2 == 1

func _process(delta: float) -> void:
	health_blink_time = maxf(0, health_blink_time - delta)
	health_history_time = maxf(0, health_history_time - delta)
	if health_history_time <= 0: previous_health = health
	damage_flash = maxf(0, damage_flash - delta)
	invulnerability = maxf(0, invulnerability - delta)
	if dead or world.player.spectator: return
	effects.tick(self,delta)
	if not effects.remaining.has("absorption"):absorption=0
	since_damage += delta
	if world.food==null and settings.regeneration_enabled and health < settings.maximum_health and since_damage >= settings.regeneration_delay:
		_regen += delta
		if _regen >= settings.regeneration_interval:
			_regen = fmod(_regen, settings.regeneration_interval)
			heal(1)

func _die(reason: String, drop_items: bool) -> void:
	if world.pearls!=null:
		world.pearls.restore([])
		for dimension in world.dimensions.states:world.dimensions.states[dimension]["pearls"]=[]
	if world.end_progression!=null:
		world.end_progression.eyes.clear();world.end_progression.queue_redraw()
		for dimension in world.dimensions.states:world.dimensions.states[dimension]["eyes"]=[]
	effects.clear();absorption=0;world.shields.cancel()
	if world.food!=null:world.food.cancel()
	if world.ranged!=null:world.ranged.cancel()
	if drop_items and world.experience!=null:world.experience.on_death()
	dead = true
	death_reason = reason
	world.player.survival_dead = true
	world.player._redraw_skin()
	if world.chat != null: world.chat.set_open(false)
	var options: Node = get_node_or_null("/root/GameOptions")
	if options != null and options.is_open: options.set_open(false)
	world.mining_held = false
	world.reset_mining()
	# Closing menus returns owned cursor/crafting stacks before the inventory drain.
	if world.upgrade_screen!=null:world.upgrade_screen.set_open(false)
	world.inventory_screen.set_open(false)
	world.furnace_screen.set_open(false)
	if world.storage_screen!=null:world.storage_screen.set_open(false)
	world.inventory_screen.set_process_input(false)
	world.furnace_screen.set_process_input(false)
	world.player.velocity = Vector2.ZERO
	world.player.set_physics_process(false)
	world.player.set_interaction_enabled(false)
	world.hotbar.hide()
	world.target_overlay.queue_redraw()
	if drop_items and settings.drop_inventory_on_death:
		var items: BlockInventory = world.inventory
		for i in range(items.SLOT_COUNT):
			if items.counts[i] > 0:
				world.dropped_items.spawn_item(items.ids[i], items.counts[i], world.player.global_position, Vector2(randf_range(-50,50),-70), items.durability[i],items.tags[i])
			items.ids[i] = 0
			items.counts[i] = 0
			items.durability[i] = 0
			items.tags[i]={}
		items.changed.emit()
	screen.show_death(reason)

func _world_spawn_point() -> Variant:
	world.chunks.update_around(world_spawn)
	var intended: Vector2i = world.ground.local_to_map(world.ground.to_local(world_spawn) + Vector2(0,14.1))
	var exact: Variant = world.beds.safe_on(intended)
	if exact != null: return exact
	var origin: Vector2i = world.ground.local_to_map(world.ground.to_local(world_spawn))
	for distance in range(settings.respawn_search_radius + 1):
		for direction in [1,-1] if distance > 0 else [1]:
			var x: int = origin.x + distance * direction
			var surface: int = world.chunks.get_surface_y(x)
			for depth in range(17):
				for sign_value in [1,-1] if depth > 0 else [1]:
					var candidate: Variant = world.beds.safe_on(Vector2i(x, surface + depth * sign_value))
					if candidate != null: return candidate
	return null

func respawn() -> bool:
	if not dead: return false
	world.dimensions.return_for_respawn()
	var point: Variant = null
	var fallback: bool = false
	if has_bed:
		world.chunks.update_around(world.ground.to_global(world.ground.map_to_local(bed_anchor)))
		point = world.beds.spawn_at(bed_anchor)
		if point == null:
			fallback = true
			has_bed = false
	if point == null: point = _world_spawn_point()
	if point == null:
		screen.set_reason("No clear respawn space found")
		return false
	dead = false
	if world.food!=null:world.food.reset()
	health = settings.maximum_health
	previous_health = health
	damage_flash = 0
	health_blink_time = 0
	health_history_time = 0
	invulnerability = settings.respawn_invulnerability
	_last_hit_damage=INF
	since_damage = 0
	_regen = 0
	world.player.survival_dead = false
	world.player._redraw_skin()
	world.player.teleport_to(point)
	world.player.spawn_position = point
	world.player.set_interaction_enabled(true)
	world.player.set_physics_process(true)
	world.inventory_screen.set_process_input(true)
	world.furnace_screen.set_process_input(true)
	world.hotbar.visible = not world.player.spectator
	world.chunks.update_around(point)
	world.lighting.invalidate()
	reset_fall()
	screen.hide_death()
	if fallback: world.show_mode_notice("Your bed was missing or obstructed")
	health_changed.emit()
	return true

func snapshot() -> Dictionary:
	return {"health": health,"absorption":absorption, "dead": dead, "reason": death_reason, "world_spawn": [world_spawn.x,world_spawn.y], "has_bed": has_bed, "bed": [bed_anchor.x,bed_anchor.y], "tracking_fall": tracking_fall, "fall_peak_y": fall_peak_y,"effects":effects.remaining.duplicate(true),"effect_amplifiers":effects.amplifiers.duplicate(true)}

func grant_upgrade_supplies() -> void:
	for entry in DataFile.array_from(world.settings.starting_inventory_path):
		if str(entry.get("item", "")) not in settings.migration_starter_keys: continue
		var id: int = BlockDatabase.id_for(str(entry["item"]))
		var remainder: int = world.inventory.add_item(id, int(entry["count"]))
		if remainder > 0: world.dropped_items.spawn_item(id, remainder, world.player.global_position)

func restore_state(state: Dictionary) -> void:
	absorption=clampf(float(state.get("absorption",0)),0,16)
	effects.clear();effects.remaining=state.get("effects",{}).duplicate(true);effects.amplifiers=state.get("effect_amplifiers",{"regeneration":1} if effects.remaining.has("regeneration") else {}).duplicate(true)
	world.shields.cancel()
	_last_hit_damage=INF
	damage_flash = 0
	health_blink_time = 0
	health_history_time = 0
	invulnerability = 0
	since_damage = 0
	_regen = 0
	world_spawn = Vector2(float(state["world_spawn"][0]),float(state["world_spawn"][1])) if state.has("world_spawn") else world.player.spawn_position
	health = clampf(float(state.get("health", settings.maximum_health)),0,settings.maximum_health)
	previous_health = health
	has_bed = bool(state.get("has_bed",false))
	bed_anchor = Vector2i(int(state["bed"][0]),int(state["bed"][1])) if state.has("bed") else Vector2i.ZERO
	tracking_fall = bool(state.get("tracking_fall",false))
	fall_peak_y = float(state.get("fall_peak_y",world.player.global_position.y))
	dead = health == 0
	world.player.survival_dead = dead
	if dead: _die(str(state.get("reason","You died")), false)
	else:
		screen.hide_death()
		world.player.set_physics_process(not world.inventory_screen.is_open and not world.furnace_screen.is_open and not world.upgrade_is_open())
		world.player.set_interaction_enabled(not world.inventory_screen.is_open and not world.furnace_screen.is_open and not world.upgrade_is_open())
		world.inventory_screen.set_process_input(not world.furnace_screen.is_open and not world.upgrade_is_open())
		world.furnace_screen.set_process_input(true)
		world.hotbar.visible = not world.player.spectator and not world.inventory_screen.is_open and not world.furnace_screen.is_open and not world.upgrade_is_open()
	health_changed.emit()
