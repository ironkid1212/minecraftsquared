class_name EntityEffects
extends RefCounted
var remaining: Dictionary={}
var amplifiers: Dictionary={}
var poison_clock: float=0
var regen_clock: float=0
static func valid(data: Variant) -> bool:
	if not data is Dictionary or data.size()>9:return false
	for key in data:
		if key not in ["poison","slowness","hunger","regeneration","absorption","resistance","fire_resistance","speed","strength"] or not ContentCatalog._number(data[key],0,9600):return false
	return true
func apply(rule: Dictionary) -> void:
	var key: String=str(rule.get("name",""));var seconds: float=float(rule.get("seconds",0))
	if key in ["poison","slowness","hunger","regeneration","absorption","resistance","fire_resistance","speed","strength"] and seconds>0:
		var amplifier: int=clampi(int(rule.get("amplifier",0)),0,4)
		if remaining.has(key) and int(amplifiers.get(key,0))>amplifier:return
		if amplifier>int(amplifiers.get(key,0)):remaining[key]=0
		remaining[key]=maxf(float(remaining.get(key,0)),minf(seconds,9600));amplifiers[key]=amplifier
func speed_factor() -> float:
	var slow: float=maxf(0,1-.15*(1+int(amplifiers.get("slowness",0)))) if remaining.has("slowness") else 1.0
	var fast: float=1+.2*(1+int(amplifiers.get("speed",0))) if remaining.has("speed") else 1.0
	return slow*fast
func clear() -> void:remaining.clear();amplifiers.clear();poison_clock=0;regen_clock=0
func tick(actor: Object,delta: float) -> void:
	var regen_seconds: float=minf(delta,float(remaining.get("regeneration",0)))
	if regen_seconds>0:
		regen_clock+=regen_seconds
		var interval: float=2.5/pow(2,int(amplifiers.get("regeneration",0)))
		while regen_clock>=interval:
			regen_clock-=interval
			if actor is PlayerSurvival:actor.heal(1)
			else:actor.health=minf(float(actor.definition.health),float(actor.health)+1)
	else:regen_clock=0
	var poison_seconds: float=minf(delta,float(remaining.get("poison",0)))
	var poison_interval: float=1.25/pow(2,int(amplifiers.get("poison",0)))
	for key in remaining.keys():
		remaining[key]=maxf(0,float(remaining[key])-delta)
		if remaining[key]<=0:remaining.erase(key);amplifiers.erase(key)
	if poison_seconds>0:
		poison_clock+=poison_seconds
		while poison_clock>=poison_interval:
			poison_clock-=poison_interval
			var damage: float=minf(1,maxf(0,float(actor.health)-1))
			if damage<=0:continue
			if actor is PlayerSurvival:actor.take_damage(damage,"Poison",true)
			else:actor.hurt(damage,actor.center(),"poison")
	else:poison_clock=0

static func valid_amplifiers(data: Variant) -> bool:
	if not data is Dictionary or data.size()>9:return false
	for key in data:
		if key not in ["poison","slowness","hunger","regeneration","absorption","resistance","fire_resistance","speed","strength"] or not ContentCatalog._number(data[key],0,4,true):return false
	return true
