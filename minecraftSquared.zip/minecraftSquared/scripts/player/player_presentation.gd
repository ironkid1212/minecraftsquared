class_name PlayerPresentation
extends RefCounted

## Visual state only. This never changes reach, mining progress, item counts,
## collision or placement success; the world reports those actions separately.
var settings: PlayerSettings = PlayerSettings.new()
var inventory: BlockInventory
var offhand: PlayerPresentation
var is_offhand: bool=false
var facing: int = 1
var pose: String = "standing"
var swim_angle: float = PI*.5
var head_pitch: float = 0.0
var blocking: bool=false
var bow_charge: float=-1
var eating_time: float=-1
var held_id: int = BlockDatabase.ID.AIR
var held_tags: Dictionary={}
var block_source: TileSetAtlasSource
var held_size: float = 8.0
var held_grip := Vector2(0.5, 0.5)
var held_offset := Vector2.ZERO
var held_rotation: float = 0.0
var held_flip_x: bool = false
var held_flip_y: bool = false
var _profile_hand: int=-1
var _profile_offhand: bool=false
var action_kind: String = ""
var action_elapsed: float = 0.0
var action_duration: float = 0.3
var mining_active: bool = false
var action_target := Vector2(30, -8)


func configure(config: PlayerSettings) -> void:
	settings = config
	_profile_hand=-1
	cancel_actions()


func look_at(local_target: Vector2, delta: float) -> void:
	# Pitch is relative to the facing direction. The head rotates at the neck,
	# but aiming is measured from its center so level eye-height stays level.
	var offset: Vector2 = local_target - (Vector2(0,9) if pose=="swimming" else Vector2(5*facing,-10) if pose=="crouching" else Vector2(0,-14))
	if absf(offset.x) > settings.mouse_turn_dead_zone:
		facing = 1 if offset.x > 0 else -1
	var limit: float = deg_to_rad(settings.maximum_head_pitch)
	var target_pitch: float = clampf(atan2(offset.y, absf(offset.x)), -limit, limit)
	head_pitch = lerpf(head_pitch, target_pitch, 1.0 - exp(-settings.head_follow_speed * delta))


func set_held_item(id: int, source: TileSetAtlasSource) -> void:
	block_source = source
	if id == held_id and _profile_hand==settings.main_hand and _profile_offhand==is_offhand:
		return
	_profile_hand=settings.main_hand;_profile_offhand=is_offhand
	held_id = id if BlockDatabase.BLOCKS.has(id) else BlockDatabase.ID.AIR
	if held_id == BlockDatabase.ID.AIR:
		return
	var definition: Dictionary = BlockDatabase.BLOCKS[held_id]
	var display: Dictionary = HeldItemProfiles.resolve(definition, settings, is_offhand)
	held_size = display["size"]
	held_grip = Vector2(0.5, 0.5)
	held_offset = display["offset"]
	held_rotation = display["rotation"]
	held_flip_x = display.get("flip_x",false)
	held_flip_y = display.get("flip_y",false)
	# Per-content overrides are optional, so existing block/recipe JSON does
	# not need replacing. Future tools can choose their own grip and rotation.
	var profile: Variant = definition.get("held", {})
	if profile is Dictionary:
		held_flip_x = bool(profile.get("flip_x",held_flip_x))
		held_flip_y = bool(profile.get("flip_y",held_flip_y))
		held_size = clampf(_number(profile.get("size"), held_size), 1.0, 32.0)
		held_grip = _vector(profile.get("grip"), held_grip).clamp(Vector2.ZERO, Vector2.ONE)
		held_offset = _vector(profile.get("offset"), held_offset)
		held_rotation = deg_to_rad(_number(profile.get("rotation_degrees"), rad_to_deg(held_rotation)))


func begin_mining(local_target: Vector2) -> void:
	mining_active = true
	action_target = local_target
	if action_kind != "mine":
		_start("mine")


func stop_mining() -> void:
	# Finish the current swing after mouse release, as with an ordinary punch.
	mining_active = false


func swing_once(kind: String, local_target: Vector2) -> void:
	mining_active = false
	action_target = local_target
	# Rapid successful clicks still perform gameplay actions. Do not pin the
	# visual arm at frame zero by restarting the same early swing repeatedly.
	if action_kind == kind and action_elapsed < action_duration * 0.35:
		return
	_start(kind)


func _start(kind: String) -> void:
	action_kind = kind
	action_elapsed = 0.0
	action_duration = maxf(0.05, settings.placing_swing_duration if kind == "place" else settings.mining_swing_duration)


func advance(delta: float) -> void:
	if action_kind.is_empty():
		return
	action_elapsed += delta
	if action_elapsed >= action_duration:
		if mining_active:
			action_kind = "mine"
			action_elapsed = fmod(action_elapsed, action_duration)
		else:
			action_kind = ""
			action_elapsed = 0.0


func cancel_actions() -> void:
	mining_active = false
	action_kind = ""
	action_elapsed = 0.0


func main_arm_angle(walk_angle: float) -> float:
	if eating_time>=0:return -deg_to_rad(settings.eating_arm_angle)+sin(eating_time*25)*settings.eating_bob
	if bow_charge>=0:return head_pitch-PI*.5
	if blocking:return deg_to_rad(-60)+head_pitch
	var rest: float = walk_angle
	if held_id != BlockDatabase.ID.AIR:
		# Both arms hold forward from the same shoulder; draw order supplies depth.
		rest = walk_angle * 0.5 - deg_to_rad(settings.offhand_arm_angle if is_offhand else settings.holding_arm_angle)
	if action_kind.is_empty():
		return rest
	var direction := Vector2(absf(action_target.x), action_target.y + 8.0)
	var aim: float = atan2(direction.y, direction.x) - PI / 2.0
	var windup_degrees: float = settings.placing_windup if action_kind == "place" else settings.mining_windup
	var windup: float = clampf(aim - deg_to_rad(windup_degrees), deg_to_rad(-175), 0)
	var strike: float = clampf(aim + deg_to_rad(settings.action_follow_through), -PI, 0.5)
	var progress: float = clampf(action_elapsed / action_duration, 0, 1)
	if progress < 0.22:
		return lerpf(rest, windup, smoothstep(0, 0.22, progress))
	if progress < 0.52:
		return lerpf(windup, strike, smoothstep(0.22, 0.52, progress))
	return lerpf(strike, rest, smoothstep(0.52, 1.0, progress))


static func _number(value: Variant, fallback: float) -> float:
	return float(value) if value is float or value is int else fallback


static func _vector(value: Variant, fallback: Vector2) -> Vector2:
	if value is Array and value.size() == 2 and (value[0] is float or value[0] is int) and (value[1] is float or value[1] is int):
		return Vector2(value[0], value[1])
	return fallback
