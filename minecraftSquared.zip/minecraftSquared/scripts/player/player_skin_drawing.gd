class_name PlayerSkinDrawing
extends RefCounted

## Fixed v1 atlas layout: right-facing parts at x=0, left-facing at x=24.
## HD skins must be 48N x 32N; their body proportions stay 8/4/12 world pixels.
const SIZE := Vector2i(48, 32)
const PARTS: Dictionary = MinecraftSkinConverter.DESTINATIONS


static func valid_texture(texture: Texture2D) -> bool:
	if texture == null:
		return false
	var dimensions := Vector2i(texture.get_width(), texture.get_height())
	return dimensions.x >= SIZE.x and dimensions.x % SIZE.x == 0 and dimensions.y * SIZE.x == dimensions.x * SIZE.y


static func region(part: String, facing: int, texture: Texture2D) -> Rect2:
	var rect: Rect2i = PARTS[part]
	if facing < 0:
		rect.position.x += 24
	var factor: int = texture.get_width() / SIZE.x
	return Rect2(Vector2(rect.position * factor), Vector2(rect.size * factor))


static func draw_model(canvas: CanvasItem, settings: PlayerSettings, origin := Vector2.ZERO,
		render_scale: float = 1.0, facing: int = 1, phase: float = 0.0, walk_amount: float = 0.0,
		base := Transform2D.IDENTITY, presentation: PlayerPresentation = null) -> void:
	var texture: Texture2D = settings.skin_texture
	if not valid_texture(texture):
		return
	var transform: Transform2D = base * Transform2D(0.0, Vector2.ONE * render_scale, 0.0, origin)
	var crouch: bool = presentation!=null and presentation.pose=="crouching"
	var swimming: bool = presentation!=null and presentation.pose=="swimming"
	if swimming: transform *= Transform2D(presentation.swim_angle,Vector2(0,9))
	var shoulder := Vector2(4*facing,-4) if crouch else Vector2(0,-8)
	var neck := Vector2(5*facing,-6) if crouch else Vector2(0,-10)
	var swing: float = sin(phase) * settings.walk_swing * walk_amount
	var near_leg: float = clampf(swing * settings.leg_swing_multiplier,-settings.maximum_leg_swing,settings.maximum_leg_swing)
	var far_leg: float = -near_leg
	var near_arm: float = -swing
	var far_arm: float = swing
	if swimming:
		near_arm=-PI+sin(phase)*.65
		far_arm=-PI-sin(phase)*.65
		near_leg*=.3
		far_leg*=.3
	var offhand: PlayerPresentation=presentation.offhand if presentation!=null else null
	var bow_visual: PlayerPresentation=presentation if presentation!=null and presentation.bow_charge>=0 else offhand if offhand!=null and offhand.bow_charge>=0 else null
	if offhand!=null and not swimming:
		if (facing>0)==(settings.main_hand==0):far_arm=offhand.main_arm_angle(far_arm)
		else:near_arm=offhand.main_arm_angle(near_arm)
	var main_hand_near: bool = (facing > 0) == (settings.main_hand == 0)
	if bow_visual!=null:
		var hold: float=bow_visual.head_pitch-PI*.5
		var pull: float=bow_visual.head_pitch-.3
		var bow_near: bool=main_hand_near!=bow_visual.is_offhand
		near_arm=hold if bow_near else pull
		far_arm=pull if bow_near else hold
	if bow_visual==null and presentation != null and (not swimming or not presentation.action_kind.is_empty()):
		if main_hand_near:
			near_arm = presentation.main_arm_angle(near_arm)
		else:
			far_arm = presentation.main_arm_angle(far_arm)
	var shade := Color(settings.far_limb_brightness, settings.far_limb_brightness, settings.far_limb_brightness, 1)
	# Draw back-to-front. All drawing belongs to the player CanvasItem, so its
	# existing self_modulate lighting also shades the entire skin, including hats.
	if bow_visual!=null:
		_bow_arm(canvas,texture,"far_arm","far_sleeve",facing,transform,shoulder,_bow_wrist(bow_visual,main_hand_near==bow_visual.is_offhand),shade,settings,presentation.inventory)
	else:
		_limb(canvas, texture, "far_arm", "far_sleeve", facing, transform,
			shoulder, far_arm * facing, shade, settings.outer_layers, settings.clothing_layer_expansion)
	if presentation!=null and bow_visual==null:Equipment.draw_part(canvas,presentation.inventory,"far_arm",facing,transform*Transform2D(far_arm*facing,shoulder),Rect2(-2,-2,4,12),shade)
	if presentation != null and not main_hand_near and (bow_visual==null or bow_visual==presentation):
		_held_item(canvas, presentation, transform, facing, far_arm, shoulder)
	_limb(canvas, texture, "far_leg", "far_trousers", facing, transform,
		Vector2(0, 2), far_leg * facing, shade, settings.outer_layers, settings.clothing_layer_expansion)
	if presentation!=null:Equipment.draw_part(canvas,presentation.inventory,"far_leg",facing,transform*Transform2D(far_leg*facing,Vector2(0,2)),Rect2(-2,0,4,12),shade)
	if offhand!=null and main_hand_near and (bow_visual==null or bow_visual==offhand):_held_item(canvas,offhand,transform,facing,far_arm,shoulder)
	var torso: Transform2D = transform*Transform2D(.45*facing,Vector2(0,2)) if crouch else transform
	var torso_bounds := Rect2(-2,-12,4,12) if crouch else Rect2(-2,-10,4,12)
	_part(canvas, texture, "body", facing, torso, torso_bounds)
	if settings.outer_layers:
		_part(canvas, texture, "jacket", facing, torso, torso_bounds.grow(maxf(0.0, settings.clothing_layer_expansion)))
	if presentation!=null:Equipment.draw_part(canvas,presentation.inventory,"body",facing,torso,torso_bounds)
	_limb(canvas, texture, "near_leg", "near_trousers", facing, transform,
		Vector2(0, 2), near_leg * facing, Color.WHITE, settings.outer_layers, settings.clothing_layer_expansion)
	if presentation!=null:Equipment.draw_part(canvas,presentation.inventory,"near_leg",facing,transform*Transform2D(near_leg*facing,Vector2(0,2)),Rect2(-2,0,4,12),Color.WHITE)
	var head_pitch: float = presentation.head_pitch if presentation != null and not swimming else 0.0
	var head_transform: Transform2D = transform * Transform2D(head_pitch * facing, neck)
	_part(canvas, texture, "head", facing, head_transform, Rect2(-4, -8, 8, 8))
	if settings.outer_layers:
		_part(canvas, texture, "hat", facing, head_transform, Rect2(-4, -8, 8, 8).grow(maxf(0.0, settings.hat_layer_expansion)))
	if presentation!=null:Equipment.draw_part(canvas,presentation.inventory,"head",facing,head_transform,Rect2(-4,-8,8,8))
	if bow_visual!=null:
		_bow_arm(canvas,texture,"near_arm","near_sleeve",facing,transform,shoulder,_bow_wrist(bow_visual,main_hand_near!=bow_visual.is_offhand),Color.WHITE,settings,presentation.inventory)
	else:
		_limb(canvas, texture, "near_arm", "near_sleeve", facing, transform,
			shoulder, near_arm * facing, Color.WHITE, settings.outer_layers, settings.clothing_layer_expansion)
	if presentation!=null and bow_visual==null:Equipment.draw_part(canvas,presentation.inventory,"near_arm",facing,transform*Transform2D(near_arm*facing,shoulder),Rect2(-2,-2,4,12),Color.WHITE)
	if presentation != null and main_hand_near and (bow_visual==null or bow_visual==presentation):
		_held_item(canvas, presentation, transform, facing, near_arm, shoulder)
	if offhand!=null and not main_hand_near and (bow_visual==null or bow_visual==offhand):_held_item(canvas,offhand,transform,facing,near_arm,shoulder)
	canvas.draw_set_transform_matrix(base)


static func _limb(canvas: CanvasItem, texture: Texture2D, part: String, outer: String,
		facing: int, transform: Transform2D, pivot: Vector2, angle: float, tint: Color, overlays: bool, expansion: float) -> void:
	var limb_transform: Transform2D = transform * Transform2D(angle, pivot)
	var bounds := Rect2(-2, 0, 4, 12)
	if "arm" in part:
		bounds.position.y = -2
	_part(canvas, texture, part, facing, limb_transform, bounds, tint)
	if overlays:
		# Inflate in limb-local space so the shell keeps the same joint and rotation.
		_part(canvas, texture, outer, facing, limb_transform, bounds.grow(maxf(0.0, expansion)), tint)


static func _part(canvas: CanvasItem, texture: Texture2D, part: String, facing: int,
		transform: Transform2D, bounds: Rect2, tint: Color = Color.WHITE) -> void:
	canvas.draw_set_transform_matrix(transform)
	canvas.draw_texture_rect_region(texture, bounds, region(part, facing, texture), tint)


static func hand_transform(transform: Transform2D, facing: int, arm_angle: float, shoulder := Vector2(0,-8)) -> Transform2D:
	return transform * Transform2D(arm_angle * facing, shoulder) * Transform2D(0.0, Vector2(2 * facing, 10))


static func _held_item(canvas: CanvasItem, presentation: PlayerPresentation,
		transform: Transform2D, facing: int, arm_angle: float, shoulder := Vector2(0,-8)) -> void:
	if presentation.held_id == BlockDatabase.ID.AIR or presentation.block_source == null:
		return
	var hand: Transform2D = hand_transform(transform, facing, arm_angle, shoulder)
	if BlockDatabase.BLOCKS[presentation.held_id].has("ranged"):
		var bow: Transform2D=bow_transform(presentation,transform,facing,arm_angle,shoulder)
		canvas.draw_set_transform_matrix(bow)
		var stage: int=2 if presentation.bow_charge>=.9 else 1 if presentation.bow_charge>=.65 else 0
		var texture: Texture2D=MobDrawing.BOW if presentation.bow_charge<0 else MobDrawing.PULLING[stage]
		canvas.draw_texture_rect(texture,Rect2(-SkeletonBowPose.SPRITE_GRIP*.75,Vector2(12,12)),false)
		if EnchantmentGlint.active(presentation.held_id,presentation.held_tags):EnchantmentGlint.draw(canvas,texture,Rect2i(Vector2i.ZERO,texture.get_size()),Rect2(-SkeletonBowPose.SPRITE_GRIP*.75,Vector2(12,12)))
		return
	if BlockDatabase.BLOCKS[presentation.held_id].has("shield"):
		var shield_transform: Transform2D=hand*Transform2D((presentation.head_pitch-arm_angle)*facing,Vector2(facing,0))
		canvas.draw_set_transform_matrix(shield_transform)
		canvas.draw_texture_rect(preload("res://assets/mobs/shield_front.png"),Rect2(-3 if presentation.blocking else -1.5,-7,6 if presentation.blocking else 3,14),false)
		if EnchantmentGlint.active(presentation.held_id,presentation.held_tags):
			var texture: Texture2D=preload("res://assets/mobs/shield_front.png")
			EnchantmentGlint.draw(canvas,texture,Rect2i(Vector2i.ZERO,texture.get_size()),Rect2(-3 if presentation.blocking else -1.5,-7,6 if presentation.blocking else 3,14))
		return
	var item_transform: Transform2D = hand * Transform2D(presentation.held_rotation * facing,
		Vector2(facing, 1), 0.0, presentation.held_offset * Vector2(facing, 1))
	item_transform *= Transform2D(0, Vector2(-1 if presentation.held_flip_x else 1, -1 if presentation.held_flip_y else 1), 0, Vector2.ZERO)
	canvas.draw_set_transform_matrix(item_transform)
	var size := Vector2.ONE * presentation.held_size
	# Draw the complete item once, with its own arm; never splice palm pixels over it.
	ItemDrawing.draw_icon(canvas, presentation.block_source, presentation.held_id,
		Rect2(-presentation.held_grip * size, size),Color.WHITE,presentation.held_tags)


static func _bow_wrist(visual: PlayerPresentation,holding: bool) -> Vector2:
	var grip:=Vector2(12,0).rotated(visual.head_pitch)
	if holding:return grip
	var stage: int=2 if visual.bow_charge>=.9 else 1 if visual.bow_charge>=.65 else 0
	var nock: Vector2=[Vector2(10,10),Vector2(11,11),Vector2(12,12)][stage]
	return Transform2D(visual.head_pitch+PI*.75,grip)*((nock-SkeletonBowPose.SPRITE_GRIP)*.75)

static func _bow_arm(canvas: CanvasItem,texture: Texture2D,part: String,outer: String,facing: int,transform: Transform2D,shoulder: Vector2,wrist: Vector2,tint: Color,settings: PlayerSettings,items: BlockInventory) -> void:
	var joint: Transform2D=transform*Transform2D(0,Vector2(facing,1),0,shoulder)*Transform2D(wrist.angle()-PI*.5,Vector2.ZERO)
	var bounds:=Rect2(-2,0,4,wrist.length())
	canvas.draw_set_transform_matrix(joint)
	canvas.draw_texture_rect_region(texture,bounds,region(part,facing,texture),tint)
	if settings.outer_layers:canvas.draw_texture_rect_region(texture,bounds.grow(settings.clothing_layer_expansion),region(outer,facing,texture),tint)
	Equipment.draw_part(canvas,items,part,facing,joint,bounds,tint)

static func bow_transform(visual: PlayerPresentation,transform: Transform2D,facing: int,arm_angle: float,shoulder:=Vector2(0,-8)) -> Transform2D:
	if visual.bow_charge>=0:
		var grip: Vector2=Vector2(12,0).rotated(visual.head_pitch)
		return transform*Transform2D(0,Vector2(facing,1),0,shoulder)*Transform2D(visual.head_pitch+PI*.75,grip)
	# Resting bows follow the actual swinging wrist, with their firing axis down.
	return hand_transform(transform,facing,arm_angle,shoulder)*Transform2D(0,Vector2(facing,1),0,Vector2.ZERO)*Transform2D(PI*1.25,Vector2.ZERO)
