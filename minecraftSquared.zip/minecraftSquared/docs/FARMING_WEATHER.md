# Farming, weather, movement and biome colors

## Playing

Use a hoe on grass/dirt, then right-click the farmland with wheat seeds,
carrots, potatoes or beetroot seeds. Break mature crops to harvest them.
Grass already supplies wheat seeds. Carrots, potatoes and beetroot seeds can
currently be obtained with `/give`; villages and mob drops are not implemented.
Three wheat in a crafting-table row make bread. Eating/hunger is not included
in this update; harvested food and bread are inventory/crafting items for now.

Water within four horizontal blocks hydrates farmland (at soil height or one
block above). Exposed rain also hydrates it. Moisture reaches seven, decreases
when dry, and empty dry farmland returns to dirt. A solid covering also turns
farmland back to dirt. Crops grow by random ticks when adequately lit; wet soil
and neighboring farmland improve growth. Support removal and flowing water
break crops and return their appropriate drops. Mature wheat/beetroot return
at least one seed in this 2D adaptation to keep small farms sustainable.

Farmland is 15 pixels high. Crop models draw one pixel lower, meeting its top
without rescaling the sprite. Crops have no collision. Trampling, fertilizer,
hunger and villager farming are not implemented yet.

Weather naturally alternates between clear periods and rain, with occasional
thunderstorms. `/weather rain`, `/weather thunder`, `/weather clear` change it
immediately; optional duration is in seconds, for example `/weather rain 120`.
`/gamerule doWeatherCycle false` freezes weather transitions. Rain fades in/out,
darkens the sky and daylight, hides stars, stops at roofs/canopies, and does not
fall in desert biomes. Exposed rain extinguishes the player. Thunderstorms have
sky flashes; damaging lightning, sounds, snow accumulation and weather-based
mob spawning are not implemented. Rain uses the supplied original rain texture.

Filled buckets cannot replace opposing fluids, and cannot replace an existing
source of the same fluid. Place beside/above the other fluid instead. Water
touching the top or side of source lava immediately makes obsidian; flowing
lava makes cobblestone. Lava falling into water makes stone. Flowing/source
metadata is committed before reaction checks, avoiding false obsidian.

## Tuning outside the game

- `data/settings/farming.tres`: enable farming, growth multiplier, rules path.
- `data/farming.json`: seed-to-stage mapping, hydration radius, minimum growth
  light and per-crop growth chance. Crop blocks, icons, drops and item IDs remain
  exclusively in `data/content.json`.
- `data/settings/world_updates.tres`: random tick frequency and simulation budget.
- `data/settings/weather.tres`: clear/rain duration ranges, storm chance,
  transition fade, daylight reduction, flash interval and rain texture.
- `data/settings/player.tres`: walking speed, jump impulse, gravity. Script
  defaults expose ground/air/vertical drag, sprint-jump impulse and sprint stride.
- `data/biomes.json`: `colors.blend_radius` (default three blocks), original grass
  and foliage colormaps, fixed birch color, and each biome's `color_climate`
  temperature, downfall, precipitation and water color.
- `data/content.json`: `biome_tint` (`grass`, `foliage`, `birch`), optional
  `biome_overlay`, eight `moisture_tiles`, `render_offset`, `collision_height`.
- `data/fancy_oak_shapes.json`: reference plus small crown/branch variants.
  `X` means a log guaranteed to have cosmetic leaves, `W` bare trunk, `L` leaves,
  `.` empty. All variants preserve a one-block-wide lower trunk.

Locomotion uses 16 pixels per block: walk 4.317, sprint 5.612, sneak 1.295
blocks/second. Ground/air acceleration and friction, 20Hz vertical gravity/drag,
and sprint-jump momentum replace instantaneous horizontal velocity. Measured
jump apex is about 1.25 blocks. Sprint animation uses a longer stride rather
than rapidly cycling the legs. Swimming, crouching, ledge protection, hold-to-jump
and adjustable spectator flight remain supported. This is a 2D adaptation,
not a complete port of Minecraft's collision or swimming physics.

Grass/foliage colors sample the original 256x256 colormaps using clamped
temperature and temperature-times-downfall. Neighboring sampled colors are
averaged horizontally at biome boundaries. Birch keeps its fixed tint. Grass
side vegetation is a separate tinted overlay, preserving brown dirt. Water,
leaves inside canopies, and waterlogged leaves use the same tint system.
Inventory icons retain their original/default item appearance.

## Saves and performance

Existing worlds load without new fields. Crop stages use normal saved block
edits; moisture and weather have optional validated save records. Fancy oak
revision 3 chooses the new variants for new worlds. Existing revision 2 worlds
retain their original reference-shaped generation; legacy revision 1 is retained.
The project's existing custom sun and moon sizes are preserved.

Crop simulation uses the existing bounded loaded-region scheduler: no crop
nodes or full-world scans. Moisture updates cached visible meshes, not physics.
Rain draws visible columns only, caches roof heights, and invalidates edited
columns. Weather adjusts cached daylight colors without recomputing light
propagation. Biome colors are cached and culled as the view moves.

## Implementation references and verification

- [Minecraft crop model](https://raw.githubusercontent.com/InventivetalentDev/minecraft-assets/1.21.1/assets/minecraft/models/block/crop.json)
  — lowered model coordinates.
- [CropBlock](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/block/CropBlock.java)
  and [FarmBlock](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/block/FarmBlock.java)
  — light, growth speed, hydration, moisture and soil reversion.
- [LivingEntity](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/LivingEntity.java)
  and [Player](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/player/Player.java)
  — movement friction, jump, gravity and sprinting.
- [ServerLevel](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/server/level/ServerLevel.java)
  — weather timing, adapted to linked 2D rain/storm states.
- [Biome](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/biome/Biome.java)
  and [OverworldBiomes](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/data/worldgen/biome/OverworldBiomes.java)
  — colormap climate lookup, precipitation and biome climate values.

Verified with Godot 4.7.2: all four plant/grow/harvest cycles, seed consumption,
hydration/drying, roof and sky responses, commands/completion, save/load and old
save migration, source/flowing lava reactions, bucket conservation, colormap
lookup/boundary blending, farmland collision and crop alignment, fancy oak
diversity, actual movement speeds and jump height. Native rendering was checked
for crops, rain clipping, terrain tints and canopy overlays. Existing fluid,
survival, mining, world-update, day/night, chat and optimization checks pass.
