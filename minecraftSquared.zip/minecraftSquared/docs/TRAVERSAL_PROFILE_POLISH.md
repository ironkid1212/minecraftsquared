# Traversal, profile management and survival polish

For Godot 4.7.2. Extract the complete project into a new folder and import
project.godot. Existing worlds gain the controls and fixes below. New worlds
also have ladder access passages in mineshafts; older worlds retain the layout
of their saved generation revision.

## Skeleton and player poses

The two-segment elbow solver has been removed from humanoid bow arms. Skeletons,
strays and the player's bow pose now draw rigid, one-piece limbs. The rear arm
is foreshortened in the 2D projection to meet the string without bending an
elbow. This affects presentation, not attack reach or damage.

An idle skeleton or stray holds its bow with its firing axis straight down,
independent of facing direction, head pitch or walking phase. Drawing rotates
the complete bow onto the aim axis and follows the supplied pulling frames.
The previous slower firing recovery remains intact.

## Supplied double chest

The uploaded double_chest (1).png replaces the paired chest's world appearance.
It is mapped to two 16-pixel atlas cells using nearest-neighbor sampling. The
old atlas pixels and all item IDs are retained, and single-chest art is unchanged.

## Ladders and vines

Craft three ladders from seven sticks in the usual H-shaped recipe. Ladders and
vines are passable climbables rather than platforms.

- Hold **Space, W or Up** (the Jump binding) to climb.
- Hold **S or Down** to descend; Climb Down is configurable in Controls.
- Hold **Sneak** to grip and stop descending.
- Move sideways to leave the ladder or vine.

The default climb speed is about 2.35 blocks per second, with a downward slide
cap of three blocks per second. Touching a climbable resets fall tracking, so
catching vines or a ladder can prevent fall damage. Sprinting is disabled on
climbables. Swimming and water currents continue to work around them.

Ladders need a wall beside or behind them. Vines may also hang from another vine,
logs, leaves or a solid anchor. Unsupported sections use the existing budgeted
block-update system. Shears recover vines. The 2D adaptation allows climbing
supported hanging vines, including those on trees.

Connecting passages could previously carve through planned chest carts. New
structure generation now moves affected loot onto clear supported track cells.

Speeds live in data/traversal.json, and support modes live in the existing
data/content.json catalog. New mineshafts include vertical ladder access without
overwriting their loot containers or spawners. A saved structure revision keeps
old mineshaft layouts unchanged.

## Eating

Ordinary food remains edible only below full hunger, as requested. Hold the Use
Item binding (right-click by default) for 1.6 seconds. Keep holding to continue
eating if still hungry. This works in either hand and when selecting food while
already holding Use. Golden apples retain their always-edible behavior.

A short click now explains that the button must be held. Trying ordinary food
at full hunger shows "You're not hungry". These messages use the HUD's reserved
text area, above the hearts, food bar, XP bar and hotbar.

Container/workstation interactions and planting take priority over eating when
pointed at a valid target. The food tests now drive actual root-viewport mouse
input through PixelGame, rather than calling the food function alone.

## Death and skins

The player's separate skin CanvasItem is hidden immediately on death and remains
hidden even if another redraw runs behind the death screen. Respawning shows it
again. Camera and respawn behavior are preserved.

Profile → Skins now offers **Rename** and **Delete** for imported skins. Names
persist without changing file identities or creating duplicate PNGs. Deletion
has an in-game confirmation page and removes only the managed skin-library copy;
the original imported file is kept. Deleting the active skin selects Steve and
updates the saved profile. Default Steve cannot be renamed or deleted. Legacy
imported skins remain manageable, and paths outside the skin library are rejected.

## Related cleanup and verification

Climbing, cobweb contact and XP-orb chunk checks now account for the Ground
node's offset. Obsolete pre-hunger recovery timing fields remain compatible with
old resources but are hidden from the Inspector; natural regeneration remains
configurable.

Checks cover physical climbing, sneaking, sliding, long-fall catches, support
loss, rigid/downward bow poses, death/respawn visibility, real mouse-driven food
use, full hunger, short-click hints, offhand food, container priority, and actual
skin-management buttons with persistence and protected paths. Prior adventure,
shield, spawner/save, mob AI and culling/streaming regressions are also checked.
Native renders verify the chest, both bow directions, ladders/vines, death screen
and all new skin pages.

References: [ladder behavior](https://minecraft.wiki/w/Ladder),
[vines](https://minecraft.wiki/w/Vines), and
[Godot viewport input](https://docs.godotengine.org/en/stable/tutorials/rendering/viewports.html).
