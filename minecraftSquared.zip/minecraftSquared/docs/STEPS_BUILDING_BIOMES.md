# Movement, building shapes and more biomes

Leg swing now scales with horizontal speed instead of jumping to full strength
for tiny movements. Releasing movement input settles it in about 0.05 seconds;
the shorter default swing is capped at 0.6 radians. Friction, walking speed,
sprinting speed, jump height, mining actions and held-item poses remain intact.

The player automatically steps over supported rises up to 0.6 blocks (9.6 world
pixels). Farmland-to-full-block edges, bottom slabs and ordinary staircases no
longer require jumping. Queries check the actual collision shape and available
headroom first. Full-block walls still require a jump. Descending half steps
uses floor snapping; jumping and falling keep their existing behavior.

## Slabs and stairs

Six material families: oak, birch, spruce, cobblestone, stone and sandstone.

- Three matching blocks in a crafting-table row produce six slabs.
- Six matching blocks in a stair pattern produce four stairs. Mirroring works.
- Aim at the lower/upper half of the target cell to place bottom/top shapes.
- Stairs rise toward the direction the player faces; both directions have
  normal and upside-down variants.
- Place a matching slab in the empty half of an existing slab to make a double
  slab. Breaking that double returns two slabs. Filling a waterlogged slab
  removes its water, as in Minecraft.
- Single slabs and stairs can be waterlogged. Placement checks occupied shape
  rectangles rather than rejecting the entire cell when only an empty half
  overlaps the player.

Sprites use masked pieces of the original material texture at its original
pixel size. Collision polygons match the visible shapes. These are 2D straight
stairs; Minecraft's 3D inner/outer corners have no third-axis counterpart here.

Material-specific recipes use `exact: true` in `data/recipes.json`. Other recipes
still use the existing crafting groups, so mixed plank types continue to make
sticks, tools and workstations. Exact matching is checked before generic matching.

## Added biomes

- **Birch Forest:** birch-dominant woodland with its own grass climate tint.
- **Flower Forest:** more flower patches and a lower tree density.
- **Taiga:** varied spruce trees, fixed spruce foliage tint, ferns and cooler
  grass colors. Spruce logs and planks are usable building/crafting materials.

Spruce logs also smelt into charcoal. Spruce logs/planks and the wooden building
shapes have furnace fuel values; stone shapes cannot be used as fuel.

The existing regional climate sampler chooses these alongside plains, forest,
desert and stony peaks. Terrain height remains independent of biome selection;
the shared boundary/soil transitions and color blending are retained.

Create a **new world** for the expanded biome selection. Saves predating this
update automatically use biome revision 1 and retain their original four-biome
generation, including newly streamed terrain. New worlds save revision 2.
Placed slab/stair orientations use normal saved block IDs, so no separate
orientation database or new per-frame block nodes are needed.

## Customizing

- `data/settings/player.tres`: `step_height`, `walk_swing`,
  `leg_swing_multiplier`, `maximum_leg_swing`, `walk_settle_speed` and stride.
- `data/content.json`: canonical material/shape records. `collision_boxes` are
  `[x,y,width,height]` rectangles in a 16x16 block, measured from its upper-left.
  `building` holds kind, material, half, facing and canonical inventory item.
  `internal: true` hides placed orientation variants from command suggestions.
- `data/recipes.json`: building recipes and their optional exact-item matching.
- `data/biomes.json`: biome placement ranges, vegetation, climate colors,
  `minimum_revision` and `tree_style`. Spruce silhouettes use the existing
  deterministic tree generator and guaranteed canopy leaf overlays.
- `data/settings/terrain.tres`: `biome_revision` and the existing biome-size
  controls. Keep a saved world's revision unchanged to preserve its terrain.

## References and checks

Minecraft's [LivingEntity](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/LivingEntity.java)
sets the normal 0.6-block step height. [SlabBlock](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/block/SlabBlock.java)
and [StairBlock](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/block/StairBlock.java)
provide the half-height geometry, orientation, merging and waterlogging model.
[OverworldBiomes](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/data/worldgen/biome/OverworldBiomes.java)
provides birch/flower forest and taiga climate and vegetation references.
The shapes, generation and animation here are adaptations to the 2D game.

Godot 4.7.2 checks cover actual farmland/slab/stair traversal and descent,
full-wall/low-ceiling rejection, quick gait settling, all six shape families,
half/direction placement, slab merging/counts/drops, waterlogged merging,
partial-shape player overlap, orientation saves, mirrored material recipes,
mixed-plank recipes, new-biome occurrence across seeds, generation/load-order
stability, old-data equivalence, save migration, spruce/birch trees and ferns.
Native renders were inspected for each new biome and for the building shapes.
