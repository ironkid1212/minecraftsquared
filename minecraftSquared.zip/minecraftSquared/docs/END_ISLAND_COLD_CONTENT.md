# Main End island and cold-weather content

Import `project.godot` from a freshly extracted folder in Godot 4.7.2. The ZIP
excludes the generated cache. Existing Overworld/Nether saves remain supported.
Original item IDs, user settings resources, script UIDs and atlas pixels are retained.

## Wither skulls

The existing Wither Skeleton Skull item is now placeable. Its world head is
8 by 8 pixels inside a 16-pixel block cell, with a smaller inventory/held icon.
Floor heads sit at the bottom of their cell on a supporting full top face.
Wall heads attach flush to the supporting side. They have matching partial
collision boxes rather than full-cube collision. Internal mounting states do
not appear as extra Creative items. Mining any mount drops the canonical skull.

As specifically requested, skulls require support and break/drop when it is
removed. This is an intentional game rule for this adaptation, rather than
vanilla's ability to leave heads floating after removing a support.

## The End

Enter a lit End portal to reach a separate saved dimension. The arrival platform
is five blocks wide at X=100, Y=48; entering recreates its floor and clears three
blocks above, so do not build in that arrival space. Coordinates and teleporting
use End Y=0 through 255. The main island is tapered End stone surrounded by void.
The dragon, crystals and egg are now included; see [End fight](ENDER_DRAGON_FIGHT.md).
Outer islands and gateways are covered by the [subsequent expansion](OUTER_END_GATEWAYS.md).

Ten pillars use the vanilla height sequence, shuffled deterministically by seed.
Their shafts are background structures, embedded under the local island surface.
Two five-wide cages have thin foreground posts/roofs with background rear bars;
the bedrock caps are foreground blocks. The central bedrock fountain unlocks its
return portal after the dragon is defeated. It returns to a valid bed spawn or
the Overworld spawn, rather than the stronghold.
All three dimensions keep independent blocks, background walls, mobs, containers
and environmental state, with shared player inventory/progression.

The End uses the supplied native End sky texture, fixed ambient light, no sun,
moon, clouds, weather or daylight burning, and natural Endermen instead of
Overworld monsters/animals. Beds explode there. Nether portals do not transport
the player there. The main island contains no Overworld ores or caves.

## Blocks and recipes

- End stone, End stone bricks, and their brick slab/stair orientations. Four End
  stone craft four bricks; ordinary slab/stair recipes give six/four respectively.
- Snow blocks and stackable snow layers. Four snowballs craft a snow block.
  Shovels collect snowballs; Silk Touch collects the snow block/layer.
- Packed ice and blue ice. Nine ice craft packed ice; nine packed ice craft blue
  ice. They require Silk Touch to collect, do not melt into water, and preserve
  movement inertia for players and mobs. Blue ice has slightly greater slip.
- Carved pumpkins: use shears on a placed pumpkin to carve it and obtain four
  seeds. A carved pumpkin above a torch crafts a light-emitting jack o'lantern.
- Throwable snowballs, raw/cooked cod and salmon. Fish cook in ten seconds and
  have their corresponding hunger/saturation values and food tooltip behavior.

## Biomes and mobs

**Ice Spikes** and **Snowy Slopes** are selected by the existing climate/terrain
pipeline in new worlds using biome revision 8. Ice Spikes is a dry, very cold
plain with rooted, tapering packed-ice spires and occasional taller needles.
Snowy Slopes is a treeless, snow-covered mountain shoulder, with snow layers
of material over stone. This pass does not add powder-snow freezing or goats.
Old worlds retain their saved biome revision and terrain layout.

**Polar bears** spawn rarely in Snowy Plains, in groups of one or two with cubs.
They have 30 health, a 0.25 movement attribute and six normal-difficulty melee
damage. Adults retaliate and protect nearby cubs; cubs flee and grow over twenty
minutes. Bears cannot be bred or tempted with fish. Their cod/salmon loot uses
an exclusive 75/25 species choice, zero to two items, and cooked variants if
burning. Four separate animated legs, side/front head faces, muzzle, ears and a
raised attack pose use the native bear sheet.

**Snow golems** are made by placing a carved pumpkin/jack o'lantern last onto two
snow blocks. Vertical, horizontal and upside-down patterns work when there is
room for the resulting body. They have four health, wander, and throw a snowball
once per second at visible monsters within ten blocks. Snowballs provoke and
push ordinary mobs without health damage, damage Blazes by three, and can be
thrown by the player. Golems never target the player. Shears remove and drop one
pumpkin. Cool terrain receives thin snow trails when mob griefing is enabled;
rain, water and hot biomes damage the golem. The full snow body and stick arms
use the native sheet, with a side-view pumpkin until a front glance is drawn.

## Customization

- `data/content.json`: single authoritative block/item catalog, mounts, partial
  collision boxes, icon/held sizes, drops, food values and slipperiness.
- `data/end.json`: island radius/thickness/surface, arrival, ambient light,
  pillar positions/heights, cage dimensions and foundation depth. Pillar radius
  follows its height; the fight controls return-portal activation.
- `data/biomes.json`: biome climate ranges, snow cover and Ice Spikes spacing,
  heights, radii and tall-spike chance. Terrain Settings exposes biome revision.
- `data/mobs.json`: bear/golem health, movement, loot, juvenile scale/age and
  `cold` behavior settings for protection, projectile range/rate and melting.
- `data/recipes.json`, `data/smelting.json`, `data/enchantment_drops.json`:
  crafting, cooking and enchanted harvesting.

Spire plans are deterministic and cached, with distant entries evicted during
chunk streaming. The existing visible-chunk renderer and lighting caches remain
in use; no nodes are created for individual natural End blocks or ice spires.

## Research references

- [Heads](https://minecraft.wiki/w/Head): head dimensions and floor/wall placement.
- [The End](https://minecraft.wiki/w/The_End), [End spikes](https://minecraft.wiki/w/End_spike),
  [arrival platform](https://minecraft.wiki/w/Obsidian_platform): island features,
  ten towers, atmosphere and platform regeneration.
- [End stone bricks](https://minecraft.wiki/w/End_stone_bricks): building recipes.
- [Ice Spikes](https://www.minecraft.net/pt-br/article/around-block--ice-spikes),
  [Snowy Slopes](https://minecraft.wiki/w/Snowy_slopes): cold surface terrain.
- [Packed ice](https://minecraft.wiki/w/Packed_ice), [blue ice](https://minecraft.wiki/w/Blue_ice):
  harvesting, melting and sliding.
- [Polar bear](https://minecraft.wiki/w/Polar_Bear),
  [official bear article](https://www.minecraft.net/en-us/article/mob-menagerie--polar-bear):
  stats, cub protection, spawning and loot.
- [Snow golem](https://minecraft.wiki/w/Snow_golem), [snow block](https://minecraft.wiki/w/Snow_block):
  construction, shearing, targeting, snowball behavior and snow crafting.
- [Food values](https://minecraft.wiki/w/Food): fish nutrition/saturation.

Where 3D rules do not fit the side view, the explicit adaptations above take
precedence; this update does not claim a complete simulation of vanilla.
