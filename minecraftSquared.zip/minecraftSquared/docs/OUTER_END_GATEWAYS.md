# Outer End and gateways

Extract the update into a fresh folder and import `project.godot` in Godot 4.7.2.
Existing saves, inventory IDs, atlas pixels and user settings are preserved.

## Pillars

Obsidian pillars are now at most seven blocks wide. The obsidian row directly
under each bedrock cap is foreground solid terrain across the whole pillar's
width, so you can stand, build and fight there. The shaft remains background
terrain for side-view traversal. These generator fixes apply to existing End
worlds; explicit player block edits retain priority.

## Gateways

A dragon victory creates one gateway, up to twenty. Its native bedrock frame is
three blocks wide and five high with a one-block portal at its center. Throw an
Ender Pearl through the opening. Terrain in front of the opening still blocks
the throw. Gateway travel itself does not inflict the ordinary pearl-impact
damage. Small enough player collision shapes can also enter directly.

The first use finds a distant island, generates a linked outer gateway and
stores the pair. The return trip uses that same main-island gateway. Arrival
searches for unobstructed footing; an isolated gateway uses the top bedrock cap.
Cooldowns prevent immediate return loops. Natural remote gateways instead return
to the original obsidian arrival platform. Portal blocks, links and cooldown
state survive saving, reloading and dimension travel. Old saves with a prior
dragon victory receive a gateway when the End resumes.

The starfield uses the native End sky and portal textures with additive scrolling
layers. Native gateway beam textures mark new portals and periodic pulses.

## Outer terrain and chorus

Beyond |X|=1024, the End contains seeded large floating islands and smaller
fragments separated by void. There is a broad empty gap between them and the
central island. End Highlands occupy large island interiors, Midlands their
slopes, Barrens their fringes and Small End Islands the fragment/void regions.
Islands have tapered undersides and varying elevations rather than an infinite
flat bottom. Endermen retain the existing End spawning behavior.

Highlands grow branching chorus trees. Their stems connect visually to adjacent
branches, flowers and End stone. Native plant/flower textures supply the pixels.
In this side-view game the plants are one-way platforms for easy traversal.

Plant a Chorus Flower on End stone or an appropriate supported stem. Live flowers
grow and branch without a light requirement, and age into dead flowers. Flowers
can be harvested directly and replanted. Destroying support collapses detached
stems, which drop zero or one fruit; flowers lost through support collapse do
not drop themselves. Growth/support work runs inside the existing loaded-region
simulation budget. Internal connection/age states are excluded from Creative.

Chorus Fruit restores four hunger and 2.4 saturation, is edible at full hunger,
and attempts a safe nearby teleport. Its use has a one-second cooldown. Cooking
it yields Popped Chorus Fruit, and four popped fruit craft four Purpur Blocks.

Outer terrain, gateways and chorus progression are now joined by End cities,
ships, shulkers, portable storage and elytra. See
[End cities and flight](END_CITIES_SHULKERS_FLIGHT.md) for the latest update.

## Data and 2D adaptations

- `data/end.json`: pillar maximum width and the existing central-island settings.
- `data/end_outer.json`: island start distance, region spacing, radii, heights,
  thickness, fragment count, chorus spacing/chance, cache limits and gateway rules.
- `data/content.json`: authoritative block/item definitions, drops, food and
  chorus updates. There is no separate outer-End item database.
- `data/recipes.json`, `data/smelting.json`: chorus processing and Purpur crafting.

Minecraft's twenty gateways normally lie around a circle. Here they fan out on
the two horizontal sides at two heights, with unique positions. The remote search
retains the 1024-to-1280 distance band where possible; nearby links spread out to
avoid ambiguous shared return portals. A small fallback island is created when
the search finds no suitable unclaimed footing. Terrain and biome silhouettes
are a deterministic 2D adaptation, not a copy of Minecraft's 3D density field.

Island/column caches are bounded and deterministic. Offscreen portals are culled;
the renderer does not create nodes for natural End blocks. The main island's
dragon simulation remains separate from distant terrain generation.

## Research and verification

References include the Minecraft Wiki and the following decompiled 1.21.1 game
classes; textures and the Purpur recipe were checked against the installed 26.3
client. Version differences and side-view choices are kept explicit above.

- [End gateway](https://minecraft.wiki/w/End_Gateway)
- [The End](https://minecraft.wiki/w/The_End)
- [Chorus fruit](https://minecraft.wiki/w/Chorus_Fruit)
- [Gateway frame geometry](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/world/gen/feature/EndGatewayFeature.java)
- [Gateway linking, landing and cooldown](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/block/entity/EndGatewayBlockEntity.java)
- [End biome selection](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/world/biome/source/TheEndBiomeSource.java)
- [Chorus flower behavior](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/block/ChorusFlowerBlock.java)
- [Chorus fruit behavior](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/item/ChorusFruitItem.java)

Checks cover deterministic island layouts and all four biomes, the central void,
cache bounds, pillar widths and real standing collision, actual pearl travel and
obstruction, safe outward/return travel, saved links and dimension changes,
twenty unique gateway pairs, rogue returns, chorus growth/support collapse and
edible fruit. Native renderer captures cover both gateway ends, chorus trees
and solid pillar tops. Existing dragon/combat, portal, streaming, inventory,
food, farm/mob, lighting and movement regression checks pass.

The crystal texture's native provenance is recorded in `END_ASSET_PROVENANCE.txt`.
The renderer draws flat sprite layers; reference GIF frames are
not an asset or dependency of the project.
