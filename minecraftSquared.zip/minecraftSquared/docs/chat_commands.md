# Chat and commands

This is local chat for the existing single-player game. Messages use the active
profile username. There is no network/server or multiplayer transport in this
update. Messages and typed history last for the current world session; commands
that change inventory, health, mode, position, checkpoints or blocks use the
existing saved-world state.

## Controls

| Input | Action |
| --- | --- |
| T | Open chat |
| / | Open chat with a command prefix |
| Enter | Submit and close |
| Escape | Cancel and close, without opening Pause |
| Up / Down | Select suggestions while the popup is visible; otherwise browse typed history |
| Tab / Shift+Tab | Accept the selected completion, then cycle forward/backward |
| Page Up / Down, wheel | Scroll message history; wheel over suggestions scrolls that list |
| Click a suggestion | Accept the row and keep editing |
| Ctrl+A/C/V, Home/End, arrows | Standard text selection/editing in the input |

Options → Controls includes Open Chat and Open Command. Existing saved keybinds
remain intact; new actions receive their defaults. Opening chat cancels mining
and captures typing/mouse clicks. It blocks movement/jumping and item actions
while gravity and world simulation continue. Closing chat restores gameplay;
opening a menu or dying closes chat safely. Spectators can use chat and commands.

The input, history, completions, debug text and transient notices stay above the
reserved heart/hotbar area. History wraps to fit; long input scrolls inside the
input field. Normal stack counts remain part of the hotbar slots.

Suggestions use a compact black popup with a yellow selected row and a scrollbar
for longer lists. Grey text previews a matching completion. Partial unknown
command names are red; valid command input and ordinary messages are white.
Messages use individual translucent rows, without a large empty background box.
Up/Down returns to history navigation when the suggestion list is absent.

## Commands

Only the local player is supported. Optional `@s` means yourself. Item/block
arguments use stable catalog keys, optional `minecraft:` prefix, or numeric IDs.
Internal bed half IDs cannot be given or placed separately. Text is plain text,
not BBCode or executable script. Invalid commands show an error without applying
partial inventory changes.

| Command | Result |
| --- | --- |
| `/help [command]` | List commands or show usage and description |
| `/give [@s] <item> [count]` | Give items; default count 1; full-inventory overflow becomes real drops |
| `/clear [@s] [item]` | Remove inventory contents or just one item type; existing world drops stay |
| `/gamemode <survival\|spectator> [@s]` | Change supported mode; also accepts 0/3; Survival requires clear loaded space |
| `/tp [@s] <x> <y>` | Teleport by displayed world position, accepting decimals and `~` relative values |
| `/setblock <x> <y> <block\|air>` | Edit one loaded cell by whole block coordinates; solid placement cannot trap the player |
| `/spawnpoint` | Set a supported clear respawn point at your feet; replaces a bed checkpoint |
| `/seed` | Print the current seed |
| `/heal [health_points]` | Restore health; no amount restores fully; one point is half a heart |
| `/kill [@s]` | Use the normal death/drop system, including in Spectator |
| `/save` | Save the active title-menu world; report write errors |
| `/time <set\|add\|query> <value>` | Set day/noon/sunset/night/midnight/sunrise or ticks; add ticks or query time |
| `/gamerule doDaylightCycle [true\|false]` | Inspect, freeze or resume the saved world clock |
| `/say <message>` | Post a local system-style message with your profile name |

Aliases: `/gm`, `/teleport`, `/save-all`, `/?`.

Displayed positions and commands use the active dimension. The Nether's
generated blocks have Y labels 0–127, with the top feet boundary at 128.
`/tp 10 64` centers X at 10.5; `/tp 10.0 64` uses X=10.0 exactly. Relative
coordinates such as `/tp ~2 ~-3` preserve your current fractional position.
F3's position is measured at the feet; its block row is the floored position.
Survival teleports require a clear body-sized space; stairs/slabs are checked
using their real collision boxes. Spectator can teleport through terrain.

Examples:

```text
/give torch 32
/give @s minecraft:diamond_pickaxe
/gamemode spectator
/tp ~20 ~10
/gamemode survival
/help setblock
/save
```

World Y goes up, matching F3. `/tp` uses the continuous feet position; `/setblock`
uses the integer block labels shown by F3. Teleport resets fall tracking. A
Survival teleport into solid/unloaded space is rejected; Spectator can pass
through terrain. `/setblock` respects linked bed halves and falling-block
occupancy, and routes changes through normal update/save systems. It does not
consume an inventory item or drop the replaced block. Furnace-content cleanup
and leaf-placement persistence remain handled by their existing systems.

## Data and organization

- `data/commands.json`: command names, aliases, help, usage and handler keys.
- `scripts/chat/command_system.gd`: validated dispatch and integration handlers.
  Add a handler to the allowlist/match when introducing new gameplay behavior;
  JSON does not run arbitrary code.
- `data/chat.json`: history/input limits, maximum give count (default 4096),
  message lifetime/fade, width, font size, row height/opacity, line counts, popup
  row limit and maximum integer scale.
- `scripts/ui/chat_screen.gd`: input, bounded history, wrapping and completions.
  Wrapping is cached until a message or layout changes, not recomputed per frame.
- `scripts/ui/hud_layout.gd`: shared safe bottom edge above hearts/hotbar.
- `data/keybindings.json`: input defaults and Controls menu entries.

There is no extra item database: `/give`, edits and completion read the canonical
catalog. `/save` uses the existing world store. Chat does not alter the save
format or application identity; existing worlds remain compatible.

## Farmland atlas

All seven supplied 16×16 PNGs are copied exactly, preserving alpha, into the
existing block atlas. Original tiles and the preceding bed/wool slots remain
unchanged. The atlas uses a 20-pixel stride with a 2-pixel margin.

| Source | Atlas tile (X, Y) |
| --- | --- |
| `farmland_side_01.png` | (5, 52) — active |
| `farmland_side_02.png` | (6, 52) |
| `farmland_side_03.png` | (7, 52) |
| `farmland_side_04.png` | (8, 52) |
| `farmland_side_05.png` | (9, 52) |
| `farmland_side_06.png` | (10, 52) |
| `farmland_side_07.png` | (11, 52) |

The existing `farmland` entry in `data/content.json` now selects (5, 52), so
hoeing, placement, inventory icons and old saved farmland all use stage 01.
Stages 02–07 are reserved artwork; hydration/crop growth is not enabled yet.

Verified in Godot 4.7.2: actual typing and modal input; history/completion;
rebinds; profile names; give/overflow/tool durability; modes/relative teleport;
invalid requests; block edits; health/death/checkpoints; save persistence and
menu handoffs. Native rendering at 1280×720, 800×450 and 385×240 verifies every
hotbar pixel stays unchanged when chat opens.
