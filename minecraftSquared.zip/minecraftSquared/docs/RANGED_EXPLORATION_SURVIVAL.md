# Ranged combat, underground structures, experience and hunger

This update targets Godot 4.7.2 and Minecraft Java-style survival rules, adapted
to the 2D world. Import the full project from a newly extracted folder.

**Create a new world for generated monster rooms and mineshafts.** Older saves
keep their original terrain: the saved generation settings explicitly disable
the new structure pass when that setting is absent. Existing worlds still gain
bows, food, XP and command-placed spawners. New worlds start with four bread in
addition to the existing finite starter supplies.

## Bows and arrows

Craft a bow from three sticks and three string in the normal bow recipe. Craft
four arrows from flint above a stick above a feather. Gravel has a 10% chance
to drop flint. Skeleton arrows also supply ammunition.

Hold right-click to draw; release to shoot. An arrow is required. One second
reaches critical charge. Partial draws change speed and damage. Firing consumes
one arrow and one of the bow's 384 durability. Switching slots or opening a
screen cancels the draw without consuming either. Drawing slows movement and
prevents sprinting and melee attacks. Bows work in either hand, and the other
arm draws the string. Other held items are hidden during the two-handed pose.

Arrows use swept collision against terrain and mob hitboxes, gravity, air drag,
water slowdown, critical damage and player kill credit. An obstructed muzzle
cannot spawn an arrow beyond a wall. Arrows that stick into terrain can be
recovered by walking nearby; they expire after a minute. Player arrows persist
in saves. Projectile flight stays within loaded terrain, with the existing cap.

The skeleton/stray bow pivot was on the lower wooden limb. It now sits at the
central grip. The grip and string nock share the aim axis through every pull
stage; mirroring reverses the complete pose. The supplied sprite's arrow points
diagonally up-left, so a 135-degree rotation points it right, followed by the
normal facing reflection. The holding hand, drawing hand and fired arrow use
that geometry. The prior slower skeleton recovery remains.

## Hunger and food

The supplied Minecraft food textures form the ten-icon hunger bar opposite the
hearts. The supplied XP-bar textures sit immediately above the hotbar. Chat and
notices reserve this enlarged HUD area.

Hold right-click with food to eat for 1.6 seconds. Continuing to hold eats another
item if needed. Food restores its own nutrition and saturation values from the
content catalog. Exhaustion comes from sprinting, swimming, jumping, mining,
attacking, taking damage and regeneration. Every four exhaustion points remove
one saturation point first, then one hunger point. Walking alone does not drain
hunger. At six hunger or fewer, sprinting is disabled.

At 18 or more hunger, health can regenerate. A full hunger bar with saturation
heals faster. Starvation occurs every four seconds and, with the default Normal
rules, stops at half a heart. Food, saturation and exhaustion persist in saves;
respawning restores food. The previous unconditional regeneration is replaced.

Raw chicken and rotten flesh can cause Hunger; spider eyes cause poison.
Golden apples give Regeneration II and absorption hearts. Enchanted golden
apples give the stronger absorption amount, longer regeneration, resistance and
fire resistance. Milk removes these effects as well as poison/slowness.

## Experience

Player-credited mob kills, mineral ores, mined spawners and collected furnace
output award physical XP orbs. They attract nearby, pause in unloaded chunks,
expire after five loaded minutes and use the supplied experience-orb texture.
Orb count is bounded. Furnace XP is banked, saved, and paid when output is taken
or the furnace is broken. Repeatedly clicking empty output cannot produce XP.

The level curve uses the Java formulas: next-level cost is 2L+7 below level 16,
5L-38 below level 31, and 9L-158 thereafter. Death drops seven XP per level,
capped at 100; the remaining experience is lost. XP and uncollected orbs save.
Enchanting/anvils are not part of this update, so XP has no spending interface.

## Spawners and monster rooms

Spawners activate for a survival player within 16 blocks. They attempt four
spawns in an adapted horizontal 9-by-3 area, then wait 200–799 ticks. Six nearby
mobs of the same type pause further spawning. Lit spawn positions cannot produce
monsters; torches can disable a room. Inactive, unloaded and spectator-only
spawners do not advance their timers. Simulation and rendering only visit loaded
spawners. Breaking a spawner with a pickaxe gives 15–43 XP and no spawner item.

Monster rooms have cobblestone walls, a mostly mossy floor, cave openings, a
central spawner and up to two loot chests. The spawner choices are 50% zombie,
25% skeleton and 25% spider. They are placed beside caves rather than as sealed
boxes in solid rock. Generation is derived from coordinates and seed, preserving
the same result regardless of chunk loading order.

## Mineshafts and actual loot

The 2D adaptation has abandoned corridors on multiple levels, sloping connecting
passages, timber supports, broken rails, cobwebs, chest minecarts and cave-spider
nests. Cave spiders now come from these nests rather than normal cave spawning.
Cobwebs slow the player; swords yield string and shears recover the web.

Chest minecarts are stationary storage containers in this update, using a side
sprite assembled from the supplied chest art and actual minecart side UV. Their
inventory icon remains the supplied vanilla item texture. Driving minecarts is
not implemented.

Both loot tables are transcribed from **Java 1.21.11 vanilla game data**. Every
pool, entry, weight, count range and roll count is retained. This includes rare
enchanted golden apples, name tags, enchanted books, iron pickaxes, minerals,
bread, seeds, glow berries, rails and torches in mineshafts, and the monster-room
music discs and horse armor. Enchanted books roll from the actual random-loot
enchantment tag and keep the enchantment and level in typed stack metadata.
Their enchantments appear in tooltips and persist through storage and saves.

The corresponding collectible items are added to the one content catalog;
unsupported entries are not silently replaced or removed. Applying enchanted
books, horse equipment, music playback, and melon/pumpkin/glow-berry planting
remain future systems. Loot initializes once on first access or discovery,
survives unloading/reloading, and does not refill after being emptied or after
breaking and replacing a generated container.

Structure spacing, corridor dimensions and 2D connections are deliberate
adaptations; they do not reproduce the 3D structure layout for a Minecraft seed.

## Sheep face correction

The front face now uses the correct 6-by-6 surface at (8,8) in the supplied
Minecraft skin, rather than the neighboring pixels at (6,6). The wool remains
around the front-facing face, while side views leave the longer nose exposed.
Sheared sheep retain their bare head. Both facings, head pitch and front glances
are visually checked against the supplied textures and Mojang sheep geometry.

## Controls, commands and editable data

- Right-click: hold food to eat, or hold a bow and release to shoot.
- `/locate structure mineshaft` or `/locate structure monster_room`: find a site.
- `/xp add @s 10 points`, `/xp add @s 1 levels`, `/xp query @s levels`.
- `/give spawner` and `/spawner skeleton`: place a cage and choose its mob while
  pointing at it. Zombie, skeleton, spider and cave spider are supported.
- `data/adventure.json`: structure density/depth/dimensions, spawner rules,
  exhaustion, starvation, XP limits and smelting rewards. These are development
  settings, not extra in-game menu controls.
- `data/content.json`: food values, bow properties, ore XP and all new items.
- `data/abandoned_mineshaft_loot.json`, `data/simple_dungeon_loot.json`: loot pools.
- `data/loot_enchantments.json`: vanilla eligible enchantments and level limits.
- Terrain resource `structures_enabled`: saved per new world.

Tests cover real projectile hits/occlusion/pickup, ammo and durability, canceled
use, both bow directions/stages, hunger and saturation, apple effects, XP curve
boundaries and furnace rewards, dark/lit spawners and caps, deterministic
structures/chunk seams, seeded loot and real save-file round trips. Existing
combat, shield, mining, equipment/storage, lighting and streaming regressions
also pass. Native renders verify the HUD, bows and both structure types.

## Research

- [Official bow article](https://www.minecraft.net/en-us/article/taking-inventory--bow)
- [Official monster-room overview](https://www.minecraft.net/en-us/article/monster-room)
- [Vanilla mineshaft loot data](https://github.com/misode/mcmeta/blob/1.21.11-data/data/minecraft/loot_table/chests/abandoned_mineshaft.json)
- [Vanilla monster-room loot data](https://github.com/misode/mcmeta/blob/1.21.11-data/data/minecraft/loot_table/chests/simple_dungeon.json)
- [Monster-spawner rules](https://minecraft.wiki/w/Monster_Spawner)
- [Hunger and exhaustion](https://minecraft.wiki/w/Hunger)
- [Experience and level formulas](https://minecraft.wiki/w/Experience)
- [Golden-apple effects](https://minecraft.wiki/w/Golden_Apple)
- [Mojang minecart geometry](https://github.com/Mojang/bedrock-samples/blob/main/resource_pack/models/entity/minecart.geo.json)

- [Mojang sheep geometry](https://github.com/Mojang/bedrock-samples/blob/main/resource_pack/models/entity/sheep.geo.json)
