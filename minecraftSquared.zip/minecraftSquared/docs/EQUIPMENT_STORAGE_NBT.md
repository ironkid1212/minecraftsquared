# Equipment, storage, biomes and typed item data

## Playing

- **F** swaps the selected mainhand stack with the offhand. The offhand also has a slot in the inventory and a widget beside the hotbar. These bindings can be changed in Options.
- Right-click tries the mainhand first, then the offhand if the mainhand did nothing. A pickaxe in the mainhand and torches in the offhand work together. Mining uses the mainhand. Sneak to place/use an item against a workstation without opening it.
- **Q** throws one selected item toward the mouse. **Ctrl+Q** throws the stack. Throws start near the eyes, have a small upward bias, and cannot be picked up for two seconds. In an inventory/container, Q uses the hovered slot. Clicking outside the panel throws the cursor stack; right-click throws one.
- The four equipment slots accept matching armor pieces. Right-click held armor to equip or exchange it with worn armor. Shift-click autoequips into an empty matching slot. Armor renders on the player and inventory preview; the HUD shows armor points above health.
- Leather, chainmail, iron, golden and diamond armor are included. Leather, iron, gold and diamond sets use the standard crafting-table patterns. Chainmail and leather materials can be obtained through `/give`; this update does not add mobs or mob drops.
- Craft a **chest** from eight planks around an empty center. A **barrel** uses six planks down the left/right sides and wooden slabs in the top/bottom center. Each holds 27 stacks. Adjacent horizontal chests pair into a 54-slot large chest, with a joined front texture. Shift-click transfers stacks. Right-click splits stacks or places one.
- A block that reaches the underside of the space above a chest prevents opening it. Barrels can open under a roof. Breaking a container drops its contents. Breaking half a large chest drops that half's contents and leaves the other half intact. Workstations remain platforms as requested for this game's traversal.

Armor uses the Java armor/toughness damage formula and material durability. Fractional damage is retained internally. Fall, drowning and the game's other bypassing damage sources ignore armor. Armor wear and item durability respect `Unbreakable`. No enchantment effects, shields, armor trims or netherite are implemented in this update.

## New world generation

Three additional biomes bring the total to ten:

| Biome | Features |
| --- | --- |
| Savanna | Acacia trees, dry grass/foliage palette, no precipitation |
| Swamp | Oak trees with hanging vines, muted foliage, green water |
| Snowy Plains | Snowy grass sides, sparse spruce, frozen pool surfaces, snow precipitation |

Acacia logs, leaves, planks, slabs and stairs have catalog entries and recipes. Vines are pass-through plants and lose unsupported sections. Snowfall does not count as rain for hydration or extinguishing. There is no snow accumulation or ice-melting simulation yet. Breaking supported ice releases water.

**Create a new world to get the additional biomes.** New worlds use biome revision 3. Existing saved worlds retain their previous generation revision; revision 2 keeps the previous seven-biome selection, avoiding newly generated biome seams in those worlds.

## Typed NBT and commands

Each stack now carries its own typed compound, independent of its content definition. Identical IDs with different tags or remaining durability do not merge. Tags survive splitting, crafting-input transfers, furnaces, dropping/pickup, equipment, containers, death and world saves. Ordinary crafting/smelting results get their recipe's normal output, rather than inheriting arbitrary input tags.

Examples:

```text
/give diamond_pickaxe 1 {display:{Name:'Survey Pick',Lore:['Keep this one']},Unbreakable:1b,Damage:5,Quest:{Stage:2}}
/itemtag get
/itemtag merge {display:{Name:'Renamed Pick'}}
/itemtag clear
/blocktag merge {CustomName:'Field Supplies',Owner:'Steve'}
/blocktag get
```

`/nbt` is an alias for `/itemtag`. `/itemtag <get|set|merge|clear>` targets the selected mainhand stack. `/blocktag` targets a reachable chest or barrel. `set` replaces custom tags; `merge` merges them; `clear` removes them. Container `Items`, `id`, `x` and `y` are generated/readable fields and cannot be overwritten by these commands. A named placed chest retains its name when broken; its contents drop separately.

Supported functional fields are `Damage`, `Unbreakable`, `display.Name`, `display.Lore`, and string `components."minecraft:custom_name"`. Names can contain plain text or a JSON text object with a `text` field. Other custom tags persist as data. Storing an enchantment/component does **not** implement that enchantment/component's gameplay behavior.

`scripts/data/nbt.gd` implements all twelve NBT payload types, SNBT parsing/formatting and uncompressed big-endian binary compound encoding/decoding. Internal nodes are `{ "t": type_id, "v": value }`; a stack's `tags` dictionary is the compound's children. Long values use decimal strings internally so JSON cannot round away 64-bit integers. Invalid ranges, heterogeneous lists and excessive nesting are rejected. Limits are 16 KiB of serialized tag data, depth 16, 128 compound entries, and 1024 list/array entries.

This is a typed data foundation for this game, **not Minecraft save-file compatibility**. World saves remain this project's JSON format. There is no gzip wrapper, region-file reader, full text-component engine or arbitrary vanilla component execution. Binary strings use UTF-8; Java modified-UTF-8 edge cases are not covered.

## Organization and tuning

- `data/content.json`: single source of item/block IDs, armor properties/textures, storage kinds, new blocks and visuals. Existing IDs are preserved.
- `data/recipes.json`: all new armor, chest, barrel and acacia recipes alongside existing recipes.
- `data/biomes.json`: climate placement, palettes, vegetation and precipitation. Biome size remains in `data/settings/terrain.tres`.
- `data/settings/drop.tres`: throwing speed, upward bias, pickup delay and existing drop physics. These are editor resource properties defined by `DropSettings`.
- `data/settings/player.tres`: player movement/rig settings, main hand and offhand pose angle.
- `data/keybindings.json`, `data/commands.json`: default bindings and command registration.
- `scripts/inventory/stack_transfer.gd`: shared cursor transactions for player, crafting, furnace and storage slots. `BlockInventory` has configurable capacity; player equipment is slots 36–40 while ordinary pickup capacity stays 36.
- `scripts/world/storage_system.gd`: container state/pairs and persistence. Containers do not allocate a processing node for each placed chest.
- `scripts/player/equipment.gd`: armor totals, damage reduction, equipping and cached armor textures.

Storage panels redraw for pointer/content changes rather than every idle frame. Resting drops cache their floor-support result and recheck after terrain edits; removed floors still wake them. Existing visible-chunk meshes, light caches and collision streaming are retained. No universal FPS improvement is claimed; results depend on scene and hardware.

Saves migrate the old 36-slot inventory to 41 slots with empty equipment. New saves also preserve container halves, custom names, tags and fractional health. Keep a backup before testing any project update. User resource settings, camera values and existing atlas pixels are preserved in the supplied project.

## Validation

Checked in Godot 4.7.2: typed SNBT/binary round trips and rejection, metadata conservation, F/offhand use priority, directional throws, armor/toughness/wear, paired chest ownership/breakage, container/furnace transfers, tagged bucket filling, terrain-triggered drop waking, saved-world migration, legacy biome determinism and new biome generation. Existing mining, controls, falls/death, fluids, farming/weather, building and rendering optimization regressions also pass. Native renderer screenshots were inspected for equipment, joined chests, storage and the new biomes. Tests and generated caches are omitted from the downloadable project.

## Research references

- [Minecraft Java 1.19.4](https://www.minecraft.net/es-es/article/minecraft-java-edition-1-19-4): using held armor exchanges it with equipped gear.
- [Minecraft Java 1.20.5](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-20-5): structured item components and custom data; this project retains its own typed data API rather than claiming a complete modern component engine.
- [Java Player implementation](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/player/Player.java): look-directed drops and pickup delay. Forward/upward velocities are converted from blocks per tick to this game's 16-pixel blocks; 3D scatter is omitted for predictable 2D aiming.
- [Java Inventory implementation](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/player/Inventory.java): main inventory, armor and offhand separation.
- [Java CombatRules](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/damagesource/CombatRules.java) and [ArmorMaterials](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/item/ArmorMaterials.java): damage reduction, toughness and material values.
- [Overworld biome definitions](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/data/worldgen/biome/OverworldBiomes.java) and [official biome descriptions](https://help.minecraft.net/hc/en-us/articles/360046470431-Minecraft-Types-of-Biomes): vegetation, climate and precipitation references. Placement and tree silhouettes are adaptations to this game's 2D terrain.

The Java source mirror is a version-specific implementation reference, not a promise that every current Minecraft behavior is reproduced.
