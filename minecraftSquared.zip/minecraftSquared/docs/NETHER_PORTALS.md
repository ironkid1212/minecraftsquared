# Nether portals and the first Nether milestone

## Playing

Craft flint and steel from one iron ingot and one flint (shapeless). Build an
obsidian rectangle with an empty opening at least two blocks wide and three
blocks high. A complete minimum frame is 4x5; its four corners are optional.
Openings up to 21x21 work. Right-click a visible side frame block with flint and
steel. Ignition consumes one of its 64 uses in Survival.

All obsidian in the activated frame, including present corners, switches to the
internal `obsidian_portal_frame` content entry. It uses ordinary obsidian's atlas
tile, hardness, pickaxe requirement and obsidian drop. Its sides are passable;
exposed tops and the portal floor are one-way platforms. This is a deliberate
2D adaptation so the player can enter a side-view frame. The active variant is
not a creative inventory item. Breaking a required frame block or replacing a
portal interior cell extinguishes the portal; surviving unshared frame blocks
return to ordinary solid obsidian. Corners do not affect validity.

Stand in the purple opening for four seconds in Survival or one tick in Creative.
Leaving reduces accumulated portal time. Menus interrupt entry; Spectator does
not activate portals. The player must leave the arrival portal before its short
half-second cooldown can expire. Portal textures animate from the supplied
Minecraft texture pack. Their rectangles use Ground's transform, including its
existing -13px offset; visibility comes from the current viewport rather than
last frame's lighting bounds.

Horizontal coordinates scale 8:1 entering the Nether and 1:8 returning. Vertical
coordinates are not scaled. Existing destination portals are searched within
16 horizontal blocks entering the Nether and 128 returning. If none is usable,
a nearby supported clear site is selected; a cleared landing platform is the
fallback. The fallback avoids bedrock and player-built blocks. A safe exit can
shift vertically or horizontally from the ideal coordinates.

## Nether environment

This initial 2D generator has a bedrock ceiling/floor, 128 generated layers,
large caverns and smaller tunnels. Lava fills natural openings through Y31.
Nether Wastes, Soul Sand Valley and Basalt Deltas provide netherrack, soul
sand/soil, basalt/blackstone, quartz ore, Nether gold ore and hanging glowstone.
The ores form seeded noise clusters suited to exploring a 2D slice. These are
2D generation rules, not a port of Minecraft's full 3D density functions.

The Nether has no daylight, sun, moon, stars or precipitation. Local light,
held torches and a dim ambient floor still work. Lava travels farther/faster than
in the Overworld. Water buckets evaporate without placing or waterlogging;
ice broken without Silk Touch also leaves no water. Soul sand slows grounded
movement. Beds explode instead of setting a Nether respawn point. Flint and
steel also lights basic animated fire; punching it extinguishes it. Fire is
basic ignition/damage in this milestone, without a spreading fire simulation.

Quartz and Nether gold respect pickaxes, Silk Touch, Fortune and mining XP.
Gold ore drops 2-6 nuggets before Fortune. Glowstone drops 2-4 dust, capped at
four with Fortune; Silk Touch yields the block. Four dust craft glowstone.
Netherrack smelts to Nether brick; quartz/gold ores have furnace recipes.
Blackstone can substitute for the existing cobblestone crafting group.

Natural Skeleton spawning is limited to Soul Sand Valleys. No Overworld passive
animals or ordinary Overworld hostile population is seeded in the Nether.
This milestone is now extended by [Nether progression](NETHER_PROGRESSION.md):
warped forests, fortresses, Blazes, Endermen, Magma Cubes, pearls and brewing.
Piglins, bastions, ancient debris and mob/item portal transport remain later work.

## Persistence and editable data

Inventory, equipment, tool wear, item tags, health, hunger, XP totals, enchanting
seed and global time travel with the player. Blocks, containers, furnaces, fluid
states, dropped items, XP orbs, mobs, arrows, plants and portal records stay in
their dimension. Inactive dimensions pause. Saving while in the Nether preserves
the active realm and both environments. A Nether death leaves its drops there
and respawns in the Overworld using the existing bed/world-spawn rules.

Old worlds default to the Overworld. Existing IDs, old atlas pixels, .tres
settings and the application's user-save location are preserved. The release
contains no .godot cache or regression fixtures; extract into a fresh project
folder and import project.godot.

- `data/content.json`: all new items and the internal active portal frame.
- `data/nether.json`: portal timings/radii, biome width, cave/floor/ceiling and ore
  thresholds, fog colors, ambient level, fire lifetime and Nether lava behavior.
- `data/recipes.json`, `data/smelting.json`, `data/enchantment_drops.json`: crafting,
  furnace recipes and enchanted resource drops.
- `scripts/world/generation/nether_generator.gd`: 2D terrain generator.
- `scripts/world/nether_portals.gd`: frame validation, activation, travel trigger,
  destination construction and visible-only animation.
- `scripts/session/world_dimensions.gd`: environment switching and validation.

Nether generation settings are captured in each world's save on its first save.
Changing those defaults affects worlds without a saved Nether configuration;
existing saved generation is retained. The generated height and supported portal
size range are fixed engine contracts, not arbitrary height settings.

## References and adaptations

Primary game-data/code references were read alongside Mojang's descriptions:

- [PortalShape](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/level/portal/PortalShape.java): frame dimensions and optional corners.
- [PortalForcer](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/level/portal/PortalForcer.java): portal search and fallback placement.
- [Player](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/entity/player/Player.java), [Entity](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/entity/Entity.java), [GameRules](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/level/GameRules.java): 80-tick Survival entry, one-tick Creative entry and the player's 10-tick cooldown. The 300-tick generic-entity cooldown does not apply to players.
- [Nether dimension data](https://raw.githubusercontent.com/misode/mcmeta/data-json/data/minecraft/dimension_type/the_nether.json): coordinate scale, ceiling, no skylight, ambient light, fast lava, evaporating water and bed behavior.
- [Mojang: Nether Wastes](https://www.minecraft.net/en-us/article/around-block--nether-wastes), [Soul Sand Valley](https://www.minecraft.net/en-us/article/around-block--soul-sand-valley), [Nether Update](https://www.minecraft.net/nl-nl/article/nether-update-java): biome materials and resources.

The platform frame, 1D horizontal biome regions, 2D ore density and projected
portal searches adapt those rules for this game's side view.

## Verification

Godot 4.7.2 regression coverage includes side ignition/wear, minimal cornerless
frames, actual side passage and floor collision, broken/flooded frame reversion,
resource distribution/bedrock/lava bounds, water evaporation, bed explosions,
round-trip portal reuse, inventory/XP/chest isolation, real save-file reopening
in the Nether, malformed nested-save rejection and death/respawn/drop isolation.
Native OpenGL screenshots verify centered animated portals in both dimensions.
The existing inventory, enchanting, smelting, equipment/storage, adventure,
spawner-save, creative-use, rendering optimization, mob-combat and traversal
regressions were also run.
