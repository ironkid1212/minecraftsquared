# Particles and sound

This update adds native Minecraft recordings and particle textures to the
existing 2D presentation. Mining, placing and walking use material families;
foreground and background mining both produce chips from the actual atlas.
Grass/leaf chips retain their biome tint. Generation and arbitrary block edits
are silent, so loading chunks does not sound like mass construction.

## Coverage

- Mining hits, block breaking/placing, footsteps, climbing, splashes and swimming.
- Eating/drinking, item and XP pickup, leveling, player/mob hurt and death,
  melee attacks, shields, bows, creeper priming and explosions. The dragon
  fireball sound also has its previously missing playback entry.
- Native mob ambient/hurt/death recordings, and footsteps where supplied by
  the client. Cave spiders share spider recordings; mooshrooms share cows.
  Creatures with no native ambient event remain quiet.
- Doors, gates, chests, barrels, shulker boxes, tilling, ignition, anvils and
  enchanting. Menu buttons share a small persistent click pool.
- Torch/fire flames and smoke, furnace smoke/crackle, lava pops, flowing-water
  ambience, portal particles/ambience and travel, rain and thunder.
- Bone-meal growth sparkles, status-effect swirls, End rod motes, shulker
  open/close/shoot/teleport sounds, and rocket launch/trail/burst effects.

## Explosion appearance

The old power-scaled single explosion stamp has been replaced. The native
six-to-nine-tick lifetime, gray variation, animated sprite and staggered emitter
are retained. A normal large blast emits three puffs per 20 Hz tick over eight
ticks in this 2D adaptation (24 puffs rather than the native 48).

Positions are sampled around the origin, shades vary from 0.4 to 1.0, and later
births have smaller sprites. Each puff advances independently through the native
16-frame texture. A power-three puff starts at four blocks across and later
births approach two blocks; lower-power blasts use smaller puffs and fewer
births. Blast spread is scaled for the side view. Cosmetic sizing does not
change damage, exposure, block resistance or crater generation.

## Tuning in Godot

Open `data/settings/effects.tres`, or the World's Effects Settings property.
It controls master/category gains, hearing distance, voice count, new particle
pool size/density, ambient scan/emission budgets and the explosion puff cap.
`data/effects_sounds.json` contains the native event variants and editable
ordered material-name rules; it does not duplicate block/item definitions.

Existing weather, dragon and combat renderers keep their own bounded systems.
The new particle-density control governs the new general effects and explosion
clouds. Existing weather/dragon-specific settings remain in their own resources.
Effects are cosmetic and transient; they are cleared across save restores and
travel, and are not added to world save records.

## Performance

- 20 reusable positional voices; four reusable menu voices. The existing four
  dragon voices remain separate. No sound node is created per event.
- 192 preallocated general particle slots; recycling uses packed arrays and
  swap removal. No Sprite2D, particle node or physics body per particle.
- At most 64 scheduled/live explosion puffs across four simultaneous clouds.
- Offscreen emissions/drawing are rejected, and particles outside the view
  margin are recycled. Sounds use a bounded hearing range and repeat throttles.
- Ambient discovery samples 48 cells every 0.2 seconds, keeps at most 96 cached
  emitter cells, and services at most eight emitters per scan. It does not scan
  all loaded chunks or rebuild terrain meshes.
- Cosmetic randomness is isolated from gameplay random streams.
- Recordings are cached during world setup; action playback does not load files.
  Lighting is sampled at particle birth rather than for every particle frame.

A local headless stress test with a continuously replenished 192-particle pool
measured about 0.30 ms per effects tick. That measures effects CPU work only,
not total game frame time or GPU cost. Initial loading/caching of the recording
library measured about two seconds in that run.

## Asset provenance and references

Sounds were copied from the installed Minecraft asset index 36 object store,
following native `sounds.json` event mappings and per-variant volume/pitch.
The bundled library is a filtered set of short gameplay/ambient recordings;
no music files are included. Particle assets come from the installed 26.3 client.
Smoke, firework and End rod strips preserve the native particle JSON frame order.
The existing native explosion sheet is reused rather than duplicated.

Explosion mechanics were checked against the decompiled 1.21.1 classes:

- [ExplosionLargeParticle](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/client/particle/ExplosionLargeParticle.java)
- [ExplosionEmitterParticle](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/client/particle/ExplosionEmitterParticle.java)

Functional checks cover recording validity, real break/place events, range and
repeat rejection, fixed voice count, particle saturation/recycling, atlas UVs,
bounded ambient scans and randomized/capped explosion clouds. Native-render
captures inspect debris, flames, sparks and early/middle/late explosion stages.
