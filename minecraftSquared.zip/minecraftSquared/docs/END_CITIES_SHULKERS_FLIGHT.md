# Outer End cities, ships and flight

Outer islands are closer together: large-island region spacing is 192 blocks
(previously 256), with radii 68�84 instead of 44�82. Small satellite islands,
void channels, all four outer biomes and chorus vegetation remain. This is a
2D traversal adjustment, rather than Minecraft's 3D island density.

## Cities and ships

Cities use seeded plans on large outer islands. Room dimensions, bridge
sections and the 29-by-24-block ship side profile come from the installed
Minecraft 26.3 End city structure templates. The 2D interiors are cutaways with
continuous outer walls, closed floors and roofs. Native spiral staircases become
ladder shafts. Bridges use full purpur decks, inverted-stair undersides and
native gentle/steep sections; openings are carved at their tower connections.
Side towers sit below the ship bridge so treasure rooms are not cut apart.
A short intentional gap separates the floating ship from its dock.

Treasure chests roll once, with 2�6 weighted entries using supported native End
city treasure weights/counts. Looted tools and armor have usable enchantments.
Unsupported horse equipment, armor trims and spears are omitted. Ships include
an elytra display, two treasure chests, a dragon head, shulker guards and a
brewing stand stocked once with two Healing II potions. Mine the display to
collect its elytra. Purpur pillars/slabs/stairs and End rods are also available.
End rods use the native model's 2-by-15-pixel shaft and 4-by-1-pixel foot UVs,
with floor, wall and ceiling orientations.

## Shulkers

Shulkers stay attached to surfaces and open their shells to fire homing bullets.
They have 30 health; a closed shell gains 20 armor and deflects ordinary arrows.
Opening extends their collision box outward by one block. Low-health hits can
trigger a short teleport to another suitable surface. Bullets can be destroyed,
collide with terrain and entities, inflict 4 damage and apply ten seconds of
levitation. Shields can block them. Open-shell bullet hits can produce another
shulker, subject to local crowding and the global mob cap.

Structure guardians persist through streaming and saves and do not respawn as
fresh guards whenever a city is revisited. Shells can be crafted with a chest
into a portable shulker box. The creative spawn-egg tab includes a shulker egg.

## Elytra and portable storage

Equip elytra in the chest slot. Press Jump again while airborne to deploy;
aim with the mouse to pitch flight. Use a firework rocket to boost. Elytra wear
once per second of survival flight, respect Unbreaking, and remain in the slot
at one durability when unusable. Wings draw behind the player's torso using
native wing texture UVs and a flat side profile. Fast wall impacts cause damage.
Ordinary armor and elytra share the chest slot. Elytra accept Unbreaking books
at an anvil, use equipment durability rates rather than armor rates, and do
not accept Protection or enchanting-table offers.

Shulker boxes have 27 storage slots and their native inventory panel. Mining a
box drops one item retaining contents, names, enchantments and tool durability.
Boxes cannot be inserted into other shulker boxes. Item metadata, containers,
guardian encounters and active bullets participate in existing world/dimension
save records. Existing saved player edits take precedence over generated cells;
new terrain and unedited natural cells use the updated generator.

## Tuning

- `data/end_outer.json`: island spacing, radius and terrain parameters.
- `data/end_cities.json`: city/ship chances, region size, plan-cache and guardian
  limits, shulker shooting/teleport/bullet parameters and rocket speed.
- `data/end_city_pieces.json`: exported native template sections.
- `data/end_city_loot.json`: supported weighted treasure entries.
- `data/content.json`: authoritative item/block properties, equipment durability
  and atlas coordinates. `data/mobs.json` owns shulker health and drops.
- `scripts/world/generation/end_city_generator.gd`: 2D assembly and room shells.

Generation plans and projectile counts are bounded. Draw calls for bullets and
rockets are view-culled; structures use the existing chunk renderer, not one
node per block. The flat End crystal renderer and seven-block pillar limit
are preserved.

## Research

Templates, textures, End rod model UVs and loot tables were read from the
installed 26.3 client. Shulker timings, armor, attachment, shell expansion,
teleporting and bullet damage/levitation were checked against the following
1.21.1 source. This is a 2D adaptation across those references, not an assertion
of identical behavior in every Minecraft version.

- [End city](https://minecraft.wiki/w/End_city)
- [End ship](https://minecraft.wiki/w/End_ship)
- [Shulker](https://minecraft.wiki/w/Shulker)
- [Elytra](https://minecraft.wiki/w/Elytra)
- [Shulker box](https://minecraft.wiki/w/Shulker_box)
- [Shulker entity source](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/entity/mob/ShulkerEntity.java)
- [Shulker bullet source](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/entity/projectile/ShulkerBulletEntity.java)

## Verification

Functional checks cover seeded placement, island gaps, closed room boundaries,
chest supports, native ship proportions, one-time loot/guardians, arrow
deflection, levitation, actual jump-button deployment, rocket boost, wear,
retained broken wings, portable storage NBT and complete save/dimension round
trips. Native renderer captures inspect cities, rooms/shulkers, ships, wings
and the shulker-box panel. Regression results are recorded with the release.
