# Fences, doors and more mobs

## Husk and skeleton rendering

The Husk source texture uses the legacy mirrored-limb layout. The previous
conversion read unused left-arm/left-leg UVs, making those faces transparent.
Both facing banks now use the actual native limb faces. The test suite checks
all compact humanoid arms and legs for opaque source pixels and captures six
idle/walking poses in both directions. Idle legs overlap in a side view; both
legs now become visible and animate as the walk pose separates them.

Skeleton rigs also have a small native-texture neck join between the head and
ribs. Wither Skeletons carry a stone sword from the hand: down and forward at
rest, raised diagonally when attacking, matching the supplied references.
`melee_pose` in `data/mobs.json` controls the angles, scale and sprite grip.

## Fences and gates

All 13 foreground fence types are solid barriers. The isolated post has a
narrow collider; connections extend it toward adjacent fences, gates or full
block faces. The entity collision height is 24 world pixels (1.5 blocks), while
the visible fence remains one block high. Normal jumps cannot clear it from
level ground. Use elevated blocks to climb over, or use a gate.

Background fences placed using the background modifier remain decorative and
non-colliding. Fences keep separate two-post inventory silhouettes instead of
reusing the placed single-post/rail connection sprite.

All 12 wood types have fence gates. Use/right-click toggles a gate. The world
view shows a narrow fixed center post, with overlapping side-view leaves that
swing away from the player. Closed gates use a four-pixel-wide, 1.5-block-high
barrier; open gates permit passage. Closing is refused if that barrier would
intersect a player or mob. Inventory icons retain their full fence-gate shape.
All fence groups, including Nether brick fences, connect to gates.

## Wooden doors

All 12 wood types have two-block doors using native upper/lower block textures
and native item icons. Six matching planks in two columns craft three doors.
Place the lower half on a full supporting top face with clear space above.
One item places both halves. Use/right-click either half to open or close both.

Closed doors show a three-pixel edge with matching narrow collision across both
block heights. Open doors show the complete panel and have no collision. Facing
right when placing anchors the left hinge; facing left anchors the right hinge.
The hinge remains fixed during a 0.18-second swing, with both halves animated
together. Reversing a swing continues from its current pose. Closing is refused
if the thin closed collider would intersect a player or mob. Background walls
remain visible through transparent pixels and during the animation. Breaking either half gives one door item; removing its support
removes the pair and drops one item. Half states stay synchronized, including
command state changes, chunk cleanup, dimension state and saves. Doors and
gates are functional foreground blocks.

Wooden gates and doors are furnace fuel. Crimson and warped variants are not.
Internal open/upper states stay out of Creative; their canonical items appear
with their wood families. Their saved IDs are ordinary content records.

## Biomes and mobs

New worlds use biome revision 7:

- Mangrove Swamp has mud, raised mangrove trunks and roots, dense foliage and
  hanging vines. Mangrove logs make the existing mangrove plank family.
- Windswept Forest uses moderate existing relief with scattered spruce/oak
  trees, exposed stone/gravel patches, and appropriate existing passive animals.

Old worlds keep their saved biome revision. Existing swamps can spawn Bogged,
and existing Nether fortresses can spawn Wither Skeletons.

Bogged use native skeleton/overlay textures, 16 health, poison arrows, and a
3.5-second draw-plus-recovery cycle. Shearing removes their head mushrooms and
drops two mushrooms. Wither Skeletons are taller melee mobs with native textures,
stone swords, fire immunity and a ten-second Wither effect on unblocked hits.
Their fortress spawn mix is editable in `data/nether.json` under
`fortress_spawn_weights`. Both mobs have native Creative spawn eggs and saved
entity state. Skull and occasional stone-sword drops are included.

Wither can kill, unlike Poison. Its timer, amplifier, milk clearing, HUD/inventory
icon, dark heart textures and save validation are integrated. Native effect
textures are preloaded so their renderer resources remain alive.

## Collision stability

One-way platform caps use cell-sized physics groups. This avoids Godot merging
diagonal mangrove root caps into self-touching polygons, which produced convex
collision decomposition errors. Ordinary solid terrain retains its batched
physics layout. Visible chunk meshes and previous travel optimizations remain.

## Main files

- `data/content.json`: canonical fence/gate/door states, shapes, icons and wood.
- `scripts/world/fence_connections.gd`: connection-specific fence collision.
- `scripts/world/world_doors.gd`: paired placement, use and cleanup.
- `data/recipes.json`, `data/smelting.json`: recipes and fuel.
- `data/biomes.json`, `data/mobs.json`, `data/nether.json`: habitats and behavior.

Original content IDs, settings resources and previous atlas pixels are retained.

## References

- [Fence collision and connections](https://minecraft.wiki/w/Fence)
- [Mojang Bogged introduction](https://feedback.minecraft.net/hc/en-us/articles/24117322935565-Minecraft-Java-Edition-Snapshot-24w07a)
- [Minecraft: Mangrove Swamp](https://www.minecraft.net/en-us/article/around-block--mangrove-swamp)
- [Wither Skeleton](https://minecraft.wiki/w/Wither_Skeleton)
- User-supplied Wither Skeleton resting and attacking reference images.

## Death cleanup and hinge renderer

All player status effects, absorption and burning clear on death and respawn.
Fatal melee and projectile attacks cannot add their effect after killing the
player. Saved dead states also run the same cleanup when reopened.

`scripts/world/hinged_blocks.gd` draws visible foreground doors/gates from a
cached list of committed cells. It uses native atlas faces and existing block
lighting, with one renderer rather than nodes per door. Transient swing poses
reset on dimension changes and save restoration; hinge and open states persist
as ordinary content IDs. All older IDs and original atlas pixels are retained.
