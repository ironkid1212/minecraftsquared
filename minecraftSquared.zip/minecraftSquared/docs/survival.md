# Survival and beds

## Play

- Health is 20 points (ten hearts); half-hearts show odd values. Taking damage
  flashes the skin and hearts. Falls up to three blocks are safe. Beyond that,
  each additional block costs one health point, rounded up with a small physics
  tolerance. Fall tracking follows the apex, so jumping down a ledge counts.
- Death closes crafting/furnace screens and drops owned inventory/cursor/crafting
  stacks. Tool durability is preserved. Stored furnace contents stay in furnaces.
  Dead players cannot collect, mine, place, open inventory or switch to spectator.
- Respawn restores health, grants brief damage immunity and does not grant more
  starter items. Drops remain in the world for collection under the existing drop
  lifetime rules. Death state, health, bed checkpoint and falls survive saves.
- Use a crafting table: white wool across three top slots and planks across three
  slots below. Oak or birch planks work. The red bed consumes one item and places
  two linked blocks in the direction the player faces. Break either half for one
  bed drop. Both cells must be empty and supported.
- Right-click a reachable bed to set respawn. The system tries clear space beside
  the bed, then on its mattress. If missing/blocked, it searches safe ground near
  original world spawn. If no safe point exists, the death screen stays open
  rather than spawning inside solid terrain. Beds do not skip time yet.
- Until sheep exist, starter supplies include three white wool. Old saves lacking
  survival state receive these once, using the same starter inventory definition.
  Keep stable block/item keys and application name when updating the project.
- Until food/hunger exists, gentle passive healing restores one point every four
  seconds after an eight-second damage-free delay. This is a temporary adaptation,
  not Minecraft's food-based regeneration. Spectator takes no damage and does not
  regenerate or accumulate falls.

## Customize

Open `data/settings/survival.tres` in Godot. Health, safe fall distance, damage per
block, immunity timers, healing enable/delay/interval, death drops and respawn
search radius are exported fields. `game.tres` references this resource.

`data/beds.json` maps each inventory bed key to right/left [foot, head] keys and
ordered candidate spawn offsets relative to the foot. X offsets mirror when
facing left. Keep `interaction: bed` and platform collision on each part.
`platform_height` is the exposed top height measured from cell bottom (bed 9px;
full cactus/log/workstation 16px). Sprites, icons, hardness, stack sizes and drops
remain in the single `data/content.json` catalog. Recipes stay in recipes.json.

Art: original atlas pixels are preserved. The appended row at tile Y=52 contains
right/left red bed halves (X=0..3) and white wool (X=4). Bed halves copy the supplied
`red_bed_foot_east`, `red_bed_head_east`, `red_bed_foot_west` and
`red_bed_head_west` side textures exactly, including their transparency. The inventory bed icon is in
`survival_items.png`; hearts use the supplied vanilla HUD sprites.

## Implementation

`PlayerSurvival` owns health, fall tracking, deaths and respawn. `SurvivalScreen`
shows hearts and the death UI. `BedSystem` owns linked placement, removal and
safe checkpoint selection. These systems do not add another block/item database.
The optional survival save field preserves older world documents. The save format
and application identity remain unchanged; existing worlds need no regeneration.

Verified in Godot 4.7.2: actual 3/4/10/23-block falls; immunity/healing/spectator;
bed recipe, orientations, chunk seam, mattress collision, missing/blocked bed;
full inventory plus cursor/crafting stacks on death; tool wear; dead save/reload;
pickup conservation; low-health/midair saves and legacy supply migration. UI
was rendered at 1280×720 and 800×450. Existing controls, world updates, falling
blocks, culling and frontend checks pass.

Design references: Minecraft's [health overview](https://www.minecraft.net/en-us/article/health-minecraft)
and [spawning and dying](https://www.minecraft.net/en-us/article/spawning-and-dying).

## Heart feedback

Heart feedback has its own timers, separate from the red skin hurt tint. On
damage, current health remains red. Pre-damage health is drawn behind it with the
supplied pale blinking sprites, so only the missing portion is visible. The
container uses `container_blinking.png` during bright phases. The HUD clock runs
at 20 ticks/second and alternates every three ticks over a one-second damage
window. Closely spaced hits retain the older health display until one second
after the latest hit. Loading or respawning clears this transient feedback.
At two hearts or less, hearts jitter one logical pixel on HUD ticks.

In `survival.tres`, Health Blink Seconds, Heart Blink Ticks, Health History
Seconds and Low Health Jitter control this feedback; Damage Flash Seconds still
controls the skin tint. Gameplay health, damage, healing and saves are unchanged.

Reference: Mojang's [health-bar damage feedback issue](https://bugs.mojang.com/browse/MC-2930).
