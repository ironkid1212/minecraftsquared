# Smelting progression

This update targets Godot 4.7.2. Import `project.godot` from the extracted
project and let Godot recreate its asset cache. Existing content IDs, settings,
skins and saved inventories are preserved.

## Using the furnace

Right-click a furnace to open it. Shift-click a smeltable inventory stack to
move it into the input slot, or fuel to move it into the fuel slot. Items that
can do both, such as logs, prefer the input. Move them manually to burn them.
Other stacks move between backpack and hotbar normally.

Shift-click furnace contents to collect them. Output fills the hotbar from
right to left, then the backpack. Input and fuel prefer the backpack. Neither
route silently fills the offhand. Right-click output takes half when the cursor
is empty or one when holding a matching stack. Output never accepts deposits.

The original furnace texture provides the flame and progress arrow. Hover the
flame for remaining burn time; hover the arrow for cooking time and explanations
such as missing fuel, blocked output, cooling, or no recipe.

## Cooking and fuel

The catalog has 68 input recipes and 51 fuel entries. Existing ore, food,
charcoal and glass recipes remain. New recipes include stone to smooth stone,
smelting supported gem ores, and recycling supported iron, gold, copper and
chainmail equipment into one metal nugget. Equipment durability and custom
tags do not transfer to the nugget. Recipe XP is collected when output is taken
or the furnace is broken.

| Fuel | Burn seconds | Items at 10 seconds each |
| --- | ---: | ---: |
| Coal / charcoal | 80 | 8 |
| Block of Coal | 800 | 80 |
| Lava bucket | 1000 | 100 |
| Overworld logs, planks, wooden stairs/fences | 15 | 1.5 |
| Wooden slab | 7.5 | 0.75 |
| Wooden tool | 10 | 1 |
| Stick / wool | 5 | 0.5 |

Lava leaves an empty bucket. Crimson and warped wood do not burn. Once lit,
fuel keeps burning while input is absent or output is blocked. New fuel is
consumed only when there is a valid recipe and output space. Fuel exhaustion
rewinds cooking progress at twice normal speed; refueling can resume it before
it reaches zero. Changing input item identity, durability or tags resets cooking
progress. Changing only its count does not.

Smooth stone, Block of Coal and iron/gold/copper nuggets have texture-pack
icons, catalog entries and appropriate crafting recipes. Coal blocks unpack
into nine coal; nine nuggets craft an ingot and an ingot unpacks into nine
nuggets. Original atlas pixels and content IDs are preserved.

## Editing the data

`data/smelting.json` is the single source for cooking recipes, fuels and
smelting XP. The duplicate XP map was removed from `data/adventure.json`.
The schema is version 2. Recipe keys and fuel keys refer to `data/content.json`
content keys. Example recipe and fuel objects:

```json
{
  "recipes": {
    "raw_iron": {
      "result": "iron_ingot",
      "seconds": 10,
      "experience": 0.7,
      "count": 1
    }
  },
  "fuels": {
    "lava_bucket": { "seconds": 1000, "remainder": "bucket" }
  }
}
```

The file also has `cook_seconds: 10` and `cooldown_multiplier: 2`. Each recipe's
`seconds` controls its cooking time; changing only the fallback does not
override explicit recipe timings. Invalid keys, durations, output sizes and
remainders are rejected at setup. Remainder-producing fuels must be unstackable.

Furnaces update at 20 Hz in loaded chunks. Event-based stepping handles elapsed
time across fuel and cooking boundaries without losing partial seconds. Idle
states do not toggle world blocks repeatedly. Contents, timers, recipe identity
and uncollected XP persist across saves. Older furnace records missing the new
optional fields remain supported.

`data/starting_inventory.json` now contains eight torches, three white wool and
four bread. The five wooden starter tools were removed for new worlds. Existing
saved tools and inventories are untouched.

## Validation

Checked exact fuel yields, large versus small time steps, cooling/refueling,
blocked output, lava remainders, equipment recycling, metadata transfers,
Shift-click and right-click input, XP collection, loaded-chunk behavior, legacy
records and active furnace save/reload. Native rendering checked progress and
status tooltips. Inventory, creative use, survival, equipment, mining, combat and
save regressions were also exercised.

## References

- [Minecraft Wiki: Smelting](https://minecraft.wiki/w/Smelting): cooking,
  fuel and cooldown behavior.
- [Minecraft Wiki: Furnace](https://minecraft.wiki/w/Furnace): 200-tick base
  cooking time.
- [Minecraft Wiki: Lava bucket](https://minecraft.wiki/w/Lava_bucket): fuel
  capacity and empty bucket remainder.
- [Minecraft Wiki: Oak Slab](https://minecraft.wiki/w/Oak_Slab): Java wooden
  slab fuel value (different from Bedrock).
- [Minecraft: Block of the Week, Oak Wood](https://www.minecraft.net/en-us/article/block-week-oak-wood):
  wood, planks and charcoal fuel yields.
- [Minecraft Wiki: Blast furnace](https://minecraft.wiki/w/Blast_furnace):
  metal equipment recycling results; this update uses ordinary furnace timing.
