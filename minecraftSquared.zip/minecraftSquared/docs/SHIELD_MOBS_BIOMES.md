# Shields, mobs, biomes and bow polish

Tested with Godot 4.7.2. Extract the complete project into a new folder and
import project.godot. Existing saves retain their generation revision and
terrain. Create a new world to see meadow, snowy taiga and badlands.

## Skeletons and strays

Both now have a connected lower spine. Bow rendering uses the actual wooden
grip pixel rather than the center of the item sprite. The holding wrist stays
on that grip, and a separate drawing arm follows the string through all three
pull stages. Both directions mirror the complete pose. Arrows originate near
the nocked arrow instead of the torso.

Drawing and recovery are separate: one second drawing plus one second recovery
gives roughly two seconds between shots, with small AI scheduling variation.

## Shield

Craft six planks and one iron ingot in a crafting table:

    plank  iron   plank
    plank  plank  plank
    empty  plank  empty

Hold right-click with a shield in either hand. Useful main-hand interactions
take priority. The shield raises after 0.25 seconds, slows movement, and blocks
frontal attacks, arrows and explosions. Rear and environmental damage still
apply. Its 336 durability wears on blocked hits of at least three damage.
Blocking also prevents an arrow's poison/slowness effect. Durability uses the
existing stack data, saving and tooltip system. Actual supplied shield art is
used for the item and held model.

## Mobs and effects

- Rabbits hop, flee nearby players, and follow carrots or dandelions. Their
  brown, gold and white variants use the supplied modern rabbit textures.
- Strays spawn beneath open sky in snowy plains and snowy taiga. Their arrows
  apply 30 seconds of slowness.
- Cave spiders are smaller and apply seven seconds of nonlethal poison.
  As a 2D adaptation until mineshafts exist, they spawn rarely underground.

Poison and slowness timers persist in saves. Milk clears effects and returns a
bucket; drinking is instant for now. The HUD uses the supplied Minecraft effect
background and icon textures, plus poisoned-heart textures. Icons stay above
the hotbar. Ordinary harmful effects use effect_background.png; the supplied
ambient background is also included for future ambient effects.

## Biomes and materials

Meadow adds upland flowers, snowy taiga adds snowy spruce terrain, and badlands
adds red sand and layered colored terracotta. New blocks share the existing
content catalog. Red sand also smelts into glass. Old content IDs, atlas pixels,
resource overrides and project settings are preserved.

## Data and organization

- data/content.json: shield, materials, item properties and durability.
- data/recipes.json and smelting data: crafting and furnace recipes.
- data/mobs.json: mob stats, spawn rules, textures, ranged timing and effects.
- data/biomes.json: biome weights, terrain, plants and badlands bands.
- scripts/mobs/skeleton_bow_pose.gd: shared bow/wrist and arrow-origin geometry.
- scripts/player/shield_system.gd: shield use and blocking rules.
- scripts/player/entity_effects.gd: shared saved effect timers.

Verification covered combat, real projectile hits, shield direction/delay/wear,
status effects, rabbit behavior, saving, old generation compatibility and the
three new biomes. Native screenshots checked both bow directions and all pull
stages, the spine, shields, supplied effect panels and generated biomes.

## References

- [Minecraft shield article](https://www.minecraft.net/en-us/article/taking-inventory--shield)
- [Mojang rabbit behavior](https://github.com/Mojang/bedrock-samples/blob/main/behavior_pack/entities/rabbit.json)
- [Mojang stray behavior](https://github.com/Mojang/bedrock-samples/blob/main/behavior_pack/entities/stray.json)
- [Mojang cave-spider behavior](https://github.com/Mojang/bedrock-samples/blob/main/behavior_pack/entities/cave_spider.json)
- [Shield details](https://minecraft.wiki/w/Shield)
- [Stray details](https://minecraft.wiki/w/Stray)

These rules are adapted to the game's 2D controls and world rather than a claim
of exact Java Edition simulation. In particular, cave-spider spawning and the
explicit slower skeleton recovery are deliberate adaptations.
