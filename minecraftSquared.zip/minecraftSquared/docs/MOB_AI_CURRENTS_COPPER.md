# Mob AI, water currents and copper equipment

## What's included

- Existing cow, sheep, pig, chicken, zombie and creeper behaviors now share a prioritized goal selector.
- Skeletons: 20 HP, daylight burning, reachable-shade seeking, ranged bow attacks, close-range retreat, sinking without drowning, bone/arrow drops.
- Spiders: 16 HP, hostile in darkness, neutral in bright areas until provoked, climbing, short attack leaps, string and conditional player-kill eye drops.
- Projectiles use swept collisions against blocks, players and intervening mobs. Friendly fire can cause retaliation. Arrows and mobs are culled outside the view when drawn; projectile population and navigation work have explicit budgets.
- Creepers normally show their side texture. Mobs occasionally turn their heads toward the screen while idle. Moving, feeding and attacking take priority over these cosmetic glances.
- Source pools remain still. Differences between neighboring water levels produce horizontal currents, spillways pull toward lower water, and falling water pulls down. Currents affect players, mobs and dropped items. Spectators remain unaffected.
- A second throw creates its own moving drop instead of merging into an older airborne drop and overwriting its velocity. Incoming ordinary drops can still merge into matching resting stacks.
- `/weather snow [seconds]`, including command completion and saved weather state. Explicit snow overrides biome precipitation; `/weather rain` and `/weather thunder` retain normal biome precipitation rules. Roofs shelter precipitation. Snow does not extinguish entities like rain.
- Copper sword, pickaxe, axe, shovel, hoe, helmet, chestplate, leggings and boots; nine crafting recipes, atlas icons, wearable armor, existing tooltip and durability integration.

## How the 2D AI works

`scripts/mobs/mob_brain.gd` selects goals, while `mob_actor.gd` handles physics and `mob_system.gd` handles population and world integration. Passive panic outranks temptation and grazing. Combat cancels idle glances. Targets must be seen to be acquired, and pursuit remembers the last visible position instead of tracking a player through walls. Spectators and dead players are excluded. Wandering avoids lava, water entry and unsafe drops. Existing bounded navigation and fractional-step movement remain shared.

Skeletons aim and charge before shooting, retreat at close range, and approach if too far away. A 2D retreat replaces circular 3D strafing. Spider climbing uses actual body collision against walls, so a ceiling still stops ascent. Brightness depends on local light and daylight, allowing daytime cave hostility. Retaliation takes priority over acquiring a new player target.

Mojang's Java and Bedrock implementations differ. The source material establishes the behavior goals, animal traits and equipment progression; practical distances and presentation are adapted for this side-view game. Existing 2.25-block player attack reach, reduced creeper trigger/blast radius and population caps are preserved. This update implements the listed behavior set; village raids, breeding, jockeys, equipment pickup and a complete Minecraft entity ecosystem remain future features.

## Edit the data

`data/mobs.json` contains the authoritative mob definitions and rules:

| Fields | Purpose |
| --- | --- |
| `follow_range`, `target_memory` | Acquisition distance in blocks and last-seen memory in seconds |
| `movement_attribute`, `chase_multiplier`, `panic_multiplier`, `tempt_multiplier` | Movement under different goals |
| `idle_seconds`, `wander_seconds`, `look_range`, `panic_seconds` | Idle, movement, looking and panic behavior |
| `front_head`, `rules.glance_interval`, `rules.glance_duration` | Front-head UV and idle glance timing |
| `ranged` | Skeleton range, retreat/hold distance, charge, cooldown, arrow velocity, gravity, damage and aim spread |
| `neutral_brightness`, `climbs`, `leap` | Spider neutrality, climbing and attack leap |
| `avoid_sun`, `sinks`, `undead` | Shade seeking and water behavior |
| `spawn_weight`, `herd`, `drops` | Natural population and loot; drops support `chance` and `player_only` |
| `rules.path_jobs_per_tick`, `rules.navigation_nodes`, `rules.projectile_cap` | Bounded simulation work |

`data/settings/fluid.tres` exposes `water_current_speed` through `FluidSettings`; its default is 22.4 world pixels/second, approximately 1.4 blocks/second. `FluidSystem.current_at()` calculates flow and `current_for_bounds()` samples actual submerged overlap, including shallow water at the feet. The movement contribution stays separate from voluntary swimming and knockback.

All block and item records, including copper equipment and new mob loot, remain in **`data/content.json`**. Recipes remain in `data/recipes.json`. No secondary block/item database was introduced. Copper icons were appended to the item atlas, preserving every original pixel and ID.

| Copper tools | Damage | Attack speed | Durability | Mining speed / harvest tier |
| --- | --- | --- | --- | --- |
| Sword | 5 | 1.6 | 190 | 5 / stone |
| Pickaxe | 3 | 1.2 | 190 | 5 / stone |
| Axe | 9 | 0.8 | 190 | 5 / stone |
| Shovel | 3.5 | 1 | 190 | 5 / stone |
| Hoe | 1 | 2 | 190 | 5 / stone |

| Copper armor | Armor points | Durability |
| --- | --- | --- |
| Helmet | 2 | 121 |
| Chestplate | 4 | 176 |
| Leggings | 3 | 165 |
| Boots | 1 | 143 |

Copper pickaxes harvest iron and copper ore, but gold, diamond, redstone and emerald still require iron. Copper equipment uses the standard crafting shapes with copper ingots. Armor uses the existing equip slots, wear and protection formula. Current worlds retain their original settings, content IDs and saved items; the added snow state is accepted by save validation.

## References

- [Mojang's vanilla entity definitions](https://github.com/Mojang/bedrock-samples/tree/main/behavior_pack/entities): zombie, creeper, skeleton and spider goal priorities, float/panic/tempt/attack behaviors, spider climbing/leaping and brightness neutrality.
- [Mojang skeleton definition](https://github.com/Mojang/bedrock-samples/blob/main/behavior_pack/entities/skeleton.json): ranged combat and sun avoidance.
- [Microsoft ranged-attack goal documentation](https://learn.microsoft.com/en-us/minecraft/creator/reference/content/entityreference/examples/entitygoals/minecraftbehavior_ranged_attack?view=minecraft-bedrock-stable): attack/charge timing and movement controls.
- [Minecraft Water reference](https://minecraft.wiki/w/Water): current direction, falling water and approximate entity push speed.
- [Minecraft Java 1.21.9 release notes](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-9): copper equipment tier and stone-equivalent damage/harvest progression.
- [Copper armor](https://minecraft.wiki/w/Copper_armor), [copper axe](https://minecraft.wiki/w/Copper_Axe), [copper hoe](https://minecraft.wiki/w/Copper_Hoe) and [armor](https://minecraft.wiki/w/Armor): exact Java-style equipment values.

All new art is extracted from the supplied Minecraft texture pack. Compact head and armor atlases use exact UV crops with nearest filtering.

## Verification

Godot 4.7.2 checks cover real arrow hits and wall occlusion, friendly-fire retaliation, shade selection, spider light behavior and physical climbing, target memory and spectator exclusion, idle glances, shallow-current player displacement, balanced and falling currents, independent throws, snow commands/completion/save restoration, all nine copper crafting recipes, tool harvesting limits, armor equipping/wear, and native rendered side/front/left/snow views. Existing mob, combat, equipment/storage, survival, rain, fluid, farming/weather, mining, step/building and optimization regressions also pass.
