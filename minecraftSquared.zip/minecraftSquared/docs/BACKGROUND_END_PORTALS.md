# Background building and End portal rooms

Hold **Alt** while using the normal place/use or mine button to target the
background. The binding is **Background Layer (hold)** in Options > Key Binds.
Release it to interact with the foreground. A blue outline distinguishes wall
targeting. Survival placement spends blocks; mining uses the normal tools,
hardness, harvest rules, drops and durability. Creative is instant.

Background blocks have no collision and never replace the foreground. Opaque
foreground blocks conceal them and prevent through-block targeting. Both
layers keep separate edits, including removed natural walls, across saves,
chunk reloads and Overworld/Nether travel. Background placement can replace
natural geological walls; already placed walls must be mined before replacing.

Normal building blocks, slabs, stairs, fences, bookshelves and stateless
workstations are supported. Crafting tables, enchanting tables, anvils and
grindstones remain usable with a normal right click. Background bookshelves
also contribute enchanting power. Plants, liquids, attached/climbable blocks
and stateful furniture such as storage, beds, furnaces, brewing stands and
spawners remain foreground-only in this update.

## End frames

The new room has five frames in a horizontal row: foreground endpoints and
three background middle frames, over a contained three-cell lava well. Its
spawner is silverfish. Right-click each empty frame with an Eye of Ender.
Reusing a filled frame consumes nothing and does not throw an Eye.

Once all five are filled, three foreground portal tiles overlay the background
middle frames. The background Eye state remains intact. Breaking a frame in
Creative deactivates the portal. Solid blocks in the opening prevent activation
without being overwritten; clearing them activates a completed frame. Generated
background frames retain the portal room brick backing, preventing sky seams.

This changes portal layout and activation; it does not introduce End dimension
travel. Existing twelve-frame ring portals remain supported. Saved worlds retain
their original generation via `stronghold_revision=1`; new worlds default to
revision 2. You can also build the new five-frame layout in existing worlds.

## Data and organization

- `data/keybindings.json`: default construction modifier.
- `data/content.json`: optional `background` eligibility override in the shared
  content database. No duplicate block IDs are required for the wall layer.
- `scripts/world/background_blocks.gd`: placement, mining and target drawing.
- `scripts/world/chunk_world.gd`: independent `wall_edits` and wall change signal.
- `data/strongholds.json`: odd `portal.frame_width`, 5 by default (5�9 supported).
- `scripts/settings/terrain_settings.gd`: versioned stronghold layout selection.
- `scripts/world/end_progression.gd`: Eye insertion and both portal layouts.
- `scripts/session/world_save_store.gd`: optional stable-key `wall_edits` records.

Walls use the existing visible chunk meshes and lighting cache, with no
per-block nodes or background collision rebuilding. Hidden walls are culled.
