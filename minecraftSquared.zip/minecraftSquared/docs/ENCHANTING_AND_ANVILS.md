# Enchanting and anvils

Import the extracted project's `project.godot` with Godot 4.7.2. Existing item
IDs, settings, skins, world terrain and inventories are preserved. New worlds
still start without tools.

## A compact 2D enchanting library

Craft an enchanting table with a book above two diamonds surrounding obsidian,
and three obsidian across the bottom row. A book needs three paper and one
leather, in any arrangement. Three sugar cane across a row make three paper.
A bookshelf needs three books between two rows of planks; plank types may mix.

Six bookshelves supply maximum power. Any shelf within a four-block circular
radius of the table counts, including shelves above, below or directly beside
it. Other blocks do not obstruct power, and no air gap or specific arrangement
is required. This is the game's intentional 2D placement rule.

Hover the GUI book to see the active count. Six shelves give the bottom offer
its level-30 requirement. Adjust `max_bookshelves` and `bookshelf_radius` under
`table` in `data/enchantments.json`. Changes to nearby shelves update the cached
count immediately; unchanged menus do not rescan the area every frame.

Right-click the table. Shift-click equipment or a plain book into the first
slot and lapis into the second. Hover an offer to see one guaranteed enchantment
and its costs. The three offers cost one, two or three lapis and levels. The
displayed level requirement is separate: a level-30 third offer requires level
30 but spends three levels, leaving level 27. Enchanting preserves progress
within the remaining level. Creative mode bypasses these costs.

Offers stay stable when an item is removed, the menu closes, or the world is
saved. Successfully enchanting changes the saved seed. Shelf power and item
enchantability affect the offers. The selection algorithm uses weighted choices,
level ranges, material enchantability and exclusions over the supported set;
its odds therefore differ from Minecraft's much larger enchantment pool.
Already enchanted items cannot be enchanted again at the table. Plain books
become enchanted books whose enchantments can be applied with an anvil.

## Initial enchantments

| Enchantment | Maximum | Implemented effect |
| --- | --- | --- |
| Efficiency | V | Adds level² + 1 mining speed when the tool already mines the block faster than hand speed |
| Unbreaking | III | Reduces durability consumption; armor uses its separate probability |
| Fortune | III | Improves supported ore/gravel drops and mature crop harvests |
| Silk Touch | I | Returns supported stone, ores, grass, glass, ice, leaves and shelves themselves; suppresses their block XP |
| Sharpness | V | Adds charged melee damage; axes receive it through anvils |
| Protection | IV | Adds damage reduction after armor, capped at 20 protection points |
| Power | V | Increases actual player-arrow impact damage |

Fortune and Silk Touch are mutually exclusive. Fortune uses ore multipliers,
redstone's additive bonus and gravel's increasing flint chance. Mature wheat
and beetroot gain seeds rather than extra grain; carrots and potatoes gain
produce. Immature crops receive no Fortune bonus. Copper, lapis and redstone
also use their proper base drop ranges. Harvest eligibility still applies.

Supported enchantments appear below item names with Roman numerals. Equipment
uses typed `Enchantments` tags; books use `StoredEnchantments`. Renaming, lore,
durability, other custom tags and enchantments survive transfers and saves.
New structure loot books draw from the seven working enchantments. Existing
books with other enchantments are preserved; those effects are not added by
this update. Enchanted items now have an animated 2D glint; the full 3D book
animation is not included. See [inventory polish](CREATIVE_GLINT_POLISH.md)
for the Inspector strength control.

While checking Power, an existing arrow-damage scale error was corrected: a
full-speed ordinary arrow now starts at six damage before its critical bonus,
and Power modifies that base. Saved player arrows retain their Power level.

## Anvils

Craft three iron blocks above one central iron ingot, with three more ingots
along the bottom. Nine ingots make an iron block, which also unpacks into nine
ingots. Right-click the anvil to open Repair & Name.

Put the item to keep in the left slot. The right slot accepts its repair
material, identical equipment, or an enchanted book. Each repair material
restores one quarter of maximum durability. Combining matching equipment adds
remaining durability plus a 12% maximum-durability bonus. Compatible equal-level
enchantments combine to the next level, capped at their maximum. Stronger
enchantments are retained. An invalid or ineffective combination cannot consume
the inputs. Bows repair by combining bows, rather than consuming string.

Click the name field to edit; it is not automatically focused on opening.
Names support up to 50 characters. Clear a custom name to restore the default.
The output tooltip previews tags and durability. Take the output normally or
Shift-click it into inventory. Inputs and levels are consumed only after output
space and affordability are confirmed. A conflicting cursor or full inventory
leaves the operation untouched.

The cost includes prior-work penalties. Repairs/combines increase the stored
`RepairCost`; a name-only operation does not increase it. Survival operations
above 39 levels are refused, with the usual rename-only cost cap. Creative
operations bypass XP and wear. Survival use has a 12% chance to advance the
anvil through chipped, damaged and broken stages.

Anvils remain pass-through workstations with exposed one-way tops, following
the game's existing 2D workstation convention. Falling/crushing anvils are not
part of this update. Their sprites project Minecraft's actual four-part anvil
model with its matching side UVs; the small top lip exposes wear-stage textures.

Closing a station returns its inputs and cursor stack, dropping overflow through
the normal inventory system. Saving closes the station before inventory is
serialized. Losing reach, removing the station or dying also returns owned
inputs, preventing discarded or duplicated items.

## Data and organization

- `data/content.json`: bookshelf, enchanting table, anvil stages, iron block,
  paper and book definitions. Existing IDs and atlas pixels are untouched.
- `data/recipes.json`: craftable progression; includes shapeless book matching.
- `data/enchantments.json`: the authoritative enchantment names, maximums,
  weights, cost ranges, target types, conflicts, enchantability, repair materials,
  anvil costs/wear and shelf settings.
- `data/enchantment_drops.json`: explicit block-specific Silk Touch, Fortune and
  mature-crop rules. This contains loot behaviors, not duplicate block records.
- `data/loot_enchantments.json`: references the enchantment keys available to
  structure loot; maximum levels come from the central definitions.
- `EnchantmentDatabase`: offers, metadata, effects and validation.
- `AnvilLogic`: previews without mutating inventory or XP.
- `UpgradeGrid` / `UpgradeScreen`: shared station transfers and GUI.

Enchantment definitions tune the supported effect types; adding a new kind of
effect still requires its engine behavior. Existing `.tres` settings and resource
UIDs are preserved. Shelf radius replaces the previous offset/gap rules;
there is no obstruction or line-of-sight requirement.

## GUI references and validation

The screens use the supplied panel, name-field, error, offer and level-marker
sprites, Standard Galactic Alphabet texture and book texture. Integer GUI scales
keep text and icons aligned. Labels use final-size font metrics; the rename
field has explicit padding and height. Native rendering checked GUI scales 1–4.

The layouts were compared visually with these reference screenshots:

- [Enchanting GUI reference](https://www.sportskeeda.com/minecraft/how-many-bookshelves-needed-level-30-enchantment-minecraft-1-19-update)
- [Anvil GUI reference](https://www.sportskeeda.com/minecraft/50-best-names-minecraft-swords-pickaxes-2023)

Mechanics and values were checked against primary sources:

- [Microsoft: Introduction to Enchantments](https://learn.microsoft.com/en-us/minecraft/creator/documents/introtoenchantments?view=minecraft-bedrock-stable)
- [Minecraft: Taking Inventory, Anvil](https://www.minecraft.net/en-us/article/taking-inventory--anvil)
- [Minecraft Help: All Enchantments](https://help.minecraft.net/hc/en-us/articles/360058730912)
- [Extracted Java enchantment data](https://github.com/misode/mcmeta/tree/data-json/data/minecraft/enchantment)
- [Extracted Java wheat loot table](https://raw.githubusercontent.com/misode/mcmeta/data-json/data/minecraft/loot_table/blocks/wheat.json)
- [Extracted Java carrot loot table](https://raw.githubusercontent.com/misode/mcmeta/data-json/data/minecraft/loot_table/blocks/carrots.json)

Tests cover shelf radius/through-wall power, deterministic offers, low-level unavailable
offers, lapis/XP transactions, actual GUI clicks/typing, enchantment effects,
anvil recipes/renaming/conflicts/prior work, blocked output and active-station
save/reload. Existing creative, furnace, survival, equipment, mining, combat,
food, spawner/save, optimization, traversal and skin regressions were checked.
