# Water, lava and buckets

Water and lava occupy foreground cells independently of the background walls.
Their IDs, icons, collision, absorption and emission live in **data/content.json**,
alongside every other block and item. Existing content IDs were preserved. The
original water/lava/fire animation PNGs and metadata are in **assets/fluids**;
their first frames and the bucket icons were appended to the existing atlases.

## Playing

- Craft an empty bucket from three iron ingots in a V on a crafting table.
- Select it and right-click a **source** block to collect it. Flowing cells cannot
  be collected. Filled buckets place sources; the empty bucket is returned.
  Aiming at a solid block places on its side toward the player, or aim directly
  at an empty cell. Filling from a stack of buckets preserves the remaining
  empties; if inventory is full, the filled bucket drops at the player's feet.
- Hold **Space** to swim upward. Swimming is slower than walking, lava is slower
  still, and holding Space against a wall helps climb out of water.
- Water and lava cancel accumulated fall distance on contact. Water extinguishes
  burning. Lava deals damage, lights its surroundings and sets the player on fire;
  the original animated fire texture makes burning visible.
- Dropped items float in water and are destroyed in lava. Sand and gravel fall
  through fluid and displace it on settlement. Ordinary placed blocks displace
  fluid as well. Water washes away torches and small plants with their usual
  drops; lava destroys these without drops. Logs, cacti and workstations block flow.
- A lava bucket fuels a furnace for 1,000 seconds and leaves an empty bucket.
- Obsidian requires a diamond pickaxe for drops; its hardness is 50.

For testing, `/give @s bucket 1`, `/give @s water_bucket 1`, and
`/give @s lava_bucket 1` use the existing chat command system. `/setblock` also
accepts `water` and `lava`, creating source blocks. Spectators ignore fluid forces
and hazards, and retain fullbright.

## Flow rules

**data/fluids.json** contains behavior and texture references, not another block
database. Water updates every 0.25 seconds and spreads seven cells across a flat
floor; Overworld lava updates every 1.5 seconds and loses two strength levels per
sideways step, reaching three cells. Both prefer downward flow, then paths toward
nearby drops. Removing or blocking their supply makes unsupported flows recede.
Two supported water sources separated by one cell can create another source;
lava does not renew this way.

Water on the top or side of a lava source makes **obsidian**. Contact with flowing
lava makes **cobblestone**. Lava flowing downward into water makes **stone** at the
water cell. Source identity and flowing/falling strength are tracked separately;
levels survive chunk unloading and saves.

This is a 2D adaptation of Java Edition fluids, not a port of the entire engine.
Waterlogging is supported for eligible blocks. There is no oxygen/drowning, fluid pushing of players, or spreading
fire to nearby terrain in this first version. Fluid motion is cell-based with
sloped surfaces, rather than finite-volume physics.

## Customization and performance

Open **data/settings/fluid.tres** in Godot. Its FluidSettings resource controls
simulation budget, update and scan caps, new-world basin/channel sizes and chances,
underground pools, deep cave lava level, lakebed materials, movement, lava damage,
and burning duration. These settings are kept out of the in-game Options menu.

New worlds generate deterministic lakes, small river channels, underground aquifer
chambers, and lava in deep caves at Y −54 and below. Lakebeds use sand with coherent
gravel patches. Banks with excessive relief are skipped. Generation is saved with
each world. Existing worlds without fluid-generation settings keep their original
terrain; buckets and simulation still work there. Create a **new world** to see
the generated bodies of water and lava.

Simulation uses a due-time min-heap and deduplicates scheduled cells. Settled cells
sleep until their neighbors change. Newly loaded chunks are scanned incrementally;
scan work gets a portion of the frame budget so due updates can still run. Fluid
at unloaded chunk seams freezes and resumes when neighbors load. No per-cell nodes
or collision bodies are created. The renderer caches only viewport-visible loaded
cells and uses nearest filtering and the existing block light values. Water does
not erase cave walls. The F3 screen includes fluid queue, update and visible counts.

World saves keep ordinary fluid block edits in the established edit list and add
an optional `fluid_levels` list for non-sources. Older saves omit that field safely.

## References

- [Minecraft water behavior, mapped source mirror](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/material/WaterFluid.java)
- [Minecraft lava behavior, mapped source mirror](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/material/LavaFluid.java)
- [Minecraft flow algorithm, mapped source mirror](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/material/FlowingFluid.java)

The original texture files came from the texture folder supplied with the project.

See [Movement and shores](movement_and_shores.md) for waterlogging, fast swimming, low sand banks and sugar cane.
