# Natural generation: biome borders, ores and caverns

Close Godot, extract `natural_generation_update.zip` to a separate folder, and
double-click `Apply-Update.cmd`. The installer checks hashes and backs up every
replaced file under `.update-backups`.

**Create a new world to see the changes.** Existing saves keep their previous
generator, including ore placement. Do not change a saved world's generation
revision: unedited terrain would regenerate. Builds, inventory, skins, content,
recipes, keybindings and settings resources are not replaced.

## Research and adaptation

Minecraft associates ecosystems with terrain and climate, rather than cycling
through biome names. Its pipeline separates terrain, biomes and features. We
apply that division to a horizontal climate slice and the four supported biomes.
This is a 2D adaptation, not Java's complete density functions or seed layout.
[Official generation overview](https://learn.microsoft.com/en-us/minecraft/creator/documents/world-generation?view=minecraft-bedrock-stable).

Iron favors Y16 underground and high mountains; copper favors Y48, gold Y-16,
and lapis Y0. Diamonds/redstone favor the depths; emeralds favor mountains.
Some ores avoid air. Rare large veins mix copper with granite and deep iron with
tuff. [Mojang's distribution notes and chart](https://feedback.minecraft.net/hc/en-us/articles/4415128577293-Minecraft-Java-Edition-1-18).

Later diamond generation increased in deepslate. Our adaptation includes an
additional deep distribution. [Mojang's diamond update](https://www.minecraft.net/en-us/article/minecraft-snapshot-23w31a).

Ore features distinguish deposit count, suitable hosts and rejection beside air.
We retain those controls, with sizes and frequency tuned for a 2D cross-section.
[Official ore-feature schema](https://learn.microsoft.com/en-us/minecraft/creator/reference/content/featuresreference/examples/features/minecraftore_feature?view=minecraft-bedrock-stable).

## Biomes and borders

Each biome's `placement` object in `data/biomes.json` defines climate intervals
and optional weights. Closest climate fit chooses plains, forest or desert;
stony peaks also require actual mountain relief. Regional sampling and minimum
widths suppress thin strips. An isolated return between matching neighbors is
absorbed deterministically. No biome rotation is forced.

At each surface border the material changes once. Underground, one shared curve
bends sideways with depth, making connected wedges instead of alternating sand
and dirt columns. World coordinates make both sides agree on slopes. Vegetation
uses the surface biome, tree density tapers near borders, and grass retains its
dirt cap. Sand/sandstone keep finite layer depths over independent geology.

Select `data/settings/terrain.tres` in Godot:

| Control | Default | Effect |
| --- | --- | --- |
| Biome Size | 0.5 | Horizontal climate scale; lower makes climate regions shorter. |
| Biome Region Width | 192 | Regional sampling width before multiplying by Biome Size. Adjacent matching regions merge. |
| Minimum Biome Width | 64 | Absolute minimum regional width. |
| Biome Transition Width | 24 | Vegetation taper and underground seam excursion scale. Zero gives a straight seam. |
| Minimum Dirt Depth | 3 | Guaranteed dirt directly under grass. |
| Terrain Region Size | 0.75 | Scale of terrain/peak fields, independent of biome size. |

For smaller biomes try Biome Size **0.35**, Biome Region Width **160**, and
Minimum Biome Width **48**, then create a new world. Climate-connected biomes
can exceed the nominal sampling width because matching regions merge.

## Ore distributions

Edit **`data/overworld_generation.json` → `ores`**. Blocks/items remain in the
single `data/content.json` catalog. `legacy_ores` in the generation file is a
frozen revision-1 compatibility profile, not another content database. Add new
active distribution rules to `ores` only.

Heights below are displayed Y coordinates: `Y = 319 - Godot row`.
These are **this game's 2D defaults**, not vanilla Java attempt counts. Attempts
are per **32×32 tile**, filtered by the height distribution and optional chance.
Sizes count distinct connected cells before caves, host checks, height limits
and exposure remove candidates. Adjacent deposits can merge.

| Ore/pass | Y band | Shape / favored Y | Attempts | Size | Keep beside air |
| --- | --- | --- | ---: | --- | ---: |
| Coal | 0..192 | Triangle / 96 | 7 | 6..12 | 65% |
| High coal | 128..319 | Uniform | 4 | 6..12 | 100% |
| Underground iron | -64..72 | Triangle / 16 | 9 | 4..8 | 100% |
| Background iron | -64..72 | Uniform | 2 | 2..4 | 100% |
| High iron | 80..319 | Triangle / 232 | 6 | 4..8 | 100% |
| 2D mountain iron | 80..160 | Triangle / 112; mountains only | 4 | 4..8 | 100% |
| Copper | -16..112 | Triangle / 48 | 8 | 5..10 | 100% |
| Gold | -64..32 | Triangle / -16 | 4 | 3..7 | 50% |
| Extra deep gold | -64..-48 | Uniform | 1 | 2..5 | 50% |
| Lapis | -32..32 | Triangle / 0 | 3 | 3..6 | 100% |
| Buried lapis | -64..64 | Uniform | 3 | 3..6 | 0% |
| Redstone | -64..16 | Uniform | 4 | 4..8 | 100% |
| Extra deep redstone | -64..-32 | Triangle / -64 | 4 | 4..8 | 100% |
| Diamond | -64..16 | Triangle / -64 | 2 | 2..5 | 35% |
| Extra deep diamond | -64..-4 | Uniform; 40% attempt chance | 1 | 2..3 | 50% |
| Emerald | -16..319 | Triangle / 112; mountains only | 5 | 1..3 | 100% |

The emerald peak and extra mountain-iron pass deliberately suit this game's
calmer, lower mountains. Local stone/deepslate selects the ore variant. Copper's
small negative-Y tail permits rare deepslate copper.

Wooden pickaxes harvest stone and coal. Cobblestone tools unlock iron/copper;
smelt iron for an iron pickaxe to unlock diamonds, gold, redstone and emeralds.
Existing recipes, tool tiers and durability remain active. Coal or charcoal can
fuel the furnace; charcoal provides an alternative when the first cave has
little coal.

### Fields to tweak

- `min_y`, `max_y`: candidate blocks must stay in this height band.
- `distribution`: `triangle` falls away from `peak_y`; `uniform` stays level.
- `attempts`: how frequently deposits are attempted per 32×32 tile.
- `chance`: optional multiplier on accepted attempts, from 0 to 1.
- `size`: inclusive minimum/maximum distinct connected cells.
- `exposed_keep`: 0 rejects candidates beside natural air; 1 keeps them all.
  Mining later does not remove already generated ores.
- `mountains_only`: requires a mountain biome.
- `priority`: smaller number wins overlaps. A rejected exposure candidate can
  fall back to another eligible distribution at that position.
- `salt`: use an independent unique integer per pass. Adding a pass then does
  not shift every other ore's random sequence.

## Caverns and large veins

Cheese, spaghetti and noodle fields produce chambers and winding passages.
The updated caverns are taller, with irregular shelves and retained columns.
They intersect tunnels and surface entrances without chunk-grid seams. Some
ores are visible in their walls; others stay embedded for mining.
[Mojang's cave feature overview](https://www.minecraft.net/nb-no/article/caves---cliffs-part-ii-the-features).

`large_veins` adds occasional copper/granite at Y0..50 and iron/tuff at Y-60..-8.
Most of each formation is filler rock, with scattered ore. These are bounded
2D formations, rather than Minecraft's potentially enormous 3D veins.

A vein rule has `chance` per 32×32 source tile, a height band, `length` in path
steps (0.55 blocks per step), `radius`, `ore_fraction`, `filler`, `ore` and `salt`.
Defaults use 14–16% source-tile chance before height checks, 24–46 path steps,
radius 1.65, and 22–24% ore. Cave/host/height clipping reduces the final size.

Select **`data/settings/cave.tres`**:

| Control | Effect |
| --- | --- |
| Cavern Threshold | Lower creates more chambers; higher leaves more rock. |
| Cavern Frequency | Lower creates broader, more widely spaced chamber fields. |
| Cavern Vertical Scale | Lower makes taller caverns; default 1.2. |
| Cavern Shelf Strength | Irregular chamber shelves; default 0.10. |
| Cavern Pillar Threshold | Higher leaves fewer stone columns; default 0.60. |
| Tunnel Width / Spaghetti Min Radius | Passage width, independent of chamber size. |
| Tunnel Region Threshold | Higher confines tunnels to fewer regions. |
| Surface Cap | Solid roof except at dedicated entrances. |
| Entrance Every / Entrance Radius | Surface access frequency and width. |

Layered caverns are on for new worlds; old saves without the field retain their
previous density. Aquifers/liquids, new cave biomes, structures and mobs are
outside this update.

## Verification

Godot 4.7.2 import and native rendering passed. Surveys covered 8,192 biome
columns and 512 columns of underground terrain per seed for 12345, 42 and
-98765. All four biomes appeared, borders stayed coherent and ordered, and
reversed requests/cache eviction reproduced the same terrain.

Each 512-column survey contained 17–50 exposed coal blocks and 96–108 exposed
iron blocks at Y0 and above. Deep diamond counts were 76–95, including 3–13
exposed blocks: about 0.4% of remaining deep solid terrain. These are area counts,
not spawn guarantees or promised completion times. Balance was checked through
statistics and progression rules; survival playtesting can refine discovery times.

Tests cover distinct connected deposits, cross-tile placement, air rejection,
mixed large veins, harvest gates, recipes, smelting and bounded caches (256
entries each). A 29,323-position comparison matched revision 1 exactly.
Controls, F3/fullbright, mining, lighting, culling, streaming, inventory, falling
blocks, grass/leaf updates and save migration regressions passed.

In the same 600-frame Compatibility travel harness on the local Intel Iris Xe,
revision 2 measured 1.67 ms mean / 4.34 ms p95 versus 1.85 / 4.42 for revision 1.
Initial generation measured 0.78 s versus 0.73 s. This is a local regression
check, not a hardware-wide claim. Incremental streaming remains active; compiled
tile masks replace repeated neighboring-feature lookups per block.

Legacy generation parameters are stored internally for old saves but hidden from the Inspector. Retired cave presets have been removed; the visible noise-cave controls above are the active ones.
