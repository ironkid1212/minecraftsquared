# Creative inventory, held Use and semi-solid fences

Import this full project in Godot 4.7.2. Extract to a new folder and open its
project.godot. Its application identity and user:// save location are unchanged.

## Quick controls

- `/gamemode creative`, then **E**: open the creative catalog.
- **Left click** a catalog item for a stack; **right click** for one; **Shift click**
  for a stack in the inventory. Hover an item and press **1�9** to assign it to a
  hotbar slot. Drag/click the held stack into the bottom hotbar normally.
- Click the compass tab for search. Names, item keys, `minecraft:diamond` and
  implemented content tags such as `#wood` or `#planks` are supported. Typing E in
  the search field does not close the menu. Use Escape to close it.
- Mouse wheel or drag the scrollbar to scroll. The chest tab opens the equipment,
  offhand and survival inventory. Its native X destroys the cursor stack;
  Shift-clicking X clears the inventory, matching the creative-only gesture.
- With the inventory closed, hold **C + 1�9** to save one of nine hotbars, or
  **X + 1�9** to load it. The two activators are rebindable in Controls. Presets
  preserve durability/NBT and live in the existing preferences file, across worlds.
- Double-tap Jump in Creative to toggle flight; Jump ascends, Sneak descends and
  Sprint accelerates. Creative keeps physical collision, normal lighting,
  unlimited placed blocks/seeds/bucket contents, no tool wear, and damage/hunger
  protection. Mode and flight state save with the world.
- `/gamemode survival` restores survival rules. Creative is never enabled by default.

## Authentic menu assets and appropriate contents

The panel, search panel, equipment panel, 26�32 selected/unselected top/bottom
tabs, scrollbar and category icons come from the supplied Minecraft texture
folder. The layout follows the reference: seven top tabs, five lower category
tabs and the lower-right inventory tab. The display keeps this game's 2D block
icons. There are no artificial extra pages for content the game does not have.
Tabs and both rows fit the screen at integer GUI scale; opening the menu does
not give a generic button keyboard focus.

327 canonical content records remain. The normal catalog exposes **246**, with
**81** hidden. Hidden entries include direct fluid blocks, lit furnace/snowy
grass states, bed halves, upper plant halves, crop growth stages, rotated/top/
double slab/stair states, and unfinished gameplay placeholders: horse armor,
music discs, unimplemented melon/pumpkin seeds,
powered/detector/activator rails and the static generated chest-minecart placeholder.
Buckets, seeds, normal beds, farmland, bedrock, working spawners and the implemented
spawn eggs remain available. Existing world blocks, loot, inventory and user-saved
hotbars are not deleted when an entry is hidden from the generated catalog.

`data/content.json` is authoritative. Each record has:

```json
"creative": true,
"creative_tabs": ["building"]
```

New records default to hidden until explicitly enabled. Supported tab keys are
`building`, `colored`, `natural`, `functional`, `redstone`, `tools`, `combat`,
`food`, `items` and `eggs`. Multiple tabs are allowed. Search includes all enabled
entries. Internal/fluid records are always excluded. `creative_tabs.json` supplies
native tab positions, labels and icons; `creative_order.json` groups wood families
and their shapes. The catalog refreshes on search/category changes, and redraws
for pointer/content changes instead of rebuilding continuously.

The Spawn Eggs tab contains eggs for the eleven existing mob types, using their
actual Minecraft item textures appended to the item atlas. They spawn this game's
supported adult mobs, respect clear loaded space/capacity, and consume eggs only
in Survival. The bookshelf tab is functional Saved Hotbars, not a decorative control.

## Fences

The previous 1.5-block collision was a literal Minecraft copy. Fences now use the
same side-view convention as other semi-solid blocks: pass through from the
side/below and stand on an uncovered top at the visible **one-block height**.
There is no tall invisible side wall. Covering a fence disables its exposed
platform top. Isolated fences show posts; compatible fences/full solid faces
add rails on the left/right. Edits update neighboring connections, including
chunk seams. Waterlogged variants retain their connections.

All twelve wood types plus nether brick are included: oak, spruce, birch,
jungle, acacia, dark oak, mangrove, cherry, pale oak, bamboo, crimson, warped and
nether brick. Missing plank materials were added for these recipes. Wood fences
use exact matching wood recipes; nether-brick fences have their corresponding
brick recipe. New sprites are appended; previous atlas pixels and item IDs are
preserved. Only oak previously existed, and it keeps its original ID.

## Held Use and command fixes

A single HeldUse controller now owns repeat timing and item-switch behavior.
Holding Use repeats valid placement at a 0.2-second interval as the cursor moves
to reachable empty cells. It does not restart an eating animation or bow charge.
A raised offhand shield no longer permanently takes over Use after switching to
food or moving to a newly valid placement target. A bow without ammunition
allows the offhand action; a real draw remains uninterrupted.

Survival food is still edible only when hungry, apart from explicitly
always-edible foods. Full hunger gives a clear message. Main-hand block use
keeps priority over eating. Opening inventory/chat/pause or otherwise disabling
interaction cancels held actions, preventing them from leaking behind a screen.

Experience supports Java-style commands and local single-player selectors:

```text
/experience add @s 10 levels
/xp add @p 25
/experience set @s 5 levels
/experience set @s 0 points
/experience query @s levels
/xp 10L
```

Points are the default for add/set. Setting points changes progress within the
current level and rejects values at or above that level's requirement. Levels
preserve proportional progress; negative add subtracts XP/levels with a zero
floor. Invalid commands do not mutate XP. Command deltas are bounded to 100,000
and level edits to 20,000 to retain the existing save limits. Add/set/query and
units autocomplete. @s, @p and the local username work; @a refers to the sole
player here. Give/clear/teleport/gamemode also accept these local selectors.

Other integration fixes include default durability for newly assigned tools,
non-recoverable creative arrows, non-consuming creative buckets/seeds, cancellation
of actions across screens, creative flight persistence, and recipe validation
that reports unknown ingredients instead of silently treating them as empty slots.

## Verification and compatibility

Twelve Godot 4.7.2 gameplay suites passed, covering real root mouse/key input,
shield-to-food switching, uninterrupted bow drawing, no-ammo fallback, repeated
placement, all thirteen fence connections/platforms/recipes, curated catalog
contents, typed search including E, scrolling, hotbar/equipment interactions,
actual C/X hotbar shortcuts and disk reload, spawn eggs, creative rules/flight,
XP syntax and saves, normal survival food, combat, mining, mob AI/currents,
structures/spawners/loot, storage/equipment/NBT, traversal, skins and rendering/
streaming regressions. Native OpenGL captures were checked against the reference.

Existing .tres overrides, UIDs, project identity, all prior content IDs and the
old regions of both atlases are preserved. Generated caches, preferences,
profiles and tests are excluded from the release. The installed source folder
was used as the baseline; this ZIP is the complete updated project.

## References

- [Minecraft: creative inventory changes](https://www.minecraft.net/nb-no/article/minecraft-snapshot-22w45a)
- [Minecraft Wiki: Creative inventory](https://minecraft.wiki/w/Creative_inventory)
- [Minecraft Wiki: Saved Hotbars](https://minecraft.wiki/w/Saved_Hotbars)
- [Minecraft Wiki: Experience command](https://minecraft.wiki/w/Commands/experience)
- [Minecraft Wiki: Monster Spawner](https://minecraft.wiki/w/Monster_Spawner)

This is a 2D adaptation. It does not add the full 3D item-model pipeline, a
complete enchantment system, rideable minecarts or horse systems.

Later updates enabled name tags, melon/pumpkin seeds and fully tagged enchanted
books; the old catalog counts above describe the initial fence/Creative release.
See [current book behavior](EFFECTS_BOOKS_MOVEMENT.md).
