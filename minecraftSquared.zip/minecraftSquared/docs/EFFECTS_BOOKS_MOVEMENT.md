# Effect icons, enchanted books and movement polish

## Status effects

The old HUD loaded each texture as a temporary resource inside `_draw`. Its RID
could be released before rendering, producing white rectangles. All nine
supported effect textures now have persistent preloaded references. They are
the native Minecraft mob-effect images already supplied in the project.

Effects render independently of the Survival hearts, so Creative players see
them too. Beneficial effects occupy the first row, harmful effects the second.
Rows wrap on narrow windows and stop before the hotbar. Short-duration effects
pulse while their background stays visible. Instant Health is applied immediately
and does not create a lasting effect icon. Water and awkward potions have no
timed effect. Opening a menu still uses the existing HUD visibility rules.

## Enchanted books

Plain books can be enchanted at an enchanting table using lapis and XP.
Existing loot books remain available. An anvil transfers stored enchantments
to compatible equipment, or combines equal-level books up to the enchantment's
maximum level. Incompatible enchantments are rejected by the existing rules.
Books use typed `StoredEnchantments`, not active equipment `Enchantments`, so
holding a book does not confer the enchantment's effect.

Creative Ingredients contains the maximum level of each supported enchantment.
Search contains every level and matches enchantment names (for example,
`efficiency`). These are generated stacks with metadata under the single
`enchanted_book` catalog ID, not duplicate content records. Hovering shows the
enchantment and level; copying, number-key hotbar assignment, saved hotbars,
containers and world saves retain that metadata. Books use the native icon,
an uncommon yellow title and the existing animated glint.

The currently supported set remains Efficiency, Unbreaking, Fortune, Silk Touch,
Sharpness, Protection and Power. The same `data/enchantments.json` definitions
generate Creative variants and power normal enchanting/anvil behavior.

## Eating and stepping

The eating arm holds food farther forward of the face, with a smaller bob.
Both directions and either hand share the same shoulder/wrist transform.
The new Inspector controls in PlayerSettings are `eating_arm_angle` (110 degrees)
and `eating_bob` (0.08 radians). Ordinary holding, mining, bow and shield poses
keep their existing transforms.

Ascending still uses the separate 0.6-block `step_height`. Descending uses
gravity, with only `floor_snap_distance` (0.1 world pixels) for contact tolerance.
The former 9.7-pixel floor snap moved an entire half-step in one physics tick.
An eight-pixel test descent now spans ten ticks with a maximum per-tick drop of
about 1.23 pixels. Camera/model interpolation and pixel alignment remain active.
Falls, jumps, crouch edge protection and blocked-headroom behavior are retained.

## Validation and references

The prior build reproduced white icons in a native render. The new native render
checks every opaque pixel in all nine icons against the original PNGs in both
Survival and Creative. Gameplay checks cover Creative metadata, anvil merges,
save round trips, real step-down physics, step-up/ceiling behavior and eating
hand clearance. Other existing inventory, food, combat and save checks are run
as regressions.

- [Minecraft HUD effect rendering](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/gui/Gui.java)
- [Minecraft Creative book variants](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/item/CreativeModeTabs.java)
- [Godot floor-snap behavior](https://docs.godotengine.org/en/stable/classes/class_characterbody2d.html#class-characterbody2d-property-floor-snap-length)
- [Microsoft's enchantment introduction](https://learn.microsoft.com/en-us/minecraft/creator/documents/introtoenchantments)

A grindstone is the next useful addition: removing unwanted enchantments and
refunding some XP would complete the current enchanting/anvil loop. Additional
enchantments should follow with their actual gameplay behavior.
