# Cleanup and platform update

Built from the supplied `minecraftSquared.zip`. Extract this full project into
a new folder and import `project.godot`. The original archive is unchanged.

## Removed

- Nine unused additive block/item/recipe/atlas/update JSON packs. Their entries
  already live in the canonical content, recipe, smelting and atlas files.
- Six interrupted scene saves, three legacy cave presets, seven `.mcmeta` files,
  and an unused title-image copy.
- The old update manifest, installer README and superseded release notes.
- 1,731 redundant atlas tile entries in `world.tscn`. Active tiles compile from
  the catalog, including their independent tint/collision alternatives.
- The retired integer-icon setting and stack-text/crisp-icon preference overrides.
  Font/icon sizing remains available in `interface.tres`.

Godot's generated `.godot` cache is excluded. Texture `.import` sidecars and
script `.uid` files remain to preserve import choices and references. Current
art, recipes, skin tools and resource overrides remain. Git ignores now cover
temporary files and local update backups.

Legacy generation parameters remain stored internally for existing worlds, but
are hidden from the Inspector. Active controls remain visible. Unused legacy
noise fields are not allocated during climate generation.

## Platforms and background walls

Small plants are non-colliding; cactus explicitly uses one-way platform
collision. Furnace/lit furnace use `workstation`, crafting tables/logs retain
wooden platforms. The player passes through sideways/from below and lands on
exposed tops. Stacked blocks expose only the uppermost top. Grass, flowers,
bushes and leaves cannot be stood on. Plants cannot support torches.

Wall culling uses `occludes_background`, compiled from sprite alpha and tint.
Cactus/flower/leaf/torch cutouts preserve the wall behind them; opaque sprites
still cull hidden wall geometry. Pixels are inspected once at startup, then
released. Drawing uses a cached boolean.

These fixes apply to existing worlds. Application identity and save format are
unchanged, so the existing user-data location is preserved.
