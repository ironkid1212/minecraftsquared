# Creative inventory, glint and bow polish

Import `project.godot` from the extracted project in Godot 4.7.2. Existing saves,
content IDs, atlas pixels, resource UIDs and `.tres` overrides are preserved.
Starter tools remain removed for new worlds.

## Creative inventory

Hovering now covers catalog slots, the owned hotbar, backpack, armor/offhand
slots, tabs and the destroy slot. Saved hotbar tooltips use the actual saved
name, enchantments, wear and tags. Shared viewport pointer state follows the
events delivered by embedded/forwarded input, stays current across screens and
clears hover when the mouse leaves the window.
Scrollbar dragging also cancels on window exit or a released mouse button.

| Action | Result |
| --- | --- |
| Click a catalog entry with an empty cursor | Pick up its displayed stack |
| Shift-click with an empty cursor | Pick up a full stack |
| Middle-click with an empty cursor | Clone a full stack |
| Left-click the same matching catalog item while carrying | Add one; Shift fills the stack |
| Right-click while carrying | Remove one from the cursor stack |
| Left-click a different or empty catalog cell while carrying | Discard the carried stack |
| Shift-click an owned creative inventory/hotbar slot | Discard that slot |
| Click the destroy slot | Discard the cursor stack; Shift clears inventory |
| Click outside the panel while carrying | Drop into the world; right-click drops one |

The matching check includes item metadata and durability. Discarding clears all
cursor fields, preventing leftover names/enchantments/wear. Number-key transfers
from saved hotbars preserve their metadata. Tooltips remain hidden while an
item is carried, following the normal cursor-stack interaction.

These controls were checked against the
[Java creative screen implementation](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/client/gui/screens/inventory/CreativeModeInventoryScreen.java).

## Bookshelf placement

Full power still requires six shelves. They can be anywhere within a circular
four-block radius, including adjacent, higher or lower cells. Walls and other
blocks do not obstruct their power. Shelves outside that radius do not count.
The menu's book tooltip reports the count. The cap and radius are in
`data/enchantments.json` under `table.max_bookshelves` and
`table.bookshelf_radius`. The old offset/air-gap configuration has been removed.

Only nearby bookshelf edits invalidate the count, so the enchanting screen
reuses it while the environment is unchanged.

## Glint strength in the editor

Select **data/settings/interface.tres** in Godot's FileSystem dock. In the
Inspector, expand **Enchantment glint**, then adjust **Enchantment Glint
Strength**:

- **0:** no visual glint; enchantment gameplay effects still work.
- **0.30:** subtle default.
- **1:** strongest glint.

Save the resource to persist the choice. The setting covers inventory, hotbar,
cursor and workstation icons; saved hotbar stacks; dropped/held items; drawn bow
stages and shields; and worn armor, including inventory previews. It supports
live resource changes without rebaking the animation textures.

The effect uses the supplied Minecraft item-glint texture and the item's actual
alpha mask. It does not color empty pixels, counts or durability bars. Frames
are cached once per sprite region, and
[CanvasItem animation slices](https://docs.godotengine.org/en/stable/classes/class_canvasitem.html#class-canvasitem-method-draw-animation-slice)
advance them on the renderer. There is no per-frame image generation/upload or
node per inventory icon. The shared cache is bounded; current draw batches keep
their texture references so eviction cannot invalidate a displayed animation.

## Resting bows and checks

The idle bow previously used a fixed offset from the shoulder. It now uses the
same wrist transform as the arm, including walking/swinging, both facings and
either hand. Its resting firing axis points down relative to the arm. Drawing
and releasing retain the existing aimed grip, pulling textures and projectile
origin. The shared `bow_transform` keeps those two modes explicit.

Automated checks exercise actual mouse input, catalog disposal/count changes,
cloning, saved metadata, empty catalog cells, outside drops, shelf radius through
walls, both bow transforms and glint alpha/cache behavior. Native rendering
checks the creative hotbar, bag and saved tooltips; idle/charged bows; glint
animation without redraw; and live strengths 0/0.3/1. Gameplay regressions cover
enchanting, smelting, equipment, creative use, mining, ranged combat, traversal,
world saves and existing optimization behavior.
