# 2D player skins, format v1

The game now loads one compact **48×32 RGBA PNG** for each skin. Steve was
converted from the 64×64 PNG you supplied. Unneeded cube fronts/backs/tops/bottoms
are discarded. The head and hat use their full, unmodified side faces.
The source file was not modified and is not required at runtime.

## Use a different skin

The title menu Profile screen can import, convert and select skins. Uploaded
skins and the selected username are stored under user://skins. The steps
below change the project default instead.

1. Copy a skin in this 48×32 layout into `assets/skins/`.
2. Select `data/settings/player.tres` in Godot.
3. Set **Skin Texture** to that PNG, save, and restart the game.

To edit Steve, duplicate `assets/skins/steve_2d.png` and paint the parts in a pixel
editor. Keep transparency, the dimensions and part positions. A 96×64 or another
integer multiple of 48×32 also works; it keeps the same body proportions.
Both in-game rendering and the inventory preview use this same texture.

`Skin_Layout.svg` labels every part. The SVG is a guide, not the texture to load.

## Layout

The PNG has two **24×32 banks**:

- Left half, x=0–23: facing right. The character's anatomical right side is near.
- Right half, x=24–47: facing left. The anatomical left side is near.

Coordinates below are **local to a bank**, with origin at its top-left. Add 24
to X for the left-facing bank. Sizes and coordinates are in source pixels at 1×.

| Part | X | Y | Width | Height |
| --- | ---: | ---: | ---: | ---: |
| Head | 0 | 0 | 8 | 8 |
| Hat/head outer layer | 8 | 0 | 8 | 8 |
| Torso | 0 | 8 | 4 | 12 |
| Near arm | 4 | 8 | 4 | 12 |
| Far arm | 8 | 8 | 4 | 12 |
| Jacket/torso outer layer | 12 | 8 | 4 | 12 |
| Near sleeve outer layer | 16 | 8 | 4 | 12 |
| Far sleeve outer layer | 20 | 8 | 4 | 12 |
| Near leg | 0 | 20 | 4 | 12 |
| Far leg | 4 | 20 | 4 | 12 |
| Near trousers outer layer | 8 | 20 | 4 | 12 |
| Far trousers outer layer | 12 | 20 | 4 | 12 |

Unused cells stay transparent. Outer-layer cells can also stay fully transparent.
All limbs are stored vertically with their tops at the top of their rectangle.
Do not paint a posed arm/leg: the game rotates each part around its shoulder/hip.
The head is 8×8, torso 4×12 and legs 4×12, making the assembled player 32 pixels
tall (two blocks). Each direction is authored independently, so asymmetric
clothes, sleeves, hair and skin details survive turning.

Both arms are centered on the torso in side view. Their shoulder pivot is two
pixels below the torso top, matching the classic model's arm attachment. Far limbs are shaded slightly for depth. Transparent
hat/jacket/sleeve/trouser layers are drawn over their corresponding base parts.
Outer layers expand slightly beyond their base parts. Hat and clothing expansion are configurable in player.tres.

## What was taken from Steve

For the right-facing bank, the right side of the head/torso and right arm/leg
are nearest the camera. The matching inward sides of the left arm/leg are kept
as far limbs. The left-facing bank uses the other sides. Both head and clothing
outer layers are retained, with their alpha channel.

The head and hat are exact eight-column side crops. No front-face slices or
painted eyes are included. Left and right head textures are kept independently.

UV rectangles are explicit in `scripts/player/minecraft_skin_converter.gd`.
The renderer uses `scripts/player/player_skin_drawing.gd`; it never needs the
original 3D skin at runtime. The conversion uses exact image-region copies.

## Convert another Minecraft skin

The included offline tool accepts **classic/Steve-layout** 64×64 PNGs and their
integer HD multiples. Legacy 64×32 PNGs also work: missing left limbs are mirrored
from the right and missing clothing layers are transparent. Alex/slim UV layouts
are not supported yet; skin dimensions alone cannot identify the arm model.

With the project imported, run this from a terminal (replace both absolute paths):

```powershell
& 'C:\Program Files\Godot\Godot 4.7.2.exe' --headless `
  --path 'C:\path\to\minecraftSquared' `
  --script res://tools/convert_minecraft_skin.gd -- `
  --input 'C:\skins\my_minecraft_skin.png' `
  --output res://assets/skins/my_2d_skin.png
```

Head side UVs are always used directly. The output directory must already exist. The tool writes only the requested output PNG. Let Godot import
the new texture, then assign it to Player Settings → Skin Texture.

Skin conversion is a development tool, not an in-game file picker. Loading a new
PNG requires no changes to the movement, renderer or inventory scripts.

For Minecraft's original PNG-skin/metadata approach, see the official
[Introduction to Skin Packs](https://learn.microsoft.com/en-us/minecraft/creator/documents/skinpack?view=minecraft-bedrock-stable).
Our 48×32 layout is specific to this game, not a Minecraft-compatible skin format.

## Animation and physics settings

`player.tres` exposes **Outer Layers**, **Far Limb Brightness**, **Walk Swing**,
**Stride Length** and **Leg Swing Multiplier** alongside movement.
Walk phase advances with actual distance travelled; pushing against a wall does
not run the walking cycle. On stopping, the limbs settle into their idle pose.
There is no fixed jump/fall spread: vertical jumps stay neutral and moving
jumps continue the horizontal locomotion cycle. Legs swing 1.4 times as much
as arms by default. This is a 2D adaptation of Minecraft locomotion. The
preview uses idle legs plus the held item and head pose frozen when opening
the inventory. See `player_interaction.md` for the newer mouse/hand controls.

The collision rectangle is now 12×32 at local `(0, -2)` so it covers the head and
keeps the feet at local Y=14, as before. The skin is drawn at native world-pixel
size with nearest filtering. Arms/legs may extend outside the fixed collider
during animation. The existing per-block world lighting shades the whole model;
the inventory preview stays unlit like the rest of the UI.

## Checked for this update

- Extracted part pixels match the supplied Steve image; head sides and unused
  transparent cells match the documented layout.
- Independent near/far limbs and both directions survive an asymmetric test skin.
- Normal, legacy, HD and invalid-size conversion paths were exercised.
- The texture is loaded through a normal exported Texture2D resource; custom
  sizes are validated before the world starts.
- Actual movement changes direction and walk phase; stopping returns to idle.
- Both directions and idle/walk/jump poses were rendered on the GPU, along with
  the in-world model and shared inventory preview.
- Mining/finite placement, crafting table interaction, one-way platforms,
  covering/uncovering blocks, chunk reloads and dropped-item support still pass.

Checks used Godot 4.7.2; screenshots used its Compatibility renderer. The full
project retains its existing Forward Plus/D3D12 preference. Sandbox OS logging
and certificate-store warnings were separate from the successful script checks.

## Player layering fix

The player scene has Z Index 20, above TargetOverlay at 10 and terrain at 0.
Mining cracks and the selection border still draw on their block but are
occluded by the player's opaque skin pixels. The inventory remains on its
existing CanvasLayer above world drawing.

Minecraft locomotion reference: Mojang's official
[player animation definitions](https://github.com/Mojang/bedrock-samples/blob/main/resource_pack/animations/player.animation.json)
use opposing arm/leg swings, with larger leg rotation. This game projects that
movement into 2D; it does not reproduce every Minecraft animation state.
