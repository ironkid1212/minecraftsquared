# Day/night sky and lighting

The world runs a saved 24,000-tick day. By default a full cycle takes twenty
real minutes and new/older worlds start at tick 1000, in the morning. The sun and
moon move across a 2D sky arc, rising at the right (east/+X) and setting at the
left (west/−X). Day, dusk, night and dawn blend sky colors and surface lighting.
Moon phase changes once per day through all eight supplied textures.

Stars use a stable pattern seeded from the world seed, with small differences
in size and brightness. The pattern drifts together across the sky instead of
reshuffling or individually twinkling. Stars fade in at dusk and out at dawn.
They are behind terrain, foliage and cave walls, alongside the celestial sky.

## Textures

`assets/environment/` contains exact copies of the supplied texture pack's
sun, eight moon phase PNGs and cloud map. Sun/moon textures use their original
black backgrounds with additive sprite blending. Cloud silhouettes use selected
patches of the original cloud map, with a shaded lower edge for the side view.
The sky gradient and seeded stars are drawn geometry; there is no star PNG in
the supplied environment folder.

## Customize

Open `data/settings/day_night.tres` in Godot. `game.tres` picks up this resource
through GameSettings. All world sessions get independent copies.

| Field | Purpose |
| --- | --- |
| Enabled | Initial clock-running value for new/older saves |
| Cycle Seconds | Length of a whole day and night; default 1200 seconds |
| Initial Time | Starting tick, 0–23999 |
| Night Sky Light | Night multiplier on geometric skylight |
| Night Ambient Factor | Night multiplier on surface fill light |
| Lighting Steps | Quantized color-update precision, default 128 |
| Day/Night Zenith/Horizon, Twilight Color | Sky palette |
| Horizon Height / Arc Height | Screen-space celestial path |
| Sun Size / Moon Size | Logical world-viewport pixels |
| Star Count / Star Brightness | Night star field density and strength |
| Clouds Enabled / Cloud Speed | Texture-map silhouettes and drift |

UI scaling and clock length are independent. The HUD remains at its existing
brightness. Torches retain their emitted light; only sky/surface fill changes.
Spectator still has fullbright terrain while the sky and clock show real time.
Grass survives normal nights, and effective low light limits grass spreading.

Pause/options freeze the clock. Chat, inventory, death screens and ordinary play
do not. Closing a world saves its current time/running flag; offline time is not
added. Existing beds retain their respawn-point behavior.

## Commands

```text
/time set day
/time set noon
/time set sunset
/time set night
/time set midnight
/time set sunrise
/time set 12500
/time add 24000
/time query daytime
/time query day
/time query gametime
/gamerule doDaylightCycle false
/gamerule doDaylightCycle true
```

`set` changes the time within the current day; `add 24000` advances a full day
and moon phase. Query returns the within-day tick, day number, or total ticks.
The runtime cycle flag is saved with the world. F3 includes day, clock time and
the current tick. `/help time` and `/help gamerule` show usage in game, and the
new forms participate in chat completion.

## Implementation and validation

`DayNightCycle` owns the clock and save snapshot. `DayNightSky` owns sky geometry
and celestial textures. `WorldLighting` caches the propagated sky/torch fields,
solid shading and daytime ambient values. Clock changes recombine these into
block colors at quantized steps; they do not rescan roofs, rerun light flooding,
rebuild TileMap collision or update offscreen block meshes. Daytime rendering
keeps the original light response. A hidden old sky rectangle avoids drawing
two full backgrounds.

The save store accepts an optional `clock` object and validates finite tick
ranges and the running flag. Old saves receive the configured initial time.
Content IDs, application identity and the rest of world state remain compatible.

Tested in Godot 4.7.2: day/night transitions, wrap/phase progression, pause,
freeze/unfreeze, commands, save/reload and older saves; unchanged light fields
and propagation count under time changes; torches, spectator and grass survival;
native noon/dusk/night/dawn rendering; scrollable completion with keyboard,
wheel and click; unchanged hotbar pixels at three window sizes. Existing controls,
world updates, rendering/culling, falling blocks, platforms and survival checks pass.

Time preset reference: [official Minecraft Creator TimeOfDay documentation](https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/timeofday?view=minecraft-bedrock-stable).
