# Fidelity fixes � 27 October 2026

Historical notes: the latest [creative/fence update](CREATIVE_USE_FENCES.md)
replaces the tall fence barrier with the requested semi-solid behavior.

Import this complete project in Godot 4.7.2. Extract it into a fresh folder, then
open its project.godot. The project identity and user:// save location are unchanged.

## Fences

Oak fences now render as a narrow post when isolated. Left/right rails appear
beside compatible fences or full solid block faces, and disappear immediately
when those neighbors are removed. Platforms, flowers, leaves and half slabs do
not count as full solid faces. A full-height stair side can accept a connection.
The horizontal connections are the side-view adaptation of Minecraft's four
horizontal directions. Fences have a two-way 24-pixel (1.5-block) collision
barrier rather than the old one-way platform. Navigation no longer assumes their
visible one-block top is a reachable floor.

Four new sprites use the existing oak planks texture, appended at atlas row 71.
No previous atlas pixels or item IDs were replaced. The existing oak_fence ID is
unchanged, so fences in old saves acquire the new behavior automatically.
Connections also survive waterlogging and save/reload. The renderer still uses
culled chunk meshes; connection refreshes happen on edits/chunk drawing, and
collision tile alternatives are reused when reopening a world.

A `fence` object in the canonical content.json controls the connection group,
four tiles (post/left/right/both) and collision height. There is no extra block
database. Mining sight tests use the visible post/rails so an isolated fence is
not treated as a solid square. Placement checks include the taller collision
shape to avoid placing a barrier through the player or a mob.

## Shields

Hold Use (right mouse by default) with a shield selected or in the offhand.
Usable blocks and main-hand actions keep their existing priority. A shield
raises after 0.25 seconds, slows movement, blocks frontal melee/projectiles/blast
damage, consumes durability and drops immediately on release. Rear hits and
unblockable environmental damage still get through.

The frontal test now uses left/right facing, independently of vertical head
pitch. Looking steeply up/down no longer lets a nearby frontal enemy bypass the
shield. Switching between main-hand shields while holding Use restarts the
raise delay. A disabling axe hit is blocked first, then disables blocking for
five seconds. The current mobs do not all wield axes; that hook is retained for
future axe-bearing mobs. Newly created tool/shield stacks also receive their
normal durability when the caller omits that field.

## Ladders and vines

Hold W/Up/Space to climb, release to stop rising and begin sliding, S/Down to
descend, and Shift to grip. These are the defaults and remain rebindable.
Release now clears upward momentum instead of leaving the player climbing
forever. Sneaking grips and fall-distance resets continue to work. Explicit
vertical controls suit the side-view game; Minecraft's 3D walk-into-wall climbing
is not copied literally.

## Movement and interface

Creepers, adult zombies and spiders no longer receive a mismatched 1.25 chase
boost on top of their Java-style base attributes. On ordinary flat ground the
measured steady travel is about 2.70 blocks/s for creepers and skeletons,
2.28 for adult zombies, and 3.89 for spiders. Jumping, panic/tempt goals, water,
knockback and effects remain separate. These are this adaptation's calibrated
ground speeds, rather than a claim that every mob action is frame-identical to
all Minecraft editions.

Crafting titles use the proper panel offsets, the crafting-table Inventory label
is restored, Furnace is centered, and chest labels align with their slots.
A shared font-ascent helper converts native GUI coordinates into text baselines
at the final integer UI scale. Stack counts sit one native pixel farther right
and down by default, matching Minecraft's slot edge placement. Custom stack
position overrides in interface.tres still take priority.

## Verification

Godot 4.7.2 import and ten gameplay suites passed: actual root mouse shield use,
natural ladder key press/release, fence connections across a chunk seam,
post-only collision width and 1.5-block barrier, tile reuse, waterlogged-fence
save/reload, measured mob ground movement, food input, shield/arrow/status
combat, mob AI/currents, equipment/storage, mining, survival/spawner saves,
traversal/death and rendering/streaming optimization regressions.

Native OpenGL screenshots were checked for fence states, waterlogged rails,
equipment inventory, crafting, furnace and chest labels, including UI scales
1�4. User .tres resources, existing UIDs, project identity, original atlas pixels
and all 294 content IDs are preserved. Generated caches and test artifacts are
excluded from the release.

## References

- [Minecraft Wiki: Fence](https://minecraft.wiki/w/Fence): connections and 1.5-block collision.
- [Mojang fence-side model asset](https://mcasset.cloud/1.21.9/assets/minecraft/models/block/fence_side.json): the two rail heights used for the 2D projection.
- [Minecraft Wiki: Shield](https://minecraft.wiki/w/Shield) and [Blocking](https://minecraft.wiki/w/Blocking): activation delay, front-facing protection and shield disabling.
- [Minecraft Wiki: Ladder](https://minecraft.wiki/w/Ladder): ascent, slide and sneaking grip.
- [Mojang Bedrock creeper behavior data](https://github.com/Mojang/bedrock-samples/blob/main/behavior_pack/entities/creeper.json): illustrates why edition-specific base movement and goal multipliers must be considered together, not mixed.
- [Minecraft Wiki: Zombie](https://minecraft.wiki/w/Zombie), [Spider](https://minecraft.wiki/w/Spider) and [Attribute](https://minecraft.wiki/w/Attribute): Java movement attributes and species differences.

This is a targeted fidelity and integration pass. It does not claim complete
parity with every Minecraft system or edition.
