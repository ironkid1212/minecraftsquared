# Building variants, lush caves and travel

## Blocks and recipes

54 new inventory items provide 188 saved shape orientations. Added families:
stone brick, mossy stone brick, mossy cobblestone, brick, cobbled/polished deepslate,
deepslate brick/tile, granite/diorite/andesite and their polished forms, red/smooth
sandstone, smooth red sandstone, cut sandstone/red sandstone slabs, red Nether
brick, and jungle/dark oak/mangrove/cherry/pale oak/bamboo/crimson/warped wood.
Cut sandstone has slabs only, matching Minecraft's available shapes.

New families support normal and inverted stairs, upper/lower/double slabs,
collision, waterlogging, background placement, drops, tool hardness, Creative
building categories and Survival recipes. Wood recipes match the exact species;
generic sticks and crafting tables still accept mixed planks. Overworld wooden
slabs and stairs are furnace fuel; crimson and warped wood are not.

Added missing full masonry materials and their crafting/smelting progression:
polished stones/deepslate, deepslate bricks/tiles and cracked versions, chiseled
stone brick/deepslate, cut/smooth sandstone variants and red Nether brick.
Existing IDs, settings resources, and original atlas pixels are retained.
Sunflower upper tiles now combine the actual native stem and flower face.

## Lush caves

The original algorithm only decorated existing narrow tunnels and only admitted
pools in single-cell pockets. Revision 2 creates deterministic 40�60-block-wide,
18�26-block-high chambers inside humid underground patches. Existing cave
networks connect through them. Moss, azaleas, short grass, hanging vines with
glow berries and spore blossoms decorate the exposed ground and ceilings.
Shallow pools have clay bottoms and clay banks instead of one-cell holes.
Natural structures retain priority over these chambers.

Tune the `lush` object in `data/strongholds.json`: `chamber_width` and
`chamber_height` are horizontal/vertical **radii**, `chamber_chance` controls
frequency within eligible regions, and `chamber_pool_chance` controls pools.
`frequency`, `threshold`, depth, vine chance and minimum world Y remain editable.

## Biomes and mobs

Grove is a snowy spruce foothill biome. Mushroom Fields is a rarer, humid,
low-continentalness region with mycelium and giant red/brown mushrooms. Our 2D
Overworld has no full ocean-island generator, so this is a climate-based region
rather than a copy of Minecraft's offshore island placement. Natural hostile
spawning is suppressed there, and mooshrooms spawn on mycelium.

Desert surface husks use native texture UVs, zombie movement, sunlight immunity
and Hunger on unblocked melee hits. Mooshrooms use native cow UVs with attached
mushrooms. Wheat breeding, milk buckets, mushroom stew from bowls, and shearing
into an ordinary cow with five mushroom drops work and persist. Both mobs have
Creative spawn eggs. The Husk's configurable `head_neutral_angle` keeps tiny
head tilts from looking like a sideways-shifted cap; deliberate turns remain.

## Performance and compatibility

Lighting now reads committed chunk arrays directly. Unloaded cells are opaque
boundary guards, so lighting never generates those chunks outside the streaming
budget. Committing chunks invalidates the guard cells. Missing roof columns are
prewarmed over several frames. Generation and tile commits check the time budget
every four cells rather than after a whole column. Existing visible chunk meshes,
light caches and culling remain in use.

Legacy lush vines use a local seven-cell probe, with the exact old column output
verified in tests. This avoids scanning a whole underground column during travel.
No debug HUD or profiling output is added to the game.

A representative 200-step headless travel probe on this machine reduced median
measured chunk+lighting work from approximately 6�8 ms to 2�3 ms. Worst measured
passes dropped from roughly 760�970 ms to approximately 23�130 ms across repeat runs. These are controlled local
measurements, not a promise of a minimum frame rate; initial loading, large edits,
and hardware still affect performance.

Worlds save `biome_revision` and `lush_revision`. Old saves keep their generation;
new worlds default to biome revision 6 and lush revision 2. Inventory IDs and
all new mob states are stable. Create a new world to explore the new layout.

## References

- [Minecraft: Lush Caves](https://www.minecraft.net/en-us/article/around-block--lush-caves)
- [Minecraft: Mushroom Fields](https://www.minecraft.net/en-us/article/around-block-mushroom-fields)
- [Minecraft: Meet the Husk](https://www.minecraft.net/en-us/article/meet-husk)
- [Minecraft biome guide](https://help.minecraft.net/hc/en-us/articles/360046470431-Minecraft-Types-of-Biomes)

These guide the habitat and gameplay rules; geometry and biome placement are
adapted to a side-view game rather than claiming Java seed compatibility.
