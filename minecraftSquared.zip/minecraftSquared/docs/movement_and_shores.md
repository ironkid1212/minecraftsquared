# Movement, waterlogging, fancy oaks and shores

## Controls

| Action | Default |
| --- | --- |
| Crouch / sneak | Hold Shift |
| Sprint | Hold Ctrl while moving, or double-tap A/D or the movement arrows |
| Swim sprint | Sprint while submerged and moving horizontally |
| Swim upward | Hold Space; also works during swim sprint |
| Dive | Hold Shift in water |

All actions are rebindable under **Options → Controls**. Sneaking moves at 30%
of walk speed and prevents walking off an unsupported edge while grounded. It
also bypasses workstation/bed use so blocks can be placed while sneaking. Running
uses a 1.3 multiplier. Releasing movement or crouching cancels a sprint. Swim sprint
uses a horizontal skin pose and a 28×10-pixel collider, aims up/down toward the
pointer, and accepts Space/Shift for explicit ascent/descent. Releasing sprint
input follows the normal sprint latch until movement stops, as on land.

Standing, crouching and swimming have distinct collision sizes. Standing up is
blocked until there is enough room; saved worlds preserve the safe collision
pose. Chat, inventory, death and spectator handling retain their existing rules.
The inventory preview keeps its independent animated presentation.

Movement multipliers, crouch/swim sizes, double-tap time and edge protection are
exported by **data/settings/player.tres**.

## Waterlogging

The unified **data/content.json** now has `waterloggable`, defaulting to false.
Oak and birch leaves enable it. Logs, cacti, workstations and full terrain blocks
remain non-waterloggable, matching the currently implemented vanilla block types.
Future cutout blocks can opt in without another block database.

Use a water bucket directly on an eligible block, or place that block into water.
The water becomes a source held alongside the block. An empty bucket removes the
water and retains the block; breaking the block leaves its water behind. Placing
an incompatible replacement displaces it. Flowing water does not automatically
waterlog every leaf it passes. Lava cannot waterlog a block.

Waterlogged cells feed normal flow, hydrate sugar cane, affect swimming and light
absorption, and participate in water–lava contact. They render water behind the
block's world texture with the usual light tint; the normal mesh skips that
foreground tile so it is not drawn twice. The background wall remains intact.
Waterlogged coordinates are saved as optional metadata and survive chunk unloading.

## The supplied fancy oak reference

The supplied **fancy_oak.png** is 224×256 pixels, representing **7×8 blocks at
32 pixels per block**. Its trunk is one block wide. New fancy oaks use that exact
block layout, rather than thick procedural branches. The layout is editable in
**data/fancy_oak_shapes.json**:

- `.` = empty space
- `L` = leaves
- `W` = a log
- `X` = a log with a guaranteed cosmetic leaf overlay; it still behaves as a log

Trees may mirror the layout and extend the bare trunk by up to two blocks. Those
variations are configurable in **data/settings/tree.tres** using
`fancy_mirror_chance` and `fancy_extra_trunk`. Set both to zero for the exact
unmirrored 7×8 reference. Regular oaks and birches retain their established shapes.
Every log inside a canopy gets its leaf overlay; the random coverage percentage
has been removed. This also covers the exposed fork cell inside the supplied
reference's crown. Bare trunk sections below the canopy stay bare. When the real
surrounding leaves are removed, the cosmetic overlay disappears as well.

## Low sand banks and sugar cane

New lakes have sand on **both** water-facing borders. The first bank column is at
the water source's row, which permits sugar cane roots beside it. Remaining sand
columns are zero or one block above that row. A wider graded strip joins the beach
back to surrounding terrain. Shore width, depth and grading width are editable in
**data/settings/fluid.tres**; the grading does not raise the immediate bank above
the one-block limit.

Sugar cane appears probabilistically on suitable shoreline sand and is also
placeable by the player. Its base needs sand, dirt or grass with water beside the
soil block; a waterlogged neighbor also qualifies. Higher segments can stand on
other cane. Cane is a pass-through plant, never a platform. Random ticks increase
the top segment's age; after 16 successful growth ticks it grows another segment,
up to three blocks tall. Removing the base, substrate or nearby water triggers
normal support checks and drops unsupported segments. Growth ages are saved.

Sugar cane's substrate, maximum height and growth-tick count live in its catalog
`updates` record. The generation chance is `sugar_cane_chance` in fluid settings.

Create a **new world** for the new oak shapes, low sand shores and naturally
generated cane. Existing saves retain their original terrain/tree generation;
movement, waterlogging, and manually planted cane work in them. Missing new save
metadata defaults safely. The generation revisions are stored per world.

## Checks and sources

Verified all 56 cells against the reference template; sampled 720 randomized bank
columns and actual generated shore/cane columns on both sides. Physics checks cover
sprint, double-tap, crouch ledges, blocked standing, swim sprint and diving. Water,
growth ages and collision poses are exercised through save/load. Native render
checks cover trees, shores, waterlogged leaves and the skin poses.

- [Vanilla sugar cane support and growth, mapped source mirror](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/block/SugarCaneBlock.java)
- [Vanilla waterlogging, mapped source mirror](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/block/SimpleWaterloggedBlock.java)
- [Vanilla movement, mapped source mirror](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/player/LocalPlayer.java)

These are 2D adaptations. Oxygen/drowning and terrain fire spreading remain outside
this update.
