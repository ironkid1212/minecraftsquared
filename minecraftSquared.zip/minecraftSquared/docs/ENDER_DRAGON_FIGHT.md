# End fight

Import `project.godot` in Godot 4.7.2 after extracting the ZIP into a fresh folder.
Existing worlds and their Overworld/Nether edits are supported. The first visit
to an existing End without fight data starts its dragon encounter.

## Encounter

The End now has a 200-health dragon, a native purple boss bar, ten destructible
crystals and healing beams. Arrows can hit the flying dragon. Aim melee attacks
at its head during a landing: the head takes full damage, while other parts take
one quarter of damage plus a small bonus. Ordinary weapon cooldown, critical
hits, enchantments and tool wear apply. The perched dragon rejects arrows.

The dragon patrols, strafes with fireballs, charges, lands, scans, roars, breathes
and takes off. A roar warns of the perched breath attack. Fireballs create
lingering purple clouds rather than terrain explosions. Clouds deal magic damage
and can be bottled with glass bottles to obtain Dragon's Breath. Crystal blasts
are dangerous; destroying the crystal currently healing the dragon also hurts it.
Creative, spectator and dead players are not attack targets.

The first victory pays 12,000 XP over the death sequence, places one dragon egg
and unlocks the return fountain. Repeated victories pay 500 XP. Health, phase,
crystals, projectiles, clouds, rewards and resummoning progress persist across
saves and dimension changes. Returning through the fountain uses the existing
bed/world-spawn logic. [Outer islands and gateways](OUTER_END_GATEWAYS.md) are
now included in the subsequent expansion.

Craft an End Crystal with seven glass, an Eye of Ender in the center and a Ghast
Tear in the bottom center. Place crystals on obsidian or bedrock with room above
and no overlapping player, mob or crystal. To resummon after winning, put four
crystals on the fountain at X=-3, -1, 1 and 3. The outside pair sits on the raised
rim. The ritual rebuilds the ten pillars and crystals over roughly 30 seconds.
Breaking a ritual crystal interrupts it and reopens the return portal.

## Side-view adaptations and fixes

- Ten distinct pillars are spread horizontally so all are usable in 2D. Their
  heights retain the shuffled vanilla sequence; radius increases with height.
  Shafts extend under each column's actual local terrain, fixing rare gaps.
- Two cages cover the 79- and 82-high pillars. Their footprint stays five blocks
  wide rather than growing with the pillar. Thin posts and roofs have matching
  collision; the rear bars and pillar shafts remain background structures.
- Crystals use the native glass, rune and bedrock texture. Flat glass-frame and rune sprites bob over a single side-face base. All anchors use the Ground
  TileMap transform, including its existing 13-pixel offset.
- The dragon uses native side-face texture regions, an articulated jaw, four
  legs, two projected wings, five neck segments and twelve tail segments.
  A small native eye patch is projected onto the side of the head so its eyes
  remain visible from this game's strict side camera.
- Flight altitude and patrol paths fit a side-view arena. Player reach and
  occlusion still apply; the same transformed pose supplies combat hit regions.
- The four resummoning locations run along a line instead of four compass
  directions. The egg can be mined directly; piston-assisted collection and its
  teleport-on-hit behavior are not implemented here.

Rendering culls offscreen crystals, dragon geometry, projectiles and particles.
Projectiles/clouds have hard caps, block destruction has a per-update budget,
and pillar rebuilding is spread across physics frames. There are no per-block
End entity nodes and no whole-world lighting pass added for this encounter.

## Data

- `data/dragon_fight.json`: health, healing, attack phases, damage, flight,
  projectiles/clouds, rewards, respawn timing, immune blocks and work limits.
- `data/dragon_model.json`: side-face UVs, dimensions and segment counts.
- `data/end.json`: island, arrival, pillar positions/heights, cage size and
  foundation depth. Pillar radius follows the height formula.
- `data/content.json`: authoritative item/block entries, crystal and egg icons,
  partial cage collision and internal states. No second item database is added.
- `data/recipes.json`: End Crystal recipe.

## Research and verification

Mechanics were checked against Minecraft's decompiled 1.21.1 game classes and
native assets/tags from the locally installed 26.3 client. These versions are
recorded deliberately; this is a 2D adaptation rather than a claim of complete
version parity. The Minecraft Wiki pages are useful further references.

- [Dragon entity: damage, healing and death](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/entity/boss/dragon/EnderDragonEntity.java)
- [Dragon model and rendering](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/client/render/entity/EnderDragonEntityRenderer.java)
- [Crystal model and animation](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/client/render/entity/EndCrystalEntityRenderer.java)
- [Pillars and cages](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/world/gen/feature/EndSpikeFeature.java)
- [Dragon phase classes](https://github.com/Soumeh/1.21.1-Deobfuscated/tree/main/minecraft/src/net/minecraft/entity/boss/dragon/phase)
- [Fight and resummoning](https://github.com/Soumeh/1.21.1-Deobfuscated/blob/main/minecraft/src/net/minecraft/entity/boss/dragon/EnderDragonFight.java)
- [Minecraft Wiki: Ender dragon](https://minecraft.wiki/w/Ender_dragon),
  [End crystal](https://minecraft.wiki/w/End_crystal),
  [End spike](https://minecraft.wiki/w/End_spike).

Verification covers 100 seeded pillar layouts, transformed crystal anchors,
healing, multipart melee and actual projectile handling, perched immunity,
phase transitions, breath/bottling, saved dimensions and fight/death state,
exact first/repeat XP totals, egg/exit unlock, actual crystal item placement,
interrupted and saved/resumed resummoning. Native renderer captures check both
flight directions, wing poses, perching, breath, death and the two cages.
Existing combat, building, lighting/targeting, inventory, portal, Nether,
streaming, farm/mob and food-input regression checks also pass.
