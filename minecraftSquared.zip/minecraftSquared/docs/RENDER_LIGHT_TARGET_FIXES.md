# Head attachments, skeleton bows, held light and targeting fixes

## Head models

Pig snouts and chicken beaks/wattles now use their head's transform for both side views and idle glances. Cow snouts have also been added: the supplied modern cow textures include a separate muzzle that the previous compact conversion omitted. All three cow variants use their appropriate snout UVs, and the warm/cold variants have distinct horn shapes. Normal cow horns also belong to the head transform.

`data/mobs.json` owns the attachment geometry under each mob's `head_attachments` record. Each `side` or `front` entry specifies a source rectangle and destination bounds. The optional `variants` dictionary supplies geometry overrides for temperate/warm/cold models. Front bounds are relative to the head's center, and side bounds use the head's local coordinates. The common `MobDrawing.head_part()` draws these children after the head. `assets/mobs/head_attachments.png` stores three 16-pixel regional rows; source art is copied directly from the supplied textures.

Other existing mobs were checked: sheep head/wool already share a transform, while zombie, creeper, skeleton and spider faces use their head geometry directly. Spider eyes share the head transform. No detached facial attachment remains in the existing mob drawing functions.

The modern cow snout is documented in [Mojang's 25w05a changes](https://www.minecraft.net/en-us/article/minecraft-snapshot-25w05a). The geometry and UV checks also use the reproduced Mojang-mapped [CowModel](https://mc-packet-reference.netlify.app/26.x/source/net/minecraft/client/model/animal/cow/cowmodel/), [ColdCowModel](https://mc-packet-reference.netlify.app/26.x/source/net/minecraft/client/model/animal/cow/coldcowmodel/) and [WarmCowModel](https://mc-packet-reference.netlify.app/26.x/source/net/minecraft/client/model/animal/cow/warmcowmodel/) definitions, together with [Mojang's pig](https://github.com/Mojang/bedrock-samples/blob/main/resource_pack/models/entity/pig.geo.json) and [chicken](https://github.com/Mojang/bedrock-samples/blob/main/resource_pack/models/entity/chicken.geo.json) geometry. The 2D horn projections retain each variant's shape within the side-view presentation.

## Skeleton bow

The bow pivots around its grip at the skeleton's hand. Its sprite rotation follows the aimed arrow direction and mirrors with the mob. The three supplied `bow_pulling_0/1/2.png` textures replace the idle bow while drawing. Stages advance at 0, 0.65 and 0.9 seconds of charging. Charging advances with physics time, so the full-draw stage is visible between AI updates. Projectile behavior and ordinary cooldowns remain integrated with the previous mob AI.

The sprite alignment is data-driven by `skeleton.ranged.bow_rotation_degrees` in `data/mobs.json`.

## Options → Mods → Dynamic Lighting

The new Mods page is available from Options in both the title screen and pause menu. It contains:

- **Dynamic Lighting**: ON/OFF, default ON.
- **Brightness (%)**: 25–100, default 100.
- **Updates**: Fast (20 Hz), Balanced (10 Hz, default), Economy (5 Hz).

Settings save in the existing user `options.cfg`. Done/Escape returns to Options; Reset Defaults affects the visible settings page. Existing zoom, GUI, durability and keybind preferences are preserved. The menu applies a lighting preview even while the world is paused. Controls are declared in the existing `data/options_menu.json`, using `page: "mods"` and `target: "mods"`; future mod controls can use the same preference mechanism.

Holding an emissive item in either hand illuminates nearby tiles, background walls, entities and mining cracks through the existing per-block color renderer. Emission uses the item's canonical `light_level`; torches emit their existing level 14. The stronger of overlapping hand sources wins. Removing the item, dying, entering spectator mode or disabling the mod clears the temporary field.

`HeldLightField` propagates within the small source radius, respects block absorption and stops at opaque blocks. It shades exposed rock interiors separately without transmitting into air on the far side. Stationary sources reuse their result. Moving sources obey the update profile; changed visible mesh colors are rebuilt through the existing renderer cache. This adds no shader, per-block node or lighting-related physics rebuild. Permanent skylight and placed-torch propagation are reused.

Held light is a visual mod: it does not alter crop light, natural mob spawning, or saved block light. The temporary field is reconstructed from the current held items and settings rather than stored in world saves.

## Mining obstruction

Previously, `cell_is_reachable()` checked only loaded status and distance. It now also checks visibility from the player's eye. A bounded grid traversal tests the same solid collision boxes used by full blocks, farmland, slabs and stairs. It reads block data directly, so a just-placed wall obstructs immediately, even before its physics collider commits. The hovered pointer location is used within the target cell; other interactions use its center.

The target block itself is accepted when reached, while intervening solid geometry obstructs. Pass-through plants and platforms do not become full-cell barriers. Both timed mining and the final `break_block()` entry point enforce reach/visibility, so a direct call cannot bypass the check. The shared reach check also protects normal placement and workstation interactions.

## Verification

Godot 4.7.2 checks cover freshly placed wall obstruction, timed/direct mining guards and tool wear, clear targets, decorative grass and slab clearance, main/offhand held light, removal/brightness/toggle behavior, rock occlusion, unchanged permanent light and sunlight rebuild count, stationary mesh reuse, Mods navigation/defaults/preference persistence, bow direction in both facings, all three stages during physical charging, and nonempty attachment UVs for every regional cow/pig/chicken view.

Native rendering was inspected for head pitch, front glances, regional attachments, both bow directions and draw stages, held light on/off, and the Mods page. Existing combat, AI, simulation, mining, equipment/storage, survival, step/building, controls, copper and optimization checks pass.
