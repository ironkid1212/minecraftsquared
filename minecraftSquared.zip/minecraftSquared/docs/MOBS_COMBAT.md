# Cows, sheep, zombies and basic combat

This is the original foundation guide for adult cows, white sheep and unarmed adult zombies. The current build also has pigs, chickens and creepers; see [MOB_POLISH_2D.md](MOB_POLISH_2D.md) for the current reach, additional mobs, collision/art fixes and explosions. Java Edition behavior is the reference, with navigation and population density adapted to a side-view world.

## Controls and play

- Left-click a reachable mob to attack with your main hand. The current 2D default reach is 2.25 blocks with a clear aimed ray; three blocks is the vanilla reference. A click on a mob attacks it rather than mining the block behind it. Holding the button does not repeatedly attack mobs.
- Let the attack indicator refill between swings. Attack speed/damage comes from the existing tool catalog. Bare-hand attacks are supported. A charged falling strike can critical-hit; a charged sprint attack adds knockback instead. Charged, grounded sword attacks can sweep nearby mobs for one point of damage. Weapon durability, Unbreakable tags and worn player armor continue to work.
- Right-click a sheep with **shears** to get 1–3 wool. A sheared sheep must graze on grass to regrow its fleece. Grazing takes two seconds and turns grass into dirt. Shears use two iron ingots diagonally in the crafting grid; they also collect leaf blocks through the existing tool-tag drop rules.
- Right-click an adult cow with an **empty bucket** to get milk. Both milking and shearing work from either hand and preserve stack metadata. Holding wheat attracts nearby cows and sheep; this does not consume the wheat.
- New worlds include one wooden sword with the existing starter supplies. Existing inventories are untouched. Previously available sword recipes now have a use.
- `/summon cow`, `/summon sheep` or `/summon zombie` creates a mob at the pointer when there is clear loaded space. Optional `x y` arguments use the same world coordinate system and relative `~` coordinates as `/tp`. Tab completion includes mob names. Summoning respects the active entity capacity.
- F3 includes active, sleeping and visible mob counts.

## Mob behavior and loot

| Mob | Health points | Behavior | Ordinary drops |
| --- | ---: | --- | --- |
| Cow | 10 | Wander, avoid unsafe drops, follow wheat, flee after injury, float in water, milk with buckets | 0–2 leather and 1–3 raw beef |
| Sheep | 8 | Wander, follow wheat, flee, graze and regrow shorn wool | 1–2 raw mutton and one wool when not sheared |
| Zombie | 20 | Pursue a visible player, briefly remember a lost target, navigate terrain, attack once per second | 0–2 rotten flesh |

Zombies deal three health points before armor at the update's Normal-difficulty setting and have two natural armor points. Player-credited zombie deaths have a 2.5% chance to drop one iron ingot, carrot or potato. Animals killed while burning drop their cooked meat instead. Raw beef and mutton can also be cooked in a furnace. Loot is created once on death, and the mob then falls over and disappears after one second.

Mobs have short damage immunity: an equal/weaker hit during that window does not apply again; a stronger hit only adds the difference. Fresh impacts flash red and knock the target away. Critical hits have particles taken from the provided Minecraft texture pack. Grounded knockback gives an upward impulse; airborne targets retain their vertical motion. Fall, fire, lava and drowning damage are included.

Daylight ignites exposed zombies. Solid roofs and light-reducing foliage provide shelter; water and actual rain extinguish fire. The sunlight check uses structural skylight, so Spectator fullbright does not change it. Zombies ignore spectators and dead players.

Animals and zombies use animated part rigs assembled from the supplied Minecraft skin textures. Cows select temperate, warm or cold textures according to the spawning biome; sheep have a separate removable wool layer. The art is copied from cube faces without smoothing. The 2D cow silhouette is shared across those texture variants.

## Movement reference

The catalog stores vanilla movement attributes: 0.2 for cows and 0.23 for sheep/zombies. They are not treated as blocks per second. Minecraft's mob controller sets both movement speed and forward input, and ground travel adds friction. For ordinary ground the terminal reference is:

```text
pixels/second = (movement_attribute × AI_goal_multiplier)²
                × 0.98 / (1 − 0.546) × 20 × 16
```

This gives approximately 1.727 blocks/second for a wandering cow and 2.284 for sheep/zombies. Cow panic uses a goal multiplier of 2; sheep panic uses 1.25. Wheat temptation uses 1.25 and 1.1 respectively. Acceleration approaches the target with ground drag. Gait phase follows traveled distance, with Minecraft's 0.6662 limb phase factor and movement-dependent amplitude. These are flat-ground reference speeds, not a claim of identical 3D navigation or every surface's friction.

Mobs step up to 0.6 blocks, jump one-block obstacles, and use a small ground graph for pursuit. Passive wandering avoids drops greater than three blocks. Swimming, collision and obstacle choices are 2D adaptations.

## Spawning, persistence and performance

Natural zombies spawn in loaded dark spaces outside a 24-block radius of the player. Emitted block light must be zero; sky darkness is tested separately. This permits dark caves during the day. Torches prevent hostile spawns regardless of visual fullbright. Packs and caps are adapted to the much smaller 2D spawning area; the default nearby cap is twelve zombies.

Passive herds are generated from saved, deterministic 64-column region visits, biome weights and suitable lit grass. The nearby passive cap is twelve. Herd records and visited regions are saved, so reopening a world does not regenerate killed animals at the same region seed. Existing worlds receive herds as suitable areas are visited. There is no requirement to create a new world.

The active simulation radius is 64 blocks. Animals outside it or outside loaded terrain are serialized and their actor nodes are freed. Returning restores their health, position, velocity, fleece, regional texture, custom typed tags and environmental timers. They do not age or simulate while sleeping. Natural hostiles beyond 128 blocks despawn; idle, distant hostiles may also despawn. An active-cap limit never silently discards sleeping animals.

One renderer handles visible mob rigs, using interpolated positions and the existing per-block light tint. Offscreen mobs do not submit their sprite parts. AI decisions are staggered, path searches have a node limit and a shared per-physics-tick job limit, particles are bounded, and no processing node is allocated for a dormant record. The default absolute active limit is 64, including summoned mobs; the persistent record limit is 4096. These limits protect the game rather than promise a particular FPS on all hardware.

## Data and organization

- `data/mobs.json` is the authoritative mob catalog: health, movement attributes, dimensions, armor, goals, textures, interactions, biome lists, weights, herds, loot, population limits and navigation budgets. `rules.enabled` controls natural spawning; existing entities still stream and simulate.
- `scripts/mobs/mob_catalog.gd` validates the catalog and saved records. Existing `cow`, `sheep` and `zombie` rigs can be reused by another definition; new visual rig families or AI actions need code.
- `scripts/mobs/mob_actor.gd` owns body motion, health, damage and short-lived presentation state. `mob_system.gd` owns spawning, streaming, interactions, environment checks and persistence.
- `scripts/mobs/mob_drawing.gd` owns rendering only. It has no per-mob shader or light nodes.
- `scripts/mobs/player_combat.gd` resolves targeting and weapon actions. Combat consumes `tool.attack_damage`, `tool.attack_speed` and durability from `data/content.json`; it does not duplicate those stats.
- Item/block definitions remain in `data/content.json`, recipes in `data/recipes.json`, and cooking results in `data/smelting.json`. New IDs are appended; existing IDs and atlas coordinates are preserved. Existing atlas pixels remain unchanged.

Save files add an optional `mobs` section containing active/dormant entity records, visited regions, population RNG state and the next stable entity ID. Missing sections migrate to an empty population. Invalid or duplicate entity records are rejected before loading. No Minecraft region-file import or full vanilla entity-NBT compatibility is implied.

## Deliberate limits of this first mob update

This is the shared adult-mob and basic-combat foundation. It does not include breeding/babies, colored sheep/dyeing, experience orbs, hunger/eating/drinking, status effects, mob sounds, zombie equipment/pickup, baby zombies, drowned conversion, door breaking, reinforcements, villagers or multiplayer. Meat and milk can be collected, and meat can be cooked; food and drink use awaits the hunger update. Existing automatic health regeneration remains. Enchantment data may persist but its combat effects are not executed. Difficulty is currently Normal through the zombie catalog's attack value, rather than a new difficulty menu.

## Verification

Godot 4.7.2 checks cover actual attack input, cooldown strength, criticals, damage immunity, natural armor, knockback, loot conservation, daylight/roof/night/torch behavior, spectator exclusion, shearing/regrowth, tagged milking, real walking and jumping, natural spawn caps/exclusion, passive exploration, sleeping-record conservation, save round trips and old-save migration. A 24-mob simulation runs for 600 physics ticks with finite motion and bounded path jobs. Native rendered captures were inspected for facing, wool, animation, hurt tint, fire, death, night lighting and offscreen culling.

Existing regression checks pass for mining/tooltips, equipment/NBT/storage, fluids, farming/weather, survival/death, controls, partial-block traversal and chunk-rendering optimizations. The download excludes editor caches, test-generated saves and verification scripts.

## Research

Primary implementation references are version-specific Java source mirrors; newer Minecraft releases may differ. The supplied texture pack provides the art. These references informed the behavior rather than being copied as a complete engine:

- [Cow goals and attributes](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/animal/Cow.java), [Sheep goals, attributes and shearing](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/animal/Sheep.java), and [Zombie attributes and daylight behavior](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/monster/Zombie.java).
- [Vanilla entity loot](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/data/loot/packs/VanillaEntityLoot.java): ordinary drops, cooked meat and player-credited rare drops.
- [Player attack resolution](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/player/Player.java): charge scaling, critical conditions and sprint/sword attack behavior. [LivingEntity](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/LivingEntity.java): immunity windows, stronger-hit differences, knockback and travel. [MeleeAttackGoal](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/ai/goal/MeleeAttackGoal.java): the attack interval.
- [MoveControl](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/ai/control/MoveControl.java) and [Mob.setSpeed](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/Mob.java): why AI goal speed and movement attributes require conversion rather than direct assignment to world velocity.
- [Monster spawning checks](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/monster/Monster.java): separate emitted-light and sky-light rules.
- [Cow model](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/model/CowModel.java), [Sheep model](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/model/SheepModel.java) and [Sheep wool model](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/model/SheepFurModel.java): body part proportions and UV layouts adapted to 2D.
- Supplemental behavior/spawning references: [Minecraft Wiki: Cow](https://minecraft.wiki/w/Cow), [Sheep](https://minecraft.wiki/w/Sheep), [Zombie](https://minecraft.wiki/w/Zombie), [Melee attack](https://minecraft.wiki/w/Melee_attack), and [Mob spawning](https://minecraft.wiki/w/Mob_spawning).
