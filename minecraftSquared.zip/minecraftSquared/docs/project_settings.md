# Project settings

Select a resource under `data/settings/`, edit the Inspector, save, and restart.
Resources store your overrides; scripts supply remaining defaults. This project
preserves the supplied overrides, including UI scale 4, 14-pixel inventory/hotbar
icons and tooltip font size 6.

| Resource | Active controls |
| --- | --- |
| `game.tres` | Reach, starter inventory and system resources |
| `terrain.tres` | Seed, surface row, soil, world bounds, streaming and biome scale/borders |
| `cave.tres` | Noise caverns/tunnels, shelves/pillars, roof cap and entrances |
| `tree.tres` | Chance/spacing, heights, canopy mix, materials and log foliage |
| `day_night.tres` | Cycle length, initial time, sky palette, stars/moon/sun and night light |
| `survival.tres` | Health, fall damage, healing, death drops and respawn rules |
| `player.tres` | Movement, skin/outer layers, held items, animations and spectator speed |
| `interface.tres` | UI scale, icons, font, stack labels, textures and tooltips |
| `pixel_presentation.tres` | Automatic/fixed integer world scale and reference viewport |
| `lighting.tres` | Daylight/ambient fade, rock shading and sky/wall/torch colors |
| `world_updates.tres` | Budgets, leaf decay, grass, falling blocks and torch mounts |
| `drop.tres` | Pickup/merge/magnet radii, lifetime, movement and icon size |

In-game Options controls zoom, UI scale, tooltip text and fullscreen; saved
preferences override these runtime options. Options → Controls rebinds inputs;
project defaults live in `data/keybindings.json`.

## Icons and stack text

Inventory/Hotbar Icon Size are logical pixels in a 16-pixel slot. At GUI scale
3, size 14 draws a 42-pixel icon. Nearest filtering keeps art sharp; a size/scale
product divisible by 16 gives equal source-pixel widths.

Stack Font Size, Stack Offset and Stack Shadow Offset are in `interface.tres`.
The offset starts at the slot's bottom-right: negative X moves left and negative
Y moves up. Text width is subtracted automatically. Retired menu preferences no
longer silently replace these authored values.

## Terrain and caves

Active generator controls are visible. Old height-noise, random-walk cave and
revision switches remain stored for save compatibility but are hidden. Their
obsolete presets are removed. Keep those internal fields in code: old world
documents still use them.

Surface Level is a Godot row: displayed Y is Top Y minus row (319−257=62).
Modern depth comes from Top Y and Bottom Y. Biome/vegetation rules live in
`data/biomes.json`; geology/ores live in `data/overworld_generation.json`.
See [generation tuning](natural_generation.md) for active controls and ore tables.

Use `plant` for non-colliding decoration. Cactus explicitly overrides collision
to `platform`. Use `workstation` for one-way tops; `platform_wood` adds wood/axe
behavior. `platform_height` sets the top height (16 for full blocks, 9 for beds). Collision modes are `solid`, `platform` and `none`.
Sprite transparency separately controls wall culling. See [content](content_catalog.md).

World.settings references `game.tres`. Duplicate it and nested resources for an
independent configuration. Preserve stable content IDs/keys for saved worlds.

See [day/night](day_night.md) for the clock resource and commands. Chat spacing,
popup rows and opacity live in `data/chat.json`.
