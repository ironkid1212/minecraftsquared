# Bats, local files, biomes and Creative organization

This update uses the supplied project as its base. Existing content IDs, native
texture pixels and Inspector resource overrides are preserved.

## User files

The game now uses a dedicated Godot custom user directory. On Windows this is
`%APPDATA%\.minecraftSquared`. It contains `saves/`, `skins/`, and `options.cfg`.
The title screen opens the game folder; world selection opens saves; Profile
and Select Skin open skins. Skin metadata, converted images and original
uploaded source skins remain together. The game does not use the project folder
or require OneDrive for runtime user files.

On first launch `UserFiles.prepare()` copies missing files from the previous
`Godot/app_userdata/Minecraft Squared/worlds` and `profile` directories. It also
copies preferences and saved hotbars. Originals remain intact; existing new
files win. A successful migration writes `migration_v1.cfg`. Failed copies are
reported and retried next launch. Back up saves before changing game versions.

## Rendering

Bats use the native modern 32x32 bat texture, full membranes on separate wing
hinges, a visible face and ears, and a narrow folded hanging pose. This is a
readable 2D projection rather than a literal edge-on view of a flat 3D wing.
Other species retain their existing rigs, including side/front head variants.

Named mobs use screen-space white text and a translucent black rectangle,
without world-light tint or a drop shadow. A custom mob name appears while
pointed at with clear sight, or when NBT `CustomNameVisible` is true, up to 64
blocks away. Labels are hidden during menus and cannot overlap the hotbar.

Water geometry is drawn relative to each cell to avoid float precision problems
when triangulating polygons far from spawn.

## Content and tuning

New worlds use biome revision 5. Existing saved revisions keep their generation.
Sunflower Plains and Old Growth Pine Taiga join the existing 13 biomes.
The latter has thick tall spruce trunks with compact crowns, podzol/coarse dirt
patches, mossy cobblestone, ferns and mushrooms.

`data/biomes.json` controls climate ranges, tree chances, plant chances and
surface patches. The pine `height`, `crown_height` and `radius` fields control
its shape. `surface_patches` contains `{block, chance}` records; their cumulative
chance must not exceed 1. The remaining chance uses the biome's normal surface.

The shared content catalog adds podzol, coarse dirt, sunflowers, large ferns,
red/brown mushrooms, bowls, mushroom stew, polished/chiseled/cracked blackstone,
three blackstone slab/stair families, soul torches and normal/soul lanterns.
Placement variants stay hidden. Lanterns choose ceiling/floor support, drop on
support removal, waterlog, and emit light. Native lantern model UVs are used.
Stew returns its bowl; coarse dirt tills to dirt before becoming farmland.
Mushrooms require light <=12 unless on podzol. Podzol drops dirt except with Silk
Touch. Recipes are in the existing recipe and smelting files.

## Creative tabs

Every supported Creative item has explicit `creative_tabs` in `content.json`.
The old runtime name-based guesses are removed. New supported items must declare
at least one real tab. Equipment in Natural Blocks is rejected during validation.
Pickaxes/shovels/hoes are Tools; swords are Combat; axes are in both. Food,
ingredients, lights, stations, natural materials and building shapes follow the
Java tab assignments where supported, including legitimate cross-listings.
`creative_order.json` stores ordering only, not duplicate item properties.
Internal variants, fluids and unfinished content remain excluded.

## References

- [Minecraft bat model](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/model/BatModel.java)
- [Minecraft entity name rendering](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/renderer/entity/EntityRenderer.java)
- [Minecraft Creative tabs](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/item/CreativeModeTabs.java)
- [Official Old Growth Pine Taiga article](https://www.minecraft.net/nb-no/article/old-growth-pine-taiga)
- [Sunflower Plains](https://minecraft.wiki/w/Sunflower_Plains)
- [Godot user data paths](https://docs.godotengine.org/en/stable/tutorials/io/data_paths.html)

The source references guide the appearance and classifications; generation is
adapted to this game's 2D world and does not reproduce Java seeds exactly.
