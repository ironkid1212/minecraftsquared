# Mining and tooltips

All block and tool stats remain in **data/content.json**. `hardness` now
replaces the misleading `break_time` field: it is Minecraft hardness, not seconds.
Existing world saves remain compatible; they store item keys, edits and durability,
not copies of block definitions. Existing IDs and atlas positions are unchanged.

The engine separately checks:

- **Speed:** matching pickaxe, axe, shovel or hoe gets the material speed, even
  when its harvest tier is too low. Wood 2, stone 4, iron 6, diamond 8, gold 12.
- **Harvest:** required kind and minimum tier control whether drops are allowed.
  Hoe efficiency on leaves does not make leaves drop themselves.
- **Time:** `ceil(hardness * (30 if harvestable else 100) / speed) / 20` seconds,
  quantized to Minecraft's 20 ticks per second. Zero hardness breaks immediately;
  `diggable: false` is unbreakable. Being airborne reduces speed to one fifth.
  Jumping or landing preserves the mining progress already earned.
- **Wear:** mining a nonzero-hardness block consumes one use for ordinary tools,
  two for swords. Breaking instant plants or torches consumes none.

Examples, grounded and without enchantments or effects:

| Block | Tool | Seconds | Drops eligible |
| --- | --- | ---: | --- |
| Gold ore | Stone pickaxe | 3.75 | No |
| Gold ore | Iron pickaxe | 0.75 | Yes |
| Gold ore | Golden pickaxe | 1.25 | No |
| Deepslate gold ore | Stone pickaxe | 5.65 | No |
| Stone | Hand | 7.50 | No |
| Stone | Wooden pickaxe | 1.15 | Yes |
| Stone | Stone pickaxe | 0.60 | Yes |
| Oak log | Stone axe | 0.75 | Yes |

`mining.speed_overrides` permits other speed rules without another database.
For example, `"speed_overrides": {"sword": 1.5}` gives leaves and wool their
sword bonus, independent of the sword's material.

Tool records also contain **total** `attack_damage` and `attack_speed`. These
are the Java Edition tooltip values, including the player's base attributes,
not the raw modifiers. Pickaxes, axes, shovels, hoes and swords all use their
proper material-specific values. They are available for future combat; this
change does not add combat or enchantments, swimming, haste or mining fatigue.

Inventory, crafting results and furnace inventory slots share one tooltip
builder. Names are white; “When in Main Hand:” is gray; attributes are dark green.
Choose **Options → Durability Tooltips** or press **F3+H** in a world, including
while an inventory is open. This preference persists across restarts. Like
Minecraft, the numeric durability line appears only after a tool has taken
damage. The small durability bar remains visible on damaged tools in both modes.

Research references (Java mechanics; 1.21.5 item data for current tool attributes):

- [Minecraft block breaking implementation, mapped source mirror](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/block/state/BlockBehaviour.java)
- [Minecraft player mining speed, mapped source mirror](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/player/Player.java)
- [Minecraft tool speed and drop checks, mapped source mirror](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/item/DiggerItem.java)
- [Minecraft block hardness definitions, mapped source mirror](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/block/Blocks.java)
- [Vanilla generated item components](https://github.com/misode/mcmeta/blob/1.21.5-summary/item_components/data.json)

The sun and moon sizes are preserved at your values of 160 and 128.
