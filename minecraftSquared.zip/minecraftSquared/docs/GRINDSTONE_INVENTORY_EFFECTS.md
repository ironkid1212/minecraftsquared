# Grindstone and inventory effects

## Active effects

The player inventory and Creative inventory show active effects to the right of
the panel. When at least 120 logical pixels are available, native backgrounds
contain the icon, white effect name/level and gray `m:ss` countdown. With 32-119
pixels available, compact icons show the name and time on hover. If neither
sidebar fits, the existing HUD icons remain available. Closing inventory
restores the normal HUD, without drawing duplicate icons.

Names include levels above I, such as Strength II. Timers use the actual remaining
effect duration, keep updating while the inventory is open, and disappear when
the effect expires or is cleared. Creative players receive the same display.

The layout uses Minecraft's right-side position, 120x32/32x32 normal backgrounds,
33-pixel row spacing and crowded-stack spacing. The native 32x32 background uses
its declared four-pixel nine-slice border. Very crowded stacks additionally
compress row artwork/icons and text so borders do not cross timers or create
overlapping hover targets. This is a small 2D readability adaptation. The inventory
is not shifted or rescaled when effects appear.

## Grindstone

Craft with sticks on either side of a stone slab in the top row, and a plank
under each stick. Plank types may mix. The grindstone appears in Creative
Functional Blocks and is a pass-through workstation with a one-way top.
Right-click it to open the native Repair & Disenchant GUI.

- One enchanted item loses its non-curse enchantments without losing durability.
- Two matching durable items combine remaining durability plus 5% of maximum,
  capped at maximum durability, and lose non-curse enchantments.
- Enchanted books without remaining curses become ordinary books.
- Two identical enchanted books can return two ordinary books; incompatible
  item types or different non-durable stacks do not combine.
- Curse tags remain. This preserves future/custom curse metadata; this update
  does not add curse gameplay effects or Creative curse-book variants.
- Prior anvil-work cost resets, then increases once per remaining curse.
- The supported removed enchantments determine the XP refund using Minecraft's
  minimum enchantment-cost formula and random half-to-full refund range.

Previewing does not roll or award XP. Taking the result consumes the inputs and
spawns XP orbs at the station exactly once. A full cursor/inventory leaves inputs
and XP untouched. Shift-clicking the output puts it into inventory. Closing,
saving or removing the station returns unused inputs through the existing
station lifecycle.

The block sprite projects the actual grindstone wheel, pivot and dark-oak stand
UVs into a side view. The wooden stand and pivot are layered in front of the
stone wheel. Existing atlas pixels and content IDs are preserved.

## Checks and references

Tests cover recipes, repair/disenchantment, books, preserved curses, prior work,
XP ranges, blocked/duplicate transactions, real mouse input, station removal,
wide/compact/crowded effect layouts, live countdowns, Creative mode and fallback.
Native renders check the model, GUI, invalid-input cross and effect tooltips.

- [Minecraft inventory effect rendering](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/gui/screens/inventory/EffectRenderingInventoryScreen.java)
- [Minecraft grindstone logic](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/inventory/GrindstoneMenu.java)
- Grindstone block model and GUI assets: supplied Minecraft texture/model folder.
