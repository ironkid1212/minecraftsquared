# Nether and stronghold progression

## Completion update

This pass completes supporting loops around farming, animals, brewing and the
existing dimensions. The End realm and dragon remain a separate expansion;
this release does not enable travel through the saved End portal.

Feed cows/sheep wheat, pigs carrots/potatoes/beetroot, chickens supported seeds,
and rabbits their configured foods. Two same-species adults enter love mode for
30 seconds, approach each other, and produce one baby after three seconds close
together. Parents have a five-minute cooldown. Babies take twenty loaded minutes
to grow, follow adults, and grow faster when fed (10% of remaining time). Babies
have smaller collision shapes, cannot be milked/sheared, lay no eggs and give no
death loot/XP. Growth waits for adult-sized clearance. Breeding gives 1–7 XP.
A single shared breeding implementation reads foods/timing/scale from each
species' `breeding` record in `data/mobs.json`; ages/love/cooldowns persist.
Uniform half-size juvenile rigs and horizontal mate/follow navigation are the
2D adaptation. They do not reproduce every species' 3D baby-head deformation.

Rename a Name Tag in an anvil, then use it on a mob. Named entities retain their
nameplates and survive distance despawning, including Endermites and Bats.
They still unload into saved sleeping records. Naming and feeding use
the normal main/offhand interaction system. Unnamed tags do nothing.

Melon and pumpkin seeds from existing mineshaft loot now grow on farmland.
Mature stems create one adjacent fruit on valid soil; leave the stem in place
and harvest the fruit to keep farming. Only left/right fruit positions exist in
this projection. Melons drop 3–7 slices (Fortune increases this up to nine), and
Silk Touch collects the block. One slice makes one seed; a pumpkin makes four.
Pumpkin + egg + sugar makes pumpkin pie (8 hunger, 4.8 saturation).
Eight gold nuggets surrounding a melon slice make glistering melon for Healing.

One bone crafts three Bone Meal. Use on crops to advance 2–5 stages, or on dry
cave vines to produce berries. Beetroot has a 75% success chance per use;
Nether wart cannot be fertilized. Mature fruit stems can attempt fruit growth.
Grass grows nearby short grass, and moss spreads across exposed nearby suitable
stone/soil with moss carpets. Cave vines grow downwards from their tips, up to
26 segments; new segments have an 11% berry chance. Fertilizing an existing dry
segment is the reliable way to restore harvested berries. Growth runs through
the existing loaded-region random-tick budget, not a per-plant frame loop.
Tune this in `data/farming.json`; `growth_multiplier` still controls crop speed.

Clay drops four clay balls (Silk Touch preserves clay). Smelt a clay ball for
one brick and 0.3 furnace XP; four bricks craft a bricks block. Hoe rooted dirt
to obtain dirt and hanging roots. Moss carpets and ceiling plants now require
real support and break when it is removed. Carpets transmit light.

Ghasts supply 0–1 tears and 0–2 gunpowder. They fly in sufficiently open Nether
Wastes, Soul Sand Valleys and Basalt Deltas, with a two-Ghast local cap for 2D.
They have 10 HP, warn after half a second, fire after one second, then recover
for two seconds. Attack a nearby large fireball while aiming at it to send it
back; a returned fireball kills a Ghast. Fireballs explode with power one and
respect mobGriefing for block damage/fire. Spawn clearance is four blocks;
flight speed, projectile speed and the local cap are deliberate 2D tuning.
`ghast_attack` in `data/mobs.json` controls the timings and tuning.
Native skins retain their own resolution, including the 128x64 Ghast texture.
Ghast fireballs, like other enemy projectiles, are transient on save/unload;
this does not add Happy Ghasts, music-disc rewards or the wider Nether population.

Healing and Regeneration now have Survival ingredient routes. Add redstone to
Strength/Swiftness for 8:00 or Regeneration for 1:30. Glowstone upgrades
Strength/Swiftness to II (1:30), Regeneration II (0:22.5) and Healing II (8 HP).
Extended and stronger variants are separate recipe branches. Tooltips include
levels, durations and attribute bonuses. Milk requires holding Use for 1.6s;
it clears effects only on completion and returns a bucket in Survival. Drinking
can be interrupted. Slowness now works without Speed, and effect amplifiers are
applied consistently. Splash/lingering potions are not part of this pass.

Visual repairs include connected Enderman necks when angry/looking, correct
bat ears/body/two-part wings, cow necks during head rotation, geometry-based
death settling, correct Ghast face UVs, a nonblank cornflower, complete azalea
stems and spore blossom bases. Existing IDs/settings/atlas pixels are preserved;
repaired sprites occupy appended atlas cells. Offscreen portal particles are
culled, and clearing projectiles immediately clears their last rendered frame.

Research cross-checks: Minecraft's extracted [Animal goals/state](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/entity/animal/Animal.java),
[age/growth](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/entity/AgeableMob.java),
[stem growth](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/level/block/StemBlock.java),
[Ghast behavior](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/entity/monster/Ghast.java),
[brewing graph](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/item/alchemy/PotionBrewing.java),
[potion strengths/durations](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/item/alchemy/Potions.java),
[Bat model](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/client/model/BatModel.java)
and [Enderman model](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/client/model/EndermanModel.java).

## Eyes of Ender, strongholds and Lush Caves

Craft one Eye of Ender from one ender pearl and one blaze powder (shapeless).
Use it in the Overworld to locate the nearest stronghold. It travels about twelve
blocks horizontally and rises when far away; within twelve blocks horizontally,
it points down toward the entrance. Eyes pass through terrain, float briefly,
then have an 80% chance of becoming a dropped item and a 20% chance of shattering.
Flights last four seconds, have independent targets, and persist across saves
and dimension changes. They do not locate structures in the Nether.

Strongholds use eight seeded sites in four bands on either side of the origin,
with distances reduced for 2D exploration. Connected galleries, ladders, a library,
loot rooms and a guaranteed portal room form the side-view layout. Ordinary,
mossy, cracked and infested stone bricks follow a 45/30/20/5 distribution. Chests
initialize once and use the stronghold library/corridor/crossing loot tables.
The library's book enchantments use the game's existing supported enchantment
pool; its selection is an adaptation, not vanilla level-30 multienchantment rolls.
Compass/map/trim loot remains collectible and hidden from Creative until its
associated gameplay is implemented. The crossing table includes supported loot
entries; unimplemented ink-sac content is omitted. Libraries include the eye
trim template. `/locate structure stronghold` finds a generated site.

The portal is a deliberate 2D projection: a vertical ring with three blocks on
each side, no corner blocks, and a 3x3 opening. Each of its twelve frame blocks
has a 10% chance of starting filled. Use an Eye on each empty frame; all twelve
filled frames activate the interior using the native End portal texture.
Frame fills, active blocks and manually built active rings save. Breaking a
required frame in Creative deactivates the opening. Frames resist explosions
and cannot be mined in Survival. Side frames are platforms so the player can
reach the interior. **The End dimension and dragon fight are not in this update**;
the completed portal is saved for the next progression milestone.

Lush Caves occur beneath the surface in humid, coherently sampled patches. They
decorate existing cave geometry with moss floors/ceilings, clay deposits, small
enclosed pools, azalea bushes, roots, spore blossoms and hanging cave vines.
Bearing vines emit level-14 light. Use on a berry-bearing vine to harvest it,
hold Use to eat the berries when hungry, or place berries under a solid ceiling
or another cave vine to plant them. Vines are climbable and passable. Their
newly planted segments start bearing berries. The completion pass adds growth
and bone meal. F3 reports Lush Caves underground instead of displaying
only the surface biome.

New mobs use native textures projected into side-view rigs:

- Silverfish: 8 health, 1 damage, portal-room spawners and infested stone. Breaking
  infested blocks without Silk Touch releases them. Injured survivors call nearby
  infested allies after a short delay, with a four-mob wake-up cap for 2D. Idle
  Silverfish can hide in nearby stone/deepslate/stone bricks. Silk Touch collects
  the ordinary host block instead of releasing a Silverfish.
- Endermites: 8 health, 2 damage, a 5% pearl-landing spawn chance at the thrower's
  location. They expire after two minutes of loaded simulation unless named.
  Lifetime and names persist. Endermen target visible Endermites.
- Bats: 6 health, passive cave flight, ceiling hanging and waking when approached,
  hurt or their support is broken. They spawn in dark underground space, have a
  separate small ambient cap, despawn beyond 32 blocks, and drop no items or XP.

All three have Creative spawn eggs and `/summon` support. `/spawner silverfish`
configures a reachable spawner. Silverfish and Endermites are excluded from
ordinary hostile spawning; Bats are excluded from the surface animal cap.

Editor tuning: `TerrainSettings.strongholds_enabled` and `lush_caves_enabled`
control the new generation. `data/strongholds.json` contains distances, depths,
brick weights, Eye rules, portal prefilling and Lush Cave noise/vegetation rules.
Mob values live in the existing `data/mobs.json`; all block/item entries remain
in `data/content.json`, and the Eye recipe lives in `data/recipes.json`.
Old saves lacking the two generation flags keep them disabled, preserving their
terrain. Start a new world to explore the new generation. Existing item IDs,
atlas regions, user settings, inventory and older dimension saves remain valid.

References: [Eye of Ender](https://minecraft.wiki/w/Eye_of_Ender),
[Stronghold](https://minecraft.wiki/w/Stronghold),
[Lush Caves](https://minecraft.wiki/w/Lush_Caves),
[Glow Berries](https://minecraft.wiki/w/Glow_Berries),
[Silverfish](https://minecraft.wiki/w/Silverfish),
[Endermite](https://minecraft.wiki/w/Endermite), and
[Bat](https://minecraft.wiki/w/Bat). April Fools snapshot mechanics are excluded.

## Modern Nether generation update

New worlds now use generation revision 3. Revision 1 retains the original
terrain; revision 2 retains its existing density shapes. Revision 3 additionally
removes isolated one-cell stone specks and pinholes. User block edits persist.
Use a new world for these density refinements. Wall/clearance repairs, blended
backgrounds and dimension-aware commands also apply to existing revision-2 worlds.

Fortress interiors reserve explicit air and wall overrides, so natural terrain,
fungi, glowstone and pillars cannot occupy their passageways. Each stair's cutout
cell has Nether-brick backing in both facing directions. Clearance stays inside
the structure instead of excavating a one-block moat around its boundary.
Open passages clear their whole piece in this 2D adaptation. Broken bridge ends
remain contiguous, and the gallery uses a complete climb-through ladder instead
of placing a stair wedge across the main bridge. Main-route floor sockets meet
at every piece boundary. Existing revision-2 layout random draws, chest and
spawner positions stay stable; these repairs change their surrounding geometry.

Basalt pillars are Minecraft Soul Sand Valley features, but solid ceiling-to-floor
columns dominate a side-view slice. They are now sparser, irregularly capped
background formations by default, anchored between real ceilings and the next
floor or lava surface. They do not block travel or override fortress walls.
Set `generation.pillars_background` to false for solid procedural pillars;
`pillar_spacing` and `pillar_chance` control their frequency. Older revision-2
saves without these fields use the corrected defaults.

Nether backgrounds use the reference fog palette with a Gaussian neighborhood
blend and a short temporal fade. Colors remain continuous across biome borders,
including with the clock disabled. Large teleports use their destination's
blended color. Tune `environment.fog_blend_radius` (blocks) and
`fog_transition_seconds` in `data/nether.json`, outside the in-game options.

F3, `/tp`, `/teleport`, `/setblock` and `/summon` share the current dimension's
coordinate origin. Nether terrain is Y=0–127; feet may reach the upper boundary
at Y=128. Absolute integer X teleport arguments center the player in that block;
decimal and `~` coordinates preserve their requested offsets. Survival teleports
test actual collision boxes and the player's current pose.

Additional references: [basalt pillars](https://minecraft.wiki/w/Basalt_Pillar)
and [Nether fog](https://minecraft.wiki/w/Fog#Nether_fog).

Terrain now samples a two-dimensional density field with solid ceiling/floor
gradients. It can contain stacked shelves, overhangs, islands, side caves and
lava-filled low caverns. Climate is independent of this density: changing
biome size does not change the underlying cavern shape. All five modern
biomes are represented, including Crimson Forest with native nylium, stems,
wart blocks, roots and fungi. Soul Sand Valleys have basalt pillars; deltas
have basalt/blackstone surface deposits. Glowstone forms attached clusters.

Fortresses assemble bridges, crossings, enclosed corridors, lava wells,
actual Nether-brick stairs, wart stair rooms, a raised gallery and a Blaze
platform. Routes change height and length. Background support pillars reach
natural terrain without blocking side-view travel beneath the bridges.
The gallery's ladder opening is traversable. Fortress chests retain the
existing researched loot table and initialize once. Open pieces may retain
netherrack above their clear walking passage; enclosed passages clear terrain.
Piece bounds determine fortress spawning; support pillars are excluded.

Magma Cubes now have their own hopping movement. They do not auto-step or
path around cliffs, are not slowed by lava, swim upward out of lava, take no
fall damage, and damage players by body contact. Idle jumps are spaced 2–6
seconds apart; pursuit divides that delay by three. The horizontal hop is
adapted to approximately 1.5 body lengths instead of converting the Java
movement attribute directly into pixels per tick. Size changes health,
armor, damage, jump power and XP. Natural spawning checks large-cube
clearance before choosing size, ignores light, is common in deltas and rare
in wastes. Cubes can also spawn inside fortress pieces. Splits avoid solid
walls and still work in lava. Separated drawing slices stay above the feet.

Editor/data tuning (outside the in-game menu):

- `data/nether.json`, `generation.density_frequency`: density feature scale.
- `generation.cavern_opening`: larger values carve more open space.
- `generation.biome_width`: larger values create broader climate regions.
- `generation.climate`: temperature, humidity and offset for each biome.
- `generation.forest_spacing`: huge-fungus placement spacing.
- `generation.fortress_layout`: region width, chance and route piece counts.
- `data/mobs.json`, Magma Cube `cube_motion`: jump delays, pursuit divisor,
  hop-distance multiplier and acceleration; `attack_interval` is contact cadence.

These are deterministic side-view adaptations, not identical Minecraft seeds.
Fortress region spacing is reduced for 2D exploration, and crossing branches
use galleries and ladders. Bastions, piglins, hoglins and wither skeletons
are not added by this update; unsupported mob populations are not substituted
with large numbers of unrelated mobs. Old generation settings remain present
for saved-world compatibility.

References: [Nether fortress](https://minecraft.wiki/w/Nether_Fortress),
[The Nether](https://minecraft.wiki/w/The_Nether),
[terrain features](https://minecraft.wiki/w/Terrain_features),
[climate placement](https://minecraft.wiki/w/World_generation), and
[Magma Cube](https://minecraft.wiki/w/Magma_Cube). Minecraft's extracted
[fortress pieces](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/levelgen/structure/structures/NetherFortressPieces.java),
[Slime](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/monster/Slime.java)
and [MagmaCube](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/monster/MagmaCube.java)
were cross-checked for structure pieces and size/jump rules.

## Playing the progression

1. Enter the Nether through your obsidian portal. Explore for teal warped
   forests, basalt deltas and Nether-brick fortresses.
2. Endermen in warped forests drop 0-1 ender pearls. They are neutral until
   attacked or stared at. Aim the mouse at their face for roughly a quarter
   second with clear line of sight to provoke them. Looking at their feet is safe.
   Creative/Spectator players and open inventory/chat screens do not provoke them.
3. Right-click with an ender pearl to throw toward the mouse. Pearls stack to 16,
   have a one-second cooldown, follow a gravity arc and teleport on impact.
   Teleporting costs five health points (2.5 hearts), resets fall tracking and
   resolves the player's body on the near side of the impact. A blocked landing
   fails safely. Successive throws have independent velocity. Pearls vanish on
   owner death, including pearls paused in another dimension.
4. Fortresses have connected bridges, corridors, stairways and galleries,
   loot chests, Nether wart gardens and Blaze spawners. Harvest wart and collect
   Soul Sand for a home farm. Wart needs Soul Sand, but no water or light.
5. Player-killed Blazes drop 0-1 blaze rods. One rod crafts two blaze powder.
   A rod above a row of three cobblestone-group blocks crafts a brewing stand.
6. Make three glass bottles using glass in a V, fill them from water in the
   Overworld, and place them in the stand. Blaze powder goes in its fuel slot;
   ingredients go in the upper central slot. One powder fuels 20 batches. Each
   batch takes 20 seconds and consumes one ingredient for up to three bottles.
7. Brew Water + Nether Wart into Awkward Potion, then add Magma Cream for Fire
   Resistance. Redstone extends it from 3:00 to 8:00. Magma Cubes in basalt deltas
   supply magma cream; medium and large cubes split into smaller cubes on death.
   The smallest cubes do not drop cream. All sizes are immune to fire/lava.

Hold Use to drink, including at full hunger. Drinking takes 1.6 seconds and
returns the empty glass bottle in Survival. Fire Resistance prevents fire/lava
and Blaze fireball damage. Strength I adds three melee damage; Swiftness I adds
20% movement speed. Regeneration I heals one HP each 2.5 seconds; golden apples
retain their faster Regeneration II effect. Effect levels and durations save.

The brewing screen supports normal/right clicks, Shift-click transfers,
per-slot limits, item tooltips, persistent contents and native progress/fuel
sprites. Removing/replacing an ingredient cancels the current brew without
creating outputs. Breaking the stand releases stored items once. Unloaded
stands pause, matching this game's existing loaded-region simulation policy.

## Included recipes and scope

| Input | Ingredient | Result |
|---|---|---|
| Water Bottle | Nether Wart | Awkward Potion |
| Awkward Potion | Magma Cream | Fire Resistance (3:00) |
| Fire Resistance | Redstone | Fire Resistance (8:00) |
| Awkward Potion | Blaze Powder | Strength I (3:00) |
| Awkward Potion | Sugar | Swiftness I (3:00) |
| Awkward Potion | Glistering Melon Slice | Healing I (4 HP) |
| Awkward Potion | Ghast Tear | Regeneration I (0:45) |

Fire Resistance, Strength, Swiftness, Healing and Regeneration have Survival
ingredient routes. The completion pass adds melon farming, Ghasts and the
upgraded/extended variants described above. Endermites, Eyes and strongholds
are implemented. Splash/lingering potions and the End remain later progression.

Fortress chests use the researched Nether-bridge loot weights and stack ranges,
including the current copper horse armor entry and the separate 1/15 rib trim
roll. Loot generates once and does not refill after reopening, leaving or saving.
Saddles/trim templates remain collectible loot and are hidden from the creative
catalog until their gameplay systems exist. Horse armor follows the pre-existing
content definitions. New mob spawn eggs appear in the Spawn Eggs tab.

## 2D generation and AI adaptations

Warped forests replace selected Nether Wastes regions, keeping the original
Soul Sand Valley/Basalt Delta placement. Nylium, huge fungi, warped stems, wart
blocks, shroomlights, fungi, roots, sprouts and twisting vines use supplied
Minecraft textures. Fungi vary in height/cap shape; they do not generate cut-off
trunks through fortress decks. Stems/caps are pass-through platforms. Twisting
vines use distinct stalk/top textures, support climbing and can be placed.
Nether fungi do not use Overworld leaf-decay behavior.

Open main caverns show the biome's fog-colored backdrop; near terrain and
fortress halls retain background walls. Terrain remains chunked and cached;
forests/fortresses are coordinate-derived, so chunk load order cannot change
placement. Only visible mob/projectile geometry is drawn. Plan/tree caches,
entity counts, teleport attempts and projectile counts are bounded.

Endermen have 40 HP, normal-difficulty seven-damage melee, tall slim models,
shorter walking swings, emissive eyes and saved anger/carried blocks. They freeze
when stared at nearby, teleport to loaded dry supported spaces with enough
headroom, evade arrows, retreat from rain/water and occasionally move suitable
blocks when mobGriefing is enabled. Side faces are the normal pose; idle glances
can reveal the front. The mouse-aim gaze rule and loaded-only teleport search
adapt the 3D view-vector rule and avoid loading distant chunks for each mob.

Blazes fly/hover, have 20 HP, resist fire/lava, take water damage and require
line of sight. They charge for three seconds, fire three shots spaced 0.3s apart,
and recover for five seconds. Fireballs deal five damage and ignite; shields
block them and Fire Resistance protects against them. Their projected flight,
fireball speed/spread and navigable fortress decks are adapted for dodging in 2D.
Blazes give 10 XP on credited kills. Natural Nether spawning selects Endermen in
warped forests, Skeletons in Soul Sand Valleys and Magma Cubes in basalt deltas;
Blazes come from fortress spawners. Nether-only mobs do not seed the Overworld.
Endermen can also spawn rarely in suitable dark Overworld locations.

Fortresses are a 2D layout generator inspired by bridges, corridors, crossings,
wart rooms and spawner platforms, not a projection of the complete 3D jigsaw.
Wither Skeletons and the remaining Nether population are future work.

## Saves, commands and editing

Existing content IDs, settings resources, skins, old atlas pixels and save-folder
identity are preserved. Only new atlas rows are appended. Existing natural
Nether terrain can gain the new forests/structures; explicit player block edits
remain authoritative. Back up worlds before testing a major content update.

Brewing inventories, partial batch times/fuel, potion stacks, thrown pearls,
status-effect levels, mob state and fortress loot/spawner initialization save.
Dimension switching keeps brewing stands, pearls, mobs and chests in their realm.
Old saves default new fields safely. Inactive dimensions and unloaded simulation
pause. Pearl cooldown is shared by the player's hands.

Useful testing commands: `/summon enderman`, `/summon blaze`,
`/summon magma_cube`, `/give ender_pearl 16`, `/locate structure fortress`
(in the Nether), and `/spawner blaze` while pointing at a reachable spawner.
The command completion list includes the new entities/structure/spawner kind.

- `data/content.json`: authoritative items/blocks, icons, drops, collisions.
- `data/mobs.json`: new mob stats, aggression/teleport and Blaze attack timings.
- `data/nether.json`: forest enable/spacing and fortress spacing/chance/deck size.
- `data/brewing.json`: potion properties, recipe graph, batch/drink times and fuel.
- `data/projectiles.json`: pearl speed, gravity, cooldown, damage and count cap.
- `data/farming.json`: wart substrate, growth chance and light requirement.
- `data/nether_bridge_loot.json`: fortress loot weights/counts.
- `scripts/mobs/nether_mob_brain.gd`: Enderman and Blaze goals.
- `scripts/world/generation/nether_fortresses.gd`: deterministic 2D structures.
- `scripts/world/brewing_system.gd`, `scripts/ui/brewing_screen.gd`: station/UI.
- `scripts/player/player_pearls.gd`: aimed throwing and safe landing.

## Research

References were read before implementation; numeric rules come from game code
and extracted vanilla data, rather than assumptions from screenshots:

- [Mojang: Meet the Enderman](https://www.minecraft.net/en-us/article/meet-enderman)
  and [official biome descriptions](https://help.minecraft.net/hc/en-us/articles/360046470431-Minecraft-Types-of-Biomes).
- [EnderMan goals and attributes](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/entity/monster/EnderMan.java)
  and [Enderman model](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/client/model/EndermanModel.java).
- [ThrownEnderpearl](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/entity/projectile/ThrownEnderpearl.java): teleport impact, fall reset, five-damage cost and owner-death behavior.
- [Blaze AI](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/entity/monster/Blaze.java)
  and [Blaze model](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/client/model/BlazeModel.java).
- [MagmaCube rules](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/entity/monster/MagmaCube.java),
  [Enderman drops](https://raw.githubusercontent.com/misode/mcmeta/data-json/data/minecraft/loot_table/entities/enderman.json),
  [Blaze drops](https://raw.githubusercontent.com/misode/mcmeta/data-json/data/minecraft/loot_table/entities/blaze.json),
  [Magma Cube drops](https://raw.githubusercontent.com/misode/mcmeta/data-json/data/minecraft/loot_table/entities/magma_cube.json).
- [BrewingStandBlockEntity](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/level/block/entity/BrewingStandBlockEntity.java)
  and [PotionBrewing](https://raw.githubusercontent.com/mahtomedi/minecraft/main/src/main/java/net/minecraft/world/item/alchemy/PotionBrewing.java).
- [Nether-bridge loot data](https://raw.githubusercontent.com/misode/mcmeta/data-json/data/minecraft/loot_table/chests/nether_bridge.json).

## Verification

Godot 4.7.2 tests cover neutral/stared/attacked Endermen, projectile immunity and
safe teleporting; pearl aim/cooldown/independent throws, real wall impact,
teleport damage and fatal impacts; timed brewing, three-bottle batches, fuel,
ingredient cancellation and real GUI transfers; drinking/bottle returns, effect
timing/levels and Fire Resistance; Blaze burst timing; deterministic forest and
fortress resources; non-refilling loot, Blaze spawners and real saved-dimension
reopening with partial brewing progress. Native OpenGL captures check mob rigs,
forest/vine materials, fortress decks and the brewing GUI. Existing gameplay,
UI, crafting, enchantment, mob/combat, farming, smelting, save and culling tests
were also run. The release ZIP is checked again after fresh extraction/import.
