# Content catalog: the Paper Minecraft approach, adapted to Godot

Open `data/content.json`. This is now the single source of truth for block and
item definitions, including tool stats. New content does not need an enum entry,
a second tools database entry, a new per-item script, or a TileSet edited by hand.
Recipes remain in their separate database, as requested earlier.

## Start here: add one record

Append this object to the catalog's `entries` array, with a comma separating it
from the previous object:

```json
{
  "id": 105,
  "key": "dark_oak_planks",
  "name": "Dark Oak Planks",
  "extends": "wood",
  "tile": [29, 19],
  "tint": [0.65, 0.5, 0.4, 1],
  "root": "oak_planks"
}
```

That creates a tinted wood block, using the existing plank texture. It inherits
stack size, solid collision, axe mining, ordinary drops and the block holding
profile. Its crafting root lets it substitute for oak planks in existing recipes.
You do not copy all the default fields. Restart after editing the catalog.

To get it in game, add `{"item":"dark_oak_planks","count":16}` to
`data/starting_inventory.json`, or add a recipe using its key. A definition alone
does not decide how the player obtains it or where terrain should generate it.
Terrain/tree settings still select generation materials by content key.

IDs must be unique positive integers; 0 is always air. Existing IDs 1-12 are
preserved. Never renumber existing entries. Keys are lowercase identifiers such
as `dark_oak_planks`, and are used by recipes, drops, roots and starter supplies.
`BlockDatabase.ID` retains old aliases for compatibility; never extend that enum
when adding content. Runtime systems discover the new record automatically.

## Optional add-content helper

The helper supplies the next stable ID, checks the entire catalog and atlas
bounds, and backs up the previous catalog before saving. In PowerShell, from
the project folder:

```powershell
& 'C:\Program Files\Godot\Godot 4.7.2.exe' --headless --path . --script res://tools/add_content.gd -- --key new_planks --name 'New Planks' --template wood --tile 29,19 --write
```

Omit `--write` for a validated preview. Optional flags: `--id 20`, `--atlas items`.
Use `--help` for the short syntax. Validation failures leave the catalog unchanged.
The backup is `data/content.json.bak`. Stop and restart the game after writing.
The helper adds a definition; edit the resulting record for optional properties,
and add starter supplies or a recipe when you want to obtain the new content.

## What I learned from your list

Your `_BLOCK_DATA.txt` contains **287 records with 20 fields per record**. The
important pattern is that shared game systems interpret record properties.
The same item is not re-registered separately in every subsystem. In particular,
the list separates tile and inventory sprites, uses a crafting/root identity,
and keeps collision, tool requirements, lighting, harvest and durability in data.

We use named JSON fields and templates to express that structure. This keeps the
records readable and lets validation catch a typo before it becomes a gameplay
bug. Paper Minecraft's numeric sprite IDs refer to its own Scratch costumes;
they are not atlas coordinates and were not copied into our game.

| Paper Minecraft field/concept | Our catalog equivalent |
| --- | --- |
| Block ID and name | `id`, stable `key`, display `name` |
| Y / N / P collision | `collision`: `solid`, `none`, `platform` |
| Hardness / unbreakable / instant | Minecraft `hardness`, `diggable`; zero time is instant, false is unbreakable |
| Digging tool and tier | Block `mining` rules; item `tool` stats |
| Light absorption / negative emission | Separate `light.absorption` and `light.emission` |
| Tile group / creative category | Explicit `placement`, `category`, `tags`, `tool` properties |
| Harvest self / other / none / chance | `drops` list with `item`, `count`, `chance`; `[]` means none |
| Tile sprite / inventory sprite | `atlas` + `tile`, optional independent `icon` |
| Item durability | `tool.durability`, inherited from a shared template if desired |
| Root item | `root` key and optional `crafting_group` |
| Activation behavior | Current supported `interaction` actions, such as `crafting_table` |

Liquid flow, falling blocks, leaf decay, furnaces/fuel, combat and redstone do
not exist in this game yet. The attachment's flags for those systems are not
silently presented as working features. Each future behavior needs a shared
runtime system; once implemented, content records can select/configure it.
A summary of the supplied list is kept under `docs/reference/` for comparison.

## Defaults and templates

The catalog has four top-level fields: `version` (currently 1), `defaults`,
`templates`, and `entries`. Each item is compiled in this order:

1. Shared defaults.
2. Its template's parent chain, then the chosen template.
3. Its own record properties.

Nested objects merge by field; arrays replace the inherited array. Thus changing
only `tool.durability` preserves its kind, tier and speed. An empty `drops` array
removes inherited drops; an empty `tags` array removes inherited tags. `null`
replaces an inherited optional object such as `tool` or `icon`.

| Template | What it supplies |
| --- | --- |
| `block` | Solid, placeable block and ordinary defaults |
| `soil` | Grass/dirt-style timing, shovel preference and soil tag |
| `wood` | Wood tag and axe preference |
| `platform` | Pass-through block with an exposed one-way top |
| `platform_wood` | Wood behavior plus that platform collision |
| `plant` | Plant tag, decoration category, quick mining and no collision |
| `workstation` | Pickaxe-mined, one-way workstation; use platform_wood for wooden stations |
| `bed` | Wooden platform, mattress-height top, bed interaction and shared item drop |
| `foliage` | Non-colliding, transparent-to-light decoration with quick mining |
| `ore` | Pickaxe requirement, with a configurable minimum tier |
| `unbreakable` | Block with `diggable:false` |
| `item` | Unplaceable, non-colliding item from the item atlas |
| `wooden_tool` | Unstackable item, 59 uses, tier 0, speed 2, one use per break |
| `wooden_pickaxe`, `wooden_axe`, `wooden_shovel` | Tool kind and appropriate held profile |

Example: another axe needs just a normal identity/icon plus a template:

```json
{
  "id": 14,
  "key": "practice_axe",
  "name": "Practice Axe",
  "extends": "wooden_axe",
  "tile": [82, 6],
  "tool": {"durability": 120, "mining_speed": 4}
}
```

Its tool kind, stack limit, placement restrictions and corrected axe grip are
inherited. No change to `scripts/data/tool_database.gd` is needed. That class is
now a compiled index/helper over catalog records, not another authoring file.

## Common record properties

| Property | Meaning |
| --- | --- |
| `id`, `key`, `name`, `extends` | Stable identity, display name and optional template |
| `atlas`, `tile` | Sprite atlas key and zero-based `[column,row]`; default atlas is `blocks` |
| `icon` | Optional `{ "atlas":"items", "tile":[79,6], "tint":[1,1,1,1] }`; omitted fields inherit the main sprite |
| `tint` | RGBA components from 0 to 1; used by world and, by default, inventory art |
| `collision` | `solid`, `none` or `platform`; the latter has a top only while its cell above is empty |
| `platform_height` | One-way top height from cell bottom, 1–16 pixels; default 16 |
| `placement` | `block`, `attached` or `none`; attached permits wall-backed placement like torches |
| `diggable`, `hardness` | Whether mining can remove it, and Minecraft hardness before mining-speed modifiers |
| `max_stack` | Integer 1-999; tools must use 1; shared default lives here, not in Game Settings |
| `category`, `tags` | String category and string tags, available to registry queries |
| `light` | Absorption 0-16, emission 0-15; independent of walking collision |
| `mining` | Preferred tool, required-tool flag, minimum tier and wrong-tool duration multiplier |
| `tool` | Kind, tier, speed, durability, wear per block; optional on unplaceable items |
| `drops` | List of item-key/count/chance objects; empty list means no drop |
| `root`, `crafting_group` | Crafting equivalence without changing the item's sprite/name/other behavior |
| `interaction` | Empty string, `crafting_table`, `furnace` or `bed` |
| `held` | Profile plus optional size, grip, offset, rotation and reflection overrides |

Placed world sprites currently use the 16x16 `blocks` atlas. Icons can use any
registered atlas. Atlas paths, tile size, margin and separation live in
`data/atlases.json`; the existing layout remains 16-pixel tiles, margin 2, gap 4.
Physical tiles are generated automatically from the records. Different records
can reuse a texture while retaining independent tint and collision properties.

### Mining and tool properties

```json
"mining": {
  "tool": "pickaxe",
  "requires_tool": true,
  "minimum_tier": 0,
  "speed_overrides": {}
},
"tool": {
  "kind": "pickaxe",
  "tier": 0,
  "mining_speed": 2,
  "durability": 59,
  "wear_per_block": 1,
  "attack_damage": 2,
  "attack_speed": 1.2
}
```

These examples describe a block's mining rules and a tool item's stats
respectively; do not put a tool object onto a placeable block. Matching tools
speed mining; required kind/tier controls drops. Existing wooden tools, recipes,
starter supplies and per-instance durability behavior are unchanged.

### Drops

```json
"drops": [
  {"item": "dirt", "count": 1},
  {"item": "stick", "count": 1, "chance": 0.0666666667}
]
```

`self` names the same item. Omitted count/chance mean 1/100%. Each listed drop
rolls independently on a successful, eligible block break. Count is a positive
integer; chance is 0-1. All references, including forward references, are
validated. Drop eligibility still respects tool requirements.

### Crafting roots

`"root":"oak_planks"` means use that item's crafting identity. Its name,
texture, collision and drops remain its own. Existing oak planks use the
`planks` crafting group. Root chains resolve once, and cycles are rejected.
This lets future wood variants share recipes without expanding every pattern.

### Lighting

Absorption 0 transmits light, 1-15 attenuates it, 16 stops transmission while
still allowing a lit surface. Emission is independent. This allows solid glass
and pass-through opaque decorations to have different optical behavior.
Per-block shading and mesh caching remain; this introduces no lighting shader
or per-block scene nodes. Existing materials retain their previous 0/16 values,
so their lighting appearance is unchanged.

### Axe orientation

`wooden_axe` selects `handheld_axe`. That profile reflects the held sprite and
adjusts its sprite axis together, reversing the blade while preserving the shaft
direction and grip. It mirrors correctly when facing left. Inventory icons keep
their original vanilla appearance. Other tools keep their existing profiles.
Future axes can inherit this template/profile without another drawing change.
See `data/held_item_profiles.json` for the underlying render parameters.

## Organization and validation

- `content.json`: canonical block/item definitions, defaults and templates.
- `atlases.json`: shared sprite-sheet metadata.
- `held_item_profiles.json`: reusable hand display transforms.
- `recipes.json`: the separate shaped-recipe database.
- `starting_inventory.json`: finite starter supplies, unchanged.
- `scripts/data/content_catalog.gd`: compile inheritance and validate references/types.
- `scripts/data/block_database.gd`: compiled ID/key/tag/category/drop queries.
- `scripts/data/tool_database.gd`: tool index and mining calculations over that catalog.
- `tools/add_content.gd`: optional validated append helper.

The former `data/blocks.json` and `data/tools.json` are removed from this clean
project. Definitions are loaded at startup; gameplay uses compiled dictionaries
and cached atlas sources, with no per-frame JSON reads. Restart after edits.
Include `*.json` in non-resource export filters when creating an exported build.

Validation catches duplicate identities, unknown fields/references/profiles,
template/root cycles, invalid types/ranges and sprite coordinates outside an
atlas. Errors identify the relevant record/property; startup stops before an
invalid catalog is used. An unknown behavior name is an error, not a silent no-op.

Verified in Godot 4.7.2: actual JSON-only additions for a tool, a platform and an
unbreakable block; tool/drop behavior; root recipes; independent icons; reused
texture with separate physics/tint; attenuation; axe direction/grip; valid helper
save/backup and rejected writes with the original file unchanged. Existing
survival, durability and table-crafting checks pass. GPU world and inventory
captures match the previous version pixel-for-pixel when holding the unchanged
pickaxe. The delivered project is imported and run from a fresh extracted ZIP.

## Per-block simulation and drops

All released block/item packs are now merged into `data/content.json`; there is
no runtime pack merge or ID reassignment. Existing IDs, stable keys and atlas
coordinates are preserved. Runtime `ToolDatabase`/`BlockDatabase` dictionaries
are compiled views of this catalog, not additional editable databases.

Use the entry's `drops` array for mining, decay and support-loss drops.
The optional `updates` object configures behavior: grass spread, falling blocks,
leaf support, attachments and plants. For example, a leaf entry contains:

```json
"drops": [{"item": "stick", "count": 1, "chance": 0.02}],
"updates": {
  "behavior": "leaves",
  "logs": ["oak_log", "birch_log"],
  "leaves": ["oak_leaves", "birch_leaves"],
  "support_distance": 6,
  "self_drop_tool_tags": ["shears", "silk_touch"]
}
```

`recipes.json`, `smelting.json` and `atlases.json` are each the single source for
their respective data. Biome placement and geology remain separate generation
rules; they reference stable content keys and do not define blocks or items.

## Platform and wall rendering rules

Small plants inherit `plant`, which is non-colliding. Cactus explicitly uses
`platform` collision. Furnace and lit furnace inherit `workstation`; crafting
tables retain wooden platform behavior. Workstations, logs and cactus allow
sideways/upward travel and catch falling players on exposed tops. Stacked blocks
expose only the uppermost top; editing the block above refreshes collision.
Grass, flowers, bushes and leaves never catch the player.

Bed rules in `data/beds.json` link two parts for each facing direction. The
`bed` template uses `platform_height: 9` to align collision with the mattress.
Internal head/left part IDs cannot be placed individually; both parts are
removed together, dropping one bed item.

Collision, light absorption and background-wall visibility are independent.
`occludes_background` is a compiled field derived from atlas alpha and tint,
not an editable catalog field. Opaque sprites hide walls; cutouts preserve them.
The atlas is inspected once at startup, and temporary CPU images are released.
Nothing scans image pixels per frame. Plants cannot support attached torches;
workstations, logs and solid blocks can.

Axes and hoes share `handheld_reversed` in `held_item_profiles.json`. It reflects
the sprite and adjusts the sprite axis together, keeping the handle aligned
with the hand while the working edge faces forward. Both player facings use
the same mirrored transform. Icon artwork is unchanged.

See [Mining and tooltips](mining_and_tooltips.md) for exact timing, speed overrides and durability options.

Fluid block and bucket records use this same catalog. Flow rules and settings are documented in [fluids](fluids.md).

The optional waterloggable boolean enables saved water alongside a placed block. Sugar cane growth uses its updates record; see [movement and shores](movement_and_shores.md).

Drop `count` accepts either a positive integer or an inclusive `[minimum,maximum]`
range, for example `{"item":"melon_slice","count":[3,7]}`. These are rolled by
the shared drop function, including normal mining and environmental destruction.

Plant update rules may specify `support_offset: [0,-1]` for a ceiling plant or
`[0,1]` for floor support. With no substrate list these require a full solid
support block at that offset. Offsets must be one cardinal cell. Placement and
subsequent support removal use the same rule; unloaded neighbors are preserved.
Moss carpets, hanging roots and spore blossoms use these records.

Animal breeding data belongs in each species' `data/mobs.json` record; it does
not duplicate the item catalog. New fruits reference crop stages, seeds, valid
soils and the fruit key from `data/farming.json`. Potion duration/amplifier and
recipe branches belong in `data/brewing.json`. These systems share existing
inventory, block edits, lighting, simulation budgets and save validation.
