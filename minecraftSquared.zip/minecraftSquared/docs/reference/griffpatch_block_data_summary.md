# Supplied Paper Minecraft reference

Studied from the user-provided `_BLOCK_DATA.txt`: 287 records, 20 values per record.
This is a summary, not the original Scratch costume/ID registry.

The fields are ID; name; walking collision; hardness; digging tool; liquid height;
flow direction; falling/support rule; light absorption/emission; tile group;
harvest/drop; smelting result; furnace fuel duration; damage; creative category;
tile sprite; inventory sprite; durability; root identity; activation on load.

The supplied wooden axe record (ID 85) uses tile sprite 287 and inventory sprite
85. Other axes also separate those sprites. This informed separate world/icon
art and reusable held orientation in our catalog. Scratch sprite IDs are not
coordinates in the supplied Minecraft atlas.

See ../content_catalog.md for the field mapping, implemented features, and
features whose shared runtime systems still need to be added.
