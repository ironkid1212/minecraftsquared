# Mob fixes, 2D combat and more animals

This update extends [the original mob system](MOBS_COMBAT.md) with pigs, chickens and creepers, and fixes the rendering, collision and targeting problems reported during play.

## Fixes

The supplied zombie texture has a legacy shared-limb layout, even though the image includes a lower half. The previous conversion read empty modern leg/arm regions. Both legs and both arms now contain the correct pixels for each facing direction. The back leg uses exactly the front leg's pivot and lies directly behind it when standing; no artificial sideways offset is used. Walking still swings the two legs in opposite directions.

The player uses a physics layer also used by terrain. Mob bodies were therefore colliding with the player despite not colliding with each other. Each mob now has an explicit collision exception for the player. Animals can walk past or through the player without being blocked, jumping onto the player, or pushing them around. Hostiles still stop to perform their attack behavior; this is AI rather than a solid collision.

The original reach check measured the eye's nearest point on a target rectangle, regardless of the mouse's aiming direction. It now intersects the actual aimed ray with target bounds, checks terrain occlusion and chooses the nearer entity along that ray. Attacks enforce targeting again before applying damage, and sword sweep victims are also kept within reach. Clicking an entity explicitly remains necessary, so a passing animal does not steal ordinary block-mining clicks.

Java's ordinary Survival entity reach is three blocks from the eyes to the hit point. **This game's default is now 2.25 blocks (36 world pixels)** to fit its side-view scale. This is a deliberate 2D gameplay adjustment, not a claim that vanilla uses 2.25. Change `rules.attack_reach` in `data/mobs.json` to tune it; `3.0` restores the vanilla reference distance with the corrected targeting. Sweeps use a smaller 0.75-block neighborhood and cannot reach beyond the main reach limit.

Player damage immunity now permits the extra portion of a stronger hit during the immunity window, matching the already implemented mob behavior. A prior weak hit no longer makes a larger explosion harmless. Respawn protection remains protected. Death poses are lifted enough to avoid rotating their feet below the ground.

## Added mobs

| Mob | Health | Behavior and drops |
| --- | ---: | --- |
| Pig | 10 | Wander and flee; follow carrots, potatoes or beetroot; drop 1–3 porkchops, cooked when burning |
| Chicken | 4 | Follow wheat/beetroot seeds; flutter down without fall damage; lay one egg every 5–10 loaded minutes; drop chicken and 0–2 feathers |
| Creeper | 20 | Follow the player, stop and flash while charging, reverse the fuse when the target retreats or becomes hidden; drop 0–2 gunpowder when killed normally |

Pigs and chickens select warm/temperate/cold art from the supplied texture pack. The cold pig includes its separate inflated coat layer rather than showing only the flat undercoat. Its irregular top edge is the shaggy fur texture; it is cosmetic and does not change the rectangular collider. Chickens use the current texture's narrow shin and separate foot pixels, rather than the empty legacy leg-cube region. Both chicken legs now visibly reach the ground.

Chicken egg timers are saved. Sleeping/unloaded chickens do not advance that timer. Raw porkchops and chicken cook in the existing furnace. Eggs and gunpowder are collectible materials; this update does not add egg projectiles, hatching, saddles/riding, breeding/babies, hunger/eating, charged creepers or sound effects.

All six mobs use the existing shared simulation, saved population and drawing systems. New passive herds are chosen by biome eligibility and catalog weights. Creepers share the existing hostile cap with zombies, with a lower relative spawn weight for 2D. There is no requirement to create a new world; explore regions whose animal population has not already been generated, or use `/summon pig`, `/summon chicken`, and `/summon creeper`. Old herds are not replaced.

## Creepers and explosions

The fuse lasts **1.5 seconds**, the Java reference duration. For this 2D game it begins within **1.75 blocks**, reverses beyond **3 blocks** or behind cover, and uses explosion power **2**. Vanilla reference values are a three-block starting distance, seven-block release distance and power three. The shorter distances and smaller crater make retreat and combat workable in a side-view world. All are catalog properties.

Creepers do not ignite in daylight. A self-exploding creeper disappears without dropping gunpowder. Killing one before detonation uses its normal loot instead. The saved fuse resumes from its stored state on reload, then responds to the current player position/visibility.

Explosions:

- Compute entity exposure against intact terrain before carving. Walls reduce or block damage; player armor still applies. Radial knockback also works in the air.
- Cast a bounded set of 2D blast rays through block resistance. Dirt and weak blocks yield more readily than stone; obsidian and bedrock resist the ordinary creeper blast. Resistance lives in `data/content.json`, alongside the other block properties.
- Break storage through its existing callbacks, releasing tagged contents once. Named container block drops retain their names when their drop survives. A two-part bed produces at most one bed item. Explosion block-drop probability decreases with power; existing dropped items are not destroyed by these blasts.
- Keep background walls, avoid editing unloaded blocks, and respect a per-blast block budget. The explosion effect uses the supplied Minecraft particle textures and has a fixed effect-count limit.

Use `/gamerule mobGriefing false` to prevent mob terrain changes. Explosion damage and knockback remain active, and sheep can regrow wool without removing the grass they graze. `/gamerule mobGriefing true` restores terrain changes. The rule is saved per world; the catalog value sets the default for worlds without a saved value.

## Configuration and compatibility

- `data/mobs.json`: reach/sweep radius, six mob definitions, food temptation, spawn weights, fuse distances/time, explosion power, egg interval, simulation/population budgets and default mob griefing.
- `data/content.json`: appended loot-item IDs and block `blast_resistance`. Existing item/block IDs and original atlas pixels are preserved.
- `data/smelting.json`: pork/chicken cooking results.
- `scripts/mobs/mob_explosions.gd`: bounded blast simulation and one shared explosion renderer.

Old saves load with zero fuse state and a fresh chicken timer where those fields were absent. Existing mob records, tagged inventories and containers remain compatible. Existing player, UI, camera, sun/moon and other `.tres` resource settings are preserved.

## Validation

Godot 4.7.2 checks cover both zombie leg/arm texture banks, chicken shins/feet, cold pig coat pixels, physical passage through the player, aimed-ray reach boundaries and wall/near-entity occlusion, direct-call reach guards, food temptation, egg laying/timer saves, chicken falling, real fuse detonation and defusing, sunlight exclusions, blast cover/damage/resistance, container/NBT and bed-drop conservation, and saved mob-griefing rules. Native render captures were inspected in both directions, standing and walking, including the user's requested shared zombie leg pivot.

Existing checks also pass for the original mobs, natural spawning and caps, a 24-mob/600-physics-tick simulation, mining, equipment/NBT/storage, survival/death, fluids, farming/weather, controls, partial-block traversal, chest/offhand rendering and chunk optimization. No universal FPS claim is made.

## Research references

- [Java aimed entity picking](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/renderer/GameRenderer.java) and [Minecraft Wiki interaction range](https://minecraft.wiki/w/Interaction_range): the ray/hit-point distinction and the ordinary three-block reference. The shorter default here is our 2D adjustment.
- [Pig goals/attributes/food](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/animal/Pig.java), [Chicken attributes, eggs and falling](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/animal/Chicken.java), [Creeper fuse/power](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/monster/Creeper.java), and [SwellGoal](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/ai/goal/SwellGoal.java).
- [Vanilla explosion implementation](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/level/Explosion.java): resistance, visibility/exposure and damage/knockback reference, adapted to bounded 2D rays.
- [LivingEntity damage handling](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/world/entity/LivingEntity.java): stronger-hit difference during immunity.
- [Pig model](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/model/PigModel.java), [quadruped proportions](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/model/QuadrupedModel.java), [chicken model](https://github.com/mahtomedi/minecraft/blob/main/src/main/java/net/minecraft/client/model/ChickenModel.java), and [ColdPigModel source](https://mc-packet-reference.netlify.app/26.x/source/net/minecraft/client/model/animal/pig/coldpigmodel/): the cold pig has a second body cube with an inflated coat, using a separate texture region. Current supplied texture pixels were checked directly because older model layouts do not match every asset.

These source mirrors are version-specific references. This game uses selected Java mechanics and explicitly documented 2D adaptations, rather than implementing all current Minecraft behavior.
